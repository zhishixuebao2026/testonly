import { useState } from "react";
import { MEMBERS, FRAMEWORKS, arcana, type Member } from "../data/analysis";
import { cn } from "../utils/cn";

type Mode = "plain" | "numerals" | "fold" | "story" | "roles";

const MODES: { key: Mode; label: string; hint: string }[] = [
  { key: "plain", label: "原始构图", hint: "四道竖光 + 一组交叉光" },
  { key: "numerals", label: "罗马数字", hint: "I · I · X · I · I → X + II = XII" },
  { key: "fold", label: "折叠数列（模型 A）", hint: "XVI · XIV · XII · X · VIII，镜像对之和 = 24" },
  { key: "story", label: "象征—剧情（模型 B）", hint: "XIV · XV · XII · X · XIII，缺席的 XI 是那把剑" },
  { key: "roles", label: "骑士 / 非骑士", hint: "光对称，人不对称" },
];

const X_POS = [140, 320, 500, 680, 860];
const FLOOR_Y = 470;
const HEAD_Y = 352;

function beamOpacity(m: Member) {
  return m.brightness === "bright" ? 1 : 0.5;
}

export default function StageDiagram() {
  const [mode, setMode] = useState<Mode>("numerals");
  const [flipped, setFlipped] = useState(false);
  const [active, setActive] = useState<Member | null>(null);

  const fwA = FRAMEWORKS.find((f) => f.key === "A")!;
  const fwB = FRAMEWORKS.find((f) => f.key === "B")!;
  const numeralFor = (m: Member) => {
    if (mode === "numerals") return m.beam === "cross" ? "X" : "I";
    if (mode === "fold") return arcana(fwA.assignments.find((a) => a.member === m.id)!.arcanaNum).roman;
    if (mode === "story") return arcana(fwB.assignments.find((a) => a.member === m.id)!.arcanaNum).roman;
    return "";
  };
  const nameFor = (m: Member) => {
    if (mode === "fold") return arcana(fwA.assignments.find((a) => a.member === m.id)!.arcanaNum).cn;
    if (mode === "story") return arcana(fwB.assignments.find((a) => a.member === m.id)!.arcanaNum).cn;
    return "";
  };

  const current = MODES.find((m) => m.key === mode)!;

  return (
    <div className="panel panel-strong rounded-2xl p-4 sm:p-6">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {MODES.map((m) => (
          <button
            key={m.key}
            onClick={() => setMode(m.key)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs sm:text-sm transition-colors",
              mode === m.key
                ? "border-gold bg-gold/15 text-gold-soft"
                : "border-white/10 text-mist hover:border-gold/40 hover:text-parchment",
            )}
          >
            {m.label}
          </button>
        ))}
        <button
          onClick={() => setFlipped((f) => !f)}
          className={cn(
            "ml-auto rounded-full border px-3 py-1.5 text-xs sm:text-sm transition-colors",
            flipped ? "border-sakiko bg-sakiko/15 text-sakiko" : "border-white/10 text-mist hover:border-sakiko/50 hover:text-parchment",
          )}
          title="像倒吊人一样把舞台倒过来看"
        >
          {flipped ? "↺ 复原视角" : "⟲ 倒吊视角（旋转 180°）"}
        </button>
      </div>

      <div className="relative overflow-hidden rounded-xl border border-white/5 bg-abyss">
        <svg
          viewBox="0 0 1000 560"
          className="h-auto w-full transition-transform duration-700 ease-in-out"
          style={{ transform: flipped ? "rotate(180deg)" : "none" }}
          role="img"
          aria-label="Ave Mujica 五人舞台站位与光柱示意图"
        >
          <defs>
            {MEMBERS.map((m) => (
              <linearGradient key={m.id} id={`beam-${m.id}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={m.color} stopOpacity="0.05" />
                <stop offset="60%" stopColor={m.color} stopOpacity="0.45" />
                <stop offset="100%" stopColor={m.color} stopOpacity="0.75" />
              </linearGradient>
            ))}
            <linearGradient id="cross-l" gradientUnits="userSpaceOnUse" x1="120" y1="0" x2="590" y2="470">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.02" />
              <stop offset="55%" stopColor="#e6dcff" stopOpacity="0.55" />
              <stop offset="100%" stopColor="#cdbcff" stopOpacity="0.15" />
            </linearGradient>
            <linearGradient id="cross-r" gradientUnits="userSpaceOnUse" x1="880" y1="0" x2="410" y2="470">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.02" />
              <stop offset="55%" stopColor="#e6dcff" stopOpacity="0.55" />
              <stop offset="100%" stopColor="#cdbcff" stopOpacity="0.15" />
            </linearGradient>
            <radialGradient id="floor" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#3b2f5c" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#0d0b17" stopOpacity="0" />
            </radialGradient>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="6" />
            </filter>
          </defs>

          {/* floor */}
          <ellipse cx="500" cy={FLOOR_Y + 30} rx="520" ry="70" fill="url(#floor)" />
          <line x1="0" y1={FLOOR_Y} x2="1000" y2={FLOOR_Y} stroke="rgba(212,175,55,0.25)" />

          {/* vertical beams */}
          {MEMBERS.filter((m) => m.beam === "vertical").map((m) => {
            const x = X_POS[m.position - 1];
            const bright = m.brightness === "bright";
            return (
              <g key={m.id} className={cn("beam", bright && "beam-bright")}>
                <polygon
                  points={`${x - 14},0 ${x + 14},0 ${x + 62},${FLOOR_Y} ${x - 62},${FLOOR_Y}`}
                  fill={`url(#beam-${m.id})`}
                  opacity={beamOpacity(m)}
                />
                <ellipse cx={x} cy={FLOOR_Y} rx="62" ry="10" fill={m.color} opacity={bright ? 0.5 : 0.3} filter="url(#glow)" />
              </g>
            );
          })}

          {/* crossing beams meeting at Sakiko */}
          <g className="beam beam-bright">
            <line x1="120" y1="0" x2="590" y2={FLOOR_Y} stroke="url(#cross-l)" strokeWidth="30" strokeLinecap="round" />
            <line x1="880" y1="0" x2="410" y2={FLOOR_Y} stroke="url(#cross-r)" strokeWidth="30" strokeLinecap="round" />
            <circle cx="500" cy="380" r="34" fill="#cdbcff" opacity="0.35" filter="url(#glow)" />
          </g>

          {/* figures */}
          {MEMBERS.map((m) => {
            const x = X_POS[m.position - 1];
            const isActive = active?.id === m.id;
            return (
              <g
                key={m.id}
                className="cursor-pointer"
                onMouseEnter={() => setActive(m)}
                onMouseLeave={() => setActive(null)}
                onClick={() => setActive(m)}
              >
                <circle cx={x} cy={HEAD_Y} r="18" fill="#0b0914" stroke={m.color} strokeWidth={isActive ? 3 : 2} />
                <path
                  d={`M${x - 26},${FLOOR_Y} L${x - 22},${HEAD_Y + 30} Q${x},${HEAD_Y + 14} ${x + 22},${HEAD_Y + 30} L${x + 26},${FLOOR_Y} Z`}
                  fill="#0b0914"
                  stroke={m.color}
                  strokeWidth={isActive ? 3 : 2}
                />
                {m.beam === "cross" && (
                  <path d={`M${x + 24},${HEAD_Y + 20} l10,-40 l3,0 l-10,40 z`} fill="#f1d27a" opacity="0.85" />
                )}
                <text x={x} y={FLOOR_Y + 32} textAnchor="middle" fill={m.color} fontSize="20" fontWeight="600" style={{ fontFamily: "var(--font-serif)" }}>
                  {m.name}
                </text>
                <text x={x} y={FLOOR_Y + 56} textAnchor="middle" fill="#9a93a8" fontSize="14" style={{ fontFamily: "var(--font-latin)", fontStyle: "italic" }}>
                  {m.stageName}
                </text>
              </g>
            );
          })}

          {/* overlays */}
          {(mode === "numerals" || mode === "fold" || mode === "story") &&
            MEMBERS.map((m) => {
              const x = X_POS[m.position - 1];
              return (
                <g key={`n-${m.id}`} className="fade-up">
                  <text
                    x={x}
                    y={mode === "numerals" ? 250 : 236}
                    textAnchor="middle"
                    fill={m.beam === "cross" ? "#f1d27a" : m.color}
                    fontSize={mode === "numerals" ? 64 : 44}
                    style={{ fontFamily: "var(--font-display)", letterSpacing: "0.05em" }}
                  >
                    {numeralFor(m)}
                  </text>
                  {nameFor(m) && (
                    <text x={x} y={272} textAnchor="middle" fill="#ece6d9" fontSize="18" style={{ fontFamily: "var(--font-serif)" }}>
                      {nameFor(m)}
                    </text>
                  )}
                </g>
              );
            })}

          {mode === "numerals" && (
            <g className="fade-up">
              <text x="500" y="80" textAnchor="middle" fill="#f1d27a" fontSize="30" style={{ fontFamily: "var(--font-display)" }}>
                X + II = XII
              </text>
              <text x="500" y="112" textAnchor="middle" fill="#9a93a8" fontSize="16" style={{ fontFamily: "var(--font-serif)" }}>
                从祥子向任意一侧读：X · I · I —— 交叉光是 X，两侧竖光把它补成 XII
              </text>
              <path d="M330 300 q170 -60 340 0" fill="none" stroke="#f1d27a" strokeDasharray="4 6" opacity="0.6" />
            </g>
          )}

          {mode === "fold" && (
            <g className="fade-up">
              <path d="M140 300 q360 -170 720 0" fill="none" stroke="#d4af37" strokeDasharray="4 6" opacity="0.7" />
              <path d="M320 300 q180 -100 360 0" fill="none" stroke="#d4af37" strokeDasharray="4 6" opacity="0.7" />
              <text x="500" y="150" textAnchor="middle" fill="#f1d27a" fontSize="22" style={{ fontFamily: "var(--font-display)" }}>
                16 + 8 = 24
              </text>
              <text x="500" y="200" textAnchor="middle" fill="#f1d27a" fontSize="22" style={{ fontFamily: "var(--font-display)" }}>
                14 + 10 = 24
              </text>
              <text x="500" y="60" textAnchor="middle" fill="#9a93a8" fontSize="16" style={{ fontFamily: "var(--font-serif)" }}>
                以 XII 为轴、步长 2：镜像位置两两相加恒为 24（= 2 × 12）
              </text>
            </g>
          )}

          {mode === "story" && (
            <g className="fade-up">
              <text x="500" y="60" textAnchor="middle" fill="#9a93a8" fontSize="16" style={{ fontFamily: "var(--font-serif)" }}>
                X · XII · XIII · XIV · XV —— 10 到 15 的连续段，唯独缺了 XI「正义」：持剑者
              </text>
              <text x="500" y="150" textAnchor="middle" fill="#f1d27a" fontSize="20" style={{ fontFamily: "var(--font-display)" }}>
                XI · Justice → 「ならば剣を手に」
              </text>
              <path d="M140 300 q90 -50 180 0" fill="none" stroke="#5aa9ff" strokeDasharray="4 6" opacity="0.6" />
              <text x="230" y="290" textAnchor="middle" fill="#9a93a8" fontSize="14" style={{ fontFamily: "var(--font-serif)" }}>
                天使 · 恶魔
              </text>
              <path d="M680 300 q90 -50 180 0" fill="none" stroke="#7ee2a8" strokeDasharray="4 6" opacity="0.6" />
              <text x="770" y="290" textAnchor="middle" fill="#9a93a8" fontSize="14" style={{ fontFamily: "var(--font-serif)" }}>
                命运 · 死亡
              </text>
            </g>
          )}

          {mode === "roles" && (
            <g className="fade-up">
              <path d="M90 300 v-14 h280 v14" fill="none" stroke="#5aa9ff" strokeWidth="2" />
              <text x="230" y="270" textAnchor="middle" fill="#5aa9ff" fontSize="20" style={{ fontFamily: "var(--font-serif)" }}>
                受封骑士 · 后来招募 · 无童年羁绊
              </text>
              <path d="M630 300 v-14 h280 v14" fill="none" stroke="#7ee2a8" strokeWidth="2" />
              <text x="770" y="270" textAnchor="middle" fill="#7ee2a8" fontSize="20" style={{ fontFamily: "var(--font-serif)" }}>
                非骑士 · 童年羁绊 · 被拒 / 缺席
              </text>
              <text x="500" y="270" textAnchor="middle" fill="#f1d27a" fontSize="20" style={{ fontFamily: "var(--font-serif)" }}>
                女神 · 持剑
              </text>
              <text x="500" y="60" textAnchor="middle" fill="#9a93a8" fontSize="16" style={{ fontFamily: "var(--font-serif)" }}>
                灯光左右对称，人物关系左右不对称：两套编码叠在同一个构图里
              </text>
            </g>
          )}
        </svg>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-start">
        <div className="text-sm text-mist">
          <span className="text-gold-soft">{current.label}</span>
          <span className="mx-2 text-ash">·</span>
          {current.hint}
          {flipped && <span className="ml-2 text-sakiko">（已倒转：读数不变）</span>}
        </div>
        <div className="text-xs text-ash">悬停 / 点击人物查看其在第 13 话剧中的位置</div>
      </div>

      <div className="mt-3 min-h-[76px] rounded-xl border border-white/5 bg-night/60 p-3 text-sm">
        {active ? (
          <div className="fade-up">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <span className="font-semibold" style={{ color: active.color }}>
                {active.name} / {active.stageName}
              </span>
              <span className="text-mist">{active.lunar}</span>
              <span className="text-mist">· {active.roleInPlay}</span>
              <span className="text-ash">
                · 光柱：{active.beam === "cross" ? "交叉光的交点" : active.brightness === "bright" ? "竖光（较亮）" : "竖光（较暗）"}
              </span>
            </div>
            <p className="mt-1 font-latin text-base italic text-parchment/90">「{active.playQuote}」</p>
          </div>
        ) : (
          <div className="text-ash">从左到右：海铃 · 若麦 · 祥子 · 初华 · 睦。竖光落在四人身上，两道光在祥子处交叉。</div>
        )}
      </div>
    </div>
  );
}
