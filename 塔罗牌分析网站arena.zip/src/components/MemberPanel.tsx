import { useState } from "react";
import { MEMBERS, MEMBER_ANALYSES, arcana, type MemberId } from "../data/analysis";
import TarotCard from "./TarotCard";
import { cn } from "../utils/cn";

const ORDER: MemberId[] = ["mutsumi", "nyamu", "umiri", "sakiko", "uika"];

export default function MemberPanel() {
  const [sel, setSel] = useState<MemberId>("mutsumi");
  const member = MEMBERS.find((m) => m.id === sel)!;
  const analysis = MEMBER_ANALYSES.find((a) => a.id === sel)!;
  const sorted = [...analysis.candidates].sort((a, b) => b.probability - a.probability);

  return (
    <div className="panel rounded-2xl p-4 sm:p-6">
      <div className="mb-5 flex flex-wrap gap-2">
        {ORDER.map((id) => {
          const m = MEMBERS.find((x) => x.id === id)!;
          const on = id === sel;
          return (
            <button
              key={id}
              onClick={() => setSel(id)}
              className={cn(
                "flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm transition-colors",
                on ? "bg-white/5" : "border-white/10 text-mist hover:text-parchment",
              )}
              style={on ? { borderColor: m.color, color: m.color } : undefined}
            >
              <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: m.color }} />
              {m.name}
              <span className="font-latin text-xs italic opacity-70">{m.stageName}</span>
            </button>
          );
        })}
      </div>

      <div key={sel} className="fade-up">
        <div className="mb-5 grid gap-4 lg:grid-cols-[1fr_auto] lg:items-start">
          <div>
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <h3 className="text-2xl font-semibold" style={{ color: member.color }}>
                {member.name}
              </h3>
              <span className="font-latin text-lg italic text-parchment/80">{member.stageName}</span>
              <span className="text-sm text-mist">{member.meaning} · {member.lunar} · {member.instrument}</span>
            </div>
            <div className="mt-1 text-sm text-mist">第 13 话剧中身份：{member.roleInPlay}</div>
            <p className="prose-cn mt-3 leading-relaxed text-parchment/90">{analysis.summary}</p>
          </div>
          <div className="flex gap-3">
            {sorted.slice(0, 2).map((c, i) => (
              <TarotCard
                key={c.arcanaNum}
                num={c.arcanaNum}
                accent={i === 0 ? member.color : "#8a7332"}
                size="md"
                label={i === 0 ? "首选" : "次选"}
              />
            ))}
          </div>
        </div>

        <div className="space-y-3">
          {sorted.map((c) => {
            const a = arcana(c.arcanaNum);
            return (
              <div key={c.arcanaNum} className="rounded-xl border border-white/5 bg-night/60 p-4">
                <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
                  <span className="font-display text-xl text-gold-soft">{a.roman}</span>
                  <span className="text-lg font-semibold">{a.cn}</span>
                  <span className="font-latin italic text-mist">{a.en}</span>
                  {a.wings && <span className="rounded-full border border-gold/30 px-2 py-0.5 text-[11px] text-gold-soft">有翼 · {a.wings}</span>}
                  {c.frameworks.map((f) => (
                    <span
                      key={f}
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[11px]",
                        f === "A" ? "bg-umiri/15 text-umiri" : "bg-mutsumi/15 text-mutsumi",
                      )}
                    >
                      模型 {f}
                    </span>
                  ))}
                  <span className="ml-auto text-sm text-mist">主观概率 {Math.round(c.probability * 100)}%</span>
                </div>
                <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/5">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${c.probability * 100}%`, background: `linear-gradient(90deg, ${member.color}, #d4af37)` }}
                  />
                </div>
                <div className="mt-3 grid gap-3 text-sm md:grid-cols-2">
                  <div>
                    <div className="mb-1 text-xs tracking-widest text-mutsumi">支持</div>
                    <ul className="space-y-1 text-parchment/85">
                      {c.pros.map((p) => (
                        <li key={p} className="flex gap-2">
                          <span className="text-mutsumi">＋</span>
                          <span>{p}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="mb-1 text-xs tracking-widest text-nyamu">反对</div>
                    <ul className="space-y-1 text-parchment/70">
                      {c.cons.map((p) => (
                        <li key={p} className="flex gap-2">
                          <span className="text-nyamu">－</span>
                          <span>{p}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="mt-3 text-xs text-ash">
                  牌面：{a.image} ｜ 正位：{a.upright} ｜ 逆位：{a.reversed}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
