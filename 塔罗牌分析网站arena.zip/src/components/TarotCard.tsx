import { arcana } from "../data/analysis";
import { cn } from "../utils/cn";

interface Props {
  num: number;
  accent?: string;
  size?: "sm" | "md" | "lg";
  reversed?: boolean;
  label?: string;
  className?: string;
}

function Glyph({ num, accent }: { num: number; accent: string }) {
  const stroke = accent;
  const common = { fill: "none", stroke, strokeWidth: 2.2, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (num) {
    case 6: // Lovers
      return (
        <g {...common}>
          <path d="M50 22 l-6 -8 h12 z" />
          <path d="M30 30 q20 -14 40 0" />
          <circle cx="36" cy="52" r="6" />
          <circle cx="64" cy="52" r="6" />
          <path d="M28 82 v-18 q8 -8 16 0 v18" />
          <path d="M56 82 v-18 q8 -8 16 0 v18" />
          <path d="M44 42 q6 -8 12 0" />
        </g>
      );
    case 8: // Strength
      return (
        <g {...common}>
          <path d="M38 22 q6 -8 12 0 q6 8 12 0 q-6 -8 -12 0 q-6 8 -12 0" />
          <circle cx="50" cy="44" r="7" />
          <path d="M40 82 v-22 q10 -8 20 0 v22" />
          <path d="M22 78 q6 -18 22 -14" />
          <path d="M20 72 q-4 -6 2 -10 q6 -2 8 4" />
          <path d="M14 66 q-2 -10 8 -12" />
        </g>
      );
    case 9: // Hermit
      return (
        <g {...common}>
          <path d="M50 22 l14 60 h-28 z" />
          <circle cx="50" cy="30" r="5" />
          <path d="M66 46 v22" />
          <rect x="60" y="66" width="12" height="12" />
          <path d="M66 70 l0 4" />
          <path d="M36 82 h28" />
        </g>
      );
    case 10: // Wheel
      return (
        <g {...common}>
          <circle cx="50" cy="52" r="24" />
          <circle cx="50" cy="52" r="10" />
          <path d="M50 28 v48 M26 52 h48 M33 35 l34 34 M67 35 l-34 34" />
          <path d="M14 22 l6 6 M86 22 l-6 6 M14 84 l6 -6 M86 84 l-6 -6" />
        </g>
      );
    case 11: // Justice
      return (
        <g {...common}>
          <path d="M50 18 v64" />
          <path d="M42 22 h16" />
          <path d="M24 40 h52" />
          <path d="M24 40 l-8 18 h16 z M76 40 l-8 18 h16 z" />
          <path d="M40 82 h20" />
        </g>
      );
    case 12: // Hanged Man
      return (
        <g {...common}>
          <path d="M22 20 h56" />
          <path d="M50 20 v14" />
          <circle cx="50" cy="72" r="7" />
          <path d="M50 34 v30" />
          <path d="M50 44 l-12 10 M50 44 l12 -10" />
          <path d="M50 42 l14 12 M50 42 l-14 -6" />
          <circle cx="50" cy="72" r="12" strokeDasharray="2 4" />
        </g>
      );
    case 13: // Death
      return (
        <g {...common}>
          <path d="M20 78 q10 -10 22 -6 q14 4 22 -8 q6 -10 16 -8" />
          <path d="M46 62 v-26" />
          <circle cx="46" cy="30" r="6" />
          <path d="M46 40 l16 -6 v22" />
          <path d="M62 34 h14 v10 h-14" />
          <path d="M28 66 l-6 14 M72 62 l6 14" />
        </g>
      );
    case 14: // Temperance
      return (
        <g {...common}>
          <circle cx="50" cy="28" r="6" />
          <path d="M50 34 v26" />
          <path d="M40 46 q-14 -10 -24 -22 q6 20 20 26" />
          <path d="M60 46 q14 -10 24 -22 q-6 20 -20 26" />
          <path d="M32 56 h12 v8 q-6 6 -12 0 z M56 60 h12 v8 q-6 6 -12 0 z" />
          <path d="M44 60 q6 4 12 0" strokeDasharray="1.5 3" />
          <path d="M18 82 h64" />
          <path d="M18 78 q10 -6 22 0" />
        </g>
      );
    case 15: // Devil
      return (
        <g {...common}>
          <circle cx="50" cy="34" r="8" />
          <path d="M42 28 l-6 -10 M58 28 l6 -10" />
          <path d="M40 44 q-18 -4 -26 8 q10 -2 18 6 M60 44 q18 -4 26 8 q-10 -2 -18 6" />
          <path d="M50 42 v22" />
          <path d="M30 80 v-12 M70 80 v-12" />
          <path d="M30 70 q20 -4 40 0" />
          <path d="M50 30 l3 6 h-6 z" />
        </g>
      );
    case 16: // Tower
      return (
        <g {...common}>
          <path d="M38 82 v-44 h24 v44" />
          <path d="M34 38 h32 M40 32 h20" />
          <path d="M60 14 l-8 10 h10 l-10 12" />
          <path d="M28 60 l-6 14 M72 60 l6 14" />
          <path d="M44 50 h12 M44 62 h12" />
        </g>
      );
    case 18: // Moon
      return (
        <g {...common}>
          <path d="M58 22 a16 16 0 1 0 0 30 a12 12 0 1 1 0 -30" />
          <path d="M18 80 v-26 h10 v26 M72 80 v-26 h10 v26" />
          <path d="M28 72 q22 -10 44 0" />
          <path d="M36 66 l4 -6 l4 6 M56 66 l4 -6 l4 6" />
        </g>
      );
    default:
      return (
        <g {...common}>
          <path d="M50 22 l8 20 l22 2 l-17 14 l6 22 l-19 -12 l-19 12 l6 -22 l-17 -14 l22 -2 z" />
        </g>
      );
  }
}

export default function TarotCard({ num, accent = "#d4af37", size = "md", reversed = false, label, className }: Props) {
  const a = arcana(num);
  const dims = size === "lg" ? "w-44 h-72" : size === "sm" ? "w-24 h-40" : "w-32 h-52";
  const numeralSize = size === "lg" ? "text-2xl" : size === "sm" ? "text-sm" : "text-lg";
  const nameSize = size === "lg" ? "text-base" : size === "sm" ? "text-[10px]" : "text-xs";
  return (
    <div className={cn("flex flex-col items-center gap-2", className)}>
      <div
        className={cn(
          "card-shine relative rounded-xl border-2 p-[6px] transition-transform duration-500",
          dims,
          reversed && "rotate-180",
        )}
        style={{
          borderColor: accent,
          background: `radial-gradient(120% 80% at 50% 0%, ${accent}22, transparent 60%), linear-gradient(180deg, #17132a, #0b0914)`,
          boxShadow: `0 0 30px -10px ${accent}88, inset 0 0 20px -12px ${accent}66`,
        }}
      >
        <div className="flex h-full w-full flex-col rounded-lg border border-white/10 px-2 py-2">
          <div className={cn("font-display text-center tracking-[0.2em]", numeralSize)} style={{ color: accent }}>
            {a.roman}
          </div>
          <div className="flex flex-1 items-center justify-center">
            <svg viewBox="0 0 100 100" className="h-[70%] w-[80%]">
              <Glyph num={num} accent={accent} />
            </svg>
          </div>
          <div className={cn("text-center leading-tight", nameSize)}>
            <div className="font-semibold text-parchment">{a.cn}</div>
            <div className="font-latin italic text-mist">{a.en}</div>
          </div>
        </div>
      </div>
      {label && <div className="text-xs text-mist">{label}</div>}
    </div>
  );
}
