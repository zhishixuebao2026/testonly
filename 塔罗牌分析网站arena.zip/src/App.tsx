import StageDiagram from "./components/StageDiagram";
import MemberPanel from "./components/MemberPanel";
import TarotCard from "./components/TarotCard";
import {
  ANCHORS,
  CHECKLIST,
  FINAL_TABLE,
  FRAMEWORKS,
  MEMBERS,
  QA_LIST,
  READINGS,
  SOURCES,
  arcana,
  memberById,
} from "./data/analysis";
import { cn } from "./utils/cn";

const NAV = [
  { id: "verdict", label: "结论" },
  { id: "stage", label: "舞台光柱" },
  { id: "anchors", label: "两个锚点" },
  { id: "frameworks", label: "两套模型" },
  { id: "members", label: "逐人推导" },
  { id: "qa", label: "你的假说" },
  { id: "verify", label: "可证伪点" },
];

function SectionTitle({ kicker, title, sub }: { kicker: string; title: string; sub?: string }) {
  return (
    <div className="mb-8">
      <div className="font-display text-xs tracking-[0.35em] text-gold">{kicker}</div>
      <h2 className="mt-2 text-3xl font-semibold text-parchment sm:text-4xl">{title}</h2>
      {sub && <p className="mt-3 max-w-3xl leading-relaxed text-mist">{sub}</p>}
      <div className="gold-line mt-6" />
    </div>
  );
}

export default function App() {
  const fwA = FRAMEWORKS.find((f) => f.key === "A")!;
  const fwB = FRAMEWORKS.find((f) => f.key === "B")!;

  return (
    <div className="relative min-h-screen">
      <div className="star-field" />

      <header className="sticky top-0 z-30 border-b border-white/5 bg-abyss/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          <a href="#top" className="font-display text-sm tracking-[0.3em] text-gold-soft">
            ARCANA MUJICA
          </a>
          <nav className="hidden gap-5 text-sm text-mist md:flex">
            {NAV.map((n) => (
              <a key={n.id} href={`#${n.id}`} className="transition-colors hover:text-gold-soft">
                {n.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main id="top" className="relative z-10 mx-auto max-w-6xl px-4 pb-24">
        {/* Hero */}
        <section className="pt-16 pb-14 text-center sm:pt-24">
          <div className="font-display text-xs tracking-[0.4em] text-gold">BANG DREAM! AVE MUJICA · 非官方推理</div>
          <h1 className="mt-5 text-4xl font-bold leading-tight sm:text-6xl">
            <span className="gold-text">光柱、骑士与二十二张牌</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-mist">
            已知丰川祥子是 <span className="font-display text-gold-soft">XII</span> 倒吊人、三角初华是{" "}
            <span className="font-display text-gold-soft">X</span> 命运之轮。
            从舞台上的四道竖光与一组交叉光、第 13 话假面舞会的册封仪式、以及两首带罗马数字的歌出发，
            推导八幡海铃、祐天寺若麦、若叶睦各自对应的大阿卡纳。
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            {MEMBERS.map((m) => (
              <div key={m.id} className="flex items-center gap-2 rounded-full border border-white/10 px-3 py-1.5 text-sm">
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: m.color }} />
                <span>{m.name}</span>
                <span className="font-latin italic text-mist">{m.stageName}</span>
              </div>
            ))}
          </div>
          <div className="mx-auto mt-8 max-w-2xl rounded-xl border border-gold/20 bg-gold/5 px-4 py-3 text-xs leading-relaxed text-mist">
            所有内容基于 TV 动画、公开歌词、官方商品页与社区速记；官方从未公布五人的完整塔罗对应。本文给出的是有证据链的推理与主观概率，不是结论性设定。
          </div>
        </section>

        {/* Verdict */}
        <section id="verdict" className="scroll-mt-24 py-12">
          <SectionTitle
            kicker="VERDICT"
            title="结论速览"
            sub="两个锚点不变。对其余三人，我给出「首选」与「次选」：首选来自象征—剧情模型（B），次选来自你提出的折叠等差模型（A）。整体上我认为 B 约 55%、A 约 30%、其它组合约 15%。"
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {FINAL_TABLE.map((row) => {
              const m = memberById(row.member);
              return (
                <div key={row.member} className="panel flex flex-col items-center rounded-2xl p-4 text-center">
                  <div className="text-sm font-semibold" style={{ color: m.color }}>
                    {m.name}
                  </div>
                  <div className="font-latin text-xs italic text-mist">{m.stageName}</div>
                  <div className="mt-3">
                    <TarotCard num={row.primary} accent={m.color} size="md" />
                  </div>
                  <div className="mt-3 text-xs text-mist">
                    次选：
                    <span className="font-display text-gold-soft"> {arcana(row.secondary).roman} </span>
                    {arcana(row.secondary).cn}
                  </div>
                  <div className="mt-1 text-xs text-ash">置信：{row.confidence}</div>
                  <div className="mt-2 text-xs leading-relaxed text-parchment/70">{row.note}</div>
                </div>
              );
            })}
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <div className="panel rounded-2xl p-5">
              <div className="font-display text-xs tracking-[0.3em] text-gold">01</div>
              <div className="mt-2 font-semibold">灯光本身就把 XII 写在祥子头顶</div>
              <p className="mt-2 text-sm leading-relaxed text-mist">
                四道竖光是四个 I，交叉光是 X。从祥子向任一侧读都是 X·I·I = XII。你问的「X 代表 10」——它既是初华的 10，也是祥子 XII 里的那个 X。
              </p>
            </div>
            <div className="panel rounded-2xl p-5">
              <div className="font-display text-xs tracking-[0.3em] text-gold">02</div>
              <div className="mt-2 font-semibold">折叠数列成立，但来源可疑</div>
              <p className="mt-2 text-sm leading-relaxed text-mist">
                XVI·XIV·XII·X·VIII 零自由参数，镜像对之和恒为 24，按逆位读也贴合。可 Ⅹ 与 Ⅻ 之差为 2 很可能只是「第十二使徒 / 十字架」数字学的副产品。
              </p>
            </div>
            <div className="panel rounded-2xl p-5">
              <div className="font-display text-xs tracking-[0.3em] text-gold">03</div>
              <div className="mt-2 font-semibold">海铃的翅膀找得到：节制</div>
              <p className="mt-2 text-sm leading-relaxed text-mist">
                有翼的大阿卡纳只有六张。排除后剩节制：一足在水一足在岸、两杯间倒水的守护天使——第 13 话她说「ここにいれば恐ろしいことはない、この私が約束しよう」。
              </p>
            </div>
          </div>
        </section>

        {/* Stage */}
        <section id="stage" className="scroll-mt-24 py-12">
          <SectionTitle
            kicker="STAGE LIGHTS"
            title="舞台光柱能读出什么"
            sub="从左到右：海铃 · 若麦 · 祥子 · 初华 · 睦。竖光落在祥子以外的四人身上，两道光在祥子处交叉。切换叠加层查看不同读法，或者像倒吊人一样把整个舞台倒过来。"
          />
          <StageDiagram />
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {READINGS.map((r, i) => (
              <div key={r.id} className={cn("panel rounded-2xl p-5", i === READINGS.length - 1 && "md:col-span-2")}>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <h3 className="text-lg font-semibold">{r.title}</h3>
                  <span className="font-display text-sm tracking-widest text-gold-soft">{r.formula}</span>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-parchment/85">{r.body}</p>
                <p className="mt-3 border-l-2 border-gold/50 pl-3 text-sm text-mist">{r.verdict}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Anchors */}
        <section id="anchors" className="scroll-mt-24 py-12">
          <SectionTitle
            kicker="ANCHORS"
            title="两个锚点为什么站得住"
            sub="推其余三人之前，先弄清已知两张牌是「怎么来的」——这决定了推导方法。结论：它们不是名字直译，而是剧情功能。"
          />
          <div className="grid gap-6 lg:grid-cols-2">
            {ANCHORS.map((an) => {
              const m = memberById(an.member);
              const a = arcana(an.arcanaNum);
              return (
                <div key={an.member} className="panel panel-strong rounded-2xl p-5 sm:p-6">
                  <div className="flex flex-col gap-5 sm:flex-row">
                    <TarotCard num={an.arcanaNum} accent={m.color} size="lg" />
                    <div className="flex-1">
                      <div className="text-xs tracking-widest text-gold">{an.confidence}</div>
                      <h3 className="mt-1 text-2xl font-semibold" style={{ color: m.color }}>
                        {m.name} <span className="font-latin text-lg italic text-parchment/70">{m.stageName}</span>
                      </h3>
                      <div className="font-display text-sm text-gold-soft">
                        {a.roman} · {a.cn} · {a.en}
                      </div>
                      <p className="mt-3 text-sm leading-relaxed text-parchment/90">{an.thesis}</p>
                    </div>
                  </div>
                  <ol className="mt-5 space-y-3">
                    {an.evidence.map((e, i) => (
                      <li key={e.title} className="rounded-xl border border-white/5 bg-night/60 p-4">
                        <div className="flex items-baseline gap-2">
                          <span className="font-display text-gold">{String(i + 1).padStart(2, "0")}</span>
                          <span className="font-semibold">{e.title}</span>
                        </div>
                        <p className="mt-1 text-sm leading-relaxed text-parchment/80">{e.detail}</p>
                        {e.source && <div className="mt-1 text-xs text-ash">来源：{e.source}</div>}
                      </li>
                    ))}
                  </ol>
                </div>
              );
            })}
          </div>
        </section>

        {/* Frameworks */}
        <section id="frameworks" className="scroll-mt-24 py-12">
          <SectionTitle
            kicker="TWO MODELS"
            title="两套推导模型的正面对撞"
            sub="模型 A 是你提出的几何假说（以祥子为轴、步长 2）；模型 B 沿用锚点的命名逻辑（剧情功能优先）。两者在 XIV 节制这张牌上直接冲突——它到底属于若麦还是海铃，是整个问题的胜负手。"
          />
          <div className="grid gap-6 lg:grid-cols-2">
            {[fwA, fwB].map((fw) => (
              <div key={fw.key} className={cn("panel rounded-2xl p-5 sm:p-6", fw.key === "B" && "panel-strong")}>
                <div className="flex items-baseline justify-between gap-3">
                  <div>
                    <div className="font-display text-xs tracking-[0.3em] text-gold">MODEL {fw.key}</div>
                    <h3 className="mt-1 text-2xl font-semibold">{fw.name}</h3>
                    <div className="text-sm text-mist">{fw.subtitle}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-display text-3xl text-gold-soft">{Math.round(fw.prior * 100)}%</div>
                    <div className="text-[11px] text-ash">主观先验</div>
                  </div>
                </div>

                <div className="mt-5 flex flex-wrap justify-center gap-2 sm:justify-between">
                  {fw.assignments.map((as) => {
                    const m = memberById(as.member);
                    return (
                      <TarotCard key={as.member} num={as.arcanaNum} accent={m.color} size="sm" label={m.short} />
                    );
                  })}
                </div>

                <div className="mt-5 flex items-center justify-center gap-2 font-display text-sm tracking-[0.25em] text-gold-soft">
                  {fw.assignments.map((as, i) => (
                    <span key={as.member} className="flex items-center gap-2">
                      {arcana(as.arcanaNum).roman}
                      {i < fw.assignments.length - 1 && <span className="text-ash">·</span>}
                    </span>
                  ))}
                </div>

                <p className="mt-5 text-sm leading-relaxed text-parchment/85">{fw.premise}</p>

                <div className="mt-5 grid gap-4">
                  <div>
                    <div className="mb-2 text-xs tracking-widest text-mutsumi">支持它的理由</div>
                    <ul className="space-y-2 text-sm text-parchment/85">
                      {fw.strengths.map((s) => (
                        <li key={s} className="flex gap-2">
                          <span className="text-mutsumi">＋</span>
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="mb-2 text-xs tracking-widest text-nyamu">反对它的理由</div>
                    <ul className="space-y-2 text-sm text-parchment/70">
                      {fw.weaknesses.map((s) => (
                        <li key={s} className="flex gap-2">
                          <span className="text-nyamu">－</span>
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="panel mt-6 rounded-2xl p-5 sm:p-6">
            <h3 className="text-lg font-semibold">为什么最终偏向 B</h3>
            <div className="prose-cn mt-3 text-sm leading-relaxed text-parchment/85">
              <p>
                第一，方法一致性。已确证的两张牌都来自剧情功能——「自缚献祭的神」与「周而复始的回归者」，而不是来自站位算术。用同一种方法推其余三人，得到的是死神、恶魔、节制。
              </p>
              <p>
                第二，制作组不会浪费死神。Mortis 这个名字、第 13 话「死の騎士モーティス」的称呼、以及死神牌本身就是大阿卡纳里唯一披甲骑马的骑士——三条线都指向 XIII。模型 A 却要把它留空。
              </p>
              <p>
                第三，A 的地基有裂缝。Ⅹ 与 Ⅻ 之差为 2 更像作词者「第十二使徒犹大 / 十字架与死亡之吻」的数字学副产品，塔罗是叠在上面的第二层；站位是否按数列排，缺乏独立证据。
              </p>
              <p>
                但 A 不该被丢掉：它零自由参数、与亮度分层一致、按逆位读通篇自洽——「五张全逆位」与倒吊人「倒着看世界」是同一件事。所以它是次选，而不是错误。
              </p>
            </div>
          </div>
        </section>

        {/* Members */}
        <section id="members" className="scroll-mt-24 py-12">
          <SectionTitle
            kicker="MEMBER BY MEMBER"
            title="逐人推导与候选牌"
            sub="每个人列出全部有竞争力的候选牌、支持与反对证据，以及我的主观概率。概率是对「若官方存在完整对应，会是这张」的估计，而非牌义契合度评分。"
          />
          <MemberPanel />
        </section>

        {/* QA */}
        <section id="qa" className="scroll-mt-24 py-12">
          <SectionTitle
            kicker="YOUR HYPOTHESES"
            title="逐条回应你的猜想"
            sub="你的每一条直觉都有对应的答案：有的成立，有的成立但推不到你想要的结论，有的需要修正数字本身。"
          />
          <div className="space-y-3">
            {QA_LIST.map((item) => (
              <details key={item.q} className="panel group rounded-2xl p-5 open:panel-strong">
                <summary className="flex cursor-pointer list-none items-center gap-3">
                  <span
                    className={cn(
                      "shrink-0 rounded-full border px-2 py-0.5 text-[11px]",
                      item.tag === "支持" && "border-mutsumi/50 text-mutsumi",
                      item.tag === "部分支持" && "border-uika/50 text-uika",
                      item.tag === "修正" && "border-nyamu/50 text-nyamu",
                    )}
                  >
                    {item.tag}
                  </span>
                  <span className="font-semibold">{item.q}</span>
                  <span className="ml-auto text-ash transition-transform group-open:rotate-45">＋</span>
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-parchment/85">{item.a}</p>
              </details>
            ))}
          </div>
        </section>

        {/* Verify */}
        <section id="verify" className="scroll-mt-24 py-12">
          <SectionTitle
            kicker="FALSIFIABILITY"
            title="能一锤定音的地方"
            sub="推理的价值在于可被推翻。以下是最可能藏着官方答案、而本次未能取得清晰材料的地方。"
          />
          <div className="grid gap-4 md:grid-cols-2">
            {CHECKLIST.map((c, i) => (
              <div key={c.title} className="panel rounded-2xl p-5">
                <div className="flex items-baseline gap-3">
                  <span className="font-display text-gold">{String(i + 1).padStart(2, "0")}</span>
                  <div className="font-semibold">{c.title}</div>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-mist">{c.why}</p>
              </div>
            ))}
          </div>

          <div className="panel mt-6 rounded-2xl p-5 sm:p-6">
            <h3 className="text-lg font-semibold">如果这些材料给出的答案是……</h3>
            <div className="mt-3 grid gap-3 text-sm md:grid-cols-3">
              <div className="rounded-xl border border-white/5 bg-night/60 p-4">
                <div className="font-display text-gold-soft">XIII · XV · XIV</div>
                <p className="mt-1 text-mist">象征—剧情模型成立；「缺席的 XI 是那把剑」值得作为正式解读。</p>
              </div>
              <div className="rounded-xl border border-white/5 bg-night/60 p-4">
                <div className="font-display text-gold-soft">VIII · XIV · XVI</div>
                <p className="mt-1 text-mist">你的折叠数列是对的，而且意味着制作组按「全逆位」设计——舞台是倒过来看的。</p>
              </div>
              <div className="rounded-xl border border-white/5 bg-night/60 p-4">
                <div className="font-display text-gold-soft">其它</div>
                <p className="mt-1 text-mist">优先回看：翅膀是否给了海铃、若麦是否落在「爱的反面」、睦是否离 XII 最近。这三条是本文的核心预测。</p>
              </div>
            </div>
          </div>

          <div className="mt-10">
            <div className="font-display text-xs tracking-[0.3em] text-gold">SOURCES</div>
            <ul className="mt-3 grid gap-2 text-sm md:grid-cols-2">
              {SOURCES.map((s) => (
                <li key={s.url} className="rounded-lg border border-white/5 bg-night/50 px-3 py-2">
                  <a href={s.url} target="_blank" rel="noreferrer" className="text-parchment underline decoration-gold/40 underline-offset-4 hover:text-gold-soft">
                    {s.label}
                  </a>
                  <div className="text-xs text-ash">{s.note}</div>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-white/5 py-8 text-center text-xs text-ash">
        <div className="ornament font-display tracking-[0.3em] text-gold-dim">AVE MUJICA · ARCANA</div>
        <p className="mx-auto mt-3 max-w-2xl px-4 leading-relaxed">
          非官方推理整理。作品、角色、歌词及相关版权归 BanG Dream! Project、Bushiroad 及各权利方所有。塔罗牌义以韦特体系为准（VIII 力量 / XI 正义）。
        </p>
      </footer>
    </div>
  );
}
