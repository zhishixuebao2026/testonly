export type MemberId = "umiri" | "nyamu" | "sakiko" | "uika" | "mutsumi";

export interface Member {
  id: MemberId;
  name: string;
  stageName: string;
  meaning: string;
  lunar: string;
  instrument: string;
  color: string;
  position: number; // 1..5 from left
  beam: "vertical" | "cross";
  brightness: "bright" | "dim" | "axis";
  roleInPlay: string;
  playQuote: string;
  short: string;
}

export const MEMBERS: Member[] = [
  {
    id: "umiri",
    name: "八幡海铃",
    stageName: "Timoris",
    meaning: "恐惧",
    lunar: "Lacus Timoris · 恐惧湖",
    instrument: "Ba.",
    color: "#5aa9ff",
    position: 1,
    beam: "vertical",
    brightness: "dim",
    roleInPlay: "恐れの騎士 · 受封骑士",
    playQuote: "心配しなくていい。ここにいれば恐ろしいことはない、この私が約束しよう。",
    short: "海铃",
  },
  {
    id: "nyamu",
    name: "祐天寺若麦",
    stageName: "Amoris",
    meaning: "爱",
    lunar: "Sinus Amoris · 爱湾",
    instrument: "Dr.",
    color: "#ff7ad9",
    position: 2,
    beam: "vertical",
    brightness: "bright",
    roleInPlay: "愛の騎士 · 受封骑士",
    playQuote: "なんで、なんであいつには……うらやみ憎んでしまうほどの愛なんて、忘れさせてくれよ。",
    short: "若麦",
  },
  {
    id: "sakiko",
    name: "丰川祥子",
    stageName: "Oblivionis",
    meaning: "忘却",
    lunar: "Lacus Oblivionis · 忘却湖",
    instrument: "Key.",
    color: "#cdbcff",
    position: 3,
    beam: "cross",
    brightness: "axis",
    roleInPlay: "忘却の女神 · 持剑者",
    playQuote: "皆が忘れようとも、忘却の神たる私だけは忘れない。世界が終焉を迎えるその時まで、この黄昏の楽園に私は君臨し続ける。",
    short: "祥子",
  },
  {
    id: "uika",
    name: "三角初华",
    stageName: "Doloris",
    meaning: "悲伤",
    lunar: "Lacus Doloris · 悲伤湖",
    instrument: "Gt. & Vo.",
    color: "#ffd166",
    position: 4,
    beam: "vertical",
    brightness: "bright",
    roleInPlay: "悲しみの騎士 · 被拒绝册封",
    playQuote: "あなたを忘れる。それで側にいられるなら、すべて忘れます。",
    short: "初华",
  },
  {
    id: "mutsumi",
    name: "若叶睦",
    stageName: "Mortis",
    meaning: "死亡",
    lunar: "Lacus Mortis · 死湖",
    instrument: "Gt.",
    color: "#7ee2a8",
    position: 5,
    beam: "vertical",
    brightness: "dim",
    roleInPlay: "死の騎士 · 未参与册封",
    playQuote: "聞いてる。世界が壊れる音。",
    short: "睦",
  },
];

export const memberById = (id: MemberId) => MEMBERS.find((m) => m.id === id)!;

export interface Arcana {
  num: number;
  roman: string;
  cn: string;
  en: string;
  upright: string;
  reversed: string;
  wings?: string;
  image: string;
}

export const ARCANA: Arcana[] = [
  { num: 0, roman: "0", cn: "愚者", en: "The Fool", upright: "自由、开始、可能性", reversed: "鲁莽、轻率", image: "悬崖边的旅人与小狗" },
  { num: 1, roman: "I", cn: "魔术师", en: "The Magician", upright: "意志、技艺、创造", reversed: "欺瞒、才能的浪费", image: "举杖者与∞" },
  { num: 2, roman: "II", cn: "女祭司", en: "The High Priestess", upright: "直觉、秘密、内省", reversed: "隐瞒、压抑", image: "两柱之间持卷者" },
  { num: 3, roman: "III", cn: "女皇", en: "The Empress", upright: "丰饶、母性", reversed: "依赖、支配", image: "麦田中的王座" },
  { num: 4, roman: "IV", cn: "皇帝", en: "The Emperor", upright: "权威、秩序", reversed: "独裁、僵硬", image: "石座上的君主" },
  { num: 5, roman: "V", cn: "教皇", en: "The Hierophant", upright: "传统、教导、信仰", reversed: "束缚、反叛", image: "两名信徒前的教皇" },
  { num: 6, roman: "VI", cn: "恋人", en: "The Lovers", upright: "爱、选择、结合", reversed: "失和、诱惑", image: "天使拉斐尔下的男女", wings: "天使拉斐尔" },
  { num: 7, roman: "VII", cn: "战车", en: "The Chariot", upright: "胜利、意志", reversed: "失控、挫折", image: "双狮身人面兽拉的战车" },
  { num: 8, roman: "VIII", cn: "力量", en: "Strength", upright: "内在之力、忍耐、温柔的驯服", reversed: "软弱、恐惧、失控、力量过剩", image: "少女合上狮子的口，头顶∞" },
  { num: 9, roman: "IX", cn: "隐者", en: "The Hermit", upright: "独处、观察、探求", reversed: "孤立、封闭", image: "雪山上提灯的老者" },
  { num: 10, roman: "X", cn: "命运之轮", en: "Wheel of Fortune", upright: "转机、循环、命运的流转", reversed: "被外因摆布、抗拒改变、停滞", image: "巨轮与四角的有翼四活物", wings: "四角的有翼四活物" },
  { num: 11, roman: "XI", cn: "正义", en: "Justice", upright: "裁决、公正、因果", reversed: "不公、失衡", image: "持剑与天平的裁判者" },
  { num: 12, roman: "XII", cn: "倒吊人", en: "The Hanged Man", upright: "悬置、自我牺牲、视角反转、试炼", reversed: "无意义的牺牲、过度自我牺牲、停滞", image: "倒悬于活树上、头有光轮的人" },
  { num: 13, roman: "XIII", cn: "死神", en: "Death", upright: "终结、变容、再生", reversed: "执着、抗拒变化、不完全的终结", image: "白马上的骸骨骑士与旗" },
  { num: 14, roman: "XIV", cn: "节制", en: "Temperance", upright: "调和、克制、中介、耐心", reversed: "过度、失衡、焦躁、极端", image: "两杯间倒水的有翼天使，一足在水一足在岸", wings: "大天使米迦勒" },
  { num: 15, roman: "XV", cn: "恶魔", en: "The Devil", upright: "束缚、执着、欲望、诱惑", reversed: "解放、自我认知", image: "巴风特与被锁的男女（恋人牌的黑暗镜像）", wings: "蝙蝠翼" },
  { num: 16, roman: "XVI", cn: "塔", en: "The Tower", upright: "崩塌、剧变、启示", reversed: "规避崩塌、推迟改变、内在崩塌", image: "被雷击中的塔与坠落的两人" },
  { num: 17, roman: "XVII", cn: "星星", en: "The Star", upright: "希望、疗愈", reversed: "失望、幻灭", image: "星下汲水的女子" },
  { num: 18, roman: "XVIII", cn: "月亮", en: "The Moon", upright: "不安、幻觉、恐惧、隐藏的真相", reversed: "恐惧消解、真相揭露", image: "犬与狼向月而吠，两塔之间的小径" },
  { num: 19, roman: "XIX", cn: "太阳", en: "The Sun", upright: "成功、喜悦", reversed: "过度自信", image: "向日葵墙前骑马的孩童" },
  { num: 20, roman: "XX", cn: "审判", en: "Judgement", upright: "复活、觉醒", reversed: "悔恨、自我否定", image: "吹号的天使与复生者", wings: "天使加百列" },
  { num: 21, roman: "XXI", cn: "世界", en: "The World", upright: "完成、统合", reversed: "未完成", image: "花环中的舞者与四活物", wings: "四角的四活物" },
];

export const arcana = (num: number) => ARCANA[num];

/* ---------------- Anchors ---------------- */

export interface Evidence {
  title: string;
  detail: string;
  source?: string;
}

export interface Anchor {
  member: MemberId;
  arcanaNum: number;
  confidence: string;
  thesis: string;
  evidence: Evidence[];
}

export const ANCHORS: Anchor[] = [
  {
    member: "sakiko",
    arcanaNum: 12,
    confidence: "锚点（题设 · 证据充分）",
    thesis:
      "被悬置的、以自我牺牲换取「神」之位置的人。Imprisoned Ⅻ 把数字直接写进了曲名，OP 用倒吊剪影把画面钉死，第 13 话再用「诸神的命运」把倒吊人的奥丁原型补齐。",
    evidence: [
      {
        title: "《Imprisoned Ⅻ》— 第 10 话插入曲 / 2025-03-07 MV",
        detail:
          "曲名中的 Ⅻ 即大阿卡纳 12 号。MV 从祥子在棺中醒来开始：鸟笼、螺旋阶梯、初华递来的手帕被无视。作词者本人说明此曲概念是「用干净旋律唱初华肮脏的欲望」，但被困在画面中心的是祥子——「监禁者与被监禁者互为一体」。",
        source: "anichoice · pixiv 百科「Imprisoned_XII」",
      },
      {
        title: "OP《KiLLKiSS》— 倒吊的成员剪影与小阿卡纳意象",
        detail:
          "OP 开头是纸牌式插画与倒吊的成员剪影，之后依次出现红液溢出的杯（圣杯五）、插在地上的五把剑（宝剑五）、并排的两只杯（圣杯二）。制作组明确在用塔罗语汇讲故事，倒吊人是其中最先出现的大阿卡纳。",
        source: "note「KiLLKiSS」映像考察",
      },
      {
        title: "第 13 话 · 开演前读的书《神々の運命》",
        detail:
          "「诸神的命运」= 诸神黄昏（Ragnarök）。韦特体系里倒吊人最常见的原型就是把自己吊在世界树上九夜、以牺牲换取卢恩智慧的奥丁——一个「自缚的神」。而祥子的舞台台词是「やがて世界が終焉を迎えるその時まで、この黄昏の楽園に私は君臨し続ける」：黄昏、终焉、神，三个词全部对位。",
        source: "note 第 13 话感想（现场速记）",
      },
      {
        title: "牌义对位",
        detail:
          "正位：悬置、试炼、自我牺牲、把世界倒过来看。逆位：无意义的牺牲、过度的自我牺牲、停滞。「残りの人生、わたくしに下さい」的献祭逻辑，加上她自己交出的全部人生，两面都成立。",
      },
    ],
  },
  {
    member: "uika",
    arcanaNum: 10,
    confidence: "锚点（题设 · 证据充分）",
    thesis:
      "周而复始、不由自主回到同一处的人。Crucifix Ⅹ 的歌词里直接出现命运女神福尔图娜与转动的齿轮；第 13 话舞台剧里，她是唯一「无论给多少次忘却都会回到乐园」的角色。",
    evidence: [
      {
        title: "《Crucifix Ⅹ》— 与 Imprisoned Ⅻ 成对的插入曲",
        detail:
          "歌词：「後ろ髪のないフォルトゥーナ」（没有后发的福尔图娜——罗马命运女神，Rota Fortunae「命运之轮」的持有者）、「命の歯車が回り出す」、「誰かの歯車が狂い出す」、「繰り返す」。轮、齿轮、循环，全是第十张牌的核心图像。",
        source: "JOYSOUND 歌词 · note 楽曲考察",
      },
      {
        title: "第 13 话舞台剧 · 唯一被拒绝册封的人",
        detail:
          "Doloris 请求成为骑士，Oblivionis 答：「幾度繰り返すのです。幾度忘却を与えても、あなたは楽園に戻ってくる」「あなたは私の騎士ではない」。旁白追问：「何度この地を訪れた」。她是这出剧里唯一在循环中的人——轮子转一圈，她就回来一次。",
        source: "note 第 13 话感想（台词速记）",
      },
      {
        title: "旋转木马与双重身份",
        detail:
          "OP 与第 13 话 Mujica 段落都从旋转木马开始；初华/初音、sumimi/Doloris 的身份轮替本身就是「轮」。命运之轮逆位「被外因摆布、抗拒承认变化」也对上了「ここに来たのは今日が初めてで」的否认。",
      },
    ],
  },
];

/* ---------------- Stage readings ---------------- */

export interface Reading {
  id: string;
  title: string;
  formula: string;
  body: string;
  verdict: string;
}

export const READINGS: Reading[] = [
  {
    id: "numerals",
    title: "把光读成罗马数字",
    formula: "I · I · X · I · I",
    body:
      "四道竖直光柱是四个 I，交叉的两道光在祥子身上画出一个 X。从祥子出发向任意一侧读，都是 X、I、I —— XII。也就是说，舞台灯光本身就把祥子的牌号写在了她头顶：交叉光是 X，两侧的竖光把它补成了 XII。",
    verdict: "这是对「祥子 = 倒吊人」最漂亮的构图级佐证。你问「X 是否代表 10」——它既是 10，也是 XII 里的那个 X。",
  },
  {
    id: "invariance",
    title: "侧着看、倒着看，读数不变",
    formula: "IIXII = IIXII（镜像 / 旋转 180°）",
    body:
      "IIXII 是回文，而且 I 与 X 两个字形上下颠倒后不变。倒吊人的视角是「把世界倒过来看」，可这个构图不管左右镜像还是整个倒转，读出来仍然是同一个数。忘却之神是不动的支点——「皆が忘れようとも、私だけは忘れない」。",
    verdict: "你猜「要不要侧着看」是对的方向：答案是无论怎么看都一样，而这个不变性本身就是含义。",
  },
  {
    id: "crucifix",
    title: "X 形交叉 = 十字架",
    formula: "Crucifix Ⅹ → 十字落在祥子身上",
    body:
      "两道光交叉成 X，正是圣安德烈十字（saltire）。Crucifix Ⅹ 是初华视角的歌，「彷徨える我が十字架」——初华的 X 被钉在祥子的位置。再看 Imprisoned Ⅻ：XII 里面本来就包含一个 X。初华的数字被囚在祥子的数字里，两首歌的关系被一组灯光画了出来。",
    verdict: "解释了为什么 X 出现在祥子而不是初华身上：那是初华放在祥子身上的东西。",
  },
  {
    id: "brightness",
    title: "亮度分层",
    formula: "内圈（若麦·初华）亮 ＞ 外圈（海铃·睦）暗",
    body:
      "以祥子为轴，距离 1 的两人略亮，距离 2 的两人略暗。这是一个以中心为轴的「层级」结构：如果 XII = X + II 里的两个 I 只算一对，最自然的就是更亮的内圈。它支持「围绕祥子折叠」的几何思路，但亮度本身并不给出具体数字。",
    verdict: "你说的「数字隐喻只算若麦和初华」在构图上说得通，但它不能单独推出 14。",
  },
  {
    id: "lateral",
    title: "左右不是对称的：骑士在左，非骑士在右",
    formula: "[海铃 · 若麦] ─ 祥子 ─ [初华 · 睦]",
    body:
      "光是左右对称的，人不是。祥子左侧是两个被 Oblivionis 亲手册封的骑士——也是后来招募、没有童年羁绊的两人；右侧是童年羁绊的两人：初华被拒绝册封，睦根本没去请求，她在「听世界崩坏的声音」。所以这个构图叠了两套编码：灯光 = 数字，左右 = 与神的关系。",
    verdict: "「两个骑士不在祥子两侧」不是漏洞，而是信息：骑士与非骑士被分在了轴的两边。",
  },
];

/* ---------------- Frameworks ---------------- */

export interface FrameworkAssignment {
  member: MemberId;
  arcanaNum: number;
}

export interface Framework {
  key: "A" | "B";
  name: string;
  subtitle: string;
  assignments: FrameworkAssignment[];
  premise: string;
  strengths: string[];
  weaknesses: string[];
  prior: number; // subjective probability that this package is the intended one
}

export const FRAMEWORKS: Framework[] = [
  {
    key: "A",
    name: "折叠等差模型",
    subtitle: "你提出的假说：以祥子为轴、步长 2 的数列",
    assignments: [
      { member: "umiri", arcanaNum: 16 },
      { member: "nyamu", arcanaNum: 14 },
      { member: "sakiko", arcanaNum: 12 },
      { member: "uika", arcanaNum: 10 },
      { member: "mutsumi", arcanaNum: 8 },
    ],
    premise:
      "祥子 XII 在正中，紧邻的初华是 X，差 2；若站位间距对应牌号间距，步长就被两个锚点唯一确定，没有任何自由参数。于是从左到右是 XVI · XIV · XII · X · VIII，镜像位置两两相加恒为 24（= 2 × 12）——你想找的「24」就是这个不变量。牌组只有 0–21，绕 12 折叠本身不对称（下方 12 张、上方 9 张），但舞台只用到 8–16 这段 ±4 的对称核心。",
    strengths: [
      "零自由参数：两个锚点给定后，其余三张牌是被「算」出来的，可证伪。",
      "与亮度分层一致：内圈 ±2、外圈 ±4。",
      "若全部按逆位读，主题惊人地贴合——逆位塔 = 靠能力规避崩塌却在内部崩塌（监督对海铃的原话）；逆位节制 = 过度、失衡、焦躁（若麦）；逆位力量 = 软弱、恐惧、失控、力量过剩（睦 vs 墨缇丝：少女与狮子，「才能占九成、自我一成」）；逆位命运之轮 = 被外因摆布；逆位倒吊人 = 过度自我牺牲。「五张全逆位」与「倒着看世界」的倒吊人视角自洽。",
      "力量牌的图像是少女合上狮子之口——母亲称睦为「怪物」，这张牌里怪物与少女共处一框。",
    ],
    weaknesses: [
      "放弃了 Mortis → 死神（XIII）这一最直白、且被第 13 话「死の騎士」再次强调的对应。",
      "把「塔」给了全队最稳定的人；海铃的第 8 话翅膀线索在这个模型里落到若麦（节制的天使）而不是海铃。",
      "X 与 XII 相差 2 很可能是基督教数字学的副产品（作词者的思路：Ⅻ = 第十二使徒犹大，Ⅹ = 十字/死亡之吻），塔罗只是第二层。步长 2 因而可能是巧合而非设计。",
    ],
    prior: 0.3,
  },
  {
    key: "B",
    name: "象征—剧情模型",
    subtitle: "用锚点的「命名逻辑」去推其余三人",
    assignments: [
      { member: "umiri", arcanaNum: 14 },
      { member: "nyamu", arcanaNum: 15 },
      { member: "sakiko", arcanaNum: 12 },
      { member: "uika", arcanaNum: 10 },
      { member: "mutsumi", arcanaNum: 13 },
    ],
    premise:
      "先看已确证的两张是怎么来的：忘却并没有对应某张「忘却牌」，悲伤也没有对应「悲伤牌」；祥子拿到倒吊人是因为「自缚献祭的神」，初华拿到命运之轮是因为「周而复始的回归者」。锚点靠的是剧情功能，不是名字直译。用同样的方法：睦 = 终结与再生本身（XIII 死神，且是大阿卡纳里唯一披甲骑马的「骑士」）；若麦 = 恋人牌的黑暗镜像（XV 恶魔：羡慕到憎恨的爱、被锁住的两人、流量与名声的执念）；海铃 = 两杯之间的调和者、说「这里没有可怕之事」的守护天使（XIV 节制，有翅膀）。",
    strengths: [
      "五张牌是 X · XII · XIII · XIV · XV ——从 10 到 15 几乎连续，唯一缺席的 XI「正义」是持剑者：第 13 话 Oblivionis 正是携剑登场、裁定谁能成为骑士（「ならば剣を手に」）。缺的那张剑，在祥子手里。",
      "结构清晰：两名骑士 = 天使（XIV）与恶魔（XV）一对；两名非骑士 = 命运（X）与死亡（XIII），恰是「神」也无法支配的两种力量；祥子 XII 被悬在命运与死亡之间——大阿卡纳顺序里倒吊人正好夹在轮与死神中间。",
      "海铃的翅膀线索、「恐れの騎士」却负责消除恐惧的反义命名（与 Oblivionis =「不惧被遗忘者」同一手法）、以及电影官网「完美处理日程等幕后工作」的调和者定位，都收束在节制上。塔罗典籍还特别指出：倒吊人与节制是夹着死神的两张有光轮的牌——XII·XIII·XIV = 祥子·睦·海铃，恰是 MyGO 第 13 话里最早决意组建新乐队的三人。",
      "睦 = XIII：马赛体系里 XIII 是唯一「无名」的牌，对应《顔》里「已无人知晓她是谁」；XIII 紧邻 XII，是祥子最亲近的人。",
    ],
    weaknesses: [
      "舞台站位与数字之间不再有算术关系（14·15·12·10·13），几何只剩「骑士左 / 非骑士右」的定性信息。",
      "若麦在恋人（VI）与恶魔（XV）之间无法用现有材料完全裁决；海铃在节制（XIV）、隐者（IX）、月亮（XVIII）之间也有竞争。",
      "「连续段缺 XI」是漂亮的解释，但漂亮不等于设计意图。",
    ],
    prior: 0.55,
  },
];

/* ---------------- Per-member candidates ---------------- */

export interface Candidate {
  arcanaNum: number;
  probability: number; // 0..1 subjective
  frameworks: Array<"A" | "B">;
  pros: string[];
  cons: string[];
}

export interface MemberAnalysis {
  id: MemberId;
  summary: string;
  candidates: Candidate[];
}

export const MEMBER_ANALYSES: MemberAnalysis[] = [
  {
    id: "sakiko",
    summary:
      "题设锚点。灯光把 XII 直接写在她头顶；OP 的倒吊剪影、第 10 话的 Imprisoned Ⅻ、第 13 话的《诸神的命运》三方印证。唯一值得记一笔的旁支：舞台剧里她持剑裁决谁是骑士，那是 XI 正义的动作——但那是「角色在剧中做的事」，不是她的牌。",
    candidates: [
      {
        arcanaNum: 12,
        probability: 0.95,
        frameworks: ["A", "B"],
        pros: ["曲名 Ⅻ 直接给出", "OP 倒吊剪影", "奥丁 / 诸神黄昏原型", "舞台灯光 X + II = XII"],
        cons: ["Imprisoned Ⅻ 是初华视角的歌，「被囚者」在歌词层面有歧义"],
      },
      {
        arcanaNum: 11,
        probability: 0.05,
        frameworks: [],
        pros: ["第 13 话持剑登场、册封与拒绝——正义牌的剑与裁决"],
        cons: ["这是 Oblivionis 在剧中的动作，不是人物本身的牌义；与 Ⅻ 冲突"],
      },
    ],
  },
  {
    id: "uika",
    summary:
      "题设锚点。福尔图娜、齿轮、「幾度繰り返す」——命运之轮的三要素在歌词与台词里全部出现。她也是舞台上唯一被拒绝进入骑士秩序的人：轮子不属于任何人的骑士团。",
    candidates: [
      {
        arcanaNum: 10,
        probability: 0.9,
        frameworks: ["A", "B"],
        pros: ["Crucifix Ⅹ 曲名与歌词（フォルトゥーナ、歯車）", "「あなたは楽園に戻ってくる」的循环", "旋转木马意象"],
        cons: ["Ⅹ 在作词者那里首先是十字/死亡之吻，塔罗是第二层"],
      },
      {
        arcanaNum: 12,
        probability: 0.1,
        frameworks: [],
        pros: ["若把 Imprisoned Ⅻ 的「最深的被囚者」读成初华自己，XII 也可能指她"],
        cons: ["与祥子锚点冲突；舞台灯光把 X 与 XII 分别落在两人位置上，反而支持题设分法"],
      },
    ],
  },
  {
    id: "mutsumi",
    summary:
      "两个模型在她身上分歧最大：名字直译与「死の騎士」指向 XIII，几何折叠指向 VIII。我的判断是 XIII 更可能——已确证的两张牌虽然不是名字直译，但制作组不会在给了「Mortis」这个名字之后，再把唯一的死神牌留空。",
    candidates: [
      {
        arcanaNum: 13,
        probability: 0.55,
        frameworks: ["B"],
        pros: [
          "Mortis 直译；第 13 话被称为「死の騎士モーティス」——死神牌正是大阿卡纳中唯一披甲骑马的骑士",
          "马赛版 XIII 无名 →《顔》「已无人知晓她是谁」",
          "XIII 紧邻 XII：祥子最亲近的人；死神 = 终结与再生，对应墨缇丝之「死」与睦的再生（镜子）",
          "她在剧中说「僕たちの命は沢山の死の上に立ってる」",
        ],
        cons: ["与站位算术无关", "过于直白，而锚点两张都不是直译"],
      },
      {
        arcanaNum: 8,
        probability: 0.25,
        frameworks: ["A"],
        pros: [
          "折叠模型的预测值（12 − 4）",
          "少女合上狮子之口：睦与墨缇丝（母亲口中的「怪物」）共处一框；头顶的 ∞ 对应人格的循环",
          "逆位力量 = 软弱、恐惧、失控、力量过剩 ——「才能占九成、自我一成」",
        ],
        cons: ["浪费了死神牌", "韦特版 VIII 与马赛版 XI 位置互换，编号本身不稳定"],
      },
      {
        arcanaNum: 18,
        probability: 0.1,
        frameworks: [],
        pros: ["Mujica 的月徽；月亮牌 = 幻觉、无意识、隐藏的真相，对应人格与演技的边界"],
        cons: ["月亮更像整支乐队的牌而非某一个人", "与两个模型都不兼容"],
      },
    ],
  },
  {
    id: "nyamu",
    summary:
      "「爱」在 Mujica 里是扭曲的爱——羡慕到憎恨、被锁住、想要又得不到。恶魔牌就是恋人牌的黑暗镜像，构图相同而意义反转，这正是 Ave Mujica 的命名手法。折叠模型给她节制（有翅膀、两只手、两只杯）也不算离谱，尤其按逆位读。",
    candidates: [
      {
        arcanaNum: 15,
        probability: 0.35,
        frameworks: ["B"],
        pros: [
          "恶魔 = 恋人的倒影：Amoris 之爱在剧中是「うらやみ憎んでしまうほどの愛」",
          "被锁链拴住的两人 ↔ 她与睦的爱憎；「私にはAve Mujicaしかない」的束缚",
          "物欲、名声、流量的执念；蝙蝠翼",
          "逆位 = 解放与自我认知，对应她后期的转向",
        ],
        cons: ["与算术无关", "恶魔是全队里最「重」的一张牌，分给她需要接受角色的阴暗面被放到台面"],
      },
      {
        arcanaNum: 14,
        probability: 0.3,
        frameworks: ["A"],
        pros: [
          "折叠模型的预测值（12 + 2）",
          "两只杯、两只手：她是双利手鼓手；在网红/演员/鼓手之间「调配」自己",
          "逆位节制 = 过度、失衡、焦躁，非常像她",
          "节制与倒吊人是夹着死神的两张光轮牌——她与祥子隔着睦",
        ],
        cons: ["正位牌义（克制、中庸）与人物相反，只能靠逆位成立", "把翅膀从海铃手里拿走了"],
      },
      {
        arcanaNum: 6,
        probability: 0.25,
        frameworks: [],
        pros: ["Amoris 直译；恋人牌也有天使翼", "「选择」的牌义：她是第一个把成员身份公开的人"],
        cons: ["过于正面，与 Mujica 一贯的反义命名不合", "与两个模型都不兼容"],
      },
    ],
  },
  {
    id: "umiri",
    summary:
      "你找「有翅膀的牌」是对的：第 8 话购物袋成翼的「炽天使乌米铃」本来就是制作组画给她的一枚翅膀。大阿卡纳里有翼的是恋人、命运之轮、节制、恶魔、审判、世界；扣掉已分配和不合的，剩下节制。节制的天使一足在水一足在岸、在两杯之间倒水——在三十支乐队间穿梭、站在 MyGO 与 Mujica 之间的 support bassist。",
    candidates: [
      {
        arcanaNum: 14,
        probability: 0.35,
        frameworks: ["B"],
        pros: [
          "翅膀：第 8 话「炽天使乌米铃」",
          "「恐れの騎士」在剧中说的却是「ここにいれば恐ろしいことはない、この私が約束しよう」——守护天使米迦勒；与 Oblivionis =「不惧被遗忘者」同一种反义命名",
          "两杯之间倒水 = support bassist；一足在水一足在岸 = 立希（MyGO）与 Mujica 之间",
          "节制 = 克制：「不再深入投入任何乐队」；电影官网：完美处理日程管理等幕后工作 = 调和者",
        ],
        cons: ["与算术无关", "若麦也在竞争这张牌"],
      },
      {
        arcanaNum: 16,
        probability: 0.25,
        frameworks: ["A"],
        pros: [
          "折叠模型的预测值（12 + 4）",
          "第 8 话：曾被四名队友集体放鸽子——她的塔早塌过一次；福冈公演后第一个说「辛苦了」离场，是最早预见终局的人",
          "逆位塔 = 靠能力规避崩塌、却在内部崩塌：几乎就是监督对她的评语",
          "塔在马赛版叫「神之家」(La Maison Dieu)——她管理着「神」的乐队的日程与后台",
        ],
        cons: ["把最剧烈的一张牌给了最平稳的人", "没有翅膀"],
      },
      {
        arcanaNum: 9,
        probability: 0.2,
        frameworks: [],
        pros: ["孤独的观察者、提灯独行；「誰も私を信じない、信じてくれない」", "旁观者 → 唯一归属的转变，正是隐者下山"],
        cons: ["没有翅膀", "与两个模型都不兼容"],
      },
      {
        arcanaNum: 18,
        probability: 0.15,
        frameworks: [],
        pros: ["月亮是恐惧与不安的牌；Timoris 本身就是月面的「恐惧湖」；Mujica 的徽记是月"],
        cons: ["没有翅膀", "月亮更像乐队整体的牌"],
      },
    ],
  },
];

/* ---------------- Q&A on the user's hypotheses ---------------- */

export interface QA {
  q: string;
  a: string;
  tag: "支持" | "部分支持" | "修正";
}

export const QA_LIST: QA[] = [
  {
    q: "交叉光柱的 X 是不是代表 10？",
    tag: "部分支持",
    a: "作为字形它就是 X，所以既是 10 也是 XII 里的那个 X。关键在于它落在祥子而不是初华身上：Crucifix Ⅹ 是初华的歌，「我的十字架」被钉在祥子的位置；而 XII 里面本来就包含 X——初华的数字被囚在祥子的数字里。所以 X 不是在说「祥子是 10」，而是在说「初华的 10 在祥子身上」。",
  },
  {
    q: "数字隐喻是不是只算若麦和初华（更亮的那两道）？",
    tag: "部分支持",
    a: "从构图看成立：X + 内圈两道 I = XII。但 IIXII 是回文，用外圈那对 I 也能读出 XII，亮度只说明「内圈更近」，推不出 14。亮度真正提供的信息是层级：内圈 ±1 步、外圈 ±2 步，这为折叠模型提供了结构支持。",
  },
  {
    q: "是不是需要侧着看 / 倒着看？",
    tag: "支持",
    a: "方向对，结论更有趣：IIXII 左右镜像、上下颠倒都读同一个数。倒吊人倒着看世界，而这个构图对「倒着看」是不变的——忘却之神是不动的支点，「皆が忘れようとも、私だけは忘れない」。",
  },
  {
    q: "0–11 与 13–21 能不能绕着 XII 折叠？「24」是什么？",
    tag: "修正",
    a: "大阿卡纳是 0–21 共 22 张（没有 24 或 25）。绕 12 折叠本身不对称：下面 12 张、上面 9 张。但镜像位置的两张牌之和恒等于 24（= 2 × 12）：10 + 14、8 + 16、9 + 15、11 + 13。你想找的「24」就是这个不变量。舞台只用了 8–16 这段 ±4 的对称核心，所以折叠在舞台范围内是成立的。",
  },
  {
    q: "若麦是不是第十四张？",
    tag: "部分支持",
    a: "折叠模型下是的：XIV 节制。按逆位读（过度、失衡、焦躁）以及双利手 / 两只杯的意象，能够自圆其说。但象征模型更倾向把她放到 XV 恶魔（恋人牌的黑暗镜像：羡慕到憎恨的爱、被锁住的两人），而把节制留给有翅膀的海铃。两个模型在 14 这张牌上正面冲突，这是整个问题的胜负手。",
  },
  {
    q: "海铃的牌应该有翅膀，可是找不到？",
    tag: "支持",
    a: "找得到。大阿卡纳里有翼的是：恋人（拉斐尔）、命运之轮（四活物）、节制（米迦勒）、恶魔（蝙蝠翼）、审判（加百列）、世界（四活物）。命运之轮已归初华，恋人与恶魔更属于「爱」，审判与世界离她太远——剩下的就是节制：一足在水一足在岸、两杯之间倒水的守护天使。第 13 话她的台词「ここにいれば恐ろしいことはない、この私が約束しよう」正是守护天使的台词。",
  },
  {
    q: "那间隔为 2 的数列（8 · 10 · 12 · 14 · 16）到底成不成立？",
    tag: "修正",
    a: "数学上完全成立且没有自由参数，主题上也能靠「全逆位」读通。但它有一个来源上的隐患：Ⅹ 与 Ⅻ 之差为 2 很可能只是基督教数字学（第十二使徒、十字架）的副产品，塔罗是作词者之外的第二层设计，站位未必按数列排。所以我把它当作「第二候选」而非「答案」，并把关键的可证伪点列在最后。",
  },
];

/* ---------------- Verification checklist ---------------- */

export const CHECKLIST: { title: string; why: string }[] = [
  {
    title: "《KiLLKiSS》初回生产分封入特典「特製キャラクターカード」（全 5 种）",
    why: "二手市场与 Amazon 评论都称之为「タロット風カード / タロットカード」。如果卡面印有牌号或牌名，这就是官方答案；本次未能取得清晰卡面。",
  },
  {
    title: "TV 动画 BD 各卷封面、《Completeness》特典卡",
    why: "同一时期的官方物料常复用同一套象征体系。",
  },
  {
    title: "剧场版《prima aurora》的 Secret Masquerade 段落与 32 页场刊",
    why: "场刊含 staff 访谈；假面舞会剧中剧最可能直接给出各人的「牌」。",
  },
  {
    title: "《Our Notes》Ave Mujica 乐队故事 / 动画后续特别篇",
    why: "文本量大，最有可能出现「你的牌是……」式的直接台词。",
  },
  {
    title: "OP 逐帧：倒吊剪影是哪几人、纸牌花色与数量",
    why: "若倒吊的只有祥子，锚点更稳；若五人皆倒吊，则「全逆位」读法获得画面支持。",
  },
];

export const SOURCES: { label: string; url: string; note: string }[] = [
  { label: "第 13 话「Per aspera ad astra.」感想（假面舞会台词速记）", url: "https://note.com/srx40090/n/n36afe28d699e", note: "骑士册封、拒绝、「幾度繰り返す」、《神々の運命》" },
  { label: "『Imprisoned Ⅻ』『Crucifix Ⅹ』楽曲考察", url: "https://note.com/tomoco35/n/n8d57ca14c679", note: "作词者的犹大 / 十字架数字学；福尔图娜" },
  { label: "Imprisoned XII 歌词与 MV 考察（第 10 话插入曲）", url: "https://anichoice.com/avemujica-imprisonedxii/", note: "棺、鸟笼、螺旋阶梯" },
  { label: "pixiv 百科「Imprisoned_XII」", url: "https://dic.pixiv.net/a/Imprisoned_XII", note: "「监禁者亦是最深的被囚者」" },
  { label: "OP「KiLLKiSS」映像考察", url: "https://note.com/haidra_bump/n/nff84dc5f0924", note: "倒吊剪影、圣杯五 / 宝剑五 / 圣杯二" },
  { label: "天球と韻律の星図を描く Ave Mujica", url: "https://sai96i.hateblo.jp/entry/2025/11/30/010544", note: "OP 中角色与塔罗牌的对应构图；Ⅹ 的多义" },
  { label: "Crucifix X 歌词（JOYSOUND）", url: "https://www.joysound.com/web/search/song/1093355", note: "後ろ髪のないフォルトゥーナ / 命の歯車" },
  { label: "KiLLKiSS 通常盘商品页（封入特典说明）", url: "https://bushiroad-store.com/products/2000195572601", note: "特製キャラクターカード 全 5 种" },
  { label: "知乎：第 8 话评价（炽天使乌米铃）", url: "https://www.zhihu.com/question/12857951872", note: "购物袋成翼；海铃被放鸽子的过去" },
  { label: "xoqnapgf-dot/bangdream 资料库", url: "https://github.com/xoqnapgf-dot/bangdream/tree/main/%E8%B5%84%E6%96%99%E5%BA%93", note: "官方访谈确证内容、剧场版资料、角色人设" },
  { label: "節制（タロット）— 日本語版 Wikipedia", url: "https://ja.wikipedia.org/wiki/%E7%AF%80%E5%88%B6_(%E3%82%BF%E3%83%AD%E3%83%83%E3%83%88)", note: "倒吊人与节制夹着死神的两枚光轮" },
];

export const FINAL_TABLE: { member: MemberId; primary: number; secondary: number; confidence: string; note: string }[] = [
  { member: "umiri", primary: 14, secondary: 16, confidence: "中", note: "翅膀 + 守护天使台词 + 调和者；折叠模型给塔" },
  { member: "nyamu", primary: 15, secondary: 14, confidence: "中偏低", note: "恋人的黑暗镜像；折叠模型给节制（逆位）" },
  { member: "sakiko", primary: 12, secondary: 12, confidence: "高", note: "题设锚点；灯光 X + II = XII" },
  { member: "uika", primary: 10, secondary: 10, confidence: "高", note: "题设锚点；福尔图娜与齿轮" },
  { member: "mutsumi", primary: 13, secondary: 8, confidence: "中偏高", note: "死の騎士 = 骑马的骸骨骑士；折叠模型给力量" },
];
