# Yutu Lunar Case File

## Run

```sh
npm install
npm run dev
```

## Build And Open Offline

```sh
npm run build
node scripts/verify-assets.mjs
```

Open `dist/index.html` directly, or deploy `dist/` to a static host.
The generated HTML contains all seven illustrations, four font subsets, CSS,
and JavaScript. It can also be copied on its own to a different folder and
opened without network access.

Original illustration files remain in `public/images/`. Source references in
`src/lib/media.ts` use relative JPEG imports with `?inline`; do not replace them
with filenames for converted assets that are not included in the project.
The font subsets are also preserved in `src/lib/font-data.ts`, so a new build
does not require downloading fonts or running Python.

## Browser Regression Check

With Python Playwright and Chromium installed:

```sh
python3 scripts/verify-media.py
```

This checks image decoding, automatic visibility, font loading, both rabbit
forms, both themes, desktop/mobile widths, standalone offline HTML, a nested
deployment path, and the Vite dev preview. Screenshots and the result report
are written to `.shots/`.

The original Markdown is preserved in `src/content/yutu.md`. The two missing
measurement images referenced in that source are represented by clearly
labeled inline SVG reconstructions, not by claimed original frames.