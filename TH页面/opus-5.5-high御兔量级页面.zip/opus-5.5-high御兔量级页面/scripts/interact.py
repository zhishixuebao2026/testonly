import os
from playwright.sync_api import sync_playwright
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
url = "file://" + os.path.join(root, "dist", "index.html")
OVF = """() => { const W=document.documentElement.clientWidth; return {sw:document.documentElement.scrollWidth, W,
 bad:[...document.querySelectorAll('main *')].filter(e=>{const r=e.getBoundingClientRect(); return r.width>0&&(r.right>W+1||r.left<-1)}).slice(0,8).map(e=>e.tagName+' '+String(e.className).slice(0,50)+' '+Math.round(e.getBoundingClientRect().right))}}"""
with sync_playwright() as p:
    b = p.chromium.launch()
    # desktop dark hero after shader change
    c = b.new_context(viewport={"width":1440,"height":900}); c.add_init_script("localStorage.setItem('yt-theme','dark')")
    pg = c.new_page(); pg.goto(url); pg.wait_for_timeout(2500); pg.screenshot(path=f"{root}/.shots/i-hero-dark.png")
    pg.evaluate("document.querySelector('#refs').scrollIntoView()"); pg.wait_for_timeout(1500)
    pg.evaluate("window.scrollTo(0, document.documentElement.scrollHeight)"); pg.wait_for_timeout(1200)
    pg.evaluate("document.querySelectorAll('.rv').forEach(e=>e.classList.add('in'))"); pg.wait_for_timeout(900)
    pg.screenshot(path=f"{root}/.shots/i-footer.png"); c.close()
    # mobile
    c = b.new_context(viewport={"width":360,"height":740}, device_scale_factor=2, is_mobile=True, has_touch=True)
    c.add_init_script("localStorage.setItem('yt-theme','dark')")
    pg = c.new_page(); errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(url); pg.wait_for_timeout(1500)
    pg.click("button[aria-label='打开目录']"); pg.wait_for_timeout(800); pg.screenshot(path=f"{root}/.shots/i-drawer.png")
    pg.click("nav[aria-label='目录'] a[href='#analysis']"); pg.wait_for_timeout(1500)
    for _ in range(4): pg.click("button[aria-label='放大字体']"); pg.wait_for_timeout(100)
    print("fs", pg.evaluate("getComputedStyle(document.documentElement).fontSize"))
    h = pg.evaluate("document.documentElement.scrollHeight"); y=0
    while y < h:
        pg.evaluate(f"window.scrollTo(0,{y})"); pg.wait_for_timeout(60); y += 500; h = pg.evaluate("document.documentElement.scrollHeight")
    pg.evaluate("document.querySelectorAll('.rv').forEach(e=>e.classList.add('in'))"); pg.wait_for_timeout(900)
    print("overflow@150%", pg.evaluate(OVF))
    pg.evaluate("document.querySelector('#analysis figure').scrollIntoView({block:'center'})"); pg.wait_for_timeout(500)
    pg.screenshot(path=f"{root}/.shots/i-m150-fig.png")
    pg.evaluate("document.querySelector('#rating').scrollIntoView()"); pg.wait_for_timeout(500)
    pg.screenshot(path=f"{root}/.shots/i-m150-rating.png")
    # 变身
    pg.evaluate("document.querySelector('#character').scrollIntoView()"); pg.wait_for_timeout(300)
    btn = pg.locator("button[aria-pressed]").filter(has_text="打回玩偶"); btn.click(); pg.wait_for_timeout(900)
    print("toggle ->", pg.locator("#character button[aria-pressed]").inner_text())
    # fireball cell
    pg.locator("#analysis button", has_text="2421").click(); pg.wait_for_timeout(600)
    print("fig label:", pg.locator("#analysis figure svg text", has_text="R ≈").first.text_content())
    print("errors", errs)
    b.close()
