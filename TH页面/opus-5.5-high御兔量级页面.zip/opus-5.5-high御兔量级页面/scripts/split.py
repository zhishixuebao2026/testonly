import sys
from PIL import Image
Image.MAX_IMAGE_PIXELS=None
src, outp, chunk, tw = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
im = Image.open(src).convert("RGB")
s = tw / im.width
n = 0
for y in range(0, im.height, chunk):
    c = im.crop((0, y, im.width, min(im.height, y + chunk)))
    c = c.resize((tw, int(c.height * s)))
    c.save(f"{outp}-{n:02d}.jpg", quality=80); n += 1
print(n)
