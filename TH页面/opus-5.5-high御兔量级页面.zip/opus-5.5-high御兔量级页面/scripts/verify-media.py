import functools
import hashlib
import http.server
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.request

from playwright.sync_api import sync_playwright


ROOT = Path(__file__).resolve().parent.parent
SHOTS = ROOT / ".shots"
SHOTS.mkdir(exist_ok=True)
SOURCE_HASH = hashlib.sha256((ROOT / "src/content/yutu.md").read_bytes()).hexdigest()


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def verify(browser, url, name, width, height, theme, offline=False):
    context = browser.new_context(
        viewport={"width": width, "height": height},
        device_scale_factor=1,
        color_scheme=theme,
        reduced_motion="no-preference" if name.startswith("dev-") else "reduce",
    )
    if offline:
        context.set_offline(True)
    context.add_init_script(
        f"try {{ localStorage.setItem('yt-theme','{theme}'); localStorage.setItem('yt-fs','1'); }} catch (e) {{}}"
    )
    page = context.new_page()
    errors = []
    requests = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.on("requestfailed", lambda request: errors.append(request.url))
    page.on("request", lambda request: requests.append((request.resource_type, request.url)))
    page.goto(url, wait_until="networkidle")
    page.wait_for_selector("#work img")
    page.evaluate("document.documentElement.style.scrollBehavior='auto'")
    images = page.evaluate("""async () => {
      return Promise.all(Array.from(document.images).map(async image => {
        image.loading = 'eager';
        await image.decode();
        return {
          alt: image.alt,
          embedded: image.currentSrc.startsWith('data:image/jpeg;base64,'),
          width: image.naturalWidth,
          height: image.naturalHeight,
          complete: image.complete
        };
      }));
    }""")
    fonts = page.evaluate("""async () => {
      await Promise.all(Array.from(document.fonts).map(font => font.load()));
      return Array.from(document.fonts).map(font => ({ family: font.family, status: font.status }));
    }""")
    assert len(images) == 7, (name, len(images))
    assert all(image["embedded"] and image["complete"] and image["width"] > 0 for image in images), (name, images)
    assert len(fonts) == 4 and all(font["status"] == "loaded" for font in fonts), (name, fonts)
    assert not errors, (name, errors)
    external_media = [(kind, uri) for kind, uri in requests if kind in ("image", "font") and not uri.startswith("data:")]
    assert not external_media, (name, external_media)

    for selector, suffix in [("#work", "city"), ("#character", "character"), ("#scenes", "scenes")]:
        page.locator(selector).evaluate("element => element.scrollIntoView({block:'start',behavior:'instant'})")
        page.wait_for_function("""selector => {
          return Array.from(document.querySelectorAll(selector + ' .panel-img')).some(frame => {
            const image = frame.querySelector('img');
            const reveal = frame.closest('.rv');
            const opacity = reveal ? Number(getComputedStyle(reveal).opacity) : 1;
            return image && image.naturalWidth > 0 && opacity > 0.99;
          });
        }""", arg=selector)
        page.screenshot(path=str(SHOTS / f"{name}-{suffix}.png"))

    # Both rabbit forms must be decoded before and after the transition.
    toggle = page.locator("#character button[aria-pressed]")
    toggle.click()
    assert toggle.get_attribute("aria-pressed") == "false"
    assert page.locator("#character img").nth(1).evaluate("image => image.naturalWidth > 0")
    page.wait_for_function("getComputedStyle(document.querySelectorAll('#character img')[1]).opacity === '1'")
    page.locator("#character").evaluate("element => element.scrollIntoView({block:'start',behavior:'instant'})")
    page.screenshot(path=str(SHOTS / f"{name}-plush.png"))

    dimensions = page.evaluate("[document.documentElement.scrollWidth, document.documentElement.clientWidth]")
    assert dimensions[0] == dimensions[1], (name, dimensions)
    result = {"case": name, "images_decoded": len(images), "fonts_loaded": len(fonts), "external_media_requests": len(external_media), "errors": errors, "viewport": dimensions}
    print(json.dumps(result))
    context.close()
    return result


results = []
with tempfile.TemporaryDirectory(prefix="yutu-offline-") as temporary:
    folder = Path(temporary)
    hosted = folder / "nested" / "site"
    hosted.mkdir(parents=True)
    html = hosted / "index.html"
    shutil.copy2(ROOT / "dist/index.html", html)
    assert list(hosted.iterdir()) == [html]

    handler = functools.partial(QuietHandler, directory=folder)
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    port = server.server_address[1]

    dev = subprocess.Popen(
        ["npm", "run", "dev", "--", "--host", "127.0.0.1", "--port", "5198", "--strictPort"],
        cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT,
    )
    try:
        for attempt in range(100):
            try:
                urllib.request.urlopen("http://127.0.0.1:5198", timeout=1).close()
                break
            except OSError:
                if dev.poll() is not None:
                    raise RuntimeError("Vite dev server failed to start")
                time.sleep(0.1)
        else:
            raise RuntimeError("Vite dev server timed out")

        with sync_playwright() as playwright:
            browser = playwright.chromium.launch()
            results.append(verify(browser, html.as_uri(), "offline-desktop-dark", 1440, 900, "dark", True))
            results.append(verify(browser, html.as_uri(), "offline-mobile-light", 390, 844, "light", True))
            results.append(verify(browser, f"http://127.0.0.1:{port}/nested/site/index.html", "subpath-mobile-dark", 360, 800, "dark"))
            results.append(verify(browser, "http://127.0.0.1:5198", "dev-desktop-light", 1280, 900, "light"))
            browser.close()
    finally:
        dev.terminate()
        dev.wait(timeout=15)
        server.shutdown()
        server.server_close()

assert SOURCE_HASH == hashlib.sha256((ROOT / "src/content/yutu.md").read_bytes()).hexdigest()
(SHOTS / "media-verification.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
print("PASS: isolated offline HTML, nested deployment, dev preview, both themes, and both rabbit forms.")