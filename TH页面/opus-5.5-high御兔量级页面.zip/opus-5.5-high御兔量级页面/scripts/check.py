import sys, os, re, json
from playwright.sync_api import sync_playwright
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
url = "file://" + os.path.join(root, "dist", "index.html")
md = open(os.path.join(root, "src/content/yutu.md"), encoding="utf-8").read()

def atoms(md):
    out = []
    for line in md.split("\n"):
        l = line.strip()
        if not l or re.match(r"^\|[-|\s]+\|$", l): continue
        if l.startswith("|"):
            cells = [c.strip() for c in l.strip("|").split("|")]
        else:
            l = re.sub(r"^(#+|>|-|\d+\.)\s+", "", l)
            m = re.match(r"^!\[([^\]]*)\]\(([^)]+)\)", l)
            cells = [m.group(1)] if m else [l]
        for c in cells:
            c = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", c).replace("**", "")
            if c: out.append(c)
    return out
norm = lambda s: re.sub(r"\s+", "", s)

shots = sys.argv[1:] or ["1440x900:dark", "390x844:light"]
with sync_playwright() as p:
    b = p.chromium.launch()
    for spec in shots:
        size, theme = spec.split(":")
        W, H = map(int, size.split("x"))
        ctx = b.new_context(viewport={"width": W, "height": H}, device_scale_factor=2 if W < 600 else 1)
        ctx.add_init_script(f"localStorage.setItem('yt-theme','{theme}')")
        pg = ctx.new_page()
        errs = []
        pg.on("console", lambda m: m.type in ("error", "warning") and errs.append(m.text))
        pg.on("pageerror", lambda e: errs.append("PAGEERR " + str(e)))
        pg.on("requestfailed", lambda r: errs.append("REQFAIL " + r.url))
        pg.goto(url); pg.wait_for_timeout(1500)
        tag = f"{W}-{theme}"
        pg.screenshot(path=f"{root}/.shots/{tag}-hero.png")
        # 滚动触发进场动画
        h = pg.evaluate("document.documentElement.scrollHeight")
        y = 0
        while y < h:
            pg.evaluate(f"window.scrollTo(0,{y})"); pg.wait_for_timeout(120); y += H // 2
            h = pg.evaluate("document.documentElement.scrollHeight")
        pg.wait_for_timeout(1200)
        pg.evaluate("document.querySelectorAll('.rv').forEach(e=>e.classList.add('in'))")
        pg.wait_for_timeout(1000)
        ov = pg.evaluate("""() => { const W = document.documentElement.clientWidth; const bad=[];
          document.querySelectorAll('body *').forEach(e=>{ const r=e.getBoundingClientRect(); if(r.width>0 && (r.right>W+1 || r.left<-1)) { let p=e, clipped=false; while(p=p.parentElement){ const cs=getComputedStyle(p); if(['hidden','clip'].includes(cs.overflowX) && p!==document.body && p!==document.documentElement){clipped=true;break;} } if(!clipped) bad.push(e.tagName+'.'+(e.className&&e.className.baseVal===undefined?String(e.className).slice(0,60):'')+' '+Math.round(r.left)+'→'+Math.round(r.right)); }});
          return {sw: document.documentElement.scrollWidth, cw: W, bad: bad.slice(0,15)} }""")
        text = norm(pg.evaluate("document.body.innerText") + pg.evaluate("Array.from(document.querySelectorAll('[aria-label], img[alt]')).map(e=>e.getAttribute('aria-label')||e.alt).join(' ')"))
        missing = [a for a in atoms(md) if norm(a) not in text]
        print(f"== {tag}: scrollW {ov['sw']} clientW {ov['cw']} overflow-els {len(ov['bad'])}")
        for x in ov["bad"]: print("   OVF", x)
        print("   errors:", errs[:10])
        print(f"   text atoms missing: {len(missing)} / {len(atoms(md))}")
        for m in missing[:20]: print("   MISSING:", m[:90])
        total = pg.evaluate("document.documentElement.scrollHeight")
        pg.evaluate("window.scrollTo(0,0)"); pg.wait_for_timeout(300)
        pg.screenshot(path=f"{root}/.shots/{tag}-full.png", full_page=True)
        print("   height", total)
        ctx.close()
    b.close()
