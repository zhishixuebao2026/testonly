import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const read = (path) => readFileSync(resolve(root, path), "utf8");
const manifest = read("src/lib/media.ts");
const html = read("dist/index.html");
const imports = [...manifest.matchAll(/import\s+\w+\s+from\s+"([^"?]+)\?inline"/g)];

assert.equal(imports.length, 7, "All seven illustrations must be explicit inline imports.");
for (const [, path] of imports) {
  const bytes = readFileSync(resolve(root, "src/lib", path));
  assert.equal(bytes.subarray(0, 3).toString("hex"), "ffd8ff", `Invalid JPEG: ${path}`);
  const uri = `data:image/jpeg;base64,${bytes.toString("base64")}`;
  assert.ok(html.includes(uri), `Image not embedded in dist/index.html: ${path}`);
}

const fontUris = [...read("src/lib/font-data.ts").matchAll(/data:font\/woff2;base64,([A-Za-z0-9+/=]+)/g)];
assert.equal(fontUris.length, 4, "All four local font subsets must be embedded.");
for (const [uri, base64] of fontUris) {
  assert.equal(Buffer.from(base64, "base64").subarray(0, 4).toString(), "wOF2", "Invalid WOFF2 data.");
  assert.ok(html.includes(uri), "Font not embedded in dist/index.html.");
}

assert.ok(!/\.\/images\/[^"\s]+\.webp/.test(html), "Stale WebP reference remains.");
assert.ok(!/src:url\("\.\/fonts\//.test(html), "External font reference remains.");
console.log("Verified: 7 JPEG illustrations and 4 WOFF2 fonts are embedded in dist/index.html.");