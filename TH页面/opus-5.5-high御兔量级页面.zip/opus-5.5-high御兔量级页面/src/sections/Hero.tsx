import { useState } from "react";
import HeroCanvas, { type HeroLayout } from "../components/HeroCanvas";
import { doc } from "../lib/doc";
import type { Theme } from "../lib/hooks";
import { I } from "../lib/inline";

function toPx(p: [number, number], w: number, h: number): [number, number] {
  return [w / 2 + p[0] * h, h / 2 - p[1] * h];
}

export default function Hero({ theme }: { theme: Theme }) {
  const [geo, setGeo] = useState<{ L: HeroLayout; w: number; h: number } | null>(null);
  const titleMatch = doc.title.match(/^(.+?)(（.*）)$/);
  const name = titleMatch ? titleMatch[1] : doc.title;
  const work = titleMatch ? titleMatch[2] : "";
  const metas = doc.quote.split(" · ");

  let trail: string | null = null;
  let hud: { moon: [number, number]; fire: [number, number]; mid: [number, number]; r: number } | null = null;
  if (geo) {
    const { L, w, h } = geo;
    const s = toPx(L.start, w, h),
      c = toPx(L.ctrl, w, h),
      e = toPx(L.end, w, h);
    trail = `M${s[0].toFixed(1)},${s[1].toFixed(1)} Q${c[0].toFixed(1)},${c[1].toFixed(1)} ${e[0].toFixed(1)},${e[1].toFixed(1)}`;
    const mid: [number, number] = [0.25 * s[0] + 0.5 * c[0] + 0.25 * e[0], 0.25 * s[1] + 0.5 * c[1] + 0.25 * e[1]];
    hud = { moon: toPx([L.moon[0], L.moon[1]], w, h), fire: toPx(L.fire, w, h), mid, r: L.moon[2] * h };
  }

  return (
    <section id="top" className="relative isolate flex min-h-[100svh] flex-col overflow-hidden" aria-label="封面">
      <HeroCanvas theme={theme} onLayout={(L, w, h) => setGeo({ L, w, h })} />

      {geo && trail && hud && (
        <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox={`0 0 ${geo.w} ${geo.h}`} aria-hidden="true">
          <defs>
            <linearGradient id="trailG" x1="0" y1="1" x2="1" y2="0">
              <stop offset="0" stopColor="var(--fire)" stopOpacity="0" />
              <stop offset="0.5" stopColor="var(--fire2)" stopOpacity="0.9" />
              <stop offset="1" stopColor="var(--moon)" stopOpacity="1" />
            </linearGradient>
            <filter id="trailBlur" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="5" />
            </filter>
          </defs>
          <path d={trail} fill="none" stroke="var(--line2)" strokeWidth="1" strokeDasharray="2 6" />
          <path
            d={trail}
            fill="none"
            stroke="var(--fire)"
            strokeWidth="9"
            strokeLinecap="round"
            pathLength={1000}
            strokeDasharray="140 1000"
            filter="url(#trailBlur)"
            opacity="0.85"
            style={{ animation: "trailrun 5s cubic-bezier(.5,0,.3,1) infinite" }}
          />
          <path
            d={trail}
            fill="none"
            stroke="url(#trailG)"
            strokeWidth="3"
            strokeLinecap="round"
            pathLength={1000}
            strokeDasharray="140 1000"
            style={{ animation: "trailrun 5s cubic-bezier(.5,0,.3,1) infinite" }}
          />
          <style>{`@keyframes trailrun{0%{stroke-dashoffset:140}88%{stroke-dashoffset:-1000}100%{stroke-dashoffset:-1000}}`}</style>
          {/* HUD 标注 */}
          <g className="hidden sm:block" fontFamily="var(--font-mono)" fontSize="10.5" fill="var(--ink3)" letterSpacing="1.5">
            <circle cx={hud.moon[0]} cy={hud.moon[1]} r={hud.r + 14} fill="none" stroke="var(--line2)" strokeDasharray="1 5" />
            {hud.moon[1] - hud.r * 0.74 - 42 > 96 && (<g><line x1={hud.moon[0] - hud.r * 0.74} y1={hud.moon[1] - hud.r * 0.74} x2={hud.moon[0] - hud.r * 0.74 - 36} y2={hud.moon[1] - hud.r * 0.74 - 36} stroke="var(--line2)" />
            <text x={hud.moon[0] - hud.r * 0.74 - 40} y={hud.moon[1] - hud.r * 0.74 - 42} textAnchor="end">
              MOON · 月宫玉兔
            </text></g>)}
            <text x={hud.mid[0] + 14} y={hud.mid[1]} fill="var(--fire)">
              ≈0.23～0.27 c
            </text>
            <circle cx={hud.fire[0]} cy={hud.fire[1]} r="16" fill="none" stroke="var(--fire)" strokeOpacity=".6" />
            <line x1={hud.fire[0] - 12} y1={hud.fire[1] - 12} x2={hud.fire[0] - 52} y2={hud.fire[1] - 52} stroke="var(--line2)" />
            <text x={hud.fire[0] - 56} y={hud.fire[1] - 58} textAnchor="end">
              终局起爆点 · 地球夜侧
            </text>
          </g>
        </svg>
      )}

      {/* 竖排宣传语 */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-[4.5%] top-[18%] hidden font-serif text-[1.05rem] tracking-[0.5em] text-ink3 lg:block"
        style={{ writingMode: "vertical-rl" }}
      >
        吃着萝卜就把人打上月球的筋肉兄贵御兔
      </div>

      <div className="relative z-10 mx-auto flex w-full max-w-[1320px] flex-1 flex-col justify-end px-5 pb-[max(4.5rem,9svh)] pt-28 sm:px-8 lg:justify-center lg:pb-24">
        <div className="max-w-[44rem]">
          <div className="rv in flex flex-wrap items-center gap-x-2 gap-y-1 text-[0.8rem] text-ink2" style={{ ["--d" as string]: "0.1s" }}>
            {metas.map((m, i) => (
              <span key={i} className="inline-flex items-center gap-2">
                {i > 0 && <span className="text-fire"> · </span>}
                <span className={i === 0 ? "rounded-full border border-line px-2.5 py-0.5 text-ink" : ""}>{m}</span>
              </span>
            ))}
          </div>

          <h1 className="mt-6 sm:mt-8">
            <span
              className="block font-brush leading-[0.86] text-ink"
              style={{ fontSize: "clamp(6.2rem, 3rem + 15vw, 13.5rem)", textShadow: theme === "dark" ? "0 0 60px rgba(255,190,110,.18)" : "none" }}
            >
              {name}
            </span>
            <span className="mt-3 block font-serif font-bold tracking-[0.06em] text-ink2" style={{ fontSize: "clamp(1.35rem, 1rem + 1.6vw, 2.1rem)" }}>
              {work}
            </span>
          </h1>

          <div className="mt-8 grid max-w-[34rem] grid-cols-2 gap-3">
            <a href="#rating" className="card ticks group block overflow-hidden p-4 transition hover:-translate-y-0.5">
              <span className="label">综合量级</span>
              <span className="glyph mt-1 block whitespace-nowrap font-serif text-[min(clamp(1.45rem,1.1rem+1.6vw,2.2rem),7.2vw)] font-black leading-tight">
                <I text="⊙国△〔实〕" />
              </span>
              <span className="mt-1 block text-[0.78rem] text-ink3">强爆国级</span>
              <span aria-hidden="true" className="absolute -right-6 -top-6 h-20 w-20 rounded-full opacity-40 blur-2xl" style={{ background: "var(--fire)" }} />
            </a>
            <a href="#rating" className="card group block overflow-hidden p-4 transition hover:-translate-y-0.5">
              <span className="label">保底量级</span>
              <span className="glyph mt-1 block whitespace-nowrap font-serif text-[min(clamp(1.45rem,1.1rem+1.6vw,2.2rem),7.2vw)] font-black leading-tight">
                <I text="⊙城△〔实〕" />
              </span>
              <span className="mt-1 block text-[0.78rem] text-ink3">强爆城级</span>
              <span aria-hidden="true" className="absolute -right-6 -top-6 h-20 w-20 rounded-full opacity-30 blur-2xl" style={{ background: "var(--moon)" }} />
            </a>
          </div>
        </div>
      </div>

      <a href="#work" className="absolute bottom-5 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-2 text-ink3 hover:text-ink" aria-label="向下阅读">
        <span className="kicker !text-[0.58rem]">Scroll</span>
        <span className="relative h-9 w-px overflow-hidden bg-line">
          <span className="absolute inset-x-0 top-0 h-1/3 bg-fire" style={{ animation: "cue 1.8s ease-in-out infinite" }} />
        </span>
      </a>
    </section>
  );
}
