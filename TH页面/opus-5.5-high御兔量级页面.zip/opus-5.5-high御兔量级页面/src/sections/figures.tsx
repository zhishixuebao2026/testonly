import { useEffect, useMemo, useState, type ReactNode } from "react";
import { fmtE } from "../components/ui";
import { I } from "../lib/inline";

/* ---------------- 工具 ---------------- */
const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹";
export function parseE(s: string): number {
  const m = s.match(/(\d+(?:\.\d+)?)×10([⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+)/);
  if (!m) return parseFloat(s);
  const exp = m[2]
    .split("")
    .map((c) => (c === "⁻" ? "-" : String(SUP.indexOf(c))))
    .join("");
  return parseFloat(m[1]) * Math.pow(10, parseInt(exp, 10));
}
const lg = Math.log10;

/* ---------------- 轨道帧重建 ---------------- */
export const CENTERS: Record<number, [number, number]> = { 650: [94, 638], 620: [106, 610], 500: [164, 504] };
const PTS: [number, number][] = [
  [300, 22],
  [350, 40],
  [400, 65],
  [450, 95],
  [478, 113],
];
const FB: [number, number] = [235, 150];

function FrameSvg({ R, w, mode, caption, id }: { R: number; w: number; mode: "ignite" | "measure"; caption: string; id: string }) {
  const [cx, cy] = CENTERS[R] ?? CENTERS[650];
  const half = w / 2;
  return (
        <svg viewBox="-24 -16 528 306" className="block h-auto w-full" role="img" aria-label={caption}>
          <defs>
            <clipPath id={`${id}c`}>
              <rect x="0" y="0" width="480" height="270" />
            </clipPath>
            <radialGradient id={`${id}e`} cx={cx} cy={cy} r={R} gradientUnits="userSpaceOnUse">
              <stop offset="0.82" stopColor="var(--fig-earth)" />
              <stop offset="0.985" stopColor="color-mix(in oklab, var(--fig-earth) 70%, var(--fig-line))" />
              <stop offset="1" stopColor="var(--fig-line)" stopOpacity="0.9" />
            </radialGradient>
            <radialGradient id={`${id}f`}>
              <stop offset="0" stopColor="#fffbe8" />
              <stop offset="0.35" stopColor="#ffd27a" />
              <stop offset="0.75" stopColor="#ff7a2c" stopOpacity="0.9" />
              <stop offset="1" stopColor="#ff5a1f" stopOpacity="0.15" />
            </radialGradient>
            <pattern id={`${id}g`} width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M30 0H0V30" fill="none" stroke="var(--fig-grid)" strokeWidth="1" />
            </pattern>
            <filter id={`${id}b`} x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="6" />
            </filter>
          </defs>
          {/* 标尺 */}
          <g fontFamily="var(--font-mono)" fontSize="7.5" fill="var(--fig-text)" opacity="0.75">
            {[0, 60, 120, 180, 240, 300, 360, 420, 480].map((x) => (
              <g key={x}>
                <line x1={x} y1={-5} x2={x} y2={0} stroke="var(--fig-text)" />
                <text x={x} y={-8} textAnchor="middle">
                  {x}
                </text>
              </g>
            ))}
            {[0, 60, 120, 180, 240].map((y) => (
              <g key={y}>
                <line x1={-5} y1={y} x2={0} y2={y} stroke="var(--fig-text)" />
                <text x={-8} y={y + 2.5} textAnchor="end">
                  {y}
                </text>
              </g>
            ))}
          </g>
          <g clipPath={`url(#${id}c)`}>
            <rect width="480" height="270" fill="var(--fig-bg)" />
            <rect width="480" height="270" fill={`url(#${id}g)`} />
            {/* 星点 */}
            {[
              [330, 8],
              [420, 30],
              [455, 12],
              [470, 60],
              [395, 18],
              [440, 75],
            ].map(([x, y], i) => (
              <circle key={i} cx={x} cy={y} r="0.9" fill="var(--fig-text)" opacity="0.6" />
            ))}
            {/* 地球 */}
            <circle cx={cx} cy={cy} r={R + 6} fill="none" stroke="var(--fig-line)" strokeOpacity="0.35" strokeWidth="10" filter={`url(#${id}b)`} />
            <circle cx={cx} cy={cy} r={R} fill={`url(#${id}e)`} style={{ transition: "all .6s" }} />
            {/* 其他拟合圆弧 */}
            {Object.entries(CENTERS).map(([rr, [x, y]]) =>
              +rr === R ? null : <circle key={rr} cx={x} cy={y} r={+rr} fill="none" stroke="var(--fig-line)" strokeOpacity="0.45" strokeDasharray="3 4" />,
            )}
            <circle cx={cx} cy={cy} r={R} fill="none" stroke="var(--fig-line)" strokeWidth="1.4" />
            {/* 夜侧灯光示意 */}
            <g fill="#ffcf7a" opacity="0.55">
              {[
                [120, 210],
                [140, 230],
                [96, 190],
                [330, 200],
                [350, 230],
                [300, 250],
                [70, 120],
                [60, 160],
                [380, 180],
              ].map(([x, y], i) => (
                <circle key={i} cx={x} cy={y} r="1.1" />
              ))}
            </g>
            {/* 火球 / 起爆点 */}
            {mode === "ignite" ? (
              <g>
                <circle cx={FB[0]} cy={FB[1]} r="20" fill="#ff7a2c" opacity="0.35" filter={`url(#${id}b)`} />
                <circle cx={FB[0]} cy={FB[1]} r="10" fill={`url(#${id}f)`} />
                <circle cx={FB[0]} cy={FB[1]} r="22" fill="none" stroke="var(--fire)" strokeDasharray="2 3" />
                {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
                  <line
                    key={a}
                    x1={FB[0] + Math.cos((a * Math.PI) / 180) * 12}
                    y1={FB[1] + Math.sin((a * Math.PI) / 180) * 12}
                    x2={FB[0] + Math.cos((a * Math.PI) / 180) * (a % 90 ? 18 : 26)}
                    y2={FB[1] + Math.sin((a * Math.PI) / 180) * (a % 90 ? 18 : 26)}
                    stroke="#ffd27a"
                    strokeWidth="1.2"
                  />
                ))}
                <text x={FB[0] + 30} y={FB[1] + 4} fontSize="10" fill="var(--fire)" fontFamily="var(--font-sans)">
                  起爆点
                </text>
              </g>
            ) : (
              <g>
                <circle cx={FB[0]} cy={FB[1]} r={half + 10} fill="#ff7a2c" opacity="0.18" filter={`url(#${id}b)`} />
                <circle cx={FB[0]} cy={FB[1]} r={half} fill={`url(#${id}f)`} style={{ transition: "r .5s" }} />
                <circle cx={FB[0] - half * 0.3} cy={FB[1] - half * 0.32} r={half * 0.45} fill="#fffbe8" opacity="0.25" />
                <line x1={FB[0] - half} y1={FB[1]} x2={FB[0] - half} y2={258} stroke="var(--fire)" strokeDasharray="3 3" />
                <line x1={FB[0] + half} y1={FB[1]} x2={FB[0] + half} y2={258} stroke="var(--fire)" strokeDasharray="3 3" />
                <path d={`M${FB[0] - half} 256 L${FB[0] + half} 256 M${FB[0] - half + 5} 252 L${FB[0] - half} 256 L${FB[0] - half + 5} 260 M${FB[0] + half - 5} 252 L${FB[0] + half} 256 L${FB[0] + half - 5} 260`} stroke="var(--fire)" strokeWidth="1.5" fill="none" />
                <text x={FB[0] + half + 6} y={259} fontSize="10" fill="var(--fire)" fontFamily="var(--font-mono)">
                  {w} px
                </text>
              </g>
            )}
            {/* 五个拟合点 */}
            {PTS.map(([x, y], i) => (
              <g key={i}>
                <circle cx={x} cy={y} r="4.5" fill="none" stroke="var(--fire)" strokeWidth="1.3" />
                <path d={`M${x - 8} ${y}h5M${x + 3} ${y}h5M${x} ${y - 8}v5M${x} ${y + 3}v5`} stroke="var(--fire)" strokeWidth="1" />
                <text x={x - 8} y={y + 16} fontSize="10" textAnchor="end" fill="var(--fig-text)" fontFamily="var(--font-mono)" paintOrder="stroke" stroke="var(--fig-earth)" strokeWidth="3">
                  ({x}, {y})
                </text>
              </g>
            ))}
          </g>
          <rect x="0" y="0" width="480" height="270" fill="none" stroke="var(--fig-text)" strokeOpacity="0.5" />
          <g fontFamily="var(--font-mono)" fontSize="8.5" fill="var(--fig-text)">
            <text x="0" y="282">480×270 px · 原帧坐标</text>
            <text x="480" y="282" textAnchor="end">
              R ≈ {R} px · 圆心 ({cx}, {cy})
            </text>
          </g>
        </svg>
  );
}

export function OrbitFigure({ R, w, mode, caption, idx }: { R: number; w: number; mode: "ignite" | "measure"; caption: string; idx: number }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", k);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", k);
      document.body.style.overflow = prev;
    };
  }, [open]);
  return (
    <figure className="card overflow-hidden !rounded-2xl">
      <div className="relative" style={{ background: "var(--fig-bg)" }}>
        <FrameSvg R={R} w={w} mode={mode} caption={caption} id={`of${idx}`} />
      </div>
      {open && (
        <div className="fixed inset-0 z-[90] grid place-items-center p-3" style={{ background: "rgba(3,5,10,.88)" }} onClick={() => setOpen(false)} role="dialog" aria-modal="true" aria-label={caption}>
          <div className="lb-rot overflow-hidden rounded-xl border border-line" style={{ background: "var(--fig-bg)" }} onClick={(e) => e.stopPropagation()}>
            <FrameSvg R={R} w={w} mode={mode} caption={caption} id={`ofl${idx}`} />
            <div className="flex items-center justify-between gap-3 border-t border-line px-3 py-2">
              <span className="font-serif text-[0.9rem] font-bold text-ink">{caption}</span>
              <button onClick={() => setOpen(false)} className="rounded-full border border-line px-3 py-1 text-[0.8rem] text-ink2" autoFocus>
                关闭
              </button>
            </div>
          </div>
        </div>
      )}
      <figcaption className="flex flex-col gap-1 border-t border-line px-4 py-3 sm:flex-row sm:items-baseline sm:justify-between sm:gap-4">
        <span className="font-serif text-[0.95rem] font-bold text-ink">{caption}</span>
        <span className="flex items-center justify-between gap-3">
          <span className="text-[0.72rem] text-ink3">示意重建：原图未随条目提供，按正文坐标与像素尺寸绘制</span>
        <button
          onClick={() => setOpen(true)}
          className="flex shrink-0 items-center gap-1.5 rounded-full border border-line px-2.5 py-1 text-[0.72rem] text-ink2 transition hover:text-ink"
          style={{ background: "color-mix(in oklab, var(--fig-bg) 70%, transparent)" }}
          aria-label={`放大查看：${caption}`}
        >
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
          </svg>
          放大
        </button>
        </span>
      </figcaption>
    </figure>
  );
}

/* ---------------- 火球换算网格 ---------------- */
export function FireballGrid({ head, rows, R, w, onPick }: { head: string[]; rows: string[][]; R: number; w: number; onPick: (R: number, w: number) => void }) {
  const ws = [180, 190];
  const max = 2421;
  return (
    <div className="card p-4 sm:p-6">
      <div className="mb-4 grid grid-cols-[4.6rem_minmax(0,1fr)_minmax(0,1fr)] gap-2 sm:grid-cols-[7rem_minmax(0,1fr)_minmax(0,1fr)] sm:gap-3">
        <span className="label wrap-any !text-[0.7rem]">{head[0]}</span>
        <span className="label wrap-any !text-[0.7rem]">{head[1]}</span>
        <span className="label wrap-any !text-[0.7rem]">{head[2]}</span>
      </div>
      <div className="space-y-2.5">
        {rows.map((r, i) => {
          const rr = parseInt(r[0], 10);
          return (
            <div key={i} className="grid grid-cols-[4.6rem_minmax(0,1fr)_minmax(0,1fr)] items-stretch gap-2 sm:grid-cols-[7rem_minmax(0,1fr)_minmax(0,1fr)] sm:gap-3">
              <div className="flex items-center font-mono text-[0.85rem] text-ink2">{r[0]}</div>
              {[r[1], r[2]].map((c, j) => {
                const km = parseInt(c, 10);
                const on = rr === R && ws[j] === w;
                return (
                  <button
                    key={j}
                    onClick={() => onPick(rr, ws[j])}
                    aria-pressed={on}
                    className="relative overflow-hidden rounded-xl border px-3 py-2.5 text-left transition"
                    style={{ borderColor: on ? "var(--fire)" : "var(--line)", background: on ? "color-mix(in oklab, var(--fire) 10%, transparent)" : "var(--panel2)" }}
                  >
                    <span className="relative z-10 block font-mono text-[0.95rem] font-semibold text-ink sm:text-[1.05rem]">{c}</span>
                    <span className="absolute bottom-0 left-0 h-[3px] rounded-full transition-all" style={{ width: `${(km / max) * 100}%`, background: on ? "var(--fire)" : "var(--line2)" }} />
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>
      <p className="mt-4 text-[0.75rem] text-ink3">点选任一格，上方重建帧随之切换地球轮廓半径与火球宽度。</p>
    </div>
  );
}

/* ---------------- 地月距离 ---------------- */
export function EarthMoon() {
  return (
    <div className="card relative overflow-hidden p-5 sm:p-7" aria-hidden="true">
      <div className="flex items-center justify-between kicker">
        <span>Earth</span>
        <span>单程 ≈ 5 s</span>
        <span>Moon</span>
      </div>
      <div className="relative mt-6 flex items-center">
        <span className="relative z-10 h-14 w-14 shrink-0 rounded-full sm:h-16 sm:w-16" style={{ background: "radial-gradient(circle at 35% 35%, #8cc0ff, #1d4b9a 55%, #0b1b40)", boxShadow: "0 0 30px rgba(110,170,255,.35)" }} />
        <div className="relative mx-2 h-10 flex-1">
          <div className="absolute inset-x-0 top-1/2 h-px" style={{ background: "repeating-linear-gradient(90deg,var(--line2) 0 5px,transparent 5px 10px)" }} />
          <div className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full" style={{ background: "var(--fire)", boxShadow: "0 0 14px 4px var(--fire)", animation: "travel 5s linear infinite" }} />
          <div className="absolute top-1/2 h-px -translate-y-1/2" style={{ left: 0, width: "100%", background: "linear-gradient(90deg, transparent, var(--fire))", opacity: 0.25 }} />
        </div>
        <span className="relative z-10 h-6 w-6 shrink-0 rounded-full sm:h-7 sm:w-7" style={{ background: "radial-gradient(circle at 35% 35%, #fff7de, #bba272 70%)" }} />
      </div>
      <div className="mt-5 grid grid-cols-2 gap-3 text-[0.82rem]">
        <div className="rounded-lg border border-line p-3">
          <div className="label">近地点 · 地表到月面</div>
          <div className="mt-1 font-mono text-ink">348300 km</div>
        </div>
        <div className="rounded-lg border border-line p-3 text-right">
          <div className="label">远地点 · 地表到月面</div>
          <div className="mt-1 font-mono text-ink">398600 km</div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- 动能矩阵 ---------------- */
const T_CHENG_TRI = 1.46e17,
  T_CHENG_STAR = 4.18e18;
export function KEMatrix({ head, rows }: { head: string[]; rows: string[][] }) {
  const lo = 1e17,
    hi = T_CHENG_STAR;
  const pos = (v: number) => ((lg(v) - lg(lo)) / (lg(hi) - lg(lo))) * 100;
  return (
    <div className="space-y-4">
      {rows.map((r, i) => (
        <article key={i} className="card p-4 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <span className="label">{head[0]}</span>
              <div className="font-serif text-[1.15rem] font-bold text-ink">{r[0]}</div>
            </div>
            <div className="text-right">
              <span className="label">{head[1]}</span>
              <div className="font-mono text-[1rem] text-fire">{r[1]}</div>
            </div>
          </div>
          <div className="mt-4 grid gap-2 sm:grid-cols-3 sm:gap-3">
            {[2, 3, 4].map((k) => {
              const v = parseE(r[k]);
              return (
                <div key={k} className="flex items-center justify-between gap-3 rounded-xl border border-line px-3 py-2.5 sm:block" style={{ background: "var(--panel2)" }}>
                  <span className="label !text-[0.75rem]">{head[k]}</span>
                  <div className="font-mono text-[0.98rem] font-semibold text-ink sm:mt-1">
                    <I text={r[k]} plainNums />
                  </div>
                  <div className="track mt-2 hidden !h-1.5 sm:block">
                    <span className="absolute inset-y-0 left-0 rounded-full" style={{ width: `${pos(v)}%`, background: "linear-gradient(90deg, var(--moon), var(--fire))" }} />
                  </div>
                </div>
              );
            })}
          </div>
        </article>
      ))}
      <div className="px-1" aria-hidden="true">
        <div className="relative h-8">
          <div className="track absolute inset-x-0 top-1/2 -translate-y-1/2 !h-1.5" />
          {[
            { v: T_CHENG_TRI, t: "城△ 1.46×10¹⁷" },
            { v: T_CHENG_STAR, t: "城☆ 4.18×10¹⁸" },
          ].map((m) => (
            <span key={m.t} className="absolute top-0 h-full w-px bg-fire" style={{ left: `${pos(m.v)}%` }}>
              <span className={`absolute top-full mt-1 whitespace-nowrap font-mono text-[0.66rem] text-ink3 ${pos(m.v) > 80 ? "right-0" : "left-0"}`}>{m.t}</span>
            </span>
          ))}
          <span className="absolute top-1/2 h-3 -translate-y-1/2 rounded-full" style={{ left: `${pos(1.77e17)}%`, width: `${pos(3.36e17) - pos(1.77e17)}%`, background: "var(--fire)", boxShadow: "0 0 10px var(--fire)" }} />
        </div>
        <div className="mt-6 text-[0.7rem] text-ink3">条带：上表六格的分布（对数刻度，起点 10¹⁷ J）</div>
      </div>
    </div>
  );
}

/* ---------------- 交互复算 ---------------- */
const C = 299792458;
export function Calculator() {
  const [t, setT] = useState(5);
  const [m, setM] = useState(80);
  const [far, setFar] = useState(false);
  const d = far ? 398600e3 : 348300e3;
  const r = useMemo(() => {
    const v = d / t;
    const b = v / C;
    const g = 1 / Math.sqrt(1 - b * b);
    const ke = (g - 1) * m * C * C;
    let tier = "城○ 以下";
    if (ke >= 4.184e18) tier = "城☆ 以上";
    else if (ke >= 1.4644e17) tier = "城△（强爆城级）";
    else if (ke >= 3.0334e16) tier = "城○（标准爆城级）";
    return { v, b, g, ke, tier };
  }, [d, t, m]);
  const lo = 1e16,
    hi = 1e19;
  const pos = (v: number) => Math.min(100, Math.max(0, ((lg(v) - lg(lo)) / (lg(hi) - lg(lo))) * 100));
  const pct = (v: number, a: number, b: number) => `${((v - a) / (b - a)) * 100}%`;
  return (
    <div className="card ticks relative overflow-hidden p-5 sm:p-7">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="kicker !text-fire">Interactive · 交互复算</span>
        <span className="rounded-full border border-dashed border-line px-2.5 py-0.5 text-[0.7rem] text-ink3">页面附加工具 · 非原文内容</span>
      </div>
      <p className="mt-2 text-[0.85rem] text-ink3">按正文给出的公式 E = (γ − 1)mc² 与距离参数自行重算，拖动看结果如何落档。</p>
      <div className="mt-5 grid gap-5 md:grid-cols-2">
        <div className="space-y-4">
          <div>
            <div className="flex items-baseline justify-between">
              <label htmlFor="calc-t" className="label">
                单程时间
              </label>
              <span className="font-mono text-ink">{t.toFixed(1)} s</span>
            </div>
            <input id="calc-t" className="rng" type="range" min={3} max={8} step={0.1} value={t} onChange={(e) => setT(+e.target.value)} style={{ ["--p" as string]: pct(t, 3, 8) }} />
          </div>
          <div>
            <div className="flex items-baseline justify-between">
              <label htmlFor="calc-m" className="label">
                虎力质量
              </label>
              <span className="font-mono text-ink">{m} kg</span>
            </div>
            <input id="calc-m" className="rng" type="range" min={70} max={100} step={1} value={m} onChange={(e) => setM(+e.target.value)} style={{ ["--p" as string]: pct(m, 70, 100) }} />
          </div>
          <div className="grid grid-cols-2 gap-2" role="group" aria-label="距离">
            {[
              { k: false, t: "近地点", s: "348300 km" },
              { k: true, t: "远地点", s: "398600 km" },
            ].map((o) => (
              <button
                key={o.t}
                onClick={() => setFar(o.k)}
                aria-pressed={far === o.k}
                className="rounded-xl border px-3 py-2 text-left transition"
                style={{ borderColor: far === o.k ? "var(--fire)" : "var(--line)", background: far === o.k ? "color-mix(in oklab, var(--fire) 10%, transparent)" : "transparent" }}
              >
                <span className="block text-[0.85rem] font-bold text-ink">{o.t}</span>
                <span className="font-mono text-[0.72rem] text-ink3">{o.s}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2.5 self-start">
          {[
            { k: "速度", v: `${fmtE(r.v)} m/s` },
            { k: "β = v/c", v: r.b.toFixed(3) },
            { k: "γ", v: r.g.toFixed(4) },
            { k: "动能", v: `${fmtE(r.ke)} J`, hot: true },
          ].map((o) => (
            <div key={o.k} className="rounded-xl border border-line p-3" style={{ background: o.hot ? "color-mix(in oklab, var(--fire) 9%, transparent)" : "var(--panel2)" }}>
              <div className="label !text-[0.7rem]">{o.k}</div>
              <div className={`mt-1 font-mono text-[0.95rem] font-semibold ${o.hot ? "text-fire" : "text-ink"}`}>{o.v}</div>
            </div>
          ))}
          <div className="col-span-2 rounded-xl border border-line p-3">
            <div className="flex items-baseline justify-between gap-2">
              <span className="label !text-[0.7rem]">落档</span>
              <span className="font-serif text-[1.05rem] font-black text-ink">{r.tier}</span>
            </div>
            <div className="relative mt-3 h-6">
              <div className="track absolute inset-x-0 top-1/2 -translate-y-1/2 !h-1.5" />
              {[
                { v: 3.0334e16, t: "城○" },
                { v: 1.4644e17, t: "城△" },
                { v: 4.184e18, t: "城☆" },
              ].map((x) => (
                <span key={x.t} className="absolute top-0 h-full w-px bg-ink3" style={{ left: `${pos(x.v)}%` }}>
                  <span className="absolute -top-4 left-1/2 -translate-x-1/2 whitespace-nowrap font-serif text-[0.68rem] font-bold text-ink3">{x.t}</span>
                </span>
              ))}
              <span className="absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 transition-all duration-300" style={{ left: `${pos(r.ke)}%`, borderColor: "var(--fire)", background: "var(--panel-solid)", boxShadow: "0 0 12px var(--fire)" }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- 区间量规 ---------------- */
export function RangeGauge({
  title,
  min,
  max,
  log,
  band,
  marks,
  note,
}: {
  title: ReactNode;
  min: number;
  max: number;
  log?: boolean;
  band: { lo: number; hi: number; label: string };
  marks: { v: number; label: string; tone?: "fire" | "ink" }[];
  note?: ReactNode;
}) {
  const p = (v: number) => (log ? ((lg(v) - lg(min)) / (lg(max) - lg(min))) * 100 : ((v - min) / (max - min)) * 100);
  return (
    <div className="card p-5 sm:p-6" aria-hidden="true">
      <div className="label">{title}</div>
      <div className="relative mb-9 mt-9 h-3">
        <div className="track absolute inset-0 !h-3" />
        <div className="absolute inset-y-0 rounded-full" style={{ left: `${p(band.lo)}%`, width: `${p(band.hi) - p(band.lo)}%`, background: "linear-gradient(90deg, var(--fire2), var(--fire))", boxShadow: "0 0 16px var(--fire)" }} />
        <span className="absolute -top-7 whitespace-nowrap text-[0.74rem] font-bold text-fire" style={{ left: `${(p(band.lo) + p(band.hi)) / 2}%`, transform: "translateX(-50%)" }}>
          {band.label}
        </span>
        {marks.map((m, i) => {
          const x = p(m.v);
          const align = x > 78 ? "right-0" : x < 22 ? "left-0" : "left-1/2 -translate-x-1/2";
          return (
            <span key={i} className="absolute -bottom-2 -top-2 w-0.5" style={{ left: `${x}%`, background: m.tone === "fire" ? "var(--fire)" : "var(--ink2)" }}>
              <span className={`absolute top-full mt-1.5 whitespace-nowrap font-mono text-[0.66rem] text-ink3 ${align}`}>{m.label}</span>
            </span>
          );
        })}
      </div>
      {note && <div className="text-[0.75rem] text-ink3">{note}</div>}
    </div>
  );
}
