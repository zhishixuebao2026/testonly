import { Fragment } from "react";
import { SectionHead, SubHead, fmtE } from "../components/ui";
import { pick, section, splitLead, sub } from "../lib/doc";
import { I } from "../lib/inline";

const LV: Record<string, number> = {
  "城○": 3.03e16,
  "城△": 1.46e17,
  "城☆": 4.18e18,
  "国△": 9.41e21,
  "国☆": 4.81e22,
};

interface Mark {
  lo: number;
  hi: number;
  label: string;
  tone: "fire" | "moon" | "dim";
}
const MARKS: Mark[] = [
  { lo: 1.8e22, hi: 4.7e22, label: "御兔 · 综合量级（每人）", tone: "fire" },
  { lo: 1.8e17, hi: 3.4e17, label: "御兔 · 保底量级", tone: "moon" },
  { lo: 6.7e16, hi: 1.27e17, label: "时间放宽到 8 秒", tone: "dim" },
];

function splitValue(v: string) {
  const sl = splitLead(v);
  if (!sl) return { glyph: "", a: v, b: "" };
  const k = sl.rest.indexOf("；");
  if (k < 0) return { glyph: sl.lead, a: sl.rest, b: "" };
  return { glyph: sl.lead, a: sl.rest.slice(0, k + 1), b: sl.rest.slice(k + 1) };
}

function MainCard({ k, v, tone }: { k: string; v: string; tone: "fire" | "moon" }) {
  const { glyph, a, b } = splitValue(v);
  const kk = splitLead(k)?.lead ?? k;
  const c = tone === "fire" ? "var(--fire)" : "var(--moon)";
  return (
    <article className="card ticks relative overflow-hidden p-5 sm:p-7">
      <div aria-hidden="true" className="pointer-events-none absolute -right-16 -top-20 h-64 w-64 rounded-full opacity-25 blur-3xl" style={{ background: c }} />
      <div aria-hidden="true" className="dots pointer-events-none absolute inset-0 opacity-60" />
      <div className="relative">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ background: c, boxShadow: `0 0 12px ${c}` }} />
          <strong className="label !text-ink2">{kk}</strong>
        </div>
        <div className="glyph mt-3 whitespace-nowrap font-serif font-black leading-none" style={{ fontSize: "min(clamp(2.6rem, 1.6rem + 4vw, 4.4rem), 15vw)" }}>
          <I text={glyph} />
        </div>
        <p className="wrap-any mt-4 text-[1rem] leading-relaxed text-ink">
          <I text={a} />
        </p>
        {b && (
          <p className="wrap-any mt-3 border-l-2 pl-3 text-[0.95rem] leading-relaxed text-ink2" style={{ borderColor: c }}>
            <I text={b} />
          </p>
        )}
      </div>
    </article>
  );
}

const ICONS: Record<string, string> = {
  全力上限: "M4 12c2.5-4 5.5-4 8 0s5.5 4 8 0M4 12c2.5 4 5.5 4 8 0s5.5-4 8 0",
  "速（速度）": "M3 8h10M5 12h14M3 16h9M17 8l4 4-4 4",
  "性（特性）": "M12 3v4M12 17v4M5 12H3M21 12h-2M7 7l-1.5-1.5M18.5 18.5 17 17M7 17l-1.5 1.5M18.5 5.5 17 7M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z",
  横向位置: "M12 4v16M5 8h14M5 8l-2.5 6h5L5 8Zm14 0-2.5 6h5L19 8ZM8 20h8",
};

export default function Rating() {
  const s = section("量级栏");
  const t = pick(s.blocks, "table");
  const note = pick(s.blocks, "p");
  const legend = sub(s, "量级栏用语说明");
  const lt = pick(legend.blocks, "table");
  const rows = t?.rows ?? [];
  const tiers = (lt?.rows ?? []).filter((r) => LV[r[0]] !== undefined).reverse();
  const prefix = (lt?.rows ?? []).find((r) => r[0] === "⊙");
  const tags = (lt?.rows ?? []).filter((r) => /^〔/.test(r[0]));

  return (
    <section id="rating" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Rating · 量级栏" no="03" mark="衡" />
      {t && (
        <div className="kicker rv mb-3">
          {t.head[0]} / {t.head[1]}
        </div>
      )}
      <div className="grid gap-4 lg:grid-cols-2">
        {rows[0] && (
          <div className="rv">
            <MainCard k={rows[0][0]} v={rows[0][1]} tone="fire" />
          </div>
        )}
        {rows[1] && (
          <div className="rv" style={{ ["--d" as string]: ".08s" }}>
            <MainCard k={rows[1][0]} v={rows[1][1]} tone="moon" />
          </div>
        )}
      </div>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        {rows.slice(2).map((r, i) => (
          <article key={i} className="rv card p-5" style={{ ["--d" as string]: `${0.05 * i}s` }}>
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-line text-fire">
                <svg viewBox="0 0 24 24" className="h-[1.1rem] w-[1.1rem]" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                  <path d={ICONS[r[0]] ?? "M5 12h14"} />
                </svg>
              </span>
              <h4 className="font-serif text-[1.1rem] font-bold text-ink">{r[0]}</h4>
            </div>
            <p className="wrap-any mt-3 text-[0.98rem] leading-relaxed text-ink2">
              <I text={r[1]} />
            </p>
          </article>
        ))}
      </div>
      {note && (
        <p className="rv mt-5 flex items-start gap-3 rounded-xl border border-dashed border-line px-4 py-3 text-[0.92rem] text-ink3">
          <span aria-hidden="true" className="mt-[0.15em] font-mono text-fire">∅</span>
          <span>
            <I text={note.text} />
          </span>
        </p>
      )}

      {/* ---------- 用语说明：能量阶梯 ---------- */}
      <SubHead title={legend.title} kicker="Glossary · Energy Ladder" />
      {lt && (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,0.65fr)] lg:gap-10">
          <div className="rv card relative overflow-hidden p-4 sm:p-7">
            <div className="mb-5 flex flex-wrap items-baseline justify-between gap-2">
              <span className="kicker">
                {lt.head[0]} / {lt.head[1]}
              </span>
              <span className="font-mono text-[0.68rem] text-ink3">对数刻度 · 由上至下能量递减</span>
            </div>
            <Ladder tiers={tiers} />
          </div>
          <div className="space-y-4">
            {prefix && (
              <div className="rv card flex items-center gap-4 p-5">
                <span className="font-serif text-[2.6rem] font-black leading-none text-fire">{prefix[0]}</span>
                <span className="text-[0.98rem] text-ink2">
                  <I text={prefix[1]} />
                </span>
              </div>
            )}
            {tags.map((r, i) => (
              <div key={i} className="rv card p-5" style={{ ["--d" as string]: `${0.06 * i}s` }}>
                <div className="text-[1.3rem]">
                  <I text={r[0]} />
                </div>
                <p className="mt-2 text-[0.95rem] leading-relaxed text-ink2">
                  <I text={r[1]} />
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}

function Ladder({ tiers }: { tiers: string[][] }) {
  const lg = Math.log10;
  return (
    <div className="relative">
      {tiers.map((r, i) => {
        const code = r[0];
        const v = LV[code];
        const next = tiers[i + 1];
        const lower = next ? LV[next[0]] : null;
        const decades = lower ? lg(v) - lg(lower) : 0;
        const marks = lower ? MARKS.filter((m) => m.hi <= v && m.lo >= lower) : [];
        const isGuo = code.startsWith("国");
        const h = Math.min(9, Math.max(marks.length ? 7 : 3, decades * 2.6));
        return (
          <Fragment key={code}>
            <div className="relative grid grid-cols-[3.6rem_minmax(0,1fr)] items-center gap-3 sm:grid-cols-[4.6rem_minmax(0,1fr)] sm:gap-5">
              <div className="relative z-10 flex flex-col items-center">
                <span
                  className="grid h-12 w-12 place-items-center rounded-full border-2 font-serif text-[1.15rem] font-black sm:h-14 sm:w-14 sm:text-[1.35rem]"
                  style={{
                    borderColor: isGuo ? "var(--tier-g)" : "var(--tier-c)",
                    color: isGuo ? "var(--tier-g)" : "var(--tier-c)",
                    background: "var(--panel-solid)",
                    boxShadow: `0 0 0 5px var(--panel-solid), 0 0 24px -4px ${isGuo ? "var(--tier-g)" : "transparent"}`,
                  }}
                >
                  {code}
                </span>
              </div>
              <div className="min-w-0 py-1">
                <p className="wrap-any text-[0.98rem] leading-relaxed text-ink">
                  <I text={r[1]} />
                </p>
              </div>
            </div>
            {lower && (
              <div className="relative grid grid-cols-[3.6rem_minmax(0,1fr)] gap-3 sm:grid-cols-[4.6rem_minmax(0,1fr)] sm:gap-5" style={{ height: `${h}rem` }}>
                <div className="relative flex justify-center">
                  <div className="absolute inset-y-0 w-px" style={{ background: "repeating-linear-gradient(180deg, var(--line2) 0 3px, transparent 3px 7px)" }} />
                  {marks.map((m, j) => {
                    const top = (1 - (lg(m.hi) - lg(lower)) / decades) * 100;
                    const bot = (1 - (lg(m.lo) - lg(lower)) / decades) * 100;
                    const c = m.tone === "fire" ? "var(--fire)" : m.tone === "moon" ? "var(--moon)" : "var(--ink3)";
                    return (
                      <div
                        key={j}
                        className="absolute w-2 rounded-full"
                        style={{ top: `${top}%`, height: `max(6px, ${bot - top}%)`, background: c, boxShadow: m.tone !== "dim" ? `0 0 14px ${c}` : "none", left: `calc(50% - 4px + ${j * 0}px)` }}
                      />
                    );
                  })}
                </div>
                <div className="relative min-w-0">
                  <span className="absolute right-0 top-1 font-mono text-[0.66rem] text-ink3">
                    ×{(v / lower).toFixed(v / lower >= 100 ? 0 : 1)}
                    {decades > 2 ? ` · ${decades.toFixed(1)} 个数量级` : ""}
                  </span>
                  {marks.map((m, j) => {
                    const mid = (1 - ((lg(m.hi) + lg(m.lo)) / 2 - lg(lower)) / decades) * 100;
                    const c = m.tone === "fire" ? "var(--fire)" : m.tone === "moon" ? "var(--moon)" : "var(--ink3)";
                    return (
                      <div key={j} className="absolute left-0 right-0 flex -translate-y-1/2 items-center gap-2" style={{ top: `${Math.min(68, Math.max(40, mid))}%` }}>
                        <span className="h-px w-4 shrink-0" style={{ background: c }} />
                        <span className="text-[0.78rem] leading-snug" style={{ color: c }}>
                          {m.label}
                          <span className="block font-mono text-[0.7rem] opacity-80">
                            {fmtE(m.lo, 1)}～{fmtE(m.hi, 1)} J
                          </span>
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </Fragment>
        );
      })}
    </div>
  );
}
