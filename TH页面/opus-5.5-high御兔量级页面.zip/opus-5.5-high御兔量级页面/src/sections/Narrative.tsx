import { SectionHead } from "../components/ui";
import { pick, section, splitLead } from "../lib/doc";
import { I } from "../lib/inline";
import { media } from "../lib/media";

export function Overview() {
  const s = section("概述");
  const ps = s.blocks.filter((b) => b.t === "p") as { t: "p"; text: string }[];
  const first = ps[0]?.text ?? "";
  return (
    <section id="overview" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Abstract · 概述" no="04" mark="概" />
      {first && (
        <p className="rv font-serif text-[clamp(1.2rem,1rem+0.8vw,1.55rem)] leading-[1.9] text-ink">
          <span aria-hidden="true" className="float-left mr-3 mt-1 font-brush text-[4.6em] leading-[0.82] text-fire">
            {first[0]}
          </span>
          <span className="sr-only">{first[0]}</span>
          <I text={first.slice(1)} />
        </p>
      )}
      <div className="clear-both mt-10 grid gap-4 md:grid-cols-2">
        {ps.slice(1).map((p, i) => (
          <article key={i} className="rv card relative overflow-hidden p-6" style={{ ["--d" as string]: `${i * 0.08}s` }}>
            <div className="mb-3 flex items-center justify-between">
              <span className="seal px-2 py-1 text-[1rem]">{i === 0 ? "主档" : "保底"}</span>
              <span className="kicker">{i === 0 ? "Fireball · 终局火球" : "Moon Shot · 一拳上月"}</span>
            </div>
            <p className="prose-yt !text-[1rem]">
              <I text={p.text} />
            </p>
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -bottom-12 -right-12 h-40 w-40 rounded-full opacity-20 blur-2xl"
              style={{ background: i === 0 ? "var(--fire)" : "var(--moon)" }}
            />
          </article>
        ))}
      </div>
    </section>
  );
}

export function Method() {
  const s = section("一、定级方法");
  const p = pick(s.blocks, "p");
  const steps = [
    { k: "逐帧", d: "M4 5h16v14H4zM8 5v14M16 5v14M4 9h4M4 15h4M16 9h4M16 15h4" },
    { k: "弧线拟合", d: "M3 19C7 9 13 5 21 4M6 13.5l.01 0M10 8.8l.01 0M15 6l.01 0M19 4.6l.01 0" },
    { k: "相对论", d: "M12 12m-2 0a2 2 0 1 0 4 0a2 2 0 1 0-4 0M3 12c0-3 4-5 9-5s9 2 9 5-4 5-9 5-9-2-9-5ZM7.5 4.2c2.6-1.5 6.6 1.3 9 5.4s2.3 8.8-.3 10.3" },
  ];
  return (
    <section id="method" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Methodology · 方法" no="05" mark="法" />
      <div className="rv card ticks relative overflow-hidden p-6 sm:p-8">
        <div aria-hidden="true" className="absolute inset-0 opacity-50" style={{ backgroundImage: "linear-gradient(var(--line) 1px, transparent 1px), linear-gradient(90deg, var(--line) 1px, transparent 1px)", backgroundSize: "28px 28px", maskImage: "linear-gradient(90deg, transparent, black 60%)", WebkitMaskImage: "linear-gradient(90deg, transparent, black 60%)" }} />
        <div className="relative grid grid-cols-1 gap-6 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
          {p && (
            <p className="prose-yt min-w-0 !text-[1.05rem] text-ink">
              <I text={p.text} />
            </p>
          )}
          <div aria-hidden="true" className="flex min-w-0 flex-wrap gap-2.5 md:flex-col">
            {steps.map((st, i) => (
              <div key={i} className="flex items-center gap-2 rounded-xl border border-line px-3 py-2" style={{ background: "var(--panel2)" }}>
                <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0 text-cyan" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d={st.d} />
                </svg>
                <span className="whitespace-nowrap text-[0.8rem] text-ink2">{st.k}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function World() {
  const s = section("二、世界观背景");
  const ps = s.blocks.filter((b) => b.t === "p") as { t: "p"; text: string }[];
  return (
    <section id="world" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Setting · 世界观" no="06" mark="界" />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)] lg:items-stretch">
        {ps[0] && (
          <p className="rv prose-yt font-serif !text-[1.15rem] !leading-[2] text-ink">
            <I text={ps[0].text} />
          </p>
        )}
        {ps[1] && (
          <aside className="rv card flex flex-col justify-between gap-5 p-6" style={{ ["--d" as string]: ".1s" }}>
            <div aria-hidden="true" className="flex items-center gap-4">
              <span className="h-12 w-12 rounded-full" style={{ background: "radial-gradient(circle at 35% 35%, #7fb2ff, #16336e 70%)", boxShadow: "0 0 20px rgba(100,160,255,.35)" }} />
              <span className="h-px flex-1" style={{ background: "repeating-linear-gradient(90deg,var(--line2) 0 4px,transparent 4px 8px)" }} />
              <span className="h-7 w-7 rounded-full" style={{ background: "radial-gradient(circle at 35% 35%, #fff6dc, #b9a06a 75%)" }} />
              <span className="font-mono text-[1.6rem] font-bold text-fire">×1</span>
            </div>
            <p className="text-[0.98rem] leading-relaxed text-ink2">
              <I text={ps[1].text} />
            </p>
          </aside>
        )}
      </div>
    </section>
  );
}

const SCENE_IMG = [
  { src: media.sceneMoon, width: 1672, height: 941, alt: "打上月球：虎力出现在画着兔子脸的月球旁（AI 生成的氛围插画）", bubble: "滚到月球去吧", pos: "50% 45%" },
  { src: media.sceneClash, width: 1672, height: 941, alt: "近身交战：二人在城市上空交手（AI 生成的氛围插画）", bubble: "", pos: "45% 40%" },
  { src: media.sceneOrbit, width: 1536, height: 1024, alt: "终局对冲：轨道视角下地球夜侧的发光火球（AI 生成的氛围插画）", bubble: "", pos: "50% 50%" },
  { src: media.sceneAfter, width: 1536, height: 1024, alt: "事后：夜晚的废墟与烟柱，变回玩偶的御兔（AI 生成的氛围插画）", bubble: "兔兔回来了", pos: "40% 60%" },
];
const CLIP = [
  "polygon(0 0, 100% 0, 97% 100%, 0 100%)",
  "polygon(5% 0, 100% 0, 100% 100%, 0 100%)",
  "polygon(0 0, 95% 0, 100% 100%, 0 100%)",
  "polygon(3% 0, 100% 0, 100% 100%, 0 100%)",
];

export function Scenes() {
  const s = section("三、关键场景");
  const ol = pick(s.blocks, "ol");
  const items = ol?.items ?? [];
  return (
    <section id="scenes" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Storyboard · 分镜" no="07" mark="景" />
      <ol className="grid gap-5 lg:grid-cols-6 lg:gap-4">
        {items.map((it, i) => {
          const sl = splitLead(it);
          const img = SCENE_IMG[i];
          const span = i === 0 || i === 3 ? "lg:col-span-4" : "lg:col-span-2";
          return (
            <li key={i} className={`rv group ${span}`} style={{ ["--d" as string]: `${(i % 2) * 0.08}s` }}>
              <article className="card flex h-full flex-col overflow-hidden !rounded-2xl">
                {img && (
                  <div className={`panel-img halftone relative ${i === 0 || i === 3 ? "aspect-[16/9]" : "aspect-[16/9] lg:aspect-[4/5]"} lg:[clip-path:var(--clip)]`} style={{ ["--clip" as string]: CLIP[i] }}>
                    <img src={img.src} alt={img.alt} width={img.width} height={img.height} loading="lazy" decoding="async" style={{ objectPosition: img.pos }} />
                    <span className="absolute left-3 top-2 z-10 font-mono text-[2.4rem] font-bold leading-none text-[#fff3dc] drop-shadow-[0_2px_10px_rgba(0,0,0,.7)]">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    {img.bubble && (
                      <span
                        aria-hidden="true"
                        className="absolute bottom-4 right-4 z-10 rounded-[1.4rem] border-2 border-[#16120c] bg-[#fffaf0] px-4 py-2 font-brush text-[clamp(1.1rem,0.9rem+1vw,1.6rem)] leading-none text-[#16120c] shadow-[4px_4px_0_#16120c]"
                        style={{ transform: "rotate(-3deg)" }}
                      >
                        {img.bubble}
                      </span>
                    )}
                  </div>
                )}
                <div className="flex flex-1 flex-col p-5">
                  {sl ? (
                    <>
                      <h3 className="font-serif text-[1.25rem] font-black text-ink">
                        <strong>{sl.lead}</strong>
                        {sl.rest.startsWith("：") && <span className="sr-only">：</span>}
                      </h3>
                      <p className="wrap-any mt-2 text-[0.98rem] leading-relaxed text-ink2">
                        <I text={sl.rest.replace(/^：/, "")} />
                      </p>
                    </>
                  ) : (
                    <p className="text-ink2">
                      <I text={it} />
                    </p>
                  )}
                </div>
              </article>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
