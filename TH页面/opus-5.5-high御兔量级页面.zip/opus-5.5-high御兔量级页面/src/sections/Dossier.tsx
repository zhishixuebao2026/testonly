import { useState } from "react";
import { KV, SectionHead } from "../components/ui";
import { pick, section } from "../lib/doc";
import { I } from "../lib/inline";
import { media } from "../lib/media";

export function Work() {
  const s = section("作品信息");
  const t = pick(s.blocks, "table");
  return (
    <section id="work" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Work · 作品档案" no="01" mark="作" />
      <figure className="rv panel-img halftone relative -mx-5 aspect-[16/9] overflow-hidden sm:mx-0 sm:aspect-[21/9] sm:rounded-2xl">
        <img src={media.city} alt="科技与仙术并存的城市“非都”（AI 生成的氛围插画）" width={1677} height={938} loading="lazy" decoding="async" />
        <div className="pointer-events-none absolute inset-0" style={{ background: "linear-gradient(180deg, transparent 45%, rgba(7, 9, 17, 0.78) 100%)" }} />
        <figcaption className="absolute bottom-3 left-5 right-5 flex items-end justify-between gap-3 sm:bottom-5 sm:left-6">
          <span className="font-brush text-[clamp(2rem,1.2rem+3vw,3.6rem)] leading-none text-[#fff4dc] drop-shadow-[0_2px_14px_rgba(0,0,0,.6)]">非都</span>
          <span className="kicker !text-[#f2e6cc] drop-shadow">Illustration · AI</span>
        </figcaption>
      </figure>
      {t && (
        <div className="rv mt-8">
          <div className="kicker mb-1">
            {t.head[0]} / {t.head[1]}
          </div>
          <dl className="grid gap-x-10 sm:grid-cols-2">
            {t.rows.map((r, i) => (
              <KV key={i} k={r[0]} wide={r[0] === "类型" || r[0] === "相关动画"}>
                <I text={r[1]} />
              </KV>
            ))}
          </dl>
        </div>
      )}
    </section>
  );
}

export function Character() {
  const s = section("角色信息");
  const t = pick(s.blocks, "table");
  const [buff, setBuff] = useState(true);
  const [flash, setFlash] = useState(0);
  const toggle = () => {
    setBuff((b) => !b);
    setFlash((f) => f + 1);
  };
  return (
    <section id="character" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Character · 角色档案" no="02" mark="兔" />
      <div className="grid items-start gap-8 md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:gap-12">
        <div className="rv md:sticky md:top-24">
          <div className="card ticks overflow-hidden p-2.5">
            <div className="panel-img halftone relative aspect-[4/5] overflow-hidden rounded-[0.8rem]">
              <img
                src={media.rabbitHero}
                alt="暴走形态：肌肉发达的人形兔子（AI 生成的氛围插画）"
                width={1024}
                height={1536}
                loading="eager"
                decoding="async"
                className="absolute inset-0 transition-all duration-700"
                style={{ opacity: buff ? 1 : 0, transform: buff ? "scale(1)" : "scale(1.08)" }}
              />
              <img
                src={media.plush}
                alt="平时形态：兔子玩偶（AI 生成的氛围插画）"
                width={1254}
                height={1254}
                loading="eager"
                decoding="async"
                className="absolute inset-0 transition-all duration-700"
                style={{ opacity: buff ? 0 : 1, transform: buff ? "scale(.94)" : "scale(1)" }}
              />
              {flash > 0 && (
                <div key={flash} className="pointer-events-none absolute inset-0 z-10" style={{ animation: "flash .7s ease-out forwards" }}>
                  <div className="speed-lines absolute inset-0" />
                  <div className="absolute inset-0" style={{ background: "radial-gradient(circle, rgba(255,250,235,.95), rgba(255,200,120,.5) 50%, transparent 75%)" }} />
                </div>
              )}
              <div className="absolute left-3 top-3 z-10 rounded-full px-3 py-1 font-serif text-[0.85rem] font-bold text-[#fff6e3]" style={{ background: "rgba(10,12,22,.62)", backdropFilter: "blur(6px)" }}>
                {buff ? "暴走 · 筋肉形态" : "平时 · 兔子玩偶"}
              </div>
            </div>
            <div className="flex items-center justify-between gap-3 px-2 pb-1 pt-3">
              <div className="flex gap-1.5" aria-hidden="true">
                <span className="h-1.5 w-6 rounded-full transition" style={{ background: !buff ? "var(--fire)" : "var(--line2)" }} />
                <span className="h-1.5 w-6 rounded-full transition" style={{ background: buff ? "var(--fire)" : "var(--line2)" }} />
              </div>
              <button
                onClick={toggle}
                className="group inline-flex items-center gap-2 rounded-full px-4 py-2 text-[0.9rem] font-bold text-white shadow-lg transition active:scale-95"
                style={{ background: "linear-gradient(135deg, var(--fire), var(--fire2))" }}
                aria-pressed={buff}
              >
                <span aria-hidden="true">🥕</span>
                {buff ? "打回玩偶" : "吃萝卜 · 变身"}
              </button>
            </div>
          </div>
          <p className="mt-3 text-center text-[0.75rem] text-ink3">插画为 AI 生成的氛围示意，非官方美术</p>
        </div>

        {t && (
          <div className="rv" style={{ ["--d" as string]: ".1s" }}>
            <div className="kicker mb-1">
              {t.head[0]} / {t.head[1]}
            </div>
            <dl>
              {t.rows.map((r, i) => (
                <KV key={i} k={r[0]}>
                  {r[0] === "名称" ? (
                    <span className="font-serif text-[1.15rem] font-bold">
                      <I text={r[1]} />
                    </span>
                  ) : (
                    <I text={r[1]} />
                  )}
                </KV>
              ))}
            </dl>
          </div>
        )}
      </div>
    </section>
  );
}
