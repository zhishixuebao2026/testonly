import { useState, type ReactNode } from "react";
import { SectionHead } from "../components/ui";
import { section, splitLead, sub, type Block } from "../lib/doc";
import { I } from "../lib/inline";
import { Calculator, EarthMoon, FireballGrid, KEMatrix, OrbitFigure, RangeGauge } from "./figures";

/** "**lead**：rest" → 标题 + 正文，冒号保留在标题末尾（视觉隐藏不删字） */
export function Lead({ text, className = "" }: { text: string; className?: string }) {
  const sl = splitLead(text);
  if (!sl) return <I text={text} />;
  const colon = sl.rest.startsWith("：");
  return (
    <span className={className}>
      <strong className="mr-1.5 inline-block rounded-md px-1.5 py-[0.05em] text-[0.92em]" style={{ background: "color-mix(in oklab, var(--fire) 13%, transparent)", color: "var(--ink)" }}>
        {sl.lead}
        {colon && <span className="sr-only">：</span>}
      </strong>
      <I text={colon ? sl.rest.slice(1) : sl.rest} />
    </span>
  );
}

function Part({ no, text, kicker }: { no: string; text: string; kicker: string }) {
  const sl = splitLead(text);
  const title = sl ? sl.lead : text;
  const m = title.match(/^(\d+)\.\s*(.*)$/);
  return (
    <div className="rv mb-6 mt-16 flex items-center gap-4 first:mt-0">
      <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl font-mono text-[1.5rem] font-bold text-white shadow-lg" style={{ background: no === "1" ? "linear-gradient(135deg,#c9b07a,#8d7440)" : "linear-gradient(135deg,var(--fire2),var(--fire))" }}>
        {m ? m[1] : no}
      </span>
      <div className="min-w-0">
        <div className="kicker">{kicker}</div>
        <h4 className="font-serif text-[clamp(1.3rem,1.05rem+1vw,1.75rem)] font-black leading-tight text-ink">
          <strong>
            {m ? (
              <>
                <span className="sr-only">{m[1]}. </span>
                {m[2]}
              </>
            ) : (
              title
            )}
          </strong>
        </h4>
      </div>
    </div>
  );
}

function P({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <p className={`rv prose-yt ${className}`}>{children}</p>;
}

export default function Analysis() {
  const s = section("四、分维度分析");
  const po = sub(s, "破（破坏力）");
  const su = sub(s, "速（速度）");
  const xi = sub(s, "性（特性）");
  const [R, setR] = useState(650);
  const [w, setW] = useState(180);

  let tableN = 0;
  let ulN = 0;
  let imgN = 0;
  const imgs = po.blocks.filter((b) => b.t === "img") as Extract<Block, { t: "img" }>[];
  const out: ReactNode[] = [];

  po.blocks.forEach((b, i) => {
    const k = `b${i}`;
    if (b.t === "p") {
      const sl = splitLead(b.text);
      if (sl && /^\d+\./.test(sl.lead) && sl.rest === "") {
        const no = sl.lead[0];
        out.push(<Part key={k} no={no} text={b.text} kicker={no === "1" ? "Kinetic · 击飞动能" : "Fireball · 终局火球"} />);
        return;
      }
      if (sl?.lead === "落档") {
        out.push(
          <div key={k} className="rv relative my-8 overflow-hidden rounded-2xl border-2 p-5 sm:p-6" style={{ borderColor: "var(--moon)", background: "color-mix(in oklab, var(--moon) 7%, transparent)" }}>
            <span aria-hidden="true" className="seal absolute right-4 top-4 hidden rotate-6 px-2 py-1 text-[1.4rem] sm:block">
              城△
            </span>
            <p className="wrap-any text-[1.05rem] leading-relaxed text-ink sm:pr-20">
              <Lead text={b.text} />
            </p>
          </div>,
        );
        out.push(
          <div key={k + "calc"} className="rv my-8">
            <Calculator />
          </div>,
        );
        return;
      }
      if (sl?.lead === "换算") {
        out.push(
          <div key={k} className="rv my-6 rounded-2xl border border-line p-5 text-center sm:p-7" style={{ background: "var(--panel2)" }}>
            <p className="wrap-any font-serif text-[clamp(1.05rem,0.95rem+0.6vw,1.4rem)] font-bold leading-relaxed text-ink">
              <Lead text={b.text} />
            </p>
          </div>,
        );
        return;
      }
      if (sl?.lead === "与事后场景的关系") {
        out.push(
          <div key={k} className="rv my-6 flex gap-4 rounded-2xl border border-dashed p-5" style={{ borderColor: "var(--warn)" }}>
            <span aria-hidden="true" className="grid h-9 w-9 shrink-0 place-items-center rounded-full font-serif text-[1.1rem] font-black" style={{ color: "var(--warn)", border: "1.5px solid var(--warn)" }}>
              ?
            </span>
            <p className="prose-yt !text-[1rem]">
              <Lead text={b.text} />
            </p>
          </div>,
        );
        return;
      }
      out.push(
        <P key={k} className="my-5">
          <Lead text={b.text} />
        </P>,
      );
      if (sl?.lead === "破坏能量") {
        out.push(
          <div key={k + "g"} className="rv my-6">
            <RangeGauge
              title="每人分担的破坏能量（对数刻度）"
              min={7e21}
              max={7e22}
              log
              band={{ lo: 1.8e22, hi: 4.7e22, label: "1.8～4.7×10²² J / 人" }}
              marks={[
                { v: 9.41e21, label: "国△ 9.41×10²¹" },
                { v: 4.81e22, label: "国☆ 4.81×10²²", tone: "fire" },
              ]}
              note="上端贴近国☆门槛而不越过。"
            />
          </div>,
        );
      }
      if (sl?.lead === "稳健性") {
        out.push(
          <div key={k + "g"} className="rv my-6">
            <RangeGauge
              title="火球直径 vs. 国△ 门槛（公里）"
              min={1200}
              max={2600}
              band={{ lo: 1764, hi: 2421, label: "实测 1764～2421" }}
              marks={[
                { v: 1430, label: "门槛 ≈1430", tone: "fire" },
                { v: 2600, label: "2600" },
              ]}
              note="实测最低值比门槛高约四分之一（1764 ÷ 1430 ≈ 1.23）。"
            />
          </div>,
        );
      }
      return;
    }
    if (b.t === "ul") {
      const n = ulN++;
      if (n === 0) {
        out.push(
          <div key={k} className="grid gap-6 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)] lg:items-start">
            <ul className="space-y-3">
              {b.items.map((it, j) => (
                <li key={j} className="rv card p-4 sm:p-5" style={{ ["--d" as string]: `${j * 0.04}s` }}>
                  <p className="wrap-any text-[1rem] leading-relaxed text-ink2">
                    <Lead text={it} />
                  </p>
                </li>
              ))}
            </ul>
            <div className="rv lg:sticky lg:top-24">
              <EarthMoon />
            </div>
          </div>,
        );
      } else {
        out.push(
          <ul key={k} className="my-6 grid gap-3 md:grid-cols-2">
            {b.items.map((it, j) => (
              <li key={j} className="rv rounded-2xl border border-line p-4 sm:p-5" style={{ background: "var(--panel2)" }}>
                <p className="wrap-any text-[0.98rem] leading-relaxed text-ink2">
                  <Lead text={it} />
                </p>
              </li>
            ))}
          </ul>,
        );
      }
      return;
    }
    if (b.t === "table") {
      const n = tableN++;
      if (n === 0)
        out.push(
          <div key={k} className="rv my-6">
            <KEMatrix head={b.head} rows={b.rows} />
          </div>,
        );
      else
        out.push(
          <div key={k} className="rv my-6">
            <FireballGrid
              head={b.head}
              rows={b.rows}
              R={R}
              w={w}
              onPick={(r, ww) => {
                setR(r);
                setW(ww);
              }}
            />
          </div>,
        );
      return;
    }
    if (b.t === "img") {
      const n = imgN++;
      if (n === 0) {
        out.push(
          <div key={k} className="rv my-8 grid gap-4 xl:grid-cols-2">
            {imgs.map((im, j) => (
              <OrbitFigure key={j} idx={j} R={R} w={w} mode={j === 0 ? "ignite" : "measure"} caption={im.alt} />
            ))}
          </div>,
        );
      }
      return;
    }
  });

  return (
    <section id="analysis" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Analysis · 分维度" no="08" mark="析" />

      <div className="rv mb-8 flex items-center gap-4">
        <h3 className="h3">{po.title}</h3>
        <span className="h-px flex-1 bg-line" />
        <span className="kicker hidden sm:inline">Destructive Power</span>
      </div>
      {out}

      <div className="mt-20 grid gap-6 lg:grid-cols-2">
        <div>
          <div className="rv mb-5 flex items-center gap-4">
            <h3 className="h3">{su.title}</h3>
            <span className="h-px flex-1 bg-line" />
            <span className="kicker hidden sm:inline">Speed</span>
          </div>
          {su.blocks.map((b, i) =>
            b.t === "p" ? (
              <P key={i}>
                <I text={b.text} />
              </P>
            ) : null,
          )}
          <div className="rv mt-5">
            <RangeGauge
              title="投送速度（光速倍数）"
              min={0}
              max={1}
              band={{ lo: 0.232, hi: 0.266, label: "0.23～0.27 c" }}
              marks={[
                { v: 0, label: "0" },
                { v: 0.5, label: "0.5 c" },
                { v: 1, label: "1 c", tone: "fire" },
              ]}
            />
          </div>
        </div>
        <div>
          <div className="rv mb-5 flex items-center gap-4">
            <h3 className="h3">{xi.title}</h3>
            <span className="h-px flex-1 bg-line" />
            <span className="kicker hidden sm:inline">Traits</span>
          </div>
          {xi.blocks.map((b, i) =>
            b.t === "ul" ? (
              <ul key={i} className="space-y-3">
                {b.items.map((it, j) => (
                  <li key={j} className="rv card flex gap-4 p-4" style={{ ["--d" as string]: `${j * 0.05}s` }}>
                    <span aria-hidden="true" className="text-[1.4rem] leading-none">
                      {["🐰", "🥕", "🧸"][j] ?? "✦"}
                    </span>
                    <p className="wrap-any text-[0.98rem] leading-relaxed text-ink2">
                      <Lead text={it} />
                    </p>
                  </li>
                ))}
              </ul>
            ) : null,
          )}
        </div>
      </div>
    </section>
  );
}
