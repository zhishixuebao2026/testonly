import { SectionHead } from "../components/ui";
import { doc, pick, section, splitLead } from "../lib/doc";
import { I } from "../lib/inline";
import { Lead } from "./Analysis";

export function Verdict() {
  const s = section("五、综合定级");
  const ps = s.blocks.filter((b) => b.t === "p") as { t: "p"; text: string }[];
  const ul = pick(s.blocks, "ul");
  const main = ps[0];
  const why = ps.find((p) => p.text.startsWith("**为什么不到超爆国**"));
  const risk = ps.find((p) => p.text.startsWith("**风险点**"));
  const riskLead = risk ? splitLead(risk.text) : null;
  return (
    <section id="verdict" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Verdict · 判定" no="09" mark="定" />
      <div className="rv card relative overflow-hidden p-6 sm:p-10">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse at 85% 20%, color-mix(in oklab, var(--fire) 22%, transparent), transparent 55%)" }} />
        <div className="relative grid gap-8 md:grid-cols-[minmax(0,1fr)_auto] md:items-center">
          {main && (
            <p className="wrap-any font-serif text-[clamp(1.12rem,1rem+0.6vw,1.4rem)] leading-[1.9] text-ink">
              <I text={main.text} />
            </p>
          )}
          <div aria-hidden="true" className="mx-auto grid place-items-center">
            <div className="seal grid h-40 w-40 rotate-[-8deg] place-items-center p-3 text-center sm:h-48 sm:w-48">
              <div>
                <div className="font-serif text-[2.7rem] font-black leading-none sm:text-[3.2rem]">⊙国△</div>
                <div className="mt-2 text-[1.1rem] tracking-[0.3em]">强爆国级</div>
                <div className="mt-1 font-mono text-[0.6rem] tracking-[0.2em] opacity-80">HENGTIAN · 1026</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {why && (
        <div className="rv mt-5 rounded-2xl border border-line p-5 sm:p-6" style={{ background: "var(--panel2)" }}>
          <p className="prose-yt !text-[1rem]">
            <Lead text={why.text} />
          </p>
        </div>
      )}
      {risk && (
        <div className="rv mb-4 mt-10 flex items-center gap-3">
          <span aria-hidden="true" className="grid h-8 w-8 place-items-center rounded-full font-black" style={{ color: "var(--warn)", border: "1.5px solid var(--warn)" }}>
            !
          </span>
          <h3 className="h3 !text-[1.35rem]">
            <strong>{riskLead?.lead}</strong>
            <span className="text-ink3">{riskLead?.rest}</span>
          </h3>
        </div>
      )}
      {ul && (
        <ol className="grid gap-3 md:grid-cols-2">
          {ul.items.map((it, i) => (
            <li key={i} className="rv card flex gap-4 p-5" style={{ ["--d" as string]: `${i * 0.05}s` }}>
              <span aria-hidden="true" className="font-mono text-[1.6rem] font-bold leading-none" style={{ color: "var(--warn)" }}>
                {String(i + 1).padStart(2, "0")}
              </span>
              <p className="wrap-any text-[0.98rem] leading-relaxed text-ink2">
                <I text={it} />
              </p>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}

export function Compare() {
  const s = section("六、横向比较");
  const t = pick(s.blocks, "table");
  return (
    <section id="compare" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Cross-check · 横向" no="10" mark="比" />
      <div className="grid gap-5 md:grid-cols-2">
        {t?.rows.map((r, i) => {
          const tiger = r[0] === "虎力";
          return (
            <article key={i} className="rv card relative overflow-hidden p-6" style={{ ["--d" as string]: `${i * 0.08}s` }}>
              <div
                aria-hidden="true"
                className="absolute inset-x-0 top-0 h-2"
                style={{
                  background: tiger ? "repeating-linear-gradient(115deg, #e8892c 0 14px, #1a120a 14px 22px)" : "linear-gradient(90deg, transparent, var(--moon), transparent)",
                }}
              />
              <div className="flex items-center gap-4">
                <span
                  aria-hidden="true"
                  className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl font-brush text-[1.9rem] leading-none"
                  style={
                    tiger
                      ? { background: "repeating-linear-gradient(115deg, #f0a040 0 9px, #2a1a0c 9px 14px)", color: "#fff7e8", textShadow: "0 1px 6px #000" }
                      : { background: "radial-gradient(circle at 35% 35%, #fff7de, #c8ae78 70%)", color: "#3a2a10" }
                  }
                >
                  {r[0][0]}
                </span>
                <div>
                  <div className="label">{t.head[0]}</div>
                  <h3 className="font-serif text-[1.6rem] font-black leading-tight text-ink">{r[0]}</h3>
                </div>
              </div>
              <dl className="mt-5 space-y-4">
                <div>
                  <dt className="label">{t.head[1]}</dt>
                  <dd className="wrap-any mt-1 text-[0.98rem] leading-relaxed text-ink2">
                    <I text={r[1]} />
                  </dd>
                </div>
                <div className="border-t border-line pt-4">
                  <dt className="label">{t.head[2]}</dt>
                  <dd className="mt-1 font-serif text-[1.15rem] font-bold text-ink">
                    <I text={r[2]} />
                  </dd>
                </div>
              </dl>
            </article>
          );
        })}
      </div>
    </section>
  );
}

export function Doubts() {
  const s = section("七、存疑与作者矛盾");
  const ol = pick(s.blocks, "ol");
  return (
    <section id="doubts" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Open Questions · 存疑" no="11" mark="疑" />
      <ol className="space-y-4">
        {ol?.items.map((it, i) => (
          <li key={i} className="rv relative grid grid-cols-[3rem_minmax(0,1fr)] gap-4 rounded-2xl border border-dashed p-5 sm:grid-cols-[4rem_minmax(0,1fr)] sm:p-6" style={{ borderColor: "color-mix(in oklab, var(--warn) 55%, transparent)" }}>
            <span className="font-serif text-[2.4rem] font-black leading-none sm:text-[3rem]" style={{ color: "var(--warn)" }}>
              {i + 1}
            </span>
            <p className="wrap-any self-center text-[1rem] leading-relaxed text-ink2">
              <I text={it} />
            </p>
          </li>
        ))}
      </ol>
    </section>
  );
}

export function Timeline() {
  const s = section("八、关键场景索引");
  const t = pick(s.blocks, "table");
  return (
    <section id="index" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="Scene Index · 索引" no="12" mark="索" />
      {t && (
        <div className="rv kicker mb-4">
          {t.head[0]} / {t.head[1]}
        </div>
      )}
      <ol className="relative ml-3 border-l pl-8 sm:ml-5 sm:pl-10" style={{ borderColor: "var(--line2)" }}>
        {t?.rows.map((r, i) => (
          <li key={i} className="rv relative pb-8 last:pb-0" style={{ ["--d" as string]: `${i * 0.06}s` }}>
            <span
              aria-hidden="true"
              className="absolute -left-[2.6rem] top-1 grid h-5 w-5 place-items-center rounded-full sm:-left-[3.1rem]"
              style={{ background: "var(--bg)", border: `2px solid ${i === 2 ? "var(--fire)" : "var(--moon)"}`, boxShadow: i === 2 ? "0 0 14px var(--fire)" : "none" }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: i === 2 ? "var(--fire)" : "var(--moon)" }} />
            </span>
            <h3 className="font-serif text-[1.2rem] font-black text-ink">{r[0]}</h3>
            <p className="wrap-any mt-1 text-[0.98rem] leading-relaxed text-ink2">
              <I text={r[1]} />
            </p>
          </li>
        ))}
      </ol>
    </section>
  );
}

function host(u: string) {
  try {
    return new URL(u).hostname.replace(/^(www|m|wap)\./, "");
  } catch {
    return "";
  }
}

export function Refs() {
  const s = section("参考资料");
  const ul = pick(s.blocks, "ul");
  return (
    <section id="refs" className="scroll-mt-24">
      <SectionHead title={s.title} kicker="References · 资料" no="13" mark="参" />
      <ul className="grid gap-3 md:grid-cols-2">
        {ul?.items.map((it, i) => {
          const m = it.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
          if (!m)
            return (
              <li key={i} className="rv card flex items-center gap-3 p-4">
                <span aria-hidden="true" className="seal grid h-8 w-8 shrink-0 place-items-center text-[0.95rem]">
                  衡
                </span>
                <span className="font-serif font-bold text-ink">
                  <I text={it} />
                </span>
              </li>
            );
          const [src, ...rest] = m[1].split(" · ");
          return (
            <li key={i} className="rv">
              <a href={m[2]} target="_blank" rel="noopener noreferrer" className="card group flex h-full items-start gap-3 p-4 transition hover:-translate-y-0.5 hover:border-[var(--fire)]">
                <span className="mt-0.5 shrink-0 rounded-md border border-line px-2 py-0.5 text-[0.75rem] font-bold text-fire">{src}</span>
                <span className="min-w-0 flex-1">
                  <span className="sr-only"> · </span>
                  <span className="block text-[0.95rem] leading-snug text-ink group-hover:text-fire">{rest.join(" · ")}</span>
                  <span className="mt-1 block truncate font-mono text-[0.68rem] text-ink3">{host(m[2])} ↗</span>
                </span>
              </a>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="relative mt-24 border-t border-line">
      <div className="mx-auto grid max-w-[1320px] gap-8 px-5 py-12 sm:px-8 md:grid-cols-[1fr_auto]">
        <div>
          <div className="flex items-center gap-3">
            <span className="seal grid h-10 w-10 place-items-center text-[1.3rem]">衡</span>
            <div>
              <div className="font-serif text-[1.1rem] font-bold text-ink">{doc.title}</div>
              <div className="text-[0.8rem] text-ink3">{doc.quote}</div>
            </div>
          </div>
          <p className="mt-6 max-w-[46rem] text-[0.78rem] leading-relaxed text-ink3">
            页面说明：正文逐字取自条目原文。场景插画为 AI 生成的氛围示意，非游戏官方美术；“轨道视角”两张测量图因原图未随条目提供，按正文给出的像素坐标与尺寸重建为示意图；“交互复算”“区间量规”等为页面附加的可视化，不属于原文。字体：Noto Serif SC、Noto Sans SC、Ma Shan Zheng、JetBrains Mono（SIL Open Font License）。
          </p>
        </div>
        <a href="#top" className="self-end justify-self-start rounded-full border border-line px-5 py-2.5 text-[0.85rem] text-ink2 transition hover:border-fire hover:text-ink md:justify-self-end">
          ↑ 回到月面
        </a>
      </div>
    </footer>
  );
}
