import { Fragment, type ReactNode } from "react";

// 行内渲染：只加样式，不改原文任何字符。
const TOKEN =
  /(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\)|〔[实推隐下]〕[。，；、：）]?|⊙?(?:城|国|陆)[○△☆▽]|\d+(?:\.\d+)?×10[⁰¹²³⁴⁵⁶⁷⁸⁹⁻]+(?:\s?J)?)/g;

const TAG_CLASS: Record<string, string> = {
  "〔实〕": "tag tag-shi",
  "〔推〕": "tag tag-tui",
  "〔隐〕": "tag tag-yin",
  "〔下〕": "tag tag-xia",
};

let keySeed = 0;

export function renderInline(text: string, opts: { plainNums?: boolean } = {}): ReactNode[] {
  const out: ReactNode[] = [];
  let last = 0;
  text.replace(TOKEN, (m, _g, offset: number) => {
    if (offset > last) out.push(text.slice(last, offset));
    const k = `i${keySeed++}`;
    if (m.startsWith("**")) {
      out.push(<strong key={k}>{renderInline(m.slice(2, -2), opts)}</strong>);
    } else if (m.startsWith("[")) {
      const mm = m.match(/^\[([^\]]+)\]\(([^)]+)\)$/)!;
      out.push(
        <a key={k} href={mm[2]} target="_blank" rel="noopener noreferrer" className="ilink">
          {mm[1]}
        </a>,
      );
    } else if (TAG_CLASS[m.slice(0, 3)]) {
      const tag = m.slice(0, 3);
      const tail = m.slice(3);
      out.push(
        tail ? (
          <span key={k} className="nowrap">
            <span className={TAG_CLASS[tag]}>{tag}</span>
            {tail}
          </span>
        ) : (
          <span key={k} className={TAG_CLASS[tag]}>
            {tag}
          </span>
        ),
      );
    } else if (/^⊙?(城|国|陆)/.test(m)) {
      const fam = m.includes("国") || m.includes("陆") ? "tier tier-guo" : "tier tier-cheng";
      out.push(
        <span key={k} className={fam}>
          {m}
        </span>,
      );
    } else if (!opts.plainNums) {
      out.push(
        <span key={k} className="num">
          {m}
        </span>,
      );
    } else out.push(m);
    last = offset + m.length;
    return m;
  });
  if (last < text.length) out.push(text.slice(last));
  return out;
}

export function I({ text, plainNums }: { text: string; plainNums?: boolean }) {
  return <Fragment>{renderInline(text, { plainNums })}</Fragment>;
}
