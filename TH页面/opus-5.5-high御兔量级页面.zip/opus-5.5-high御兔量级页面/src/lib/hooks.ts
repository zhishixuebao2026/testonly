import { useCallback, useEffect, useRef, useState } from "react";

export type Theme = "dark" | "light";
export const FS_STEPS = [0.875, 1, 1.125, 1.25, 1.375, 1.5];

function read(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function write(key: string, v: string) {
  try {
    localStorage.setItem(key, v);
  } catch {
    /* file:// 或隐私模式下可能不可用 */
  }
}

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => {
    const t = document.documentElement.getAttribute("data-theme");
    return t === "light" ? "light" : "dark";
  });
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    const meta = document.querySelector('meta[name="theme-color"]');
    meta?.setAttribute("content", theme === "dark" ? "#06080f" : "#f3ede1");
    write("yt-theme", theme);
  }, [theme]);
  const toggle = useCallback(() => setTheme((t) => (t === "dark" ? "light" : "dark")), []);
  return { theme, toggle };
}

export function useFontScale() {
  const [idx, setIdx] = useState(() => {
    const v = parseFloat(read("yt-fs") || "1");
    const i = FS_STEPS.indexOf(v);
    return i >= 0 ? i : 1;
  });
  useEffect(() => {
    const v = FS_STEPS[idx];
    document.documentElement.style.setProperty("--fs", String(v));
    write("yt-fs", String(v));
  }, [idx]);
  return {
    scale: FS_STEPS[idx],
    canDec: idx > 0,
    canInc: idx < FS_STEPS.length - 1,
    dec: () => setIdx((i) => Math.max(0, i - 1)),
    inc: () => setIdx((i) => Math.min(FS_STEPS.length - 1, i + 1)),
    reset: () => setIdx(1),
  };
}

/** 进场动画：给 .rv 元素加 .in */
export function useReveal() {
  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>(".rv:not(.in)"));
    if (!("IntersectionObserver" in window)) {
      els.forEach((e) => e.classList.add("in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add("in");
            io.unobserve(en.target);
          }
        });
      },
      { rootMargin: "0px 0px -6% 0px", threshold: 0.01 },
    );
    els.forEach((e) => io.observe(e));
    // 保险：无论如何 4 秒后对已在视口上方的元素也显示
    const t = window.setTimeout(() => {
      els.forEach((e) => {
        if (e.getBoundingClientRect().top < window.innerHeight) e.classList.add("in");
      });
    }, 4000);
    return () => {
      io.disconnect();
      clearTimeout(t);
    };
  }, []);
}

export function useScrollSpy(ids: string[]) {
  const [active, setActive] = useState<string>("");
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const h = document.documentElement;
        const max = h.scrollHeight - h.clientHeight;
        setProgress(max > 0 ? Math.min(1, Math.max(0, h.scrollTop / max)) : 0);
        const line = window.innerHeight * 0.32;
        let cur = "";
        for (const id of ids) {
          const el = document.getElementById(id);
          if (el && el.getBoundingClientRect().top <= line) cur = id;
        }
        setActive(cur);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, [ids]);
  return { active, progress };
}

export function useInView<T extends Element>(margin = "0px") {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || !("IntersectionObserver" in window)) {
      setInView(true);
      return;
    }
    const io = new IntersectionObserver(([e]) => setInView(e.isIntersecting), { rootMargin: margin });
    io.observe(el);
    return () => io.disconnect();
  }, [margin]);
  return { ref, inView };
}

export function useReducedMotion() {
  const [r, setR] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!mq) return;
    setR(mq.matches);
    const f = () => setR(mq.matches);
    mq.addEventListener?.("change", f);
    return () => mq.removeEventListener?.("change", f);
  }, []);
  return r;
}
