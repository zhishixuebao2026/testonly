// 原文 Markdown 解析器：正文内容全部来自 src/content/yutu.md，页面不改写原文。
import raw from "../content/yutu.md?raw";

export type Block =
  | { t: "p"; text: string }
  | { t: "quote"; text: string }
  | { t: "ul"; items: string[] }
  | { t: "ol"; items: string[] }
  | { t: "table"; head: string[]; rows: string[][] }
  | { t: "img"; alt: string; src: string };

export interface Sub {
  title: string;
  blocks: Block[];
}
export interface Section {
  title: string;
  blocks: Block[];
  subs: Sub[];
}
export interface Doc {
  title: string;
  quote: string;
  sections: Section[];
}

const splitRow = (line: string) =>
  line
    .trim()
    .replace(/^\|/, "")
    .replace(/\|$/, "")
    .split("|")
    .map((c) => c.trim());

function parse(src: string): Doc {
  const lines = src.replace(/\r\n?/g, "\n").split("\n");
  const doc: Doc = { title: "", quote: "", sections: [] };
  let cur: Block[] | null = null;
  let curSec: Section | null = null;
  let i = 0;
  const push = (b: Block) => {
    if (cur) cur.push(b);
    else if (b.t === "quote") doc.quote = b.text;
  };
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) {
      i++;
      continue;
    }
    let m: RegExpMatchArray | null;
    if ((m = line.match(/^#\s+(.*)$/))) {
      doc.title = m[1].trim();
      i++;
      continue;
    }
    if ((m = line.match(/^##\s+(.*)$/))) {
      curSec = { title: m[1].trim(), blocks: [], subs: [] };
      doc.sections.push(curSec);
      cur = curSec.blocks;
      i++;
      continue;
    }
    if ((m = line.match(/^###\s+(.*)$/))) {
      const sub: Sub = { title: m[1].trim(), blocks: [] };
      curSec?.subs.push(sub);
      cur = sub.blocks;
      i++;
      continue;
    }
    if (line.startsWith(">")) {
      push({ t: "quote", text: line.replace(/^>\s?/, "").trim() });
      i++;
      continue;
    }
    if (line.trim().startsWith("|")) {
      const rows: string[][] = [];
      while (i < lines.length && lines[i].trim().startsWith("|")) {
        rows.push(splitRow(lines[i]));
        i++;
      }
      const [head, , ...body] = rows;
      push({ t: "table", head, rows: body });
      continue;
    }
    if ((m = line.match(/^!\[([^\]]*)\]\(([^)]+)\)/))) {
      push({ t: "img", alt: m[1], src: m[2] });
      i++;
      continue;
    }
    if (/^-\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^-\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^-\s+/, "").trim());
        i++;
      }
      push({ t: "ul", items });
      continue;
    }
    if (/^\d+\.\s+/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\.\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\d+\.\s+/, "").trim());
        i++;
      }
      push({ t: "ol", items });
      continue;
    }
    push({ t: "p", text: line.trim() });
    i++;
  }
  return doc;
}

export const doc = parse(raw);

export function section(title: string): Section {
  const s = doc.sections.find((x) => x.title === title);
  if (!s) return { title, blocks: [], subs: [] };
  return s;
}

export function sub(sec: Section, title: string): Sub {
  return sec.subs.find((x) => x.title === title) ?? { title, blocks: [] };
}

/** 按类型取第 n 个块 */
export function pick<T extends Block["t"]>(blocks: Block[], t: T, n = 0) {
  return blocks.filter((b) => b.t === t)[n] as Extract<Block, { t: T }> | undefined;
}

/** 把 "**标题**：正文" 拆成 [标题, 分隔符+正文]（不改字） */
export function splitLead(text: string): { lead: string; rest: string } | null {
  const m = text.match(/^\*\*([^*]+)\*\*(：)?([\s\S]*)$/);
  if (!m) return null;
  return { lead: m[1], rest: (m[2] ?? "") + m[3] };
}

/** 列表项 "**距离**：..." → lead / rest */
export const ids: Record<string, string> = {
  作品信息: "work",
  角色信息: "character",
  量级栏: "rating",
  概述: "overview",
  "一、定级方法": "method",
  "二、世界观背景": "world",
  "三、关键场景": "scenes",
  "四、分维度分析": "analysis",
  "五、综合定级": "verdict",
  "六、横向比较": "compare",
  "七、存疑与作者矛盾": "doubts",
  "八、关键场景索引": "index",
  参考资料: "refs",
};
