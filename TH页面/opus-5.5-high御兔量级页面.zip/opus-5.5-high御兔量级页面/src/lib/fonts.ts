import { fontData } from "./font-data";

// Embedded subsets keep standalone HTML independent of a fonts directory.
const faces = [
  { family: "YT Serif", src: fontData.serif, weight: "200 900" },
  { family: "YT Sans", src: fontData.sans, weight: "100 900" },
  { family: "YT Brush", src: fontData.brush, weight: "400" },
  { family: "YT Mono", src: fontData.mono, weight: "100 800" },
];

export function injectFonts() {
  if (document.getElementById("yt-fonts")) return;
  const css = faces
    .map(
      (f) =>
        `@font-face{font-family:"${f.family}";src:url("${f.src}") format("woff2");font-weight:${f.weight};font-style:normal;font-display:swap;}`,
    )
    .join("\n");
  const style = document.createElement("style");
  style.id = "yt-fonts";
  style.textContent = css;
  document.head.appendChild(style);
}
