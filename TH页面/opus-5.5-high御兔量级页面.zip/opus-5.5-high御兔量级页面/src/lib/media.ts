import city from "../../public/images/city.jpg?inline";
import rabbitHero from "../../public/images/rabbit-hero.jpg?inline";
import plush from "../../public/images/plush.jpg?inline";
import sceneMoon from "../../public/images/scene-moon.jpg?inline";
import sceneClash from "../../public/images/scene-clash.jpg?inline";
import sceneOrbit from "../../public/images/scene-orbit.jpg?inline";
import sceneAfter from "../../public/images/scene-after.jpg?inline";

// Keep the original files in the project; inline their bytes in both dev and build.
export const media = {
  city,
  rabbitHero,
  plush,
  sceneMoon,
  sceneClash,
  sceneOrbit,
  sceneAfter,
} as const;