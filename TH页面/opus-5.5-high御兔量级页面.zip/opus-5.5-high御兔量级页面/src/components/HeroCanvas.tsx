import { useEffect, useRef, useState } from "react";
import type { Theme } from "../lib/hooks";

const VERT = `
attribute vec2 aPos;
void main(){ gl_Position = vec4(aPos,0.0,1.0); }
`;

const FRAG = `
precision highp float;
uniform vec2 uRes;
uniform float uTime;
uniform float uLight;
uniform vec3 uMoon;
uniform vec3 uEarth;
uniform vec2 uFire;
uniform vec2 uPar;
uniform sampler2D uTex;

float hash(vec2 p){ p = fract(p*vec2(123.34,456.21)); p += dot(p,p+45.32); return fract(p.x*p.y); }
float noise(vec2 p){
  vec2 i=floor(p), f=fract(p); vec2 u=f*f*(3.0-2.0*f);
  return mix(mix(hash(i),hash(i+vec2(1.,0.)),u.x), mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),u.x), u.y);
}
vec2 grad(vec2 p){ float a = hash(p)*6.2831853; return vec2(cos(a), sin(a)); }
float gnoise(vec2 p){
  vec2 i=floor(p), f=fract(p); vec2 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  float a=dot(grad(i),f), b=dot(grad(i+vec2(1.,0.)),f-vec2(1.,0.));
  float c=dot(grad(i+vec2(0.,1.)),f-vec2(0.,1.)), d=dot(grad(i+vec2(1.,1.)),f-vec2(1.,1.));
  return 0.5 + 0.75*mix(mix(a,b,u.x), mix(c,d,u.x), u.y);
}
const mat2 ROT = mat2(0.8,-0.6,0.6,0.8);
float fbm(vec2 p){ float v=0.0, a=0.5; for(int i=0;i<5;i++){ v+=a*gnoise(p); p=ROT*p*2.03+vec2(1.7,9.2); a*=0.5; } return v; }
// 蜂窝式环形山：坑底变暗、坑缘提亮
float craters(vec2 uv, float scale, float seed){
  vec2 g = uv*scale; vec2 id = floor(g); float acc = 0.0;
  for(int y=-1;y<=1;y++) for(int x=-1;x<=1;x++){
    vec2 c = id + vec2(float(x), float(y));
    float h = hash(c+seed);
    if(h > 0.42){
      vec2 o = vec2(hash(c+seed+1.3), hash(c+seed+2.7));
      float r = 0.14 + 0.32*hash(c+seed+5.1);
      float d = length(g-(c+o));
      acc += -smoothstep(r, r*0.55, d)*0.55 + smoothstep(r*0.78, r, d)*smoothstep(r*1.3, r, d)*0.6;
    }
  }
  return acc;
}
float lightDots(vec2 p, float s){
  vec2 g=p*s; vec2 id=floor(g); vec2 f=fract(g); float h=hash(id);
  vec2 o=vec2(hash(id+0.7),hash(id+1.9))*0.8+0.1;
  return smoothstep(0.16,0.0,length(f-o))*step(0.5,h)*h;
}

float stars(vec2 p, float scale, float thr){
  vec2 g = p*scale; vec2 id=floor(g); vec2 f=fract(g)-0.5;
  float h = hash(id);
  if(h < thr) return 0.0;
  vec2 off = vec2(hash(id+3.1), hash(id+7.7))-0.5;
  float d = length(f-off*0.7);
  float tw = 0.55+0.45*sin(uTime*(1.0+h*3.0)+h*60.0);
  return smoothstep(0.09, 0.0, d) * tw * (h-thr)/(1.0-thr);
}

// 月面数据：返回 x=是否在盘内(抗锯齿)，y=光照，z=反照率，w=玉兔遮罩
vec4 moonData(vec2 p){
  vec2 d = p - uMoon.xy; float r = uMoon.z; float dist = length(d);
  float inside = smoothstep(r, r-0.0035, dist);
  vec2 q = d/r; float z = sqrt(max(0.0, 1.0-dot(q,q)));
  vec3 n = vec3(q, z);
  vec3 L = normalize(vec3(-0.62, 0.38, 0.72));
  float lam = max(dot(n,L), 0.0);
  vec2 uv = q*0.5+0.5;
  float rabbit = 1.0 - texture2D(uTex, vec2(uv.x, 1.0-uv.y)).r;
  float maria = smoothstep(0.48, 0.78, fbm(uv*4.0+2.0));
  float cr = craters(uv, 7.0, 0.0)*0.10 + craters(uv, 17.0, 3.0)*0.06 + craters(uv, 38.0, 7.0)*0.035;
  float albedo = 0.94 - 0.15*maria - rabbit*(0.16 + 0.16*fbm(uv*7.0)) + cr + 0.05*(fbm(uv*16.0)-0.5);
  albedo *= mix(0.78, 1.0, z); // 边缘变暗
  return vec4(inside, lam, albedo, rabbit);
}

vec3 sceneDark(vec2 p){
  vec3 col = mix(vec3(0.018,0.025,0.05), vec3(0.04,0.06,0.15), smoothstep(-0.7,0.7,p.y)*0.7);
  float neb = fbm(p*1.4 + vec2(uTime*0.004, 0.0));
  col += vec3(0.10,0.07,0.22)*smoothstep(0.45,0.9,neb)*0.35;
  col += vec3(0.05,0.10,0.22)*smoothstep(0.5,0.95,fbm(p*2.3-3.0))*0.25;
  vec2 sp = p + uPar*0.015;
  float s = stars(sp, 60.0, 0.93) + stars(sp*1.0+11.0, 130.0, 0.955)*0.7 + stars(sp+5.0, 26.0, 0.975)*1.4;
  col += vec3(0.85,0.88,1.0)*s;

  // 月亮
  vec4 m = moonData(p);
  vec2 dm = p - uMoon.xy; float dist = length(dm);
  float glow = exp(-max(dist-uMoon.z,0.0)*7.0);
  col += vec3(1.0,0.86,0.6)*glow*0.16;
  col += vec3(1.0,0.92,0.75)*exp(-max(dist-uMoon.z,0.0)*30.0)*0.12;
  vec3 moonCol = vec3(0.98,0.92,0.78)*m.z*(0.06+1.05*m.y);
  moonCol += vec3(0.30,0.33,0.45)*0.05*(1.0-m.y);
  col = mix(col, moonCol, m.x);

  // 地球
  vec2 e = p - uEarth.xy; float de = length(e) - uEarth.z;
  float inE = smoothstep(0.002, -0.002, de);
  vec2 eu = e/uEarth.z;
  float land = smoothstep(0.50, 0.58, fbm(eu*5.5+vec2(3.0,1.0)));
  float lights = lightDots(eu, 240.0)*1.6 + lightDots(eu+3.0, 120.0)*1.0 + lightDots(eu+7.0, 520.0)*1.2;
  lights *= land * smoothstep(0.42, 0.72, fbm(eu*14.0));
  vec3 surf = mix(vec3(0.012,0.02,0.045), vec3(0.03,0.045,0.08), land);
  surf += vec3(1.0,0.72,0.38)*lights*0.9;
  float limbIn = exp(de*38.0);
  float sideWarm = smoothstep(-0.2, 0.9, eu.x);
  vec3 atm = mix(vec3(0.25,0.55,1.0), vec3(1.0,0.55,0.3), sideWarm*0.55);
  surf += atm*limbIn*0.35;
  col = mix(col, surf, inE);
  col += atm*exp(-abs(de)*95.0)*0.75;
  col += atm*exp(-max(de,0.0)*16.0)*0.22*(1.0-inE);

  // 终局起爆点：周期闪光与冲击环
  float cyc = fract(uTime/9.0);
  float fd = length(p-uFire);
  float ring = exp(-abs(fd - cyc*0.22)*70.0)*(1.0-cyc)*(1.0-cyc);
  float core = exp(-fd*28.0)*(0.35+0.65*pow(1.0-cyc,3.0));
  vec3 fire = vec3(1.0,0.55,0.18)*ring*1.3 + vec3(1.0,0.82,0.5)*core*1.4;
  col += fire*inE;

  // 暗角
  vec2 vu = gl_FragCoord.xy/uRes - 0.5;
  col *= 1.0 - dot(vu,vu)*0.55;
  return col;
}

vec3 sceneLight(vec2 p){
  vec3 paper = vec3(0.953,0.929,0.882);
  float g = fbm(p*3.0);
  vec3 col = paper*(0.965 + 0.05*g);
  col -= vec3(0.03,0.035,0.04)*smoothstep(0.55,0.9,noise(p*vec2(300.0,26.0)))*0.5;
  col -= vec3(0.05)*smoothstep(0.6,1.0,fbm(p*0.9+4.0))*0.35;
  // 墨点星
  float s = stars(p+uPar*0.01, 40.0, 0.975);
  col = mix(col, vec3(0.35,0.32,0.28), s*0.35);

  // 月亮：淡彩 + 墨线
  vec4 m = moonData(p);
  vec2 dm = p - uMoon.xy; float dist = length(dm); float r = uMoon.z;
  float halo = exp(-max(dist-r,0.0)*9.0);
  col = mix(col, vec3(0.96,0.85,0.62), halo*0.22);
  float wash = fbm((dm/r)*3.0+7.0);
  vec3 moonFill = mix(vec3(0.985,0.93,0.78), vec3(0.93,0.80,0.52), wash*0.55 + (1.0-m.y)*0.35);
  moonFill = mix(moonFill, vec3(0.50,0.40,0.24), m.w*(0.16 + 0.22*fbm((dm/r)*6.0+1.0)));
  moonFill = mix(moonFill, vec3(0.62,0.52,0.36), (1.0-m.z)*0.35);
  col = mix(col, moonFill, m.x);
  float brush = 0.0035 + 0.004*fbm(vec2(atan(dm.y,dm.x)*3.0, 1.0)+3.0);
  float outline = smoothstep(brush, 0.0, abs(dist-r));
  col = mix(col, vec3(0.17,0.14,0.11), outline*0.85);

  // 地球：靛蓝淡墨
  vec2 e = p - uEarth.xy; float de = length(e) - uEarth.z;
  float inE = smoothstep(0.003, -0.003, de);
  vec2 eu = e/uEarth.z;
  float land = smoothstep(0.50, 0.6, fbm(eu*5.5+vec2(3.0,1.0)));
  vec3 ink = vec3(0.16,0.25,0.47);
  float w = 0.06 + 0.07*fbm(eu*8.0) + land*0.08 + exp(de*30.0)*0.12;
  col = mix(col, ink, inE*w);
  float eb = 0.003 + 0.004*fbm(vec2(atan(e.y,e.x)*40.0, 2.0));
  col = mix(col, vec3(0.12,0.17,0.32), smoothstep(eb, 0.0, abs(de))*0.8);
  col = mix(col, ink, exp(-max(de,0.0)*40.0)*0.12*(1.0-inE));

  // 朱砂起爆环
  float cyc = fract(uTime/9.0);
  float fd = length(p-uFire);
  float ring = exp(-abs(fd - cyc*0.22)*80.0)*(1.0-cyc);
  float core = exp(-fd*30.0)*(0.3+0.7*pow(1.0-cyc,3.0));
  col = mix(col, vec3(0.76,0.24,0.15), clamp((ring*0.9+core*0.9)*inE, 0.0, 0.9));

  vec2 vu = gl_FragCoord.xy/uRes - 0.5;
  col *= 1.0 - dot(vu,vu)*0.22;
  return col;
}

void main(){
  vec2 p = (gl_FragCoord.xy - 0.5*uRes)/uRes.y;
  vec3 c;
  if(uLight <= 0.001) c = sceneDark(p);
  else if(uLight >= 0.999) c = sceneLight(p);
  else c = mix(sceneDark(p), sceneLight(p), uLight);
  // 抖动去色带
  c += (hash(gl_FragCoord.xy+fract(uTime))-0.5)/255.0;
  gl_FragColor = vec4(c,1.0);
}
`;

export interface HeroLayout {
  moon: [number, number, number];
  earth: [number, number, number];
  fire: [number, number];
  start: [number, number];
  end: [number, number];
  ctrl: [number, number];
}

export function computeLayout(w: number, h: number): HeroLayout {
  const asp = w / h;
  let moon: [number, number, number];
  let earth: [number, number, number];
  let fireAng: number;
  let startAng: number;
  if (asp > 1.05) {
    const r = Math.min(0.27, asp * 0.15);
    moon = [asp * 0.5 - r - 0.16 * Math.min(asp, 1.9) * 0.5, 0.08, r];
    earth = [-asp * 0.12, -2.28, 1.9];
    fireAng = Math.PI / 2 + 0.2;
    startAng = Math.PI / 2 - 0.12;
  } else {
    const r = Math.min(0.17, asp * 0.3);
    moon = [asp * 0.18, 0.31, r];
    earth = [-asp * 0.2, -2.0, 1.58];
    fireAng = Math.PI / 2 + 0.12;
    startAng = Math.PI / 2 - 0.08;
  }
  const fire: [number, number] = [
    earth[0] + Math.cos(fireAng) * (earth[2] - 0.05),
    earth[1] + Math.sin(fireAng) * (earth[2] - 0.05),
  ];
  const start: [number, number] = [earth[0] + Math.cos(startAng) * earth[2], earth[1] + Math.sin(startAng) * earth[2]];
  const dx = moon[0] - start[0];
  const dy = moon[1] - start[1];
  const len = Math.hypot(dx, dy);
  const end: [number, number] = [moon[0] - (dx / len) * moon[2] * 1.02, moon[1] - (dy / len) * moon[2] * 1.02];
  const ctrl: [number, number] = [start[0] + dx * 0.25 + (dy / len) * 0.18, start[1] + dy * 0.6 - (dx / len) * 0.05];
  return { moon, earth, fire, start, end, ctrl };
}

function makeRabbitTexture(): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const g = c.getContext("2d")!;
  g.fillStyle = "#fff";
  g.fillRect(0, 0, 256, 256);
  try {
    g.filter = "blur(3.5px)";
  } catch {
    /* Safari 无 filter */
  }
  g.fillStyle = "#000";
  const ell = (x: number, y: number, rx: number, ry: number, rot: number) => {
    g.beginPath();
    g.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2);
    g.fill();
  };
  // 玉兔捣药：兔子面向右，长耳朝左上
  ell(92, 150, 40, 30, -0.25); // 身体
  ell(122, 118, 20, 17, 0.2); // 头
  ell(104, 78, 7, 30, -0.55); // 耳 1
  ell(118, 76, 6.5, 28, -0.3); // 耳 2
  ell(60, 168, 13, 11, 0); // 尾
  ell(118, 178, 14, 8, 0.2); // 后腿
  // 杵
  g.save();
  g.translate(152, 120);
  g.rotate(0.35);
  g.fillRect(-2.5, -30, 5, 54);
  g.restore();
  // 臼
  g.beginPath();
  g.moveTo(150, 152);
  g.lineTo(196, 152);
  g.lineTo(188, 190);
  g.lineTo(158, 190);
  g.closePath();
  g.fill();
  ell(173, 152, 24, 7, 0);
  // 月海散斑
  ell(66, 214, 20, 9, 0.3);
  return c;
}

export default function HeroCanvas({ theme, onLayout }: { theme: Theme; onLayout?: (l: HeroLayout, w: number, h: number) => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const themeRef = useRef(theme);
  const [ok, setOk] = useState(true);
  const onLayoutRef = useRef(onLayout);
  onLayoutRef.current = onLayout;

  useEffect(() => {
    themeRef.current = theme;
  }, [theme]);

  useEffect(() => {
    const canvas = ref.current!;
    let gl: WebGLRenderingContext | null = null;
    try {
      gl = (canvas.getContext("webgl", { antialias: false, alpha: false, powerPreference: "high-performance" }) ||
        canvas.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    } catch {
      gl = null;
    }
    if (!gl) {
      setOk(false);
      return;
    }
    const compile = (type: number, src: string) => {
      const s = gl!.createShader(type)!;
      gl!.shaderSource(s, src);
      gl!.compileShader(s);
      if (!gl!.getShaderParameter(s, gl!.COMPILE_STATUS)) {
        console.warn(gl!.getShaderInfoLog(s));
        return null;
      }
      return s;
    };
    const vs = compile(gl.VERTEX_SHADER, VERT);
    const fs = compile(gl.FRAGMENT_SHADER, FRAG);
    if (!vs || !fs) {
      setOk(false);
      return;
    }
    const prog = gl.createProgram()!;
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      setOk(false);
      return;
    }
    gl.useProgram(prog);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, "aPos");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, makeRabbitTexture());
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

    const U = (n: string) => gl!.getUniformLocation(prog, n);
    const uRes = U("uRes"),
      uTime = U("uTime"),
      uLight = U("uLight"),
      uMoon = U("uMoon"),
      uEarth = U("uEarth"),
      uFire = U("uFire"),
      uPar = U("uPar"),
      uTex = U("uTex");
    gl.uniform1i(uTex, 0);

    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    let light = themeRef.current === "light" ? 1 : 0;
    let visible = true;
    let raf = 0;
    let lastW = 0,
      lastH = 0;
    const par = [0, 0],
      parT = [0, 0];
    const t0 = performance.now();

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const w = Math.max(1, rect.width),
        h = Math.max(1, rect.height);
      const small = w < 768;
      let dpr = Math.min(window.devicePixelRatio || 1, small ? 1.5 : 1.5);
      const maxPx = small ? 1.4e6 : 2.4e6;
      if (w * h * dpr * dpr > maxPx) dpr = Math.sqrt(maxPx / (w * h));
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      gl!.viewport(0, 0, canvas.width, canvas.height);
      const L = computeLayout(w, h);
      gl!.uniform3fv(uMoon, L.moon);
      gl!.uniform3fv(uEarth, L.earth);
      gl!.uniform2fv(uFire, L.fire);
      onLayoutRef.current?.(L, w, h);
      lastW = w;
      lastH = h;
    };

    const draw = (now: number) => {
      const target = themeRef.current === "light" ? 1 : 0;
      light += (target - light) * (reduced ? 1 : 0.08);
      if (Math.abs(target - light) < 0.002) light = target;
      par[0] += (parT[0] - par[0]) * 0.05;
      par[1] += (parT[1] - par[1]) * 0.05;
      gl!.uniform2f(uRes, canvas.width, canvas.height);
      gl!.uniform1f(uTime, reduced ? 2.2 : (now - t0) / 1000);
      gl!.uniform1f(uLight, light);
      gl!.uniform2f(uPar, par[0], par[1]);
      gl!.drawArrays(gl!.TRIANGLES, 0, 3);
    };

    const loop = (now: number) => {
      raf = 0;
      const rect = canvas.getBoundingClientRect();
      if (Math.abs(rect.width - lastW) > 1 || Math.abs(rect.height - lastH) > 1) resize();
      draw(now);
      const settling = Math.abs((themeRef.current === "light" ? 1 : 0) - light) > 0;
      if (visible && !document.hidden && (!reduced || settling)) raf = requestAnimationFrame(loop);
    };
    const kick = () => {
      if (!raf) raf = requestAnimationFrame(loop);
    };

    resize();
    kick();

    const io = new IntersectionObserver(([e]) => {
      visible = e.isIntersecting;
      if (visible) kick();
    });
    io.observe(canvas);
    const onVis = () => !document.hidden && kick();
    document.addEventListener("visibilitychange", onVis);
    const onResize = () => {
      resize();
      kick();
    };
    window.addEventListener("resize", onResize);
    const onMove = (e: PointerEvent) => {
      parT[0] = (e.clientX / window.innerWidth - 0.5) * 2;
      parT[1] = -(e.clientY / window.innerHeight - 0.5) * 2;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    const themeObs = new MutationObserver(() => kick());
    themeObs.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    const onLost = (e: Event) => {
      e.preventDefault();
      setOk(false);
    };
    canvas.addEventListener("webglcontextlost", onLost);

    return () => {
      cancelAnimationFrame(raf);
      io.disconnect();
      themeObs.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("webglcontextlost", onLost);
    };
  }, []);

  return (
    <>
      <canvas ref={ref} aria-hidden="true" className="absolute inset-0 h-full w-full" style={{ display: ok ? "block" : "none" }} />
      {!ok && (
        <div
          aria-hidden="true"
          className="absolute inset-0"
          style={{
            background:
              theme === "dark"
                ? "radial-gradient(circle at 72% 40%, #f2e3bd 0 13%, rgba(242,227,189,.18) 13.5%, transparent 30%), radial-gradient(ellipse at 30% 140%, #13224a 0 45%, transparent 46%), linear-gradient(#05070e,#0b1230)"
                : "radial-gradient(circle at 72% 40%, #f4e2b8 0 13%, rgba(168,122,34,.12) 13.5%, transparent 30%), radial-gradient(ellipse at 30% 140%, #d9d4c6 0 45%, transparent 46%), #f3ede1",
          }}
        />
      )}
    </>
  );
}
