import { useEffect, useState } from "react";
import type { Theme } from "../lib/hooks";

export interface TocItem {
  id: string;
  title: string;
  no: string;
}

const KM = 348300;

function SunIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-[1.1rem] w-[1.1rem]" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
      <circle cx="12" cy="12" r="4.2" />
      <path d="M12 2.5v2.2M12 19.3v2.2M4.6 4.6l1.6 1.6M17.8 17.8l1.6 1.6M2.5 12h2.2M19.3 12h2.2M4.6 19.4l1.6-1.6M17.8 6.2l1.6-1.6" />
    </svg>
  );
}
function MoonIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-[1.1rem] w-[1.1rem]" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round">
      <path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z" />
    </svg>
  );
}

export function TopBar({
  theme,
  onTheme,
  fs,
  onMenu,
  progress,
}: {
  theme: Theme;
  onTheme: () => void;
  fs: { scale: number; canDec: boolean; canInc: boolean; dec: () => void; inc: () => void; reset: () => void };
  onMenu: () => void;
  progress: number;
}) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 40);
    f();
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  const btn =
    "grid h-9 min-w-9 place-items-center rounded-full border border-line px-2 text-ink2 transition hover:border-fire hover:text-ink disabled:cursor-not-allowed disabled:opacity-35";
  return (
    <header
      className="fixed inset-x-0 top-0 z-50 transition-[background,border-color,backdrop-filter] duration-500"
      style={{
        background: scrolled ? "color-mix(in oklab, var(--bg) 78%, transparent)" : "transparent",
        backdropFilter: scrolled ? "blur(16px) saturate(1.2)" : "none",
        WebkitBackdropFilter: scrolled ? "blur(16px) saturate(1.2)" : "none",
        borderBottom: `1px solid ${scrolled ? "var(--line)" : "transparent"}`,
        paddingTop: "env(safe-area-inset-top)",
      }}
    >
      <div className="mx-auto flex h-14 max-w-[1320px] items-center gap-2 px-3 sm:px-6">
        <a href="#top" className="group flex min-w-0 items-center gap-2.5" aria-label="回到顶部">
          <span className="seal grid h-8 w-8 shrink-0 place-items-center text-[1.05rem]">衡</span>
          <span className="min-w-0 leading-tight">
            <span className="block truncate font-serif text-[0.95rem] font-bold text-ink">
              御兔<span className="hidden text-ink3 sm:inline"> · 衡天⊙定级</span>
            </span>
            <span className="kicker block truncate !text-[0.58rem] !tracking-[0.18em]">LUNAR CASE FILE</span>
          </span>
        </a>
        <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
          <div className="flex items-center gap-1 rounded-full border border-line p-0.5" role="group" aria-label="字体大小">
            <button className={btn + " !h-8 !min-w-8 border-transparent"} onClick={fs.dec} disabled={!fs.canDec} aria-label="缩小字体">
              <span className="font-serif text-[0.8rem] font-bold">A−</span>
            </button>
            <button
              className="hidden h-8 min-w-[3.1rem] rounded-full font-mono text-[0.72rem] text-ink3 hover:text-ink sm:block"
              onClick={fs.reset}
              aria-label="重置字体大小"
              title="重置字体大小"
            >
              {Math.round(fs.scale * 100)}%
            </button>
            <button className={btn + " !h-8 !min-w-8 border-transparent"} onClick={fs.inc} disabled={!fs.canInc} aria-label="放大字体">
              <span className="font-serif text-[1rem] font-bold">A+</span>
            </button>
          </div>
          <button className={btn} onClick={onTheme} aria-label={theme === "dark" ? "切换到亮色" : "切换到暗色"} title={theme === "dark" ? "亮色 · 月宫宣纸" : "暗色 · 夜侧轨道"}>
            {theme === "dark" ? <SunIcon /> : <MoonIcon />}
          </button>
          <button className={btn + " xl:hidden"} onClick={onMenu} aria-label="打开目录">
            <svg viewBox="0 0 24 24" className="h-[1.1rem] w-[1.1rem]" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
              <path d="M4 7h16M4 12h11M4 17h16" />
            </svg>
          </button>
        </div>
      </div>
      <div className="h-[2px] w-full bg-transparent">
        <div
          className="h-full origin-left"
          style={{ transform: `scaleX(${progress})`, background: "linear-gradient(90deg, var(--cyan), var(--moon) 55%, var(--fire))" }}
        />
      </div>
    </header>
  );
}

export function Flight({ progress }: { progress: number }) {
  const km = Math.round(progress * KM);
  return (
    <div className="rounded-xl border border-line p-3">
      <div className="flex items-center justify-between kicker !text-[0.6rem]">
        <span>地表</span>
        <span>月面</span>
      </div>
      <div className="relative my-2 h-5">
        <div className="absolute inset-x-2 top-1/2 h-px -translate-y-1/2" style={{ background: "repeating-linear-gradient(90deg,var(--line2) 0 4px,transparent 4px 8px)" }} />
        <div className="absolute left-0 top-1/2 h-4 w-4 -translate-y-1/2 rounded-full" style={{ background: "radial-gradient(circle at 35% 35%, #6fa8ff, #173a7a)" }} />
        <div className="absolute right-0 top-1/2 h-4 w-4 -translate-y-1/2 rounded-full" style={{ background: "radial-gradient(circle at 35% 35%, #fff6dc, #c9b07a)" }} />
        <div
          className="absolute top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{ left: `calc(0.5rem + (100% - 1rem) * ${progress})`, background: "var(--fire)", boxShadow: "0 0 10px 2px var(--fire)" }}
        />
      </div>
      <div className="font-mono text-[0.72rem] text-ink2 tabular-nums">
        {km.toLocaleString("en-US")} <span className="text-ink3">/ 348,300 km</span>
      </div>
    </div>
  );
}

export function TocList({ items, active, onPick }: { items: TocItem[]; active: string; onPick?: () => void }) {
  return (
    <ol className="space-y-0.5">
      {items.map((it) => {
        const on = it.id === active;
        return (
          <li key={it.id}>
            <a
              href={`#${it.id}`}
              onClick={onPick}
              className="group flex items-baseline gap-3 rounded-lg px-2.5 py-1.5 text-[0.9rem] transition"
              style={{ color: on ? "var(--ink)" : "var(--ink3)", background: on ? "var(--panel2)" : "transparent" }}
              aria-current={on ? "true" : undefined}
            >
              <span className="w-6 shrink-0 font-mono text-[0.68rem]" style={{ color: on ? "var(--fire)" : undefined }}>
                {it.no}
              </span>
              <span className="leading-snug group-hover:text-ink">{it.title}</span>
            </a>
          </li>
        );
      })}
    </ol>
  );
}

export function Drawer({ open, onClose, items, active, progress }: { open: boolean; onClose: () => void; items: TocItem[]; active: string; progress: number }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", k);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);
  return (
    <div className={`fixed inset-0 z-[70] xl:hidden ${open ? "" : "pointer-events-none"}`} aria-hidden={!open}>
      <div className="absolute inset-0 transition-opacity duration-300" style={{ background: "rgba(0,0,0,.45)", opacity: open ? 1 : 0 }} onClick={onClose} />
      <nav
        aria-label="目录"
        className="absolute right-0 top-0 flex h-full w-[min(86vw,22rem)] flex-col border-l border-line p-4 transition-transform duration-500"
        style={{
          background: "var(--panel-solid)",
          transform: open ? "translateX(0)" : "translateX(105%)",
          transitionTimingFunction: "cubic-bezier(.2,.8,.2,1)",
          paddingTop: "calc(1rem + env(safe-area-inset-top))",
        }}
      >
        <div className="mb-3 flex items-center justify-between">
          <span className="kicker">Contents · 目录</span>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full border border-line text-ink2" aria-label="关闭目录" tabIndex={open ? 0 : -1}>
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>
        <div className="no-scrollbar -mx-1 flex-1 overflow-y-auto px-1">
          <TocList items={items} active={active} onPick={onClose} />
        </div>
        <div className="mt-3">
          <Flight progress={progress} />
        </div>
      </nav>
    </div>
  );
}
