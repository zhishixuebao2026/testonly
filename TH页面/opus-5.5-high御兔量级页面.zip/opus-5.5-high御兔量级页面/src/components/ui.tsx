import type { ReactNode } from "react";
import type { Block } from "../lib/doc";
import { I } from "../lib/inline";

export function SectionHead({ title, kicker, no, mark, children }: { title: string; kicker: string; no: string; mark: string; children?: ReactNode }) {
  return (
    <header className="rv relative mb-10 sm:mb-14">
      <span aria-hidden="true" className="sec-mark pointer-events-none absolute -top-10 right-0 select-none sm:-top-16">
        {mark}
      </span>
      <div className="relative flex items-center gap-3">
        <span className="font-mono text-[0.72rem] text-fire">§{no}</span>
        <span className="h-px w-10 bg-line" />
        <span className="kicker">{kicker}</span>
      </div>
      <h2 className="sec-title relative mt-3">{title}</h2>
      <div className="brush-line mt-4" aria-hidden="true" />
      {children}
    </header>
  );
}

export function SubHead({ title, kicker }: { title: string; kicker?: string }) {
  return (
    <div className="rv mb-6 mt-14 flex flex-wrap items-end gap-x-4 gap-y-1">
      <h3 className="h3">{title}</h3>
      {kicker && <span className="kicker pb-1">{kicker}</span>}
    </div>
  );
}

/** 通用块渲染（兜底） */
export function Blocks({ blocks }: { blocks: Block[] }) {
  return (
    <div className="prose-yt space-y-4">
      {blocks.map((b, i) => {
        if (b.t === "p" || b.t === "quote")
          return (
            <p key={i}>
              <I text={b.text} />
            </p>
          );
        if (b.t === "ul" || b.t === "ol")
          return (
            <ul key={i} className="space-y-2 pl-5" style={{ listStyle: b.t === "ol" ? "decimal" : "disc" }}>
              {b.items.map((it, j) => (
                <li key={j}>
                  <I text={it} />
                </li>
              ))}
            </ul>
          );
        if (b.t === "table")
          return (
            <div key={i} className="space-y-2">
              {b.rows.map((r, j) => (
                <div key={j} className="card p-4">
                  {r.map((c, k) => (
                    <div key={k}>
                      <span className="label">{b.head[k]}</span> <I text={c} />
                    </div>
                  ))}
                </div>
              ))}
            </div>
          );
        return null;
      })}
    </div>
  );
}

export function KV({ k, children, wide }: { k: string; children: ReactNode; wide?: boolean }) {
  return (
    <div className={`group relative border-t border-line py-4 ${wide ? "sm:col-span-2" : ""}`}>
      <dt className="label mb-1 flex items-center gap-2">
        <span className="inline-block h-1.5 w-1.5 rotate-45 bg-fire opacity-80" />
        {k}
      </dt>
      <dd className="wrap-any text-[1rem] leading-relaxed text-ink">{children}</dd>
    </div>
  );
}

export const sup = (n: number) =>
  String(n)
    .split("")
    .map((c) => ("⁰¹²³⁴⁵⁶⁷⁸⁹"["0123456789".indexOf(c)] ?? (c === "-" ? "⁻" : c)))
    .join("");

export function fmtE(x: number, d = 2) {
  if (!isFinite(x) || x <= 0) return "—";
  const e = Math.floor(Math.log10(x));
  let m = x / Math.pow(10, e);
  let ee = e;
  if (+m.toFixed(d) >= 10) {
    m /= 10;
    ee += 1;
  }
  return `${m.toFixed(d)}×10${sup(ee)}`;
}
