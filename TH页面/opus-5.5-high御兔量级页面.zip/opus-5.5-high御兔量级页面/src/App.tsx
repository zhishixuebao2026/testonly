import { useCallback, useMemo, useState } from "react";
import { Drawer, Flight, TocList, TopBar, type TocItem } from "./components/Chrome";
import { doc, ids } from "./lib/doc";
import { useFontScale, useReveal, useScrollSpy, useTheme } from "./lib/hooks";
import Analysis from "./sections/Analysis";
import { Compare, Doubts, Footer, Refs, Timeline, Verdict } from "./sections/Closing";
import { Character, Work } from "./sections/Dossier";
import Hero from "./sections/Hero";
import { Method, Overview, Scenes, World } from "./sections/Narrative";
import Rating from "./sections/Rating";

export default function App() {
  const { theme, toggle } = useTheme();
  const fs = useFontScale();
  const [menu, setMenu] = useState(false);
  const toc: TocItem[] = useMemo(
    () =>
      doc.sections
        .filter((s) => ids[s.title])
        .map((s, i) => ({ id: ids[s.title], title: s.title, no: String(i + 1).padStart(2, "0") })),
    [],
  );
  const idList = useMemo(() => toc.map((t) => t.id), [toc]);
  const { active, progress } = useScrollSpy(idList);
  useReveal();
  const close = useCallback(() => setMenu(false), []);

  return (
    <div className="relative min-h-screen">
      <div className="grain" aria-hidden="true" />
      <a href="#work" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[80] focus:rounded-lg focus:bg-fire focus:px-3 focus:py-2 focus:text-white">
        跳到正文
      </a>
      <TopBar theme={theme} onTheme={toggle} fs={fs} onMenu={() => setMenu(true)} progress={progress} />
      <Drawer open={menu} onClose={close} items={toc} active={active} progress={progress} />

      <Hero theme={theme} />

      <div className="relative">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-0 top-0 h-[60vh]"
          style={{ background: "radial-gradient(ellipse at 70% 0%, color-mix(in oklab, var(--moon) 9%, transparent), transparent 60%)" }}
        />
        <div className="relative mx-auto grid max-w-[1320px] gap-10 px-5 pt-20 sm:px-8 sm:pt-28 xl:grid-cols-[13.5rem_minmax(0,1fr)] xl:gap-14">
          <aside className="hidden xl:block">
            <nav aria-label="目录" className="sticky top-24 max-h-[calc(100vh-7rem)] overflow-y-auto pb-6 no-scrollbar">
              <div className="kicker mb-3 px-2.5">Contents · 目录</div>
              <TocList items={toc} active={active} />
              <div className="mt-5">
                <Flight progress={progress} />
              </div>
            </nav>
          </aside>
          <main className="min-w-0 space-y-28 sm:space-y-36">
            <Work />
            <Character />
            <Rating />
            <Overview />
            <Method />
            <World />
            <Scenes />
            <Analysis />
            <Verdict />
            <Compare />
            <Doubts />
            <Timeline />
            <Refs />
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
