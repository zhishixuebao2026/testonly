import React, { useEffect, useState } from "react";
import Starfield from "./components/Starfield";
import Masthead from "./components/Masthead";
import Chrome, { TocList, FONT_STEPS } from "./components/Chrome";
import { CHAPTERS, scrollToId, type Chapter } from "./lib/doc";
import { ChapterBody, useSplitBody } from "./lib/markdown";
import { ClauseNav, HeptadDial, CoverageModels, PowerTower } from "./components/Extras";
import { decorate } from "./lib/inline";

/* ================================================================== */
/* 衡天 ⊙ 多维战力量级体系 · 第五版 —— 单页全文呈现                        */
/* ================================================================== */

const EXTRAS: Record<number, { before: string; el: React.ReactNode }> = {
  8: { before: "## 0.1", el: <ClauseNav /> },
  9: { before: "## 1.1", el: <HeptadDial /> },
  12: { before: "## 4.3", el: <CoverageModels /> },
  13: { before: "## 5.3", el: <PowerTower /> },
};

const REV_NUM = ["Ⅴ", "Ⅳ", "Ⅲ", "Ⅱ"];
const CN_NUM = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一"];

function Orbit() {
  return (
    <svg className="ch-orbit" viewBox="0 0 120 120" aria-hidden="true">
      <circle cx="60" cy="60" r="54" className="ch-orbit-r1" />
      <circle cx="60" cy="60" r="36" className="ch-orbit-r2" />
      <g className="ch-orbit-spin"><circle cx="60" cy="6" r="3.4" className="ch-orbit-p" /></g>
      <g className="ch-orbit-spin2"><circle cx="60" cy="24" r="2.4" className="ch-orbit-p2" /></g>
      <circle cx="60" cy="60" r="7" className="ch-orbit-sun" />
    </svg>
  );
}

function ChapterHeader({ c }: { c: Chapter }) {
  if (c.kind === "cover") return null;
  if (c.kind === "part") {
    const [part, name] = c.title.split("\u3000");
    return (
      <header className="ch-head ch-head-part" data-rv>
        <span className="ch-water" aria-hidden="true">{CN_NUM[c.idx - 8]}</span>
        <Orbit />
        <p className="ch-kicker">{c.kicker}</p>
        <h1 className="ch-title">
          <span className="ch-part">{part}</span>
          <span className="ch-name">{decorate(name ?? "")}</span>
        </h1>
        <div className="ch-rule" aria-hidden="true"><i /><span>⊙</span><i /></div>
      </header>
    );
  }
  if (c.kind === "revision") {
    return (
      <header className="ch-head ch-head-rev" data-rv>
        <span className="ch-rev-seal" aria-hidden="true">{REV_NUM[c.idx - 2]}</span>
        <div>
          <p className="ch-kicker">{c.kicker}</p>
          <h1 className="ch-title ch-title-rev">{decorate(c.title)}</h1>
        </div>
      </header>
    );
  }
  return (
    <header className="ch-head ch-head-plain" data-rv>
      <Orbit />
      <p className="ch-kicker">{c.kicker}</p>
      <h1 className="ch-title">{decorate(c.title)}</h1>
      <div className="ch-rule" aria-hidden="true"><i /><span>⊙</span><i /></div>
    </header>
  );
}

function ChapterSection({ c, active, onGo }: { c: Chapter; active: string; onGo: (id: string) => void }) {
  void active; void onGo;
  const extra = EXTRAS[c.idx];
  const [before, after] = useSplitBody(c.body, extra?.before);
  return (
    <section id={c.id} className={`chapter chapter-${c.kind}`} data-spy
      data-title={c.short} data-kicker={c.kicker}>
      {c.kind === "cover" ? (
        <div className="preface" data-rv>
          <p className="ch-kicker">卷首 · 原文照录</p>
          <h1 className="preface-title">{decorate(c.title)}</h1>
          <ChapterBody md={c.body} />
        </div>
      ) : (
        <>
          <ChapterHeader c={c} />
          <ChapterBody md={before} />
          {extra && after && (
            <>
              {extra.el}
              <ChapterBody md={after} />
            </>
          )}
        </>
      )}
      {c.kind !== "revision" && c.kind !== "cover" && (
        <div className="ch-end" aria-hidden="true"><i /><span>✦</span><span className="ch-end-sun">⊙</span><span>✦</span><i /></div>
      )}
    </section>
  );
}

function readStore(key: string, fallback: string): string {
  try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
}

export default function App() {
  const [theme, setTheme] = useState<"dark" | "light">(() =>
    readStore("ht-theme", "dark") === "light" ? "light" : "dark"
  );
  const [fontStep, setFontStep] = useState(() => {
    const n = parseInt(readStore("ht-font", "1"), 10);
    return Number.isNaN(n) ? 1 : Math.max(0, Math.min(FONT_STEPS.length - 1, n));
  });
  const [spy, setSpy] = useState({ id: "ch-0", title: "题名与缘起", kicker: "卷首 · PREFACE" });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem("ht-theme", theme); } catch { /* 忽略 */ }
    const meta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (meta) meta.content = theme === "dark" ? "#070b16" : "#f4f5f0";
  }, [theme]);

  useEffect(() => {
    document.documentElement.style.setProperty("--doc-fs", `${FONT_STEPS[fontStep]}px`);
    try { localStorage.setItem("ht-font", String(fontStep)); } catch { /* 忽略 */ }
  }, [fontStep]);

  /* 滚动显现 */
  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>("[data-rv]"));
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add("is-in");
            io.unobserve(e.target);
          }
        }
      },
      { threshold: 0.04, rootMargin: "0px 0px -5% 0px" }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  /* 章节侦测 */
  useEffect(() => {
    const sections = Array.from(document.querySelectorAll<HTMLElement>("[data-spy]"));
    const io = new IntersectionObserver(
      (entries) => {
        const hit = entries.filter((e) => e.isIntersecting).pop();
        if (hit) {
          const t = hit.target as HTMLElement;
          setSpy({
            id: t.id,
            title: t.dataset.title ?? "",
            kicker: t.dataset.kicker ?? "",
          });
        }
      },
      { rootMargin: "-30% 0px -60% 0px", threshold: 0 }
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  /* 初始锚点：瞬时跳转，字体就绪后再校正一次 */
  useEffect(() => {
    if (!location.hash) return;
    const id = location.hash.slice(1);
    const jump = () => {
      const el = document.getElementById(id);
      if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 80, behavior: "instant" });
    };
    const t = setTimeout(jump, 260);
    document.fonts?.ready.then(() => setTimeout(jump, 60)).catch(() => {});
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="app">
      <div className="app-bg" aria-hidden="true">
        <svg className="bg-rings" viewBox="0 0 900 900">
          <g fill="none" stroke="currentColor">
            <circle cx={450} cy={450} r={430} strokeWidth={1} />
            <circle cx={450} cy={450} r={360} strokeWidth={0.6} strokeDasharray="3 9" />
            <circle cx={450} cy={450} r={280} strokeWidth={0.8} />
            <circle cx={450} cy={450} r={190} strokeWidth={0.5} strokeDasharray="2 6" />
            {Array.from({ length: 72 }, (_, i) => {
              const a = (i * 5 * Math.PI) / 180;
              const r1 = i % 6 === 0 ? 404 : 416;
              return (
                <line key={i}
                  x1={450 + r1 * Math.cos(a)} y1={450 + r1 * Math.sin(a)}
                  x2={450 + 430 * Math.cos(a)} y2={450 + 430 * Math.sin(a)}
                  strokeWidth={i % 6 === 0 ? 1.2 : 0.5} />
              );
            })}
          </g>
        </svg>
      </div>
      <Starfield theme={theme} />

      <Chrome
        theme={theme}
        onTheme={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
        fontStep={fontStep}
        onFontStep={(n) => setFontStep(Math.max(0, Math.min(FONT_STEPS.length - 1, n)))}
        activeChapter={spy.id}
        activeTitle={spy.title}
        activeKicker={spy.kicker}
      />

      <Masthead />

      <div className="layout">
        <aside className="rail" aria-label="章节导航">
          <div className="rail-sticky">
            <p className="rail-cap">目录 · CONTENTS</p>
            <div className="rail-scroll">
              <TocList active={spy.id} onGo={scrollToId} />
            </div>
          </div>
        </aside>

        <main className="content">
          {CHAPTERS.map((c) => (
            <ChapterSection key={c.id} c={c} active={spy.id} onGo={scrollToId} />
          ))}

          <footer className="colophon" data-rv>
            <div className="colophon-seal" aria-hidden="true">
              <span>衡</span><span>天</span>
            </div>
            <p className="colophon-line">自一颗恒星，向外衡量。</p>
            <div className="colophon-rule" aria-hidden="true"><i /><span>⊙</span><i /></div>
            <div className="colophon-meta">
              <p>原文完整收录 · 未删改一字</p>
              <p>底本：【10.30】衡天量级体系（第五版·最新）.md</p>
              <p>第五版 2026-10-25 发布 · 2026-10-26 补 10.4 · 2026-10-28 补 1.7 · 2026-10-30 修订 5.6、8.3</p>
              <p className="colophon-dim">
                夜观 / 昼测双主题 · 字号五档 · Ctrl+K 检索条文 ·{" "}
                <a href="https://github.com/zhishixuebao2026/testonly/blob/main/%E3%80%9010.30%E3%80%91%E8%A1%A1%E5%A4%A9%E9%87%8F%E7%BA%A7%E4%BD%93%E7%B3%BB%EF%BC%88%E7%AC%AC%E4%BA%94%E7%89%88%C2%B7%E6%9C%80%E6%96%B0%EF%BC%89.md"
                  target="_blank" rel="noreferrer">核对底本 ↗</a>
              </p>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}
