import React from "react";
import type { Element } from "hast";
import { ChevronRight, CheckCircle2, ArrowDownToLine, GitBranch, EyeOff, CircleSlash, Sparkles } from "lucide-react";
import { tableMatrix, parseLogs, logPos, decorateText, type Cell } from "../lib/inline";
import { ladderTarget, scrollToId } from "../lib/doc";

/* ================================================================== */
/* 表格 → 信息图：全部结构均无横向滚动，单元格文字逐字保留                 */
/* ================================================================== */

function Seal({ ch, tone = "brass", dashed = false, size = "md" }: {
  ch: string; tone?: string; dashed?: boolean; size?: "sm" | "md" | "lg";
}) {
  return (
    <span className={`seal seal-${tone} seal-${size} ${ch.length > 2 ? "seal-auto" : ""} ${dashed ? "seal-dashed" : ""}`} aria-hidden="true">
      {ch}
    </span>
  );
}

/* ---------------- 修饰符 / 证据状态 / 维度：字符印墙 ---------------- */

const EV_META: Record<string, { icon: React.ReactNode; tone: string }> = {
  实: { icon: <CheckCircle2 size={15} />, tone: "shi" },
  下: { icon: <ArrowDownToLine size={15} />, tone: "xia" },
  推: { icon: <GitBranch size={15} />, tone: "tui" },
  隐: { icon: <EyeOff size={15} />, tone: "yin" },
  缺: { icon: <CircleSlash size={15} />, tone: "que" },
};

function EvidenceTiles({ rows }: { rows: Cell[][] }) {
  return (
    <div className="ev-grid" data-rv>
      {rows.map((r, i) => {
        const key = r[0].text.replace(/[〔〕]/g, "");
        const meta = EV_META[key] ?? EV_META["缺"];
        return (
          <div key={i} className={`ev-card ev-card-${meta.tone}`}>
            <div className="ev-card-head">
              <span className="ev-card-mark">{r[0].inline}</span>
              <span className="ev-card-icon">{meta.icon}</span>
            </div>
            <p className="ev-card-body">{r[1].inline}</p>
          </div>
        );
      })}
    </div>
  );
}

function GlyphTiles({ rows, tone = "brass" }: { rows: Cell[][]; tone?: string }) {
  return (
    <div className="glyph-grid" data-rv>
      {rows.map((r, i) => (
        <div key={i} className="glyph-tile">
          <Seal ch={r[0].text} tone={tone} />
          <span className="glyph-name">{r[1].inline}</span>
        </div>
      ))}
    </div>
  );
}

function PairGlyphs({ rows, beyond = false }: { rows: Cell[][]; beyond?: boolean }) {
  const items: { g: string; n: React.ReactNode }[] = [];
  rows.forEach((r) => {
    if (r[0]?.text) items.push({ g: r[0].text, n: r[1].inline });
    if (r[2]?.text) items.push({ g: r[2].text, n: r[3].inline });
  });
  return (
    <div className="glyph-grid glyph-grid-pair" data-rv>
      {items.map((it, i) => (
        <div key={i} className="glyph-tile">
          <Seal ch={it.g} tone={beyond ? (i >= 4 ? "viol" : "sky") : "brass"} size={it.g.length > 1 ? "sm" : "md"} />
          <span className="glyph-name">{it.n}</span>
        </div>
      ))}
    </div>
  );
}

/* ---------------------- 2.3 量级表：分级卡 ---------------------- */

function heatTone(log: number | null): string {
  if (log == null) return "var(--brass)";
  const t = Math.max(0, Math.min(1, (log + 5) / 48));
  return `color-mix(in oklab, var(--brass) ${Math.round((1 - t) * 100)}%, var(--verm))`;
}

function TierGroups({ rows }: { rows: Cell[][] }) {
  const groups: { title: Cell; rows: Cell[][] }[] = [];
  rows.forEach((r) => {
    if (r[0].text) groups.push({ title: r[0], rows: [] });
    if (groups.length) groups[groups.length - 1].rows.push(r);
  });
  return (
    <div className="tier-stack">
      {groups.map((g, gi) => {
        const inner = g.title.text.replace(/[（）]/g, "|").split("|").filter(Boolean);
        const glyph = inner.length > 1 ? inner[inner.length - 1] : "渡";
        const isTrans = g.title.text.includes("过渡");
        const logs = g.rows.flatMap((r) => parseLogs(r[3]?.text ?? ""));
        const maxLog = logs.length ? Math.max(...logs) : null;
        return (
          <div key={gi} className={`tier-card ${isTrans ? "tier-card-trans" : ""}`} data-rv
            style={{ ["--heat" as string]: heatTone(maxLog) }}>
            <div className="tier-head">
              <Seal ch={glyph.length > 1 ? "渡" : glyph} dashed={isTrans} />
              <h4 className="tier-title">{g.title.inline}</h4>
              <span className="tier-index">{String(gi + 1).padStart(2, "0")}</span>
            </div>
            <div className="tier-rows">
              {g.rows.map((r, ri) => (
                <div key={ri} className="tier-row">
                  <span className="tier-sub">{r[1].inline}</span>
                  <span className="tier-feat">{r[2].inline}</span>
                  <span className="tier-energy">{r[3].inline}</span>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------------- 8.5 论外分档：基数阶梯 ---------------------- */

const BEYOND_ZONES = [
  { label: "ZFC 内可证明存在", tone: "sky" },
  { label: "ZFC 无法证明存在（只能作为额外公理）", tone: "viol" },
  { label: "与 ZFC 不相容（须放弃选择公理）", tone: "verm" },
];

function ArrowChain({ text }: { text: string }) {
  const segs = text.split("→");
  return (
    <span className="chain">
      {segs.map((s, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span className="chain-arrow" aria-hidden="true">→</span>}
          <span className="chain-chip">{decorateText(s.trim(), `ch${i}`)}</span>
        </React.Fragment>
      ))}
    </span>
  );
}

function CardinalRungs({ rows }: { rows: Cell[][] }) {
  let lastZone = -1;
  return (
    <div className="rungs">
      {rows.map((r, i) => {
        const zone = i <= 3 ? 0 : i <= 6 ? 1 : 2;
        const z = BEYOND_ZONES[zone];
        const band = zone !== lastZone;
        lastZone = zone;
        return (
          <React.Fragment key={i}>
            {band && (
              <div className={`rung-band rung-band-${z.tone}`} data-rv>
                <Sparkles size={13} aria-hidden="true" />
                <span>{z.label}</span>
              </div>
            )}
            <div className={`rung rung-${z.tone}`} data-rv>
              <div className="rung-side">
                <Seal ch={r[0].text} tone={z.tone} size="sm" />
                <span className="rung-step">{String(i + 1).padStart(2, "0")}</span>
              </div>
              <div className="rung-main">
                <h4 className="rung-title">{r[1].inline}</h4>
                <div className="rung-content"><ArrowChain text={r[2].text} /></div>
                <p className="rung-def">{r[3].inline}</p>
              </div>
            </div>
          </React.Fragment>
        );
      })}
    </div>
  );
}

/* ---------------------- 5.4 快速增长层级：递升台阶 ---------------------- */

function GrowthSteps({ rows }: { rows: Cell[][] }) {
  return (
    <div className="steps">
      {rows.map((r, i) => (
        <div key={i} className="step-card" data-rv
          style={{ ["--step" as string]: i }}>
          <div className="step-f">{r[2].inline}</div>
          <div className="step-body">
            <div className="step-head">
              <Seal ch={r[0].text} tone="gold" size="sm" />
              <h4 className="step-title">{r[1].inline}</h4>
              <span className="step-no">{String(i + 1).padStart(2, "0")}</span>
            </div>
            <p className="step-note">{r[3].inline}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------------- 1.1 七个维度：维度卡 ---------------------- */

function DimensionCards({ rows }: { rows: Cell[][] }) {
  return (
    <div className="dim-grid">
      {rows.map((r, i) => (
        <div key={i} className="dim-card" data-rv>
          <div className="dim-head">
            <Seal ch={r[0].text} tone={i < 3 ? "brass" : i < 5 ? "jade" : "sky"} />
            <div>
              <h4 className="dim-name">{r[1].inline}</h4>
              <span className="dim-what">{r[2].inline}</span>
            </div>
          </div>
          <p className="dim-how">{r[3].inline}</p>
          <span className="dim-ref">细则 · {r[4].inline}</span>
        </div>
      ))}
    </div>
  );
}

/* ---------------------- 11.2 全链条总览：衡天天梯 ---------------------- */

type Zone = "inherit" | "cover" | "univer" | "wide" | "beyond" | "trans";

function zoneOf(glyph: string, name: string): Zone {
  const g = glyph.trim();
  if (g === "—") return "trans";
  if (g === "广") return "wide";
  if (g.startsWith("外")) return "beyond";
  if (g.startsWith("宇")) return "univer";
  if ("系团河簇构".includes(g[0])) return "cover";
  void name;
  return "inherit";
}

const ZONE_TITLE: Record<string, { t: string; s: string }> = {
  inherit: { t: "有限 · 继承区", s: "目标式 · 第二至第三部分" },
  cover: { t: "有限 · 覆盖体系", s: "E = 2πD² × F* · 第四部分" },
  wide: { t: "广义无限区", s: "仍是有限量 · 第五部分" },
  beyond: { t: "论外级 · 真无限", s: "基数与序数 · 第八部分" },
};

const TICKS = [
  { e: -5, label: "10⁻⁵" }, { e: 15, label: "10¹⁵" }, { e: 35, label: "10³⁵" },
  { e: 55, label: "10⁵⁵" }, { e: 75, label: "10⁷⁵" }, { e: 95, label: "10⁹⁵" },
];

export function MasterLadder({ rows }: { rows: Cell[][] }) {
  let lastZone: Zone | null = null;
  return (
    <div className="ladder" data-rv>
      <div className="ladder-tabs" role="group" aria-label="天梯分区快速定位">
        {(["inherit", "cover", "wide", "beyond"] as const).map((z) => (
          <button key={z} type="button" className={`ladder-tab ladder-tab-${z}`}
            onClick={(e) => {
              const root = (e.currentTarget as HTMLElement).closest(".ladder");
              const el = root?.querySelector<HTMLElement>(`[data-zone="${z}"]`);
              if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 130, behavior: "smooth" });
            }}>
            {ZONE_TITLE[z].t}
          </button>
        ))}
      </div>
      <div className="ladder-scale" aria-hidden="true">
        <span className="ladder-scale-cap">能量 · 对数刻度（J）</span>
        <div className="ladder-ticks">
          {TICKS.map((t, i) => (
            <span key={i} className="ladder-tick" style={{ left: `${logPos(t.e)}%` }}
              data-edge={i === 0 ? "l" : i === TICKS.length - 1 ? "r" : undefined}>
              {t.label}
            </span>
          ))}
        </div>
      </div>
      {rows.map((r, i) => {
        const glyph = r[0].text;
        const name = r[1].text;
        const zone = zoneOf(glyph, name);
        const logs = parseLogs(r[2].text);
        const isArrow = r[2].text.includes("10↑↑3");
        let lo: number | null = null, hi: number | null = null;
        if (logs.length) {
          lo = Math.min(...logs);
          hi = Math.max(...logs);
          if (isArrow && zone === "univer") hi = 95;
        }
        const band =
          zone !== lastZone && zone !== "trans" && zone !== "univer"
            ? ZONE_TITLE[zone === "inherit" ? "inherit" : zone]
            : null;
        if (zone !== "trans") lastZone = zone;
        const target = ladderTarget(glyph, name);
        const special = zone === "wide" || zone === "beyond";
        return (
          <React.Fragment key={i}>
            {band && (
              <div className={`ladder-zone ladder-zone-${zone}`} data-zone={zone}>
                <span className="ladder-zone-t">{band.t}</span>
                <span className="ladder-zone-s">{band.s}</span>
              </div>
            )}
            <button type="button"
              className={`ladder-row ladder-row-${zone} ${special ? "ladder-row-special" : ""}`}
              onClick={() => scrollToId(target)}
              title={`跳转到对应章节（${name}）`}
              aria-label={`${name}，跳转到对应章节`}>
              <span className="ladder-glyph">
                {glyph === "—"
                  ? <span className="ladder-dash">—</span>
                  : <Seal ch={glyph} size="sm" tone={zone === "beyond" ? "viol" : zone === "wide" ? "gold" : zone === "inherit" || zone === "trans" ? "brass" : "jade"} />}
              </span>
              <span className="ladder-name">{r[1].inline}</span>
              <span className="ladder-bar" aria-hidden="true">
                <span className="ladder-bar-track">
                  {TICKS.map((t, k) => (
                    <i key={k} style={{ left: `${logPos(t.e)}%` }} />
                  ))}
                  {special ? (
                    <span className={`ladder-bar-special ladder-bar-${zone}`} />
                  ) : lo != null && hi != null ? (
                    <span className="ladder-bar-fill"
                      style={{
                        left: `${logPos(lo)}%`,
                        width: `${Math.max(1.2, logPos(hi) - logPos(lo))}%`,
                      }} />
                  ) : null}
                </span>
              </span>
              <span className="ladder-energy">{r[2].inline}</span>
              <ChevronRight className="ladder-go" size={14} aria-hidden="true" />
            </button>
          </React.Fragment>
        );
      })}
      <p className="ladder-note">同一横尺纵览约一百个数量级；条带为该区间的能量跨度，「—」为不设代字的过渡带。点按任意一级可直达正文。</p>
    </div>
  );
}

/* ---------------------- 通用账目式记录（默认表格） ---------------------- */

function Ledger({ headers, rows }: { headers: Cell[]; rows: Cell[][] }) {
  const n = headers.length;
  return (
    <div className={`ledger ledger-${Math.min(n, 4)}`} data-rv>
      <div className="ledger-headrow" aria-hidden="true">
        {headers.map((h, i) => <span key={i}>{h.inline}</span>)}
      </div>
      {rows.map((r, i) => (
        <div key={i} className="ledger-row">
          {r.map((c, j) => (
            <div key={j} className={`ledger-cell ${j === 0 ? "ledger-key" : ""}`}>
              <span className="ledger-label">{headers[j]?.inline}</span>
              <span className="ledger-value">{c.inline}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

/* ------------------------------ 分发 ------------------------------ */

const CAP_SIGS = new Set([
  "量级（代字）|细分|表现|能量",
  "代字|档位|内容|定义特征",
  "代字|分段|对应增长|判读要点与参照",
  "代字|量级|能量区间（J）",
  "代字|维度|衡量什么|计量方式|细则",
  "区段|语义分界",
]);

function FieldCap({ headers }: { headers: Cell[] }) {
  return (
    <p className="tbl-cap">
      <span className="tbl-cap-mark" aria-hidden="true">▤</span>
      {headers.map((h) => h.text).join(" · ")}
    </p>
  );
}

export function DocTable({ node }: { node: Element }) {
  const { headers, rows } = tableMatrix(node);
  const sig = headers.map((h) => h.text).join("|");
  if (CAP_SIGS.has(sig)) {
    return (
      <>
        <FieldCap headers={headers} />
        <DocTableInner sig={sig} headers={headers} rows={rows} />
      </>
    );
  }
  return <DocTableInner sig={sig} headers={headers} rows={rows} />;
}

function DocTableInner({ sig, headers, rows }: { sig: string; headers: Cell[]; rows: Cell[][] }) {
  switch (sig) {
    case "符号|含义":
      return <GlyphTiles rows={rows} tone="brass" />;
    case "标记|含义":
      return <EvidenceTiles rows={rows} />;
    case "代字|量级|代字|量级":
      return <PairGlyphs rows={rows} />;
    case "代字|档位|代字|档位":
      return <PairGlyphs rows={rows} beyond />;
    case "代字|分段":
      return <GlyphTiles rows={rows} tone="gold" />;
    case "代字|维度":
      return <GlyphTiles rows={rows} tone="jade" />;
    case "量级（代字）|细分|表现|能量":
      return <TierGroups rows={rows} />;
    case "代字|档位|内容|定义特征":
      return <CardinalRungs rows={rows} />;
    case "代字|分段|对应增长|判读要点与参照":
      return <GrowthSteps rows={rows} />;
    case "代字|量级|能量区间（J）":
      return <MasterLadder rows={rows} />;
    case "代字|维度|衡量什么|计量方式|细则":
      return <DimensionCards rows={rows} />;
    case "区段|语义分界":
      return (
        <div className="glyph-grid glyph-grid-pair" data-rv>
          {rows.map((r, i) => (
            <div key={i} className="glyph-tile">
              <Seal ch="◈" tone={i === 0 ? "sky" : i === 1 ? "viol" : "verm"} />
              <span className="glyph-name">
                <b className="zone-name">{r[0].inline}</b>
                <em className="zone-sem">{r[1].inline}</em>
              </span>
            </div>
          ))}
        </div>
      );
    default:
      return <Ledger headers={headers} rows={rows} />;
  }
}
