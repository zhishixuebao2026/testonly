import { useEffect, useMemo, useRef, useState } from "react";
import {
  Search, Menu, X, Sun, Moon, ArrowUp, Minus, Plus, ChevronRight, BookOpen,
} from "lucide-react";
import { CHAPTERS, TOC_GROUPS, SEARCH_INDEX, QUICK_JUMPS, scrollToId, type SearchEntry } from "../lib/doc";

/* ================================================================== */
/* 顶栏 / 进度 / 目录 / 检索 / 字号 / 昼夜                                */
/* ================================================================== */

export const FONT_STEPS = [15, 16.5, 18, 19.5, 21];

interface ChromeProps {
  theme: "dark" | "light";
  onTheme: () => void;
  fontStep: number;
  onFontStep: (n: number) => void;
  activeChapter: string;
  activeTitle: string;
  activeKicker: string;
}

/* ------------------------------ 检索 ------------------------------ */

function SearchDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const results = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return [];
    const out: SearchEntry[] = [];
    for (const e of SEARCH_INDEX) {
      const hay = `${e.num ?? ""} ${e.text} ${e.chapter}`.toLowerCase();
      if (hay.includes(query)) out.push(e);
      if (out.length >= 60) break;
    }
    out.sort((a, b) => a.level - b.level);
    return out;
  }, [q]);

  useEffect(() => {
    if (open) {
      setQ(""); setSel(0);
      setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open]);

  useEffect(() => { setSel(0); }, [q]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, results.length - 1)); }
      if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
      if (e.key === "Enter" && results[sel]) {
        scrollToId(results[sel].id);
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, results, sel, onClose]);

  useEffect(() => {
    const el = listRef.current?.querySelector<HTMLElement>(`[data-i="${sel}"]`);
    el?.scrollIntoView({ block: "nearest" });
  }, [sel]);

  if (!open) return null;
  return (
    <div className="modal-veil" onClick={onClose} role="dialog" aria-modal="true" aria-label="检索条文">
      <div className="search-panel" onClick={(e) => e.stopPropagation()}>
        <div className="search-inputrow">
          <Search size={17} aria-hidden="true" />
          <input ref={inputRef} value={q} onChange={(e) => setQ(e.target.value)}
            placeholder="检索条文 · 如「0.2」「证伪」「葛立恒」「位格」…"
            aria-label="检索条文" />
          <button className="icon-btn" onClick={onClose} aria-label="关闭检索"><X size={16} /></button>
        </div>
        <div className="search-results" ref={listRef}>
          {q.trim() === "" ? (
            <div className="search-quick">
              <p className="search-hint">常用直达</p>
              {QUICK_JUMPS.map((j) => (
                <button key={j.id} className="search-item" onClick={() => { scrollToId(j.id); onClose(); }}>
                  <span className="search-item-num">◈</span>
                  <span className="search-item-text">{j.label}<em>{j.hint}</em></span>
                  <ChevronRight size={14} aria-hidden="true" />
                </button>
              ))}
            </div>
          ) : results.length === 0 ? (
            <p className="search-empty">未找到「{q}」——试试条文编号或量级名称。</p>
          ) : (
            results.map((r, i) => (
              <button key={r.id + i} data-i={i}
                className={`search-item ${i === sel ? "is-sel" : ""}`}
                onMouseEnter={() => setSel(i)}
                onClick={() => { scrollToId(r.id); onClose(); }}>
                <span className="search-item-num">{r.num ?? (r.level === 1 ? "卷" : "◈")}</span>
                <span className="search-item-text">{r.text}<em>{r.chapter}</em></span>
                <ChevronRight size={14} aria-hidden="true" />
              </button>
            ))
          )}
        </div>
        <div className="search-foot">
          <span>↑↓ 选择</span><span>Enter 跳转</span><span>Esc 关闭</span>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ 目录 ------------------------------ */

function TocList({ active, onGo }: { active: string; onGo: (id: string) => void }) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const nav = ref.current;
    if (!nav) return;
    const sc = nav.closest<HTMLElement>(".rail-scroll") ?? nav.closest<HTMLElement>(".drawer-scroll");
    const el = nav.querySelector<HTMLElement>(".toc-item.is-active");
    if (sc && el) {
      const y = el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop;
      if (y < sc.scrollTop + 40 || y > sc.scrollTop + sc.clientHeight - 60) {
        sc.scrollTo({ top: Math.max(0, y - sc.clientHeight / 2), behavior: "smooth" });
      }
    }
  }, [active]);
  return (
    <nav className="toc" aria-label="章节目录" ref={ref}>
      {TOC_GROUPS.map((g) => (
        <div key={g.label} className="toc-group">
          <p className="toc-label">{g.label}</p>
          {g.items.map((c) => (
            <button key={c.id}
              className={`toc-item ${active === c.id ? "is-active" : ""}`}
              onClick={() => onGo(c.id)}>
              <span className="toc-tick" aria-hidden="true" />
              <span className="toc-text">
                {c.kind === "part" && <em>{c.kicker.split(" · ")[0]}</em>}
                {c.short}
              </span>
            </button>
          ))}
        </div>
      ))}
    </nav>
  );
}

/* ------------------------------ 顶栏 ------------------------------ */

export default function Chrome(props: ChromeProps) {
  const { theme, onTheme, fontStep, onFontStep, activeChapter, activeTitle, activeKicker } = props;
  const [progress, setProgress] = useState(0);
  const [showTop, setShowTop] = useState(false);
  const [showDock, setShowDock] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [search, setSearch] = useState(false);

  useEffect(() => {
    let tick = false;
    const onScroll = () => {
      if (tick) return;
      tick = true;
      requestAnimationFrame(() => {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        setProgress(max > 0 ? Math.min(1, window.scrollY / max) : 0);
        setShowTop(window.scrollY > 1400);
        setShowDock(window.scrollY > window.innerHeight * 0.8);
        tick = false;
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearch((s) => !s);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    document.body.style.overflow = drawer ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [drawer]);

  const go = (id: string) => { setDrawer(false); scrollToId(id); };

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <button className="brand" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="回到卷首">
            <span className="brand-sun" aria-hidden="true">⊙</span>
            <span className="brand-name">衡天</span>
            <span className="brand-tag">第五版</span>
          </button>

          <div className="topbar-now" aria-live="polite">
            <span className="topbar-now-kicker" key={activeKicker + "k"}>{activeKicker}</span>
            <span className="topbar-now-title" key={activeTitle + "t"}>{activeTitle}</span>
          </div>

          <div className="topbar-tools">
            <button className="tool-btn" onClick={() => setSearch(true)} aria-label="检索条文（Ctrl+K）" title="检索条文（Ctrl+K）">
              <Search size={16} /><span className="tool-label">检索</span>
            </button>
            <div className="font-ctrl" role="group" aria-label="字号调节">
              <button className="tool-btn tool-sq" onClick={() => onFontStep(fontStep - 1)}
                disabled={fontStep <= 0} aria-label="减小字号" title="减小字号">
                <Minus size={14} />
              </button>
              <span className="font-meter" title={`字号 ${fontStep + 1} / ${FONT_STEPS.length}`} aria-label={`字号 ${fontStep + 1} / ${FONT_STEPS.length}`}>
                <span className="font-meter-a">A</span>
                <span className="font-meter-bars" aria-hidden="true">
                  {FONT_STEPS.map((_, i) => <i key={i} className={i <= fontStep ? "on" : ""} />)}
                </span>
              </span>
              <button className="tool-btn tool-sq" onClick={() => onFontStep(fontStep + 1)}
                disabled={fontStep >= FONT_STEPS.length - 1} aria-label="增大字号" title="增大字号">
                <Plus size={14} />
              </button>
            </div>
            <button className="tool-btn" onClick={onTheme}
              aria-label={theme === "dark" ? "切换到昼测（亮色）" : "切换到夜观（暗色）"}
              title={theme === "dark" ? "切换到昼测（亮色）" : "切换到夜观（暗色）"}>
              {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
              <span className="tool-label">{theme === "dark" ? "昼测" : "夜观"}</span>
            </button>
            <button className="tool-btn toc-toggle" onClick={() => setDrawer(true)} aria-label="打开目录">
              <Menu size={17} /><span className="tool-label">目录</span>
            </button>
          </div>
        </div>
        <div className="progress" aria-hidden="true">
          <i style={{ width: `${progress * 100}%` }} />
        </div>
      </header>

      {/* 移动端目录抽屉 */}
      <div className={`drawer-veil ${drawer ? "is-open" : ""}`} onClick={() => setDrawer(false)} aria-hidden={!drawer} />
      <aside className={`drawer ${drawer ? "is-open" : ""}`} aria-label="目录抽屉" aria-hidden={!drawer}>
        <div className="drawer-head">
          <span className="drawer-title"><BookOpen size={15} /> 目录</span>
          <button className="icon-btn" onClick={() => setDrawer(false)} aria-label="关闭目录"><X size={17} /></button>
        </div>
        <button className="drawer-search" onClick={() => { setDrawer(false); setSearch(true); }}>
          <Search size={15} /> 检索条文与量级…
        </button>
        <div className="drawer-scroll">
          <TocList active={activeChapter} onGo={go} />
        </div>
      </aside>

      <SearchDialog open={search} onClose={() => setSearch(false)} />

      {(() => {
        const i = CHAPTERS.findIndex((c) => c.id === activeChapter);
        const prev = i > 0 ? CHAPTERS[i - 1] : null;
        const next = i >= 0 && i < CHAPTERS.length - 1 ? CHAPTERS[i + 1] : null;
        return (
          <nav className={`dock ${showDock ? "is-show" : ""}`} aria-label="章节快捷导航">
            <button className="dock-btn" disabled={!prev} onClick={() => prev && scrollToId(prev.id)} aria-label="上一章">
              <ChevronRight size={17} style={{ transform: "rotate(180deg)" }} />
            </button>
            <button className="dock-now" onClick={() => setDrawer(true)} aria-label="打开目录">
              <span className="dock-ring" aria-hidden="true" style={{ ["--p" as string]: progress }} />
              <span className="dock-text">
                <em>{activeKicker.split(" · ")[0]}</em>
                <b>{activeTitle}</b>
              </span>
              <Menu size={15} aria-hidden="true" />
            </button>
            <button className="dock-btn" disabled={!next} onClick={() => next && scrollToId(next.id)} aria-label="下一章">
              <ChevronRight size={17} />
            </button>
            <button className="dock-btn dock-top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="回到顶部">
              <ArrowUp size={16} />
            </button>
          </nav>
        );
      })()}

      <button className={`backtop ${showTop ? "is-show" : ""}`}
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        aria-label="回到顶部" title="回到顶部">
        <ArrowUp size={17} />
      </button>
    </>
  );
}

export { TocList };