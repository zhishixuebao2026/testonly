import { useEffect, useState } from "react";

/* ------------------------------------------------------------------ */
/* 衡天仪：二十八宿外环 · 黄道环（-23.4°）· 十二辰内环 · 北斗 · 中心 ⊙     */
/* ------------------------------------------------------------------ */

const XIU = "角亢氐房心尾箕斗牛女虚危室壁奎娄胃昴毕觜参井鬼柳星张翼轸".split("");
const CHEN = "子丑寅卯辰巳午未申酉戌亥".split("");
const CX = 260, CY = 260;

function polar(r: number, deg: number): [number, number] {
  const a = ((deg - 90) * Math.PI) / 180;
  return [CX + r * Math.cos(a), CY + r * Math.sin(a)];
}

/* 北斗七星（相对坐标，装饰用） */
const DIPPER: [number, number][] = [
  [96, 118], [126, 104], [156, 112], [182, 130], [214, 126], [226, 158], [196, 170],
];

export default function Armillary() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    setReduced(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }, []);

  const outerTicks = Array.from({ length: 112 }, (_, i) => {
    const deg = (i * 360) / 112;
    const major = i % 4 === 0;
    const [x1, y1] = polar(major ? 225 : 230, deg);
    const [x2, y2] = polar(237, deg);
    return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} strokeWidth={major ? 1.4 : 0.6} />;
  });

  const innerTicks = Array.from({ length: 60 }, (_, i) => {
    const deg = i * 6;
    const [x1, y1] = polar(96, deg);
    const [x2, y2] = polar(i % 5 === 0 ? 106 : 102, deg);
    return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} strokeWidth={i % 5 === 0 ? 1.2 : 0.5} />;
  });

  return (
    <svg viewBox="0 0 520 520" className="armillary" role="img"
      aria-label="衡天仪：以二十八宿与黄道环围绕太阳符号 ⊙ 的观象仪器图形">
      <defs>
        <radialGradient id="arm-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--brass)" stopOpacity="0.5" />
          <stop offset="45%" stopColor="var(--brass)" stopOpacity="0.08" />
          <stop offset="100%" stopColor="var(--brass)" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="arm-tube" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="var(--brass)" stopOpacity="0" />
          <stop offset="50%" stopColor="var(--brass)" stopOpacity="0.5" />
          <stop offset="100%" stopColor="var(--brass)" stopOpacity="0" />
        </linearGradient>
      </defs>

      <circle cx={CX} cy={CY} r={252} fill="url(#arm-glow)" className="arm-breath" />

      {/* 二十八宿外环 */}
      <g className="arm-rot-slow arm-ink">
        <circle cx={CX} cy={CY} r={244} fill="none" strokeWidth={1.1} />
        <circle cx={CX} cy={CY} r={222} fill="none" strokeWidth={0.5} opacity={0.7} />
        <g stroke="currentColor">{outerTicks}</g>
        {XIU.map((ch, i) => {
          const deg = (i * 360) / 28 + 360 / 56;
          const [x, y] = polar(208, deg);
          return (
            <text key={i} x={x} y={y} fontSize={13.5}
              transform={`rotate(${deg} ${x} ${y})`}
              textAnchor="middle" dominantBaseline="middle"
              className="arm-xiu" fill="currentColor" stroke="none">
              {ch}
            </text>
          );
        })}
      </g>

      {/* 赤道刻度环 */}
      <g className="arm-ink" opacity={0.5}>
        <circle cx={CX} cy={CY} r={168} fill="none" strokeWidth={0.7} strokeDasharray="2 5" />
        <circle cx={CX} cy={CY} r={140} fill="none" strokeWidth={0.5} strokeDasharray="1 7" />
      </g>

      {/* 黄道环 -23.4° */}
      <g transform={`rotate(-23.4 ${CX} ${CY})`} className="arm-ecliptic">
        <path id="arm-ecl-path"
          d={`M ${CX - 196} ${CY} A 196 74 0 1 0 ${CX + 196} ${CY} A 196 74 0 1 0 ${CX - 196} ${CY}`}
          fill="none" strokeWidth={1} strokeDasharray="6 4" />
        {!reduced && (
          <circle r={4.5} className="arm-planet" stroke="none">
            <animateMotion dur="16s" repeatCount="indefinite" rotate="0">
              <mpath href="#arm-ecl-path" />
            </animateMotion>
          </circle>
        )}
        {reduced && <circle cx={CX + 196} cy={CY} r={4.5} className="arm-planet" stroke="none" />}
      </g>

      {/* 窥管 */}
      <g transform={`rotate(37 ${CX} ${CY})`} opacity={0.5}>
        <rect x={CX - 158} y={CY - 5} width={316} height={10} rx={5} fill="url(#arm-tube)" />
      </g>

      {/* 十二辰内环 */}
      <g className="arm-rot-rev arm-ink">
        <circle cx={CX} cy={CY} r={112} fill="none" strokeWidth={0.9} />
        <g stroke="currentColor">{innerTicks}</g>
        {CHEN.map((ch, i) => {
          const deg = i * 30 + 15;
          const [x, y] = polar(84, deg);
          return (
            <text key={i} x={x} y={y} fontSize={10.5}
              transform={`rotate(${deg} ${x} ${y})`}
              textAnchor="middle" dominantBaseline="middle"
              className="arm-chen" fill="currentColor" stroke="none">
              {ch}
            </text>
          );
        })}
      </g>

      {/* 北斗 */}
      <g className="arm-dipper">
        <polyline points={DIPPER.map((p) => p.join(",")).join(" ")}
          fill="none" strokeWidth={0.8} strokeDasharray="3 3" />
        {DIPPER.map((p, i) => (
          <circle key={i} cx={p[0]} cy={p[1]} r={i === 0 ? 3.4 : 2.4} stroke="none" />
        ))}
      </g>

      {/* 中心 ⊙ */}
      <g className="arm-core">
        <line x1={CX - 66} y1={CY} x2={CX - 34} y2={CY} strokeWidth={0.8} />
        <line x1={CX + 34} y1={CY} x2={CX + 66} y2={CY} strokeWidth={0.8} />
        <line x1={CX} y1={CY - 66} x2={CX} y2={CY - 34} strokeWidth={0.8} />
        <line x1={CX} y1={CY + 34} x2={CX} y2={CY + 66} strokeWidth={0.8} />
        <circle cx={CX} cy={CY} r={26} fill="none" strokeWidth={1.6} className="arm-sun-ring" />
        <circle cx={CX} cy={CY} r={7.5} stroke="none" className="arm-sun-dot" />
        {!reduced && <circle cx={CX} cy={CY} r={26} fill="none" strokeWidth={1} className="arm-pulse" />}
      </g>
    </svg>
  );
}
