import { useState } from "react";
import { CHAPTERS, scrollToId } from "../lib/doc";

/* ================================================================== */
/* 附加信息图（原文之外新增的可视化，不改动任何原文文字）                   */
/* ================================================================== */

/* ---------------------- 通则速航：0.1 – 0.20 ---------------------- */

export function ClauseNav() {
  const items = CHAPTERS[8].headings.filter(
    (h) => h.level === 2 && h.num && /^0\.\d+$/.test(h.num)
  );
  return (
    <div className="clausenav" data-rv aria-label="判定通则速航">
      <p className="clausenav-cap">二十条通则 · 点按直达</p>
      <div className="clausenav-grid">
        {items.map((h) => (
          <button key={h.id} type="button" className="clausenav-chip"
            onClick={() => scrollToId(h.id)}
            title={h.text}>
            <span className="clausenav-num">{h.num}</span>
            <span className="clausenav-text">{h.text.replace(/^0\.\d+\s*/, "")}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------------------- 七维罗盘 ---------------------- */

const DIMS = [
  { g: "破", name: "破坏", d: "一次作用实际造成的破坏", to: "s-1-1" },
  { g: "控", name: "掌控", d: "对一片范围的整体接管", to: "s-9-3" },
  { g: "域", name: "影响范围", d: "范围 × 可突破强度上限", to: "s-9-3" },
  { g: "御", name: "防御", d: "承受过什么而未被摧毁", to: "s-9-2" },
  { g: "速", name: "速度", d: "移动 · 反应 · 投送", to: "s-9-1" },
  { g: "算", name: "计算层级", d: "有限算力或图灵跃迁", to: "s-9-4" },
  { g: "性", name: "特性", d: "不灭、跨界、概念类等", to: "s-9-5" },
];

export function HeptadDial() {
  const [hover, setHover] = useState<number | null>(null);
  const CX = 200, CY = 186, R = 118;
  const pts = DIMS.map((_, i) => {
    const a = ((i * 360) / 7 - 90) * (Math.PI / 180);
    return [CX + R * Math.cos(a), CY + R * Math.sin(a)] as const;
  });
  const rings = [0.38, 0.68, 1].map((k) =>
    pts.map((p) => `${CX + (p[0] - CX) * k},${CY + (p[1] - CY) * k}`).join(" ")
  );
  const active = hover != null ? DIMS[hover] : null;
  return (
    <div className="heptad" data-rv>
      <svg viewBox="0 0 400 372" className="heptad-svg" role="img" aria-label="七维罗盘：破、控、域、御、速、算、性">
        <g className="heptad-web">
          {rings.map((r, i) => <polygon key={i} points={r} fill="none" />)}
          {pts.map((p, i) => <line key={i} x1={CX} y1={CY} x2={p[0]} y2={p[1]} />)}
        </g>
        <g className="heptad-sweep">
          <line x1={CX} y1={CY} x2={CX} y2={CY - R - 8} />
        </g>
        <circle cx={CX} cy={CY} r={4} className="heptad-core" />
        {pts.map((p, i) => {
          const dx = p[0] - CX, dy = p[1] - CY;
          const lx = CX + dx * 1.3;
          const ly = CY + dy * 1.3 + (dy > 80 ? 8 : dy < -80 ? -4 : 0);
          const anchor = Math.abs(dx) < 30 ? "middle" : dx > 0 ? "start" : "end";
          return (
            <g key={i} className={`heptad-node ${hover === i ? "is-hover" : ""}`}
              onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}
              onFocus={() => setHover(i)} onBlur={() => setHover(null)}
              onClick={() => scrollToId(DIMS[i].to)}
              tabIndex={0} role="button"
              aria-label={`${DIMS[i].g}（${DIMS[i].name}）：${DIMS[i].d}，点击查看细则`}>
              <circle cx={p[0]} cy={p[1]} r={17} className="heptad-node-bg" />
              <text x={p[0]} y={p[1] + 1} textAnchor="middle" dominantBaseline="middle" className="heptad-glyph">{DIMS[i].g}</text>
              <text x={lx} y={ly} textAnchor={anchor} dominantBaseline="middle" className="heptad-name">{DIMS[i].name}</text>
            </g>
          );
        })}
      </svg>
      <div className="heptad-side">
        <p className="heptad-cap">七维罗盘</p>
        <p className="heptad-read" aria-live="polite">
          {active ? (
            <><b>{active.g} · {active.name}</b><span>{active.d}</span></>
          ) : (
            <><b>多维表负责记录，综合量级负责比较</b><span>悬停或点按任一维，查看含义与细则</span></>
          )}
        </p>
        <p className="heptad-note">数量轴与层级轴不是独立维度，而是「破」「控」「域」的范围描述。</p>
      </div>
    </div>
  );
}

/* ---------------------- 覆盖模型双图 ---------------------- */

export function CoverageModels() {
  return (
    <div className="models" data-rv>
      <div className="model-card">
        <svg viewBox="0 0 240 130" aria-hidden="true">
          <path d="M 20 110 A 100 100 0 0 1 220 110" fill="none" className="model-arc" />
          <path d="M 20 110 A 100 100 0 0 1 220 110 L 20 110 Z" className="model-fill" stroke="none" />
          <line x1={20} y1={110} x2={220} y2={110} className="model-base" />
          <line x1={20} y1={110} x2={158} y2={38} className="model-ray" />
          <circle cx={20} cy={110} r={5} className="model-src" />
          <circle cx={220} cy={110} r={3.4} className="model-edge" />
          <text x={120} y={124} textAnchor="middle" className="model-d">D（边缘到边缘）</text>
          <text x={78} y={62} className="model-r">传播半径 = D</text>
        </svg>
        <h4>半球扩散 <em>立体球状目标 · 默认</em></h4>
        <p className="model-formula">E = 2πD² × F*</p>
      </div>
      <div className="model-vs" aria-hidden="true">8×</div>
      <div className="model-card">
        <svg viewBox="0 0 240 130" aria-hidden="true">
          <ellipse cx={120} cy={78} rx={100} ry={30} className="model-fill" />
          <ellipse cx={120} cy={78} rx={100} ry={30} fill="none" className="model-arc" />
          <ellipse cx={120} cy={78} rx={62} ry={18} fill="none" className="model-inner" />
          <line x1={20} y1={78} x2={220} y2={78} className="model-ray" />
          <circle cx={20} cy={78} r={5} className="model-src" />
          <text x={120} y={124} textAnchor="middle" className="model-d">D（盘面直径）</text>
        </svg>
        <h4>盘面适配 <em>扁平盘状目标 · 星系专用</em></h4>
        <p className="model-formula">E = πD²/4 × F*</p>
      </div>
      <p className="models-note">同一直径 D 下，半球值恰为盘面值的 8 倍；覆盖模型恰好罩住一颗恒星时的最低代价为 8U——覆盖开销的地板。</p>
    </div>
  );
}

/* ---------------------- 入区线幂塔 ---------------------- */

export function PowerTower() {
  return (
    <div className="tower" data-rv>
      <div className="tower-visual" aria-hidden="true">
        <span className="tower-l tower-l1">10</span>
        <span className="tower-l tower-l2">10</span>
        <span className="tower-l tower-l3">10</span>
        <span className="tower-eq">= 10↑↑3</span>
      </div>
      <div className="tower-text">
        <p className="tower-cap">入区线 · 记数方式的质变</p>
        <p className="tower-desc">
          标准宇宙能量的 10↑↑3 倍——10 的 10¹⁰ 次方。在此之前，指数是普通的数；
          在此之后，<b>指数本身也要用指数来写</b>。
        </p>
      </div>
    </div>
  );
}
