import type { MouseEvent } from "react";
import { ChevronDown, Scale, Layers, Library, Sigma } from "lucide-react";
import Armillary from "./Armillary";
import { scrollToId } from "../lib/doc";

function tilt(e: MouseEvent<HTMLDivElement>) {
  const el = e.currentTarget;
  const r = el.getBoundingClientRect();
  const x = (e.clientX - r.left) / r.width - 0.5;
  const y = (e.clientY - r.top) / r.height - 0.5;
  el.style.setProperty("--tx", `${(-y * 5).toFixed(2)}deg`);
  el.style.setProperty("--ty", `${(x * 7).toFixed(2)}deg`);
}
function untilt(e: MouseEvent<HTMLDivElement>) {
  e.currentTarget.style.setProperty("--tx", "0deg");
  e.currentTarget.style.setProperty("--ty", "0deg");
}

/* ------------------------------------------------------------------ */
/* 卷首门面：题名 · 衡天仪 · 全链能谱                                     */
/* ------------------------------------------------------------------ */

const SPECTRUM = [
  { key: "inherit", label: "虫 → 恒", sub: "继承区", target: "s-2-3", grow: 30 },
  { key: "transA", label: "过渡", sub: "A", target: "s-3-1", grow: 5 },
  { key: "cover", label: "系 → 构", sub: "覆盖体系", target: "s-4-3", grow: 24 },
  { key: "univer", label: "宇", sub: "宇宙级", target: "s-4-9", grow: 15 },
  { key: "wide", label: "广", sub: "广义无限区", target: "ch-13", grow: 12 },
  { key: "beyond", label: "外·天", sub: "论外级", target: "ch-16", grow: 14 },
];

export default function Masthead() {
  return (
    <section className="masthead" aria-label="卷首">
      <div className="masthead-grid">
        <div className="masthead-left">
          <div className="masthead-kicker">
            <span className="masthead-seal" aria-hidden="true">第五版</span>
            <span className="masthead-eyebrow">观象授时 · 以恒星为尺</span>
          </div>

          <h1 className="masthead-title" aria-label="衡天⊙ 多维战力量级体系（第五版）">
            <span className="masthead-brush">衡天</span>
            <span className="masthead-sun" aria-hidden="true">⊙</span>
          </h1>

          <p className="masthead-sub">多维战力量级体系<span className="masthead-ver">第五版</span></p>
          <p className="masthead-en">HENGTIAN · MULTI-AXIS POWER SCALE · FIFTH EDITION</p>

          <p className="masthead-quote">
            「衡」是称量，「天」是从凡人一直量到天外。<br className="br-desktop" />
            整套刻度，从一颗恒星开始向外衡量。
          </p>

          <div className="masthead-stats" role="list">
            <span role="listitem"><Layers size={14} aria-hidden="true" />七维评定</span>
            <span role="listitem"><Scale size={14} aria-hidden="true" />二十条通则</span>
            <span role="listitem"><Library size={14} aria-hidden="true" />十二个部分</span>
            <span role="listitem"><Sigma size={14} aria-hidden="true" />10⁻⁵ J 至 ℵ₀ 之上</span>
          </div>

          <div className="spectrum" aria-label="全链能谱：点击区间直达对应部分">
            <div className="spectrum-head">
              <span>全链能谱</span>
              <span className="spectrum-hint">点按区间直达</span>
            </div>
            <div className="spectrum-bar">
              {SPECTRUM.map((s) => (
                <button key={s.key} type="button"
                  className={`spectrum-seg spectrum-${s.key}`}
                  style={{ flexGrow: s.grow }}
                  onClick={() => scrollToId(s.target)}
                  title={`${s.sub} · 点击直达`}
                  aria-label={`${s.sub}，点击直达`}>
                  <span className="spectrum-label">{s.label}</span>
                </button>
              ))}
            </div>
            <div className="spectrum-foot">
              <span>10⁻⁵ J</span>
              <span className="spectrum-foot-mid">能量对数轴 → 10↑↑3 → 真无限</span>
              <span>ℵ₀ 起</span>
            </div>
          </div>

          <p className="masthead-meta">
            2026-10-25 发布 · 2026-10-30 修订 · 原文完整收录，未删改
          </p>
        </div>

        <div className="masthead-right" onMouseMove={tilt} onMouseLeave={untilt}>
          <Armillary />
          <p className="masthead-caption">
            <span className="sun-mark">⊙</span> 基准通量 F* = 1.64×10²³ J/m²
            <em>自一颗恒星，向外衡量</em>
          </p>
        </div>
      </div>

      <button className="scroll-cue" onClick={() => scrollToId("ch-0")}
        aria-label="向下开卷">
        <span>下滑开卷</span>
        <ChevronDown size={16} aria-hidden="true" />
      </button>
    </section>
  );
}
