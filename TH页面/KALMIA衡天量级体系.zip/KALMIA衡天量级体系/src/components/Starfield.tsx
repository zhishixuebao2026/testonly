import { useEffect, useRef } from "react";

/* ------------------------------------------------------------------ */
/* 星空画布：夜观为星，昼测为尘埃刻度；视差随滚动，尊重减弱动态设置          */
/* ------------------------------------------------------------------ */

interface Star {
  x: number; y: number; r: number; d: number;
  tw: number; ph: number; hue: number;
}

export default function Starfield({ theme }: { theme: "dark" | "light" }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const themeRef = useRef(theme);
  themeRef.current = theme;

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let stars: Star[] = [];
    let w = 0, h = 0, dpr = 1;
    let raf = 0;
    let running = true;
    let shoot: { x: number; y: number; vx: number; vy: number; life: number } | null = null;
    let nextShoot = performance.now() + 5000;

    const resize = () => {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(200, Math.floor((w * h) / 11000));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: Math.random() * 1.4 + 0.3,
        d: Math.random() * 0.8 + 0.2,
        tw: Math.random() * 1.6 + 0.6,
        ph: Math.random() * Math.PI * 2,
        hue: Math.random(),
      }));
      if (reduced) draw(0);
    };

    const color = (s: Star, a: number) => {
      if (themeRef.current === "dark") {
        if (s.hue > 0.86) return `rgba(240,205,138,${a})`;
        if (s.hue > 0.72) return `rgba(150,222,205,${a})`;
        return `rgba(226,233,248,${a})`;
      }
      if (s.hue > 0.8) return `rgba(148,110,32,${a * 0.5})`;
      return `rgba(34,48,80,${a * 0.4})`;
    };

    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h);
      const scroll = window.scrollY;
      const dark = themeRef.current === "dark";
      for (const s of stars) {
        const twinkle = reduced ? 0.75 : 0.55 + 0.45 * Math.sin(t / 1000 * s.tw + s.ph);
        const a = (dark ? 0.85 : 0.5) * twinkle * s.d;
        const y = (((s.y - scroll * s.d * 0.12) % h) + h) % h;
        ctx.beginPath();
        ctx.arc(s.x, y, s.r * (dark ? 1 : 0.8), 0, Math.PI * 2);
        ctx.fillStyle = color(s, a);
        ctx.fill();
        if (dark && s.r > 1.3 && twinkle > 0.9) {
          ctx.fillStyle = color(s, a * 0.25);
          ctx.beginPath();
          ctx.arc(s.x, y, s.r * 2.6, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      if (dark && !reduced) {
        const now = performance.now();
        if (!shoot && now > nextShoot) {
          shoot = {
            x: Math.random() * w * 0.7 + w * 0.2,
            y: Math.random() * h * 0.3,
            vx: -(4 + Math.random() * 3),
            vy: 2 + Math.random() * 1.6,
            life: 1,
          };
          nextShoot = now + 6000 + Math.random() * 8000;
        }
        if (shoot) {
          shoot.x += shoot.vx; shoot.y += shoot.vy; shoot.life -= 0.018;
          const g = ctx.createLinearGradient(shoot.x, shoot.y, shoot.x - shoot.vx * 12, shoot.y - shoot.vy * 12);
          g.addColorStop(0, `rgba(240,215,160,${Math.max(0, shoot.life) * 0.9})`);
          g.addColorStop(1, "rgba(240,215,160,0)");
          ctx.strokeStyle = g;
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(shoot.x, shoot.y);
          ctx.lineTo(shoot.x - shoot.vx * 12, shoot.y - shoot.vy * 12);
          ctx.stroke();
          if (shoot.life <= 0) shoot = null;
        }
      }
    };

    const loop = (t: number) => {
      if (!running) return;
      draw(t);
      raf = requestAnimationFrame(loop);
    };

    resize();
    window.addEventListener("resize", resize);
    const onVis = () => {
      running = document.visibilityState === "visible";
      if (running && !reduced) { cancelAnimationFrame(raf); raf = requestAnimationFrame(loop); }
    };
    document.addEventListener("visibilitychange", onVis);
    if (!reduced) raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  return <canvas ref={ref} className="starfield" aria-hidden="true" />;
}
