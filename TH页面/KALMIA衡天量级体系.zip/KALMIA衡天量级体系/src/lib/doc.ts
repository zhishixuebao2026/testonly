import raw from "../../content/original.md?raw";

/* ------------------------------------------------------------------ */
/* 衡天 · 文档数据层：章节切分 / 锚点 / 目录 / 检索索引                    */
/* 原文完整内嵌，不删改一字。                                            */
/* ------------------------------------------------------------------ */

export type ChapterKind =
  | "cover"
  | "sigils"
  | "revision"
  | "purpose"
  | "workflow"
  | "part"
  | "appendix";

export interface Heading {
  id: string;
  text: string;
  level: 2 | 3;
  num?: string;
}

export interface Chapter {
  id: string;
  idx: number;
  title: string;
  kind: ChapterKind;
  kicker: string;
  short: string;
  body: string;
  headings: Heading[];
}

export function hashText(s: string): string {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h.toString(36);
}

export function headingId(text: string): string {
  const m = text.match(/^(\d+(?:\.\d+)*)[ \u3000]/);
  if (m) return "s-" + m[1].replace(/\./g, "-");
  return "h-" + hashText(text);
}

const CN = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一"];

function kindOf(idx: number): ChapterKind {
  if (idx === 0) return "cover";
  if (idx === 1) return "sigils";
  if (idx >= 2 && idx <= 5) return "revision";
  if (idx === 6) return "purpose";
  if (idx === 7) return "workflow";
  if (idx >= 8 && idx <= 19) return "part";
  return "appendix";
}

function buildChapters(): Chapter[] {
  const chunks = raw.split(/(?=^# )/m).filter((c) => c.trim().length > 0);
  return chunks.map((chunk, idx) => {
    const nl = chunk.indexOf("\n");
    const title = chunk.slice(2, nl).trim();
    let body = chunk.slice(nl + 1).replace(/^\s*\n/, "");
    // 去掉章节末尾的纯分隔线（渲染为卷首装饰，不属于文字内容）
    body = body.replace(/\n---\s*$/, "\n");
    const kind = kindOf(idx);
    const headings: Heading[] = [];
    for (const line of body.split("\n")) {
      const m = line.match(/^(##|###)\s+(.*)$/);
      if (m) {
        const text = m[2].trim();
        const num = text.match(/^(\d+(?:\.\d+)*)[ \u3000]/)?.[1];
        headings.push({
          id: headingId(text),
          text,
          level: m[1].length as 2 | 3,
          num,
        });
      }
    }
    let kicker = "";
    let short = title;
    if (kind === "cover") {
      kicker = "卷首 · PREFACE";
      short = "题名与缘起";
    } else if (kind === "sigils") {
      kicker = "符号 · SIGILS";
      short = "符号速查";
    } else if (kind === "revision") {
      const v = ["五", "四", "三", "二"][idx - 2];
      kicker = `沿革 · REVISION Ⅴ`.replace("Ⅴ", ["Ⅴ", "Ⅳ", "Ⅲ", "Ⅱ"][idx - 2]);
      short = `第${v}版修订`;
    } else if (kind === "purpose") {
      kicker = "用途 · PURPOSE";
      short = "定级与证伪";
    } else if (kind === "workflow") {
      kicker = "流程 · WORKFLOW";
      short = "使用流程";
    } else if (kind === "part") {
      const n = idx - 8;
      kicker = `第${CN[n]}部分 · PART ${String(n).padStart(2, "0")}`;
      short = title.split("\u3000")[1] ?? title;
    } else {
      kicker = "附录 · APPENDIX";
      short = "未定稿事项";
    }
    return { id: `ch-${idx}`, idx, title, kind, kicker, short, body, headings };
  });
}

export const CHAPTERS: Chapter[] = buildChapters();
export const RAW_DOC = raw;
export const DOC_CHAR_COUNT = raw.replace(/\s/g, "").length;

/* ---------------------------- 目录分组 ---------------------------- */

export interface TocGroup {
  label: string;
  items: Chapter[];
}

export const TOC_GROUPS: TocGroup[] = [
  { label: "卷首", items: CHAPTERS.filter((c) => c.idx <= 1) },
  { label: "版本沿革", items: CHAPTERS.filter((c) => c.idx >= 2 && c.idx <= 5) },
  { label: "用途与流程", items: CHAPTERS.filter((c) => c.idx >= 6 && c.idx <= 7) },
  { label: "体系正文", items: CHAPTERS.filter((c) => c.idx >= 8 && c.idx <= 19) },
  { label: "附录", items: CHAPTERS.filter((c) => c.idx === 20) },
];

/* ---------------------------- 检索索引 ---------------------------- */

export interface SearchEntry {
  id: string;
  text: string;
  num?: string;
  chapter: string;
  kicker: string;
  level: 1 | 2 | 3;
}

export const SEARCH_INDEX: SearchEntry[] = CHAPTERS.flatMap((c) => [
  {
    id: c.id,
    text: c.title,
    chapter: c.short,
    kicker: c.kicker,
    level: 1 as const,
  },
  ...c.headings.map((h) => ({
    id: h.id,
    text: h.text,
    num: h.num,
    chapter: c.short,
    kicker: c.kicker,
    level: h.level,
  })),
]);

export const QUICK_JUMPS: { id: string; label: string; hint: string }[] = [
  { id: "s-0-2", label: "0.2 「无数」不等于阿列夫零", hint: "虚词默认值" },
  { id: "s-2-3", label: "2.3 量级表（昆虫～爆恒星）", hint: "继承区刻度" },
  { id: "s-4-2", label: "4.2 核心公式与基准", hint: "F* 与覆盖模型" },
  { id: "s-5-6", label: "5.6 证伪信号", hint: "先核对再降级" },
  { id: "s-8-5", label: "8.5 论外级内部分档", hint: "大基数阶梯" },
  { id: "s-11-2", label: "11.2 全链条总览", hint: "一图纵览全链" },
];

/* ------------------------- 天梯跳转目标 ------------------------- */

export const LADDER_TARGETS: Record<string, string> = {
  虫: "s-2-3", 人: "s-2-3", 砖: "s-2-3", 墙: "s-2-3", 屋: "s-2-3",
  楼: "s-2-3", 街: "s-2-3", 城: "s-2-3", 国: "s-2-3", 陆: "s-2-3",
  表: "s-2-3", 星: "s-2-3", 褐: "s-2-3", 恒: "s-2-3",
  过渡区: "s-2-3", "过渡带 A": "s-3-1", "过渡带 B": "s-3-2",
  系: "s-4-3", 团: "s-4-4", 河: "s-4-6", 簇: "s-4-7", 构: "s-4-8",
  宇: "s-4-9", 广: "ch-13", 外: "ch-16",
};

export function ladderTarget(glyph: string, name: string): string {
  const g = glyph.trim();
  if (g.startsWith("宇")) return LADDER_TARGETS["宇"];
  if (g.startsWith("外")) return LADDER_TARGETS["外"];
  if (g === "广") return LADDER_TARGETS["广"];
  if (g === "—") return LADDER_TARGETS[name.trim()] ?? "s-2-3";
  return LADDER_TARGETS[g[0]] ?? "s-2-3";
}

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
  history.replaceState(null, "", `#${id}`);
}