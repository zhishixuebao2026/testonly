import React from "react";
import type { Element, ElementContent, RootContent } from "hast";

/* ------------------------------------------------------------------ */
/* 内联渲染：证据标签着色、⊙ 标记、表格单元格抽取、能量对数解析           */
/* ------------------------------------------------------------------ */

const EV_CLASS: Record<string, string> = {
  实: "ev ev-shi",
  下: "ev ev-xia",
  推: "ev ev-tui",
  隐: "ev ev-yin",
  缺: "ev ev-que",
};

/** 将纯文本中的〔实〕〔下〕…与 ⊙ 装饰化（字符原样保留） */
export function decorateText(text: string, keyBase = ""): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  const re = /〔([实下推隐缺])〕|⊙/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    if (m[0] === "⊙") {
      parts.push(
        <span key={`${keyBase}sun${k++}`} className="sun-mark">⊙</span>
      );
    } else {
      parts.push(
        <span key={`${keyBase}ev${k++}`} className={EV_CLASS[m[1]]}>
          {m[0]}
        </span>
      );
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

/** 递归装饰 React children 中的字符串叶子 */
export function decorate(children: React.ReactNode): React.ReactNode {
  return React.Children.map(children, (child, i) => {
    if (typeof child === "string") return decorateText(child, `d${i}-`);
    if (React.isValidElement(child)) {
      const props = child.props as { children?: React.ReactNode };
      if (props.children != null && child.type !== "code") {
        return React.cloneElement(
          child,
          props as never,
          decorate(props.children)
        );
      }
    }
    return child;
  });
}

/* ------------------------- hast 内联渲染 ------------------------- */

export function renderInline(nodes: ElementContent[] | undefined, keyBase = "i"): React.ReactNode {
  if (!nodes) return null;
  return nodes.map((n, i) => {
    const key = `${keyBase}-${i}`;
    if (n.type === "text") return <React.Fragment key={key}>{decorateText(n.value, key)}</React.Fragment>;
    if (n.type === "element") {
      const inner = renderInline(n.children as ElementContent[], key);
      switch (n.tagName) {
        case "strong": return <strong key={key}>{inner}</strong>;
        case "em": return <em key={key}>{inner}</em>;
        case "del": return <del key={key}>{inner}</del>;
        case "code": return <code key={key}>{inner}</code>;
        case "br": return <br key={key} />;
        case "a": {
          const href = String(n.properties?.href ?? "#");
          return <a key={key} href={href}>{inner}</a>;
        }
        default: return <React.Fragment key={key}>{inner}</React.Fragment>;
      }
    }
    return null;
  });
}

export function textOf(node: ElementContent | Element | RootContent | undefined): string {
  if (!node) return "";
  if (node.type === "text") return node.value;
  if ("children" in node && node.children) {
    return (node.children as ElementContent[]).map((c) => textOf(c)).join("");
  }
  return "";
}

export interface Cell {
  text: string;
  node: Element;
  inline: React.ReactNode;
}

/** 从 table 的 hast 节点抽取行矩阵（含渲染好的内联内容） */
export function tableMatrix(node: Element): { headers: Cell[]; rows: Cell[][] } {
  const grab = (el: Element): Cell[] =>
    (el.children as Element[])
      .filter((c) => c.type === "element" && (c.tagName === "td" || c.tagName === "th"))
      .map((c, i) => ({
        text: textOf(c).trim(),
        node: c,
        inline: renderInline(c.children as ElementContent[], `c${i}`),
      }));
  let headers: Cell[] = [];
  const rows: Cell[][] = [];
  for (const part of node.children as Element[]) {
    if (part.type !== "element") continue;
    if (part.tagName === "thead") {
      const tr = (part.children as Element[]).find((c) => c.type === "element" && c.tagName === "tr");
      if (tr) headers = grab(tr);
    } else if (part.tagName === "tbody") {
      for (const tr of part.children as Element[]) {
        if (tr.type === "element" && tr.tagName === "tr") rows.push(grab(tr));
      }
    }
  }
  return { headers, rows };
}

/* ------------------------- 能量对数解析 ------------------------- */

const SUP_MAP: Record<string, string> = {
  "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
  "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9", "⁻": "-",
};

function supToInt(s: string): number {
  let out = "";
  for (const ch of s) out += SUP_MAP[ch] ?? "";
  return parseInt(out, 10);
}

/** 解析文本中所有能量数量级，返回 log10 值数组 */
export function parseLogs(s: string): number[] {
  const logs: number[] = [];
  const re = /([\d.,]*)\s*[×x]\s*10([⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+)|10([⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s)) !== null) {
    const sup = m[2] ?? m[3];
    const e = supToInt(sup);
    if (Number.isNaN(e)) continue;
    let coef = 1;
    if (m[1]) {
      const c = parseFloat(m[1].replace(/,/g, ""));
      if (!Number.isNaN(c) && c > 0) coef = c;
    }
    logs.push(e + Math.log10(coef));
  }
  if (logs.length === 0 && !s.includes("↑") && !s.includes("ℵ")) {
    const plain = s.match(/\d+(?:\.\d+)?/g);
    if (plain) {
      for (const p of plain.slice(0, 4)) {
        const v = parseFloat(p);
        if (v > 0) logs.push(Math.log10(v));
      }
    }
  }
  return logs;
}

export const LOG_MIN = -5;
export const LOG_MAX = 95;

export function logPos(v: number): number {
  const t = (v - LOG_MIN) / (LOG_MAX - LOG_MIN);
  return Math.max(0, Math.min(100, t * 100));
}