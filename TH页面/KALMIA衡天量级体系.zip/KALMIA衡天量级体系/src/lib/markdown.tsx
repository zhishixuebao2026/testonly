import React, { useMemo } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import type { Element } from "hast";
import { textOf, decorate } from "../lib/inline";
import { headingId } from "../lib/doc";
import { DocTable } from "../components/tables";

/* ------------------------------------------------------------------ */
/* 正文渲染：原文逐字保留，仅改变呈现方式                                 */
/* ------------------------------------------------------------------ */

type P = { node?: Element; children?: React.ReactNode };

function H2({ node, children }: P) {
  const text = textOf(node);
  const id = headingId(text);
  const num = text.match(/^(\d+(?:\.\d+)*)[ \u3000]/)?.[1];
  const rest = num ? text.slice(num.length).trim() : text;
  return (
    <h2 id={id} className="clause-head" data-rv>
      {num ? (
        <span className="clause-num" aria-hidden="true">{num}</span>
      ) : (
        <span className="clause-dot" aria-hidden="true">◈</span>
      )}
      <span className="clause-title">{num ? decorate(rest) : children}</span>
    </h2>
  );
}

function H3({ node, children }: P) {
  const text = textOf(node);
  const id = headingId(text);
  const num = text.match(/^(\d+(?:\.\d+)*)[ \u3000]/)?.[1];
  const rest = num ? text.slice(num.length).trim() : text;
  return (
    <h3 id={id} className="sub-head" data-rv>
      {num && <span className="sub-num">{num}</span>}
      <span>{num ? decorate(rest) : children}</span>
    </h3>
  );
}

const components = {
  h2: H2 as never,
  h3: H3 as never,
  p({ children }: P) {
    return <p className="doc-p" data-rv>{decorate(children)}</p>;
  },
  blockquote({ children }: P) {
    return (
      <aside className="callout" data-rv>
        <span className="callout-mark" aria-hidden="true">⊙</span>
        <div className="callout-body">{children}</div>
      </aside>
    );
  },
  ul({ children }: P) {
    return <ul className="doc-ul" data-rv>{children}</ul>;
  },
  ol({ children }: P) {
    return <ol className="doc-ol" data-rv>{children}</ol>;
  },
  li({ children }: P) {
    return <li className="doc-li">{decorate(children)}</li>;
  },
  strong({ children }: P) {
    return <strong className="doc-strong">{children}</strong>;
  },
  table({ node }: P) {
    return node ? <DocTable node={node} /> : null;
  },
  hr() {
    return (
      <div className="doc-divider" aria-hidden="true" data-rv>
        <i /><span>⊙</span><i />
      </div>
    );
  },
};

export const ChapterBody = React.memo(function ChapterBody({ md }: { md: string }) {
  return (
    <ReactMarkdown remarkPlugins={[remarkGfm]} components={components as never}>
      {md}
    </ReactMarkdown>
  );
});

/** 按指定的 h2 标题把正文切成两段（用于插入附加信息图，不改原文） */
export function useSplitBody(md: string, beforeHeading?: string) {
  return useMemo(() => {
    if (!beforeHeading) return [md, ""] as const;
    const i = md.indexOf(beforeHeading);
    if (i < 0) return [md, ""] as const;
    return [md.slice(0, i), md.slice(i)] as const;
  }, [md, beforeHeading]);
}
