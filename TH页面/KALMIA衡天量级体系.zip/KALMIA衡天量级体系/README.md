# 衡天 ⊙ 多维战力量级体系（第五版）· 单页网站

以「观象台 / 天文法典」为视觉母题的全文单页呈现：⊙ 太阳符号、二十八宿衡天仪、
夜观（暗）／昼测（亮）双主题、全链能量天梯、七维罗盘、论外基数阶梯。
**原文完整收录，未删改一字**（底本见 `content/original.md`）。

## 直接打开（无需任何环境）

双击 **`dist/index.html`** 即可在浏览器中运行整个网站。
该文件为构建产物，已内嵌全部脚本、样式与子集化字体（约 1.9 MB），
不依赖网络、不依赖 Node、不依赖任何外链，可放在任意静态托管或本地 `file://` 打开。

## 开发与构建（可选）

```bash
npm install        # 依赖已随包提供 node_modules，可跳过
npm run dev        # 开发预览
npm run build      # 重新构建 dist/index.html
```

字体如需重新生成（需联网下载原始字体）：

```bash
pip install fonttools brotli
python3 scripts/build_fonts.py   # 产物写入 src/assets/fonts/
```

## 自检脚本（Playwright）

```bash
node scripts/verify.mjs   # 溢出扫描 / 原文完整性 / 交互 / 双主题多尺寸截图 → shots/
node scripts/edge.mjs     # 减弱动态 / 最大字号小屏 / 锚点直达 / 主题持久化
```

## 功能一览

- 夜观 / 昼测 双主题（记忆偏好），字号五档（记忆偏好）
- 桌面粘性目录 + 滚动侦测高亮；移动端目录抽屉
- `Ctrl / ⌘ + K` 全文条文检索（编号、标题、常用直达）
- 宽表全部改为无横向滚动的信息图：量级分级卡、全链对数天梯（可点击跳转）、
  论外分档阶梯、快速增长台阶、七维卡与罗盘、证据印墙、账目式记录
- 星空画布（视差 / 流星，亮色为尘埃刻度）、衡天仪转环与指针微倾、滚动显现
- `prefers-reduced-motion` 全面降级；打印样式；320px 起无横向滚动

## 目录结构

```
content/original.md      原文底本（逐字内嵌进成品）
src/                     源码（数据层 / 渲染器 / 组件 / 主题样式）
src/assets/fonts/        子集化本地字体（woff2）
scripts/                 字体生成与自检脚本
shots/                   自检截图
dist/index.html          ★ 成品：双击即开的完整网站
```
