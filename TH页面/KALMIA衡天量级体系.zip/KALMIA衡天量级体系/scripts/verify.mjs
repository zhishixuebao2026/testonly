/* 自检：控制台错误 / 横向溢出 / 原文完整性 / 交互 / 截图 */
import { chromium } from "playwright";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SHOTS = path.join(ROOT, "shots");
fs.mkdirSync(SHOTS, { recursive: true });

const norm = (s) => s.replace(/\s+/g, "");
const clean = (s) => norm(s.replace(/\*\*/g, "").replace(/\\\*/g, "*"));

/* ---- 原文原子 ---- */
const md = fs.readFileSync(path.join(ROOT, "content/original.md"), "utf8");
const atoms = [];
for (let line of md.split("\n")) {
  line = line.trim().replace(/^>\s?/, "");
  if (!line || /^-{3,}$/.test(line)) continue;
  if (line.startsWith("|")) {
    for (let c of line.split("|").slice(1, -1)) {
      c = clean(c);
      if (c && !/^[-:]+$/.test(c)) atoms.push(c);
    }
    continue;
  }
  line = line.replace(/^#+\s*/, "").replace(/^[-*]\s+/, "").replace(/^\d+\.\s+/, "");
  const a = clean(line);
  if (a) atoms.push(a);
}

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
page.on("pageerror", (e) => errors.push(String(e)));

const url = "file://" + path.join(ROOT, "dist/index.html");
await page.goto(url, { waitUntil: "load" });
await page.evaluate(() => document.fonts.ready);
await page.waitForTimeout(1200);

/* ---- 横向溢出扫描 ---- */
const overflowReport = [];
for (const w of [320, 390, 768, 1024, 1440]) {
  await page.setViewportSize({ width: w, height: 900 });
  await page.waitForTimeout(450);
  const r = await page.evaluate(() => {
    const doc = document.documentElement;
    const bad = [];
    const vw = window.innerWidth;
    for (const el of document.querySelectorAll("body *")) {
      const b = el.getBoundingClientRect();
      if (b.width > 0 && (b.right > vw + 2 || b.left < -2)) {
        const cls = (el.className && typeof el.className === "string") ? el.className.slice(0, 60) : el.tagName;
        if (!el.closest(".bg-rings") && !el.closest(".armillary") && !el.closest(".drawer")) {
          bad.push(`${el.tagName}.${cls} L${Math.round(b.left)} R${Math.round(b.right)}`);
        }
      }
      if (bad.length > 12) break;
    }
    return { sw: doc.scrollWidth, vw, bad };
  });
  overflowReport.push({ w, ...r });
}
console.log("== 横向溢出 ==");
for (const r of overflowReport) {
  console.log(`w=${r.w} scrollWidth=${r.sw} innerWidth=${r.vw} ${r.sw > r.vw + 1 ? "❌溢出" : "✓"}`);
  r.bad.slice(0, 8).forEach((b) => console.log("   ", b));
}

/* ---- 原文完整性 ---- */
await page.setViewportSize({ width: 1440, height: 900 });
await page.waitForTimeout(400);
const pageText = norm(await page.evaluate(() => document.body.innerText));
const missing = [...new Set(atoms.filter((a) => a.length >= 2 && !pageText.includes(a)))];
console.log(`== 原文完整性 == 原子数 ${atoms.length}，缺失 ${missing.length}`);
missing.slice(0, 30).forEach((m) => console.log("  MISS:", m.slice(0, 90)));

/* ---- 交互 ---- */
console.log("== 交互 ==");
// 字号
const fsBefore = await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue("--doc-fs"));
await page.click('button[aria-label="增大字号"]');
const fsAfter = await page.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue("--doc-fs"));
console.log(`字号 ${fsBefore.trim()} -> ${fsAfter.trim()} ${fsBefore !== fsAfter ? "✓" : "❌"}`);
await page.click('button[aria-label="减小字号"]');
// 检索
await page.keyboard.press("Control+k");
await page.waitForTimeout(350);
await page.keyboard.type("证伪信号");
await page.waitForTimeout(350);
await page.keyboard.press("Enter");
await page.waitForTimeout(900);
const hash1 = await page.evaluate(() => location.hash);
console.log(`检索跳转 hash=${hash1} ${hash1.includes("5-6") ? "✓" : "❌"}`);
// 天梯点击
await page.evaluate(() => document.getElementById("s-11-2")?.scrollIntoView());
await page.waitForTimeout(700);
const rows = page.locator(".ladder-row");
console.log("天梯行数:", await rows.count());
await rows.nth(3).click();
await page.waitForTimeout(700);
console.log("天梯点击 hash=", await page.evaluate(() => location.hash));

/* ---- 截图 ---- */
await page.evaluate(() => { document.documentElement.style.scrollBehavior = "auto"; });
const snap = async (name, sel) => {
  if (sel) {
    await page.evaluate((s) => {
      const el = document.querySelector(s);
      if (el) window.scrollTo(0, el.getBoundingClientRect().top + window.scrollY - 74);
    }, sel);
    await page.waitForTimeout(1050);
  }
  await page.screenshot({ path: path.join(SHOTS, name + ".png") });
};
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(900);
await snap("d-top");
await snap("d-sigils", "#ch-1");
await snap("d-tiers", "#s-2-3");
await snap("d-models", "#s-4-2");
await snap("d-steps", "#s-5-4");
await snap("d-rungs", "#s-8-5");
await snap("d-ladder", "#s-11-2");
await snap("d-heptad", "#ch-9");
// 亮色
await page.click('button[aria-label="切换到昼测（亮色）"]');
await page.waitForTimeout(900);
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(700);
await snap("l-top");
await snap("l-tiers", "#s-2-3");
await snap("l-ladder", "#s-11-2");
await snap("l-rungs", "#s-8-5");
// 手机
await page.setViewportSize({ width: 390, height: 844 });
await page.waitForTimeout(600);
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(700);
await snap("m-light-top");
await page.click('button[aria-label="切换到夜观（暗色）"]');
await page.waitForTimeout(900);
await snap("m-top");
await snap("m-tiers", "#s-2-3");
await snap("m-ladder", "#s-11-2");
await snap("m-rungs", "#s-8-5");
// 抽屉 + 检索
await page.click('button[aria-label="打开目录"]');
await page.waitForTimeout(600);
await snap("m-drawer");
await page.click('button[aria-label="关闭目录"]');
await page.waitForTimeout(400);

console.log("== 控制台错误 ==", errors.length);
errors.slice(0, 10).forEach((e) => console.log("  ERR:", e.slice(0, 200)));
await browser.close();
console.log("DONE");
