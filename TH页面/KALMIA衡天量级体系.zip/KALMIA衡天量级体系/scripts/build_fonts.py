#!/usr/bin/env python3
"""下载并子集化本站全部字体（产物存入 src/assets/fonts，成品不依赖外链）。"""
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC_DIR = ROOT / ".fonts-src"
OUT = ROOT / "src" / "assets" / "fonts"
SRC_DIR.mkdir(exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)

FONTS = {
    "NotoSansSC.ttf": "https://raw.githubusercontent.com/google/fonts/main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf",
    "NotoSerifSC.ttf": "https://raw.githubusercontent.com/google/fonts/main/ofl/notoserifsc/NotoSerifSC%5Bwght%5D.ttf",
    "MaShanZheng.ttf": "https://raw.githubusercontent.com/google/fonts/main/ofl/mashanzheng/MaShanZheng-Regular.ttf",
    "PlexMono-R.ttf": "https://raw.githubusercontent.com/google/fonts/main/ofl/ibmplexmono/IBMPlexMono-Regular.ttf",
    "PlexMono-SB.ttf": "https://raw.githubusercontent.com/google/fonts/main/ofl/ibmplexmono/IBMPlexMono-SemiBold.ttf",
}

for name, url in FONTS.items():
    dest = SRC_DIR / name
    if not dest.exists() or dest.stat().st_size < 10000:
        print(f"downloading {name} ...", flush=True)
        subprocess.run(["curl", "-sL", url, "-o", str(dest)], check=True)
    print(name, dest.stat().st_size, "bytes")

# ---- 字符集：原文 + 全部源码 + 兜底符号 ----
chars = set()
files = [ROOT / "content" / "original.md", ROOT / "index.html"]
for pat in ("src/**/*.tsx", "src/**/*.ts", "src/**/*.css"):
    files.extend(ROOT.glob(pat))
for f in files:
    if f.is_file():
        chars.update(f.read_text(encoding="utf-8", errors="ignore"))

extra = (
    "".join(chr(c) for c in range(0x20, 0x7F))
    + "，。、；：？！「」『』（）《》〈〉【】〔〕—…·～×÷±≈≥≤≠∞▽○△◆☆◈◇"
    + "→←↑↓↗↘ℵ₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁸⁹⁻⁺⁽⁾′″°※§αβγεωφΓΩλκθμνπρστυξδηζ"
    + "∆∈∉⊂⊃∪∩⊨⊢∀≡≪≫√∑∏①②④⑤⑥⑧⑨⑩ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ"
    + "〇零一二三四五六七八九十百千万亿兆第部分卷夜观昼测衡天仪玑抚辰"
    + "角亢氐房心尾箕斗牛女虚危室壁奎娄胃昴毕觜参井鬼柳星张翼轸"
    + "子丑寅卯辰巳午未申酉戌亥东南西北"
)
chars.update(extra)
chars = {c for c in chars if c.isprintable() and not c.isspace()} | {" "}
text = "".join(sorted(chars))
(ROOT / ".fonts-src" / "charset.txt").write_text(text, encoding="utf-8")
print("charset size:", len(text))

BRUSH = "衡天第五版观象授时以恒星为尺自一颗向外量" + \
    "角亢氐房心尾箕斗牛女虚危室壁奎娄胃昴毕觜参井鬼柳星张翼轸子丑寅卯辰巳午未申酉戌亥零一二三四五六七八九十"
(ROOT / ".fonts-src" / "brush.txt").write_text(BRUSH, encoding="utf-8")

MONO = (
    "".join(chr(c) for c in range(0x20, 0x7F))
    + "×÷−–—→↑≈≥≤∞°·′″⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺⁽⁾₀₁₂₃₄₆₇₈₉ℵℶωεΓφ⊙△○▽◆☆〔〕"
)
(ROOT / ".fonts-src" / "mono.txt").write_text(MONO, encoding="utf-8")

PY = sys.executable

def subset(src, textfile, out, extra_args=()):
    cmd = [
        PY, "-m", "fontTools.subset", str(SRC_DIR / src),
        f"--text-file={ROOT / '.fonts-src' / textfile}",
        "--flavor=woff2", f"--output-file={OUT / out}",
        "--layout-features=*", "--no-hinting",
        *extra_args,
    ]
    subprocess.run(cmd, check=True)
    print(out, (OUT / out).stat().st_size, "bytes")

subset("NotoSansSC.ttf", "charset.txt", "ht-sans.woff2")
subset("NotoSerifSC.ttf", "charset.txt", "ht-serif.woff2")
subset("MaShanZheng.ttf", "brush.txt", "ht-brush.woff2")
subset("PlexMono-R.ttf", "mono.txt", "ht-mono.woff2")
subset("PlexMono-SB.ttf", "mono.txt", "ht-mono-sb.woff2")
print("done")
