/* 边界自检：减弱动态 / 最大字号小屏 / 锚点直达 / 主题持久化 */
import { chromium } from "playwright";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const url = "file://" + path.join(ROOT, "dist/index.html");
const browser = await chromium.launch();

/* 1. prefers-reduced-motion */
{
  const page = await browser.newPage({ reducedMotion: "reduce", viewport: { width: 1280, height: 800 } });
  const errs = [];
  page.on("pageerror", (e) => errs.push(String(e)));
  await page.goto(url); await page.waitForTimeout(1200);
  const r = await page.evaluate(() => {
    const rv = document.querySelector("[data-rv]");
    const ring = document.querySelector(".arm-rot-slow");
    return {
      rvOpacity: rv ? getComputedStyle(rv).opacity : "none",
      ringAnim: ring ? getComputedStyle(ring).animationName : "none",
    };
  });
  console.log(`减弱动态：rv opacity=${r.rvOpacity}（应为1） 环动画=${r.ringAnim}（应为none） 错误=${errs.length}`);
  await page.close();
}

/* 2. 最大字号 + 320px */
{
  const page = await browser.newPage({ viewport: { width: 320, height: 700 } });
  await page.goto(url); await page.waitForTimeout(1000);
  for (let i = 0; i < 3; i++) { await page.click('button[aria-label="增大字号"]'); await page.waitForTimeout(120); }
  await page.waitForTimeout(500);
  const r = await page.evaluate(() => ({
    fs: getComputedStyle(document.documentElement).getPropertyValue("--doc-fs").trim(),
    sw: document.documentElement.scrollWidth, vw: window.innerWidth,
  }));
  console.log(`最大字号小屏：fs=${r.fs} scrollWidth=${r.sw}/${r.vw} ${r.sw <= r.vw + 1 ? "✓" : "❌"}`);
  await page.screenshot({ path: path.join(ROOT, "shots/e-maxfont-320.png") });
  await page.close();
}

/* 3. 锚点直达 */
{
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.goto(url + "#s-8-5"); await page.waitForTimeout(1800);
  const r = await page.evaluate(() => {
    const el = document.getElementById("s-8-5");
    return { y: Math.round(window.scrollY), top: el ? Math.round(el.getBoundingClientRect().top) : -999 };
  });
  console.log(`锚点直达：scrollY=${r.y} 目标距顶=${r.top}px ${r.y > 1000 && Math.abs(r.top) < 200 ? "✓" : "❌"}`);
  await page.close();
}

/* 4. 主题持久化 */
{
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.goto(url); await page.waitForTimeout(900);
  await page.click('button[aria-label="切换到昼测（亮色）"]');
  await page.waitForTimeout(500);
  await page.reload(); await page.waitForTimeout(1200);
  const t = await page.evaluate(() => document.documentElement.dataset.theme);
  console.log(`主题持久化：刷新后=${t} ${t === "light" ? "✓" : "❌"}`);
  await page.close();
}

await browser.close();
console.log("EDGE DONE");
