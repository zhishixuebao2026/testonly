"""
Makes every font-size in the stylesheets follow the reader's font-size setting.
  content  -> × var(--rs)          (full reader scale), floor 11px / 12px for CJK labels
  chrome   -> × var(--rs-ui)       (damped scale for toolbars and dialogs), floor 10.5px / 11.5px
  display  -> × var(--rs-display)  (damped scale for giant headings)
  svg text -> × var(--rs-svg)      (capped, inside fixed viewBoxes)
  decor    -> untouched            (watermark glyphs)
Prose line-heights additionally follow var(--leading). Idempotent: values already
containing a scale variable are only floored, never wrapped twice.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / "src" / "styles"
FILES = ["tokens.css", "document.css", "figures.css", "ui.css", "responsive.css", "polish-mobile.css"]

DECOR = (".chapter-watermark", ".chapter-glyph", ".footer-glyph")
SVG = (".node-label", ".node-unit", ".core-number", ".core-word", ".plate-caption", ".crater-labels")
DISPLAY = (".hero-title", ".chapter-title", ".hero-fact-value", ".footer-quote", ".threshold-number")
FORCE_CONTENT = (".source-body", ".source-inline-cta", ".font-preview")
CHROME = (".rail", ".topbar", ".mobile-dock", ".overlay", ".sheet-", ".search-", ".settings-", ".theme-option",
          ".font-step", ".font-size", ".source-", ".toast", ".fab-top", ".brand", "kbd", ".mobile-nav",
          ".skip-link", ".icon-button", ".hero-masthead", ".masthead", ".plate-", ".seal-mark", ".button")
CJK = (".metric-key", ".material-metrics dt", ".cloud-metrics dt", ".phase-metric-label", ".chapter-chip",
       ".stage-source", ".material-note", ".range-note", ".phase-basis", ".dossier-source", ".dossier-material",
       ".figure-footnote", ".threshold-legend-item", ".footer-brand", ".verdict-tag", ".latent-legend",
       ".strength-header", ".spectrum-label", ".crush-tnt", ".ladder-energy", ".hero-fact-label", ".rail-meta",
       ".rail-seal p", ".rail-progress-caption", ".settings-label", ".search-result-meta", ".search-summary",
       ".sheet-foot", ".theme-option", ".source-foot", ".source-head p", ".mobile-nav-copy small",
       ".topbar-context-label", ".rail-action", ".mobile-dock button", ".toast", ".hero-guide", ".hero-pill",
       ".chapter-meta", ".chapter-chip-mini", ".rule-card-tag", ".settings-action small", ".rail-nav-label",
       ".search-empty p", ".search-no-results p", ".font-preview > span", ".sheet-head p", ".footer-bottom",
       ".material-metrics dd", ".cloud-metrics dd", ".phase-metric-label strong", ".stage-value p",
       ".dimension-question", ".chapter-chip > span:last-child", ".dossier-material > span:last-child")
LEADING = (".prose-paragraph", ".prose-list", ".prose-quote p", ".rule-card p", ".hero-deck p",
           ".dimension-question", ".stage-value p", ".source-body pre", ".list-content", ".prose-list--sources > li")

def has(selector, keys):
    return any(key in selector for key in keys)

def classify(selector):
    if has(selector, DECOR): return "decor"
    if has(selector, SVG): return "svg"
    if has(selector, DISPLAY): return "display"
    if has(selector, FORCE_CONTENT): return "content"
    if has(selector, CHROME): return "chrome"
    return "content"

def floor_value(value, floor_px):
    v = value.strip()
    m = re.fullmatch(r"([\d.]+)px", v)
    if m:
        return f"{max(float(m.group(1)), floor_px):g}px"
    m = re.fullmatch(r"([\d.]+)rem", v)
    if m:
        px = float(m.group(1)) * 16
        return v if px >= floor_px else f"{floor_px:g}px"
    m = re.fullmatch(r"calc\(\s*([\d.]+)px\s*\*\s*var\(--(reader-scale|rs|rs-ui)\)\s*\)", v)
    if m:
        return f"calc({max(float(m.group(1)), floor_px):g}px * var(--{m.group(2)}))"
    m = re.fullmatch(r"calc\(\s*([\d.]+)rem\s*\*\s*var\(--(reader-scale|rs|rs-ui)\)\s*\)", v)
    if m and float(m.group(1)) * 16 < floor_px:
        return f"calc({floor_px:g}px * var(--{m.group(2)}))"
    m = re.fullmatch(r"clamp\(\s*([\d.]+)(px|rem)\s*,(.*)\)", v)
    if m:
        px = float(m.group(1)) * (16 if m.group(2) == "rem" else 1)
        if px < floor_px:
            return f"clamp({floor_px:g}px,{m.group(3)})"
    return v

def transform_font(value, kind, cjk):
    important = "!important" in value
    v = value.replace("!important", "").strip()
    if kind == "decor" or re.search(r"\d(em)\b", v) and "rem" not in v or v in ("inherit", "100%"):
        return value
    floors = {"content": 12 if cjk else 11, "chrome": 11.5 if cjk else 10.5, "display": 0, "svg": 0}
    if floors[kind]:
        v = floor_value(v, floors[kind])
    if not re.search(r"var\(--(reader-scale|rs)", v):
        var = {"content": "--rs", "chrome": "--rs-ui", "display": "--rs-display", "svg": "--rs-svg"}[kind]
        v = f"calc({v} * var({var}))"
    elif kind == "chrome":
        v = v.replace("var(--reader-scale)", "var(--rs-ui)")
    return f"{v}{' !important' if important else ''}"

def process(text):
    out = []
    selector_buffer = []
    stack = []  # (selector, is_print)
    for line in text.split("\n"):
        stripped = line.strip()
        if "{" in stripped and not stripped.startswith("/*"):
            head = " ".join(selector_buffer + [stripped.split("{")[0]]).strip()
            selector_buffer = []
            in_print = any(p for _, p in stack) or head.startswith("@media print")
            stack.append((head, in_print))
            out.append(line)
            if "}" in stripped:
                stack.pop()
            continue
        if stripped.endswith(",") and not stripped.startswith(("/*", "--")) and ":" not in stripped.split(",")[0][-2:] and not re.match(r"^[\w-]+\s*:", stripped):
            selector_buffer.append(stripped)
            out.append(line)
            continue
        if stripped.startswith("}"):
            if stack:
                stack.pop()
            out.append(line)
            continue
        m = re.match(r"^(\s*)(font-size|line-height)\s*:\s*(.+?);\s*$", line)
        if m and stack:
            selector, in_print = stack[-1]
            if not in_print and not selector.startswith("@"):
                prop, value = m.group(2), m.group(3)
                if prop == "font-size":
                    kind = classify(selector)
                    new = transform_font(value, kind, has(selector, CJK))
                    line = f"{m.group(1)}font-size: {new};"
                elif prop == "line-height" and has(selector, LEADING) and "--leading" not in value and re.fullmatch(r"[\d.]+(\s*!important)?", value.strip()):
                    important = "!important" in value
                    num = value.replace("!important", "").strip()
                    line = f"{m.group(1)}line-height: calc({num} * var(--leading)){' !important' if important else ''};"
        out.append(line)
    return "\n".join(out)

changed = 0
for name in FILES:
    path = ROOT / name
    text = path.read_text(encoding="utf-8")
    text = text.replace(".chapter-header h1", ".chapter-header .chapter-title")
    new = process(text)
    if new != text:
        changed += 1
    path.write_text(new, encoding="utf-8")
print("files updated:", changed)
