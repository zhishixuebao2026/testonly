import { createContext } from "react";

export type XrefMap = {
  /** "4.4" -> heading id */
  subs: Record<string, string>;
  /** "四" -> chapter heading id */
  chapters: Record<string, string>;
};

export const XrefContext = createContext<XrefMap>({ subs: {}, chapters: {} });

export const ToastContext = createContext<(message: string) => void>(() => undefined);
