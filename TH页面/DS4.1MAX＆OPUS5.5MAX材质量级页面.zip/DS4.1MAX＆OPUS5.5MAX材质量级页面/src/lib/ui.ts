export type ThemeMode = "light" | "dark" | "system";
export type BodyFont = "sans" | "serif";
export type Leading = "compact" | "normal" | "relaxed";

/** Seven reading sizes. Every piece of text on the page is derived from the active value. */
export const FONT_SCALES = [0.86, 0.93, 1, 1.08, 1.17, 1.28, 1.4] as const;
export const FONT_LABELS = ["小", "较小", "标准", "较大", "大", "特大", "超大"] as const;
export const DEFAULT_SCALE = 1;
export const MIN_SCALE = FONT_SCALES[0];
export const MAX_SCALE = FONT_SCALES[FONT_SCALES.length - 1];

export const LEADING_VALUES: Record<Leading, number> = {
  compact: 0.9,
  normal: 1,
  relaxed: 1.12,
};

export const LEADING_LABELS: Record<Leading, string> = {
  compact: "紧凑",
  normal: "标准",
  relaxed: "宽松",
};

export function nearestFontStep(scale: number): number {
  let best = 2;
  let distance = Number.POSITIVE_INFINITY;
  FONT_SCALES.forEach((value, index) => {
    const next = Math.abs(value - scale);
    if (next < distance) {
      distance = next;
      best = index;
    }
  });
  return best;
}

export function stepScale(scale: number, delta: number): number {
  const index = Math.min(FONT_SCALES.length - 1, Math.max(0, nearestFontStep(scale) + delta));
  return FONT_SCALES[index];
}

export function isValidScale(value: number): boolean {
  return Number.isFinite(value) && value >= MIN_SCALE - 0.02 && value <= MAX_SCALE + 0.02;
}
