export type Inline = { type: "text" | "strong"; value: string };

export type HeadingBlock = {
  type: "h1" | "h2" | "h3";
  id: string;
  inline: Inline[];
  text: string;
  sectionId: string;
};

export type ParagraphBlock = {
  type: "p";
  id: string;
  inline: Inline[];
  text: string;
  sectionId: string;
};

export type QuoteBlock = {
  type: "quote";
  id: string;
  paragraphs: Inline[][];
  text: string;
  sectionId: string;
};

export type ListBlock = {
  type: "ul" | "ol";
  id: string;
  items: Inline[][];
  text: string;
  sectionId: string;
};

export type TableBlock = {
  type: "table";
  id: string;
  header: string[];
  rows: string[][];
  text: string;
  sectionId: string;
  figure: string;
};

export type HrBlock = {
  type: "hr";
  id: string;
  sectionId: string;
};

export type Block =
  | HeadingBlock
  | ParagraphBlock
  | QuoteBlock
  | ListBlock
  | TableBlock
  | HrBlock;

export type Section = {
  index: number;
  id: string;
  title: string;
  kicker: string;
  label: string;
  english: string;
  glyph: string;
  accent: "amber" | "teal" | "neutral" | "ember";
  blocks: Block[];
};

const CHAPTER_META: Omit<
  Section,
  "index" | "id" | "title" | "blocks"
>[] = [
  {
    kicker: "VOL",
    label: "卷首",
    english: "CODEX",
    glyph: "衡",
    accent: "amber",
  },
  {
    kicker: "REV",
    label: "修订要点",
    english: "REVISION",
    glyph: "校",
    accent: "teal",
  },
  {
    kicker: "00",
    label: "方法论",
    english: "METHOD",
    glyph: "衡",
    accent: "amber",
  },
  {
    kicker: "01",
    label: "粉碎能量",
    english: "CRUSH",
    glyph: "碎",
    accent: "ember",
  },
  {
    kicker: "02",
    label: "材料强度",
    english: "STRENGTH",
    glyph: "御",
    accent: "teal",
  },
  {
    kicker: "03",
    label: "相变能量",
    english: "PHASE",
    glyph: "熔",
    accent: "ember",
  },
  {
    kicker: "04",
    label: "引力束缚",
    english: "GRAVITY",
    glyph: "引",
    accent: "amber",
  },
  {
    kicker: "05",
    label: "持续通量",
    english: "FLUX",
    glyph: "炽",
    accent: "ember",
  },
  {
    kicker: "06",
    label: "撞击成坑",
    english: "IMPACT",
    glyph: "坑",
    accent: "neutral",
  },
  {
    kicker: "07",
    label: "数据源现状",
    english: "PROVENANCE",
    glyph: "源",
    accent: "teal",
  },
  {
    kicker: "08",
    label: "爆炸与云层",
    english: "BLAST",
    glyph: "爆",
    accent: "amber",
  },
  {
    kicker: "SRC",
    label: "参考来源",
    english: "SOURCES",
    glyph: "据",
    accent: "neutral",
  },
  {
    kicker: "TODO",
    label: "待补充事项",
    english: "OPEN ITEMS",
    glyph: "续",
    accent: "teal",
  },
];

export function parseInline(text: string): Inline[] {
  const out: Inline[] = [];
  const re = /\*\*(.+?)\*\*/g;
  let last = 0;
  let result: RegExpExecArray | null = re.exec(text);
  while (result) {
    if (result.index > last) {
      out.push({ type: "text", value: text.slice(last, result.index) });
    }
    out.push({ type: "strong", value: result[1] });
    last = result.index + result[0].length;
    result = re.exec(text);
  }
  if (last < text.length) out.push({ type: "text", value: text.slice(last) });
  return out.length ? out : [{ type: "text", value: "" }];
}

export function inlineText(inline: Inline[]): string {
  return inline.map((part) => part.value).join("");
}

function stripOuterPipes(line: string): string[] {
  const trimmed = line.trim();
  const withoutStart = trimmed.startsWith("|") ? trimmed.slice(1) : trimmed;
  const withoutEnd = withoutStart.endsWith("|")
    ? withoutStart.slice(0, -1)
    : withoutStart;
  return withoutEnd.split("|").map((cell) => cell.trim());
}

const TABLE_SEPARATOR = /^\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?$/;

export function parseDocument(raw: string): Section[] {
  const lines = raw.replace(/\r\n/g, "\n").split("\n");
  const sections: Section[] = [];
  let current: Section | null = null;
  let blockCounter = 0;
  let tableCounter = 0;
  let subHeadCounter = 0;

  const pushBlock = (block: Omit<Block, "sectionId">) => {
    if (!current) {
      current = {
        index: 0,
        id: "sec-0",
        title: "材质与破坏能量数据库（第二版）",
        ...CHAPTER_META[0],
        blocks: [],
      };
      sections.push(current);
    }
    const withSection = { ...block, sectionId: current.id } as Block;
    current.blocks.push(withSection);
  };

  const startSection = (title: string) => {
    const index = sections.length;
    const meta = CHAPTER_META[Math.min(index, CHAPTER_META.length - 1)];
    subHeadCounter = 0;
    current = {
      index,
      id: `sec-${index}`,
      title,
      ...meta,
      blocks: [],
    };
    sections.push(current);
    return current;
  };

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) continue;

    if (/^#\s+/.test(trimmed)) {
      const title = trimmed.replace(/^#\s+/, "").trim();
      if (sections.length === 0) {
        startSection(title);
      } else {
        startSection(title);
      }
      subHeadCounter = 0;
      const id = current!.id;
      const headingId = id;
      blockCounter += 1;
      current!.blocks.push({
        type: "h1",
        id: headingId,
        inline: parseInline(title),
        text: title,
        sectionId: id,
      } as HeadingBlock);
      continue;
    }

    if (/^##\s+/.test(trimmed) || /^###\s+/.test(trimmed)) {
      const isH3 = /^###\s+/.test(trimmed);
      const text = trimmed.replace(/^#{2,3}\s+/, "").trim();
      subHeadCounter += 1;
      blockCounter += 1;
      const id = `${sections[sections.length - 1]?.id ?? "sec-0"}-h${subHeadCounter}`;
      pushBlock({
        type: isH3 ? "h3" : "h2",
        id,
        inline: parseInline(text),
        text,
      } as HeadingBlock);
      continue;
    }

    if (trimmed === "---") {
      blockCounter += 1;
      pushBlock({ type: "hr", id: `blk-${blockCounter}` });
      continue;
    }

    if (/^>\s?/.test(trimmed)) {
      const quoteLines: string[] = [];
      while (i < lines.length && /^>\s?/.test(lines[i].trim())) {
        quoteLines.push(lines[i].trim().replace(/^>\s?/, ""));
        i += 1;
      }
      i -= 1;
      blockCounter += 1;
      pushBlock({
        type: "quote",
        id: `blk-${blockCounter}`,
        paragraphs: quoteLines.map(parseInline),
        text: quoteLines.join("\n"),
      } as QuoteBlock);
      continue;
    }

    if (trimmed.startsWith("|") && lines[i + 1] && TABLE_SEPARATOR.test(lines[i + 1].trim())) {
      const header = stripOuterPipes(trimmed);
      const rows: string[][] = [];
      i += 2;
      while (i < lines.length && lines[i].trim().startsWith("|")) {
        rows.push(stripOuterPipes(lines[i]));
        i += 1;
      }
      i -= 1;
      tableCounter += 1;
      blockCounter += 1;
      const headerText = header.join(" ");
      const bodyText = rows.map((row) => row.join(" ")).join("\n");
      pushBlock({
        type: "table",
        id: `blk-${blockCounter}`,
        header,
        rows,
        text: `${headerText}\n${bodyText}`,
        figure: `T-${String(tableCounter).padStart(2, "0")}`,
      } as TableBlock);
      continue;
    }

    if (/^[-*]\s+/.test(trimmed)) {
      const items: string[] = [];
      while (i < lines.length && /^[-*]\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^[-*]\s+/, ""));
        i += 1;
      }
      i -= 1;
      blockCounter += 1;
      pushBlock({
        type: "ul",
        id: `blk-${blockCounter}`,
        items: items.map(parseInline),
        text: items.join("\n"),
      } as ListBlock);
      continue;
    }

    if (/^\d+\.\s+/.test(trimmed)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\.\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^\d+\.\s+/, ""));
        i += 1;
      }
      i -= 1;
      blockCounter += 1;
      pushBlock({
        type: "ol",
        id: `blk-${blockCounter}`,
        items: items.map(parseInline),
        text: items.join("\n"),
      } as ListBlock);
      continue;
    }

    // Paragraph: consume consecutive ordinary lines.
    const paragraphLines: string[] = [trimmed];
    while (
      i + 1 < lines.length &&
      lines[i + 1].trim() &&
      !/^#{1,3}\s+/.test(lines[i + 1].trim()) &&
      !/^[-*]\s+/.test(lines[i + 1].trim()) &&
      !/^\d+\.\s+/.test(lines[i + 1].trim()) &&
      !/^>\s?/.test(lines[i + 1].trim()) &&
      !lines[i + 1].trim().startsWith("|") &&
      lines[i + 1].trim() !== "---"
    ) {
      paragraphLines.push(lines[i + 1].trim());
      i += 1;
    }
    blockCounter += 1;
    const text = paragraphLines.join(" ");
    pushBlock({
      type: "p",
      id: `blk-${blockCounter}`,
      inline: parseInline(text),
      text,
    } as ParagraphBlock);
  }

  return sections;
}

export type SearchEntry = {
  id: string;
  sectionId: string;
  sectionLabel: string;
  sectionKicker: string;
  subLabel: string;
  text: string;
};

export function buildSearchIndex(sections: Section[]): SearchEntry[] {
  const entries: SearchEntry[] = [];
  for (const section of sections) {
    if (section.index === 0) continue;
    let subLabel = "";
    for (const block of section.blocks) {
      if (block.type === "hr") continue;
      if (block.type === "h2") subLabel = block.text;
      const blockId = block.id;
      let text = "";
      if (block.type === "table") {
        text = [block.header.join("，"), ...block.rows.map((r) => r.join("，"))].join("；");
      } else if (block.type === "quote") {
        text = block.text;
      } else if (block.type === "ul" || block.type === "ol") {
        text = block.text.split("\n").join("；");
      } else if ("text" in block) {
        text = block.text;
      }
      text = text.replace(/\*\*/g, "");
      if (!text.trim()) continue;
      entries.push({
        id: blockId,
        sectionId: section.id,
        sectionLabel: section.label,
        sectionKicker: section.kicker,
        subLabel: block.type === "h1" ? "" : subLabel,
        text,
      });
    }
  }
  return entries;
}
