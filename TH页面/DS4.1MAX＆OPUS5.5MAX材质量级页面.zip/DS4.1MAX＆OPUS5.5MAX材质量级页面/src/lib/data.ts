export const SUPERSCRIPT: Record<string, string> = {
  "⁰": "0",
  "¹": "1",
  "²": "2",
  "³": "3",
  "⁴": "4",
  "⁵": "5",
  "⁶": "6",
  "⁷": "7",
  "⁸": "8",
  "⁹": "9",
};

/** Read the first finite number from a source cell, without changing the source string. */
export function firstNumber(value: string): number | null {
  const cleaned = value.replace(/,/g, "");
  const match = cleaned.match(/-?\d+(?:\.\d+)?/);
  if (!match) return null;
  const number = Number(match[0]);
  return Number.isFinite(number) ? number : null;
}

/** Read a range, falling back to a single value on both ends. */
export function numberRange(value: string): [number | null, number | null] {
  const cleaned = value.replace(/,/g, "");
  const matches = Array.from(cleaned.matchAll(/\d+(?:\.\d+)?/g)).map((m) => Number(m[0]));
  if (!matches.length) return [null, null];
  if (matches.length === 1) return [matches[0], matches[0]];
  return [matches[0], matches[1]];
}

/** Convert values such as 3.35×10⁴⁴ into a plain exponent for a logarithmic chart. */
export function scientificLog(value: string): number | null {
  const normalized = value
    .split("")
    .map((char) => SUPERSCRIPT[char] ?? char)
    .join("")
    .replace(/,/g, "");
  const match = normalized.match(/(\d+(?:\.\d+)?)\s*[×x]\s*10\s*\^?\s*(-?\d+)/);
  if (!match) {
    const plain = firstNumber(normalized);
    return plain && plain > 0 ? Math.log10(plain) : null;
  }
  const mantissa = Number(match[1]);
  const exponent = Number(match[2]);
  if (!Number.isFinite(mantissa) || !Number.isFinite(exponent) || mantissa <= 0) return null;
  return Math.log10(mantissa) + exponent;
}

export function formatFigureIndex(value: string): string {
  return value.replace(/^T-/, "");
}

export const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));
