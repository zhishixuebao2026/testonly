export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fall back to the legacy path below (file:// pages, older browsers).
  }
  try {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.top = "-1000px";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(textarea);
    return ok;
  } catch {
    return false;
  }
}

export function jumpTo(id: string, block: ScrollLogicalPosition = "start") {
  const element = document.getElementById(id);
  if (!element) return;
  window.dispatchEvent(new Event("heng:navigate"));
  element.scrollIntoView({ behavior: "smooth", block });
  try {
    window.history.replaceState(null, "", `#${id}`);
  } catch {
    // Some file:// contexts refuse history updates; navigation still works.
  }
}
