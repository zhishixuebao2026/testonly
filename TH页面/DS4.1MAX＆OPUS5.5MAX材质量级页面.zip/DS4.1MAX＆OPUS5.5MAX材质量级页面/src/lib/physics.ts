/**
 * Formula helpers for the interactive tools. Every formula and constant below is
 * taken from the source document (sections 0.3, 4.2, 4.4, 4.5, 5.2, 8.1, 8.2).
 * The default inputs reproduce the worked examples printed in the document.
 */
export const G = 6.674e-11;
export const M_SUN = 1.989e30;
export const TNT_TON_J = 4.184e9;
export const SUN_BINDING_J = 2.277e41; // 4.3
export const CITY_TIER_J = 4.184e15; // 衡天城▽，见 8.1
export const WATER_LATENT_J_PER_KG = 2264705; // 8.2
export const CLOUD_DENSITY = 1.003; // 8.2：水加空气约 1.003 kg/m³
export const EARTH_ABSORBED = 240; // 5.1
export const SOLAR_CONSTANT = 1367; // 5.2
export const EARTH_RADIUS_M = 6.371e6;
export const PERSON_AREA = 0.68; // 8.1：成年人截面积
export const DEFAULT_OVERPRESSURE_BAR = 1.37895; // 8.1：约 20 psi

export const uniformSphereBinding = (mass: number, radius: number) =>
  (3 * G * mass * mass) / (5 * radius);

/** n = 1.5 polytrope (4.4): (6/7)GM²/R */
export const polytropeBinding = (mass: number, radius: number) =>
  ((6 / 7) * G * mass * mass) / radius;

export const sphereMass = (density: number, radius: number) =>
  density * (4 / 3) * Math.PI * radius ** 3;

/** Force between the two hemispheres of a uniform sphere (4.5): 3GM²/(16R²) */
export const hemisphereForce = (mass: number, radius: number) =>
  (3 * G * mass * mass) / (16 * radius * radius);

/** Curvature horizon (0.3): √(2Rh + h²); any consistent length unit. */
export const horizon = (radius: number, height: number) =>
  Math.sqrt(2 * radius * height + height * height);

/** Air extinction (0.3): e^(−kx), x in km. */
export const transmittance = (k: number, distanceKm: number) => Math.exp(-k * distanceKm);

/** Air burst (8.1): Y(Mt) = (x ÷ 0.28)³ ÷ 1000, conventional explosions × 0.5 */
export const airBurstMt = (radiusKm: number, conventional: boolean) =>
  ((radiusKm / 0.28) ** 3 / 1000) * (conventional ? 0.5 : 1);

/** Ground burst (8.1): W(t) = R³ × (√(27136P + 8649) ÷ 13568 − 93 ÷ 13568)² */
export const groundBurstTons = (radiusM: number, overpressureBar: number) => {
  const a = Math.sqrt(27136 * overpressureBar + 8649) / 13568 - 93 / 13568;
  return radiusM ** 3 * a * a;
};

/** Cloud volume (8.2): π × (view distance)² × thickness, in m³ */
export const cloudVolume = (viewKm: number, thicknessM: number) =>
  Math.PI * (viewKm * 1000) ** 2 * thicknessM;

export const condensationEnergy = (volume: number, liquidWaterGm3: number) =>
  volume * (liquidWaterGm3 / 1000) * WATER_LATENT_J_PER_KG;

export const cloudKinetic = (volume: number, speed: number) =>
  0.5 * CLOUD_DENSITY * volume * speed * speed;

/** Extra absorbed power needed to lift the global mean absorbed flux (5.2). */
export const extraPower = (target: number, base = EARTH_ABSORBED, radius = EARTH_RADIUS_M) =>
  (target - base) * 4 * Math.PI * radius * radius;

export const totalInsolation = (radius = EARTH_RADIUS_M) => SOLAR_CONSTANT * Math.PI * radius * radius;

/** Inverse-square share of a blast received by a body (8.1). */
export const blastReceived = (energy: number, distance: number, ground: boolean, area = PERSON_AREA) =>
  (energy / ((ground ? 2 : 4) * Math.PI * distance * distance)) * area;

const SUP: Record<string, string> = {
  "0": "⁰",
  "1": "¹",
  "2": "²",
  "3": "³",
  "4": "⁴",
  "5": "⁵",
  "6": "⁶",
  "7": "⁷",
  "8": "⁸",
  "9": "⁹",
  "-": "⁻",
};

const FROM_SUP: Record<string, string> = Object.fromEntries(
  Object.entries(SUP).map(([plain, sup]) => [sup, plain]),
);

export const toSup = (value: number | string) =>
  String(value)
    .split("")
    .map((char) => SUP[char] ?? char)
    .join("");

/** Accepts 5.972e24, 5.972×10^24, 5.972×10²⁴, 1,200 … */
export function parseNum(input: string): number {
  if (!input) return Number.NaN;
  let text = input
    .trim()
    .split("")
    .map((char) => FROM_SUP[char] ?? char)
    .join("")
    .replace(/[,，\s]/g, "")
    .replace(/−/g, "-");
  text = text.replace(/[×xX*]10\^?/, "e");
  if (!text) return Number.NaN;
  const value = Number(text);
  return Number.isFinite(value) ? value : Number.NaN;
}

export type SciParts = { mantissa: string; exponent: number | null; plain: string };

export function sci(value: number, digits = 3): SciParts {
  if (!Number.isFinite(value)) return { mantissa: "—", exponent: null, plain: "—" };
  if (value === 0) return { mantissa: "0", exponent: null, plain: "0" };
  const abs = Math.abs(value);
  if (abs >= 0.01 && abs < 1e5) {
    const decimals = abs >= 1000 ? 0 : abs >= 100 ? 1 : abs >= 10 ? 2 : 3;
    const rounded = Number(value.toPrecision(Math.max(digits, 1)));
    const text = rounded.toLocaleString("en-US", { maximumFractionDigits: decimals });
    return { mantissa: text, exponent: null, plain: text };
  }
  let exponent = Math.floor(Math.log10(abs));
  let mantissa = Number((value / 10 ** exponent).toPrecision(digits));
  if (Math.abs(mantissa) >= 10) {
    mantissa /= 10;
    exponent += 1;
  }
  const text = mantissa.toPrecision(digits).replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
  return { mantissa: text, exponent, plain: `${text}×10${toSup(exponent)}` };
}

export function tntLabel(joules: number): string {
  const tons = joules / TNT_TON_J;
  if (!Number.isFinite(tons) || tons <= 0) return "—";
  if (tons < 1) return `约 ${sci(tons * 1000).plain} 千克 TNT`;
  if (tons < 1e4) return `约 ${sci(tons).plain} 吨 TNT`;
  if (tons < 1e8) return `约 ${sci(tons / 1e4).plain} 万吨 TNT`;
  if (tons < 1e12) return `约 ${sci(tons / 1e8).plain} 亿吨 TNT`;
  return `约 ${sci(tons).plain} 吨 TNT`;
}

export function percent(value: number): string {
  if (!Number.isFinite(value)) return "—";
  const pct = value * 100;
  if (pct === 0) return "0%";
  if (Math.abs(pct) < 0.01) return `${sci(pct, 2).plain}%`;
  return `${pct.toLocaleString("en-US", { maximumFractionDigits: pct < 1 ? 3 : 1 })}%`;
}
