import { useEffect, useRef } from "react";

/**
 * A slow, low-contrast WebGL fracture field behind the hero: a Voronoi crack network
 * with an energy pulse radiating from the five-dimension plate. Paused off-screen,
 * static for reduced-motion users, silently skipped when WebGL is unavailable.
 */
const VERT = `attribute vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }`;

const FRAG = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec2 uRes;
uniform vec2 uFocus;
uniform float uTime;
uniform vec4 uLine;
uniform vec4 uGlow;
uniform vec4 uCell;

vec2 hash2(vec2 p) {
  p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
  return fract(sin(p) * 43758.5453);
}

float hash1(vec2 p) {
  return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec3 voronoi(vec2 x, float t) {
  vec2 n = floor(x);
  vec2 f = fract(x);
  vec2 mg = vec2(0.0);
  vec2 mr = vec2(0.0);
  float md = 8.0;
  for (int j = -1; j <= 1; j++) {
    for (int i = -1; i <= 1; i++) {
      vec2 g = vec2(float(i), float(j));
      vec2 o = hash2(n + g);
      o = 0.5 + 0.42 * sin(t + 6.2831 * o);
      vec2 r = g + o - f;
      float d = dot(r, r);
      if (d < md) { md = d; mr = r; mg = g; }
    }
  }
  md = 8.0;
  for (int j = -2; j <= 2; j++) {
    for (int i = -2; i <= 2; i++) {
      vec2 g = mg + vec2(float(i), float(j));
      vec2 o = hash2(n + g);
      o = 0.5 + 0.42 * sin(t + 6.2831 * o);
      vec2 r = g + o - f;
      if (dot(mr - r, mr - r) > 0.00001) {
        md = min(md, dot(0.5 * (mr + r), normalize(r - mr)));
      }
    }
  }
  return vec3(md, n + mg);
}

void main() {
  float unit = min(uRes.x, uRes.y);
  vec2 p = gl_FragCoord.xy / unit;
  vec2 focus = uFocus / unit;
  float t = uTime;
  vec3 v1 = voronoi(p * 3.3 + vec2(0.0, t * 0.012), t * 0.11);
  vec3 v2 = voronoi(p * 8.6 + vec2(t * 0.01, 0.0), t * 0.17);
  float aa1 = 1.7 / unit * 3.3;
  float aa2 = 1.7 / unit * 8.6;
  float e1 = 1.0 - smoothstep(0.0, 0.012 + aa1, v1.x);
  float e2 = (1.0 - smoothstep(0.0, 0.009 + aa2, v2.x)) * step(0.52, hash1(v2.yz));
  float d = length(p - focus);
  float mask = 1.0 - smoothstep(0.06, 0.92, d);
  float lines = clamp(e1 + e2 * 0.5, 0.0, 1.0) * mask;
  float wave = 0.5 + 0.5 * sin(d * 10.0 - t * 1.05);
  wave = pow(wave, 8.0);
  float glow = exp(-v1.x * 40.0) * wave * mask;
  float cell = hash1(v1.yz) * mask * 0.6;
  float la = uLine.a * lines;
  float ga = uGlow.a * glow * (1.0 - la);
  float ca = uCell.a * cell * (1.0 - la);
  vec3 rgb = uLine.rgb * la + uGlow.rgb * ga + uCell.rgb * ca;
  float a = clamp(la + ga + ca, 0.0, 1.0);
  gl_FragColor = vec4(rgb, a);
}`;

type Vec4 = [number, number, number, number];
type Palette = { line: Vec4; glow: Vec4; cell: Vec4 };

const PALETTES: Record<"light" | "dark", Palette> = {
  light: { line: [0.3, 0.23, 0.16, 0.2], glow: [0.79, 0.4, 0.17, 0.5], cell: [0.65, 0.31, 0.13, 0.05] },
  dark: { line: [0.93, 0.9, 0.84, 0.12], glow: [0.97, 0.68, 0.42, 0.78], cell: [0.89, 0.64, 0.41, 0.05] },
};

function compile(gl: WebGLRenderingContext, type: number, source: string) {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

export function HeroCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    let context: WebGLRenderingContext | null = null;
    try {
      context = canvas.getContext("webgl", {
        alpha: true,
        premultipliedAlpha: true,
        antialias: false,
        depth: false,
        stencil: false,
        powerPreference: "low-power",
      }) as WebGLRenderingContext | null;
    } catch {
      context = null;
    }
    if (!context) return;
    const gl = context;
    const vs = compile(gl, gl.VERTEX_SHADER, VERT);
    const fs = compile(gl, gl.FRAGMENT_SHADER, FRAG);
    if (!vs || !fs) return;
    const program = gl.createProgram();
    if (!program) return;
    gl.attachShader(program, vs);
    gl.attachShader(program, fs);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return;
    gl.useProgram(program);

    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, "aPos");
    gl.enableVertexAttribArray(position);
    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);

    const uRes = gl.getUniformLocation(program, "uRes");
    const uFocus = gl.getUniformLocation(program, "uFocus");
    const uTime = gl.getUniformLocation(program, "uTime");
    const uLine = gl.getUniformLocation(program, "uLine");
    const uGlow = gl.getUniformLocation(program, "uGlow");
    const uCell = gl.getUniformLocation(program, "uCell");

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const applyPalette = () => {
      const palette = PALETTES[document.documentElement.dataset.theme === "dark" ? "dark" : "light"];
      gl.uniform4fv(uLine, palette.line);
      gl.uniform4fv(uGlow, palette.glow);
      gl.uniform4fv(uCell, palette.cell);
    };
    applyPalette();

    let currentTime = 14;
    const draw = (time: number) => {
      currentTime = time;
      gl.uniform1f(uTime, time);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const scale = rect.width < 760 ? 0.62 : 0.74;
      const width = Math.max(2, Math.round(rect.width * dpr * scale));
      const height = Math.max(2, Math.round(rect.height * dpr * scale));
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      gl.viewport(0, 0, width, height);
      gl.uniform2f(uRes, width, height);
      const hero = canvas.closest(".hero");
      const art = hero?.querySelector(".orbit-plate") ?? hero?.querySelector(".hero-art");
      let fx = rect.width * 0.74;
      let fy = rect.height * 0.42;
      if (art) {
        const box = art.getBoundingClientRect();
        fx = box.left + box.width / 2 - rect.left;
        fy = box.top + box.height / 2 - rect.top;
      }
      gl.uniform2f(uFocus, (fx / rect.width) * width, (1 - fy / rect.height) * height);
      canvas.style.setProperty("--fx", `${((fx / rect.width) * 100).toFixed(2)}%`);
      canvas.style.setProperty("--fy", `${((fy / rect.height) * 100).toFixed(2)}%`);
      draw(currentTime);
    };

    let raf = 0;
    let running = false;
    let visible = true;
    let last = 0;
    const start = performance.now();
    const frame = (now: number) => {
      if (!running) return;
      raf = window.requestAnimationFrame(frame);
      if (now - last < 33) return;
      last = now;
      draw((now - start) / 1000 + 14);
    };
    const play = () => {
      if (reduce || running || !visible || document.hidden) return;
      running = true;
      raf = window.requestAnimationFrame(frame);
    };
    const pause = () => {
      running = false;
      window.cancelAnimationFrame(raf);
    };

    resize();
    canvas.classList.add("is-ready");
    play();

    const resizeObserver = new ResizeObserver(() => resize());
    resizeObserver.observe(canvas);
    const intersection = new IntersectionObserver(
      ([entry]) => {
        visible = entry.isIntersecting;
        if (visible) play();
        else pause();
      },
      { threshold: 0 },
    );
    intersection.observe(canvas);
    const themeObserver = new MutationObserver(() => {
      applyPalette();
      draw(currentTime);
    });
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    const onVisibility = () => (document.hidden ? pause() : play());
    document.addEventListener("visibilitychange", onVisibility);
    const onLost = (event: Event) => {
      event.preventDefault();
      pause();
    };
    canvas.addEventListener("webglcontextlost", onLost);

    return () => {
      pause();
      resizeObserver.disconnect();
      intersection.disconnect();
      themeObserver.disconnect();
      document.removeEventListener("visibilitychange", onVisibility);
      canvas.removeEventListener("webglcontextlost", onLost);
      gl.deleteBuffer(buffer);
      gl.deleteProgram(program);
      gl.deleteShader(vs);
      gl.deleteShader(fs);
    };
  }, []);

  return <canvas ref={ref} className="hero-canvas" aria-hidden="true" />;
}
