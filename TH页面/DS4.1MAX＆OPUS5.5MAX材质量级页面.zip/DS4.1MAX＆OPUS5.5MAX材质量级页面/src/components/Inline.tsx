import { Fragment, useContext, type ReactNode } from "react";
import type { Inline } from "../lib/parse";
import { XrefContext, type XrefMap } from "../lib/context";

/**
 * prose: cross references become links, numbers with units get a marker highlight
 * cell:  cross references only (table cells already have their own numeric styling)
 * plain: untouched
 * The source text is never altered — only wrapped.
 */
export type RichMode = "prose" | "cell" | "plain";

const PATTERN_SOURCE = [
  String.raw`(?<ext>衡天\s?(?:第[零一二三四五六七八九十]+部分|\d+(?:\.\d+)?(?:、\d+(?:\.\d+)?)*))`,
  String.raw`(?<ch>(?:本文件)?第(?<chn>[零一二三四五六七八])部分(?:\s?(?<chsub>\d+\.\d+))?)`,
  String.raw`(?<paren>（(?<pnum>\d+\.\d+)）)`,
  String.raw`(?<see>见\s?(?<snum>\d+\.\d+))`,
  String.raw`(?<sci>−?\d+(?:\.\d+)?\s?[×x]\s?10[⁻⁰¹²³⁴⁵⁶⁷⁸⁹]+(?:\s?(?:J|W|N|erg|kg)(?![A-Za-z/]))?)`,
  String.raw`(?<num>−?\d[\d,]*(?:\.\d+)?(?:\s?[–-]\s?\d[\d,]*(?:\.\d+)?)?\s?(?:J\/\(mol·K\)|J\/cc|J\/kg|J\/m³|kJ\/mol|kJ\/cm³|kJ\/cc|W\/m²|MPa·√m|MPa|GPa|kg\/m³|g\/cm³|g\/m³|t\/m³|psi|erg|km²|m²|km|kg|M☉|万吨 TNT|亿吨 TNT|吨 TNT|亿焦耳|°C|公里|英尺|巴|倍|J|W|N|K|m|米)(?![A-Za-z²³]))`,
].join("|");

function renderRich(text: string, mode: RichMode, map: XrefMap, keyBase: string): ReactNode[] {
  if (mode === "plain" || !text) return [text];
  const out: ReactNode[] = [];
  const re = new RegExp(PATTERN_SOURCE, "g");
  let last = 0;
  let counter = 0;
  let match: RegExpExecArray | null = re.exec(text);
  while (match) {
    const groups = match.groups ?? {};
    const value = match[0];
    const start = match.index;
    const key = `${keyBase}-${counter++}`;
    let node: ReactNode = null;

    if (groups.ext) {
      node = (
        <span className="xref-ext" key={key} title="《衡天⊙多维战力量级体系》中的章节（外部文档）">
          {value}
        </span>
      );
    } else if (groups.ch) {
      const target = (groups.chsub && map.subs[groups.chsub]) || map.chapters[groups.chn];
      if (target) {
        node = (
          <a className="xref" href={`#${target}`} key={key}>
            {value}
          </a>
        );
      }
    } else if (groups.paren) {
      const target = map.subs[groups.pnum];
      if (target) {
        node = (
          <Fragment key={key}>
            （
            <a className="xref" href={`#${target}`}>
              {groups.pnum}
            </a>
            ）
          </Fragment>
        );
      }
    } else if (groups.see) {
      const target = map.subs[groups.snum];
      if (target) {
        node = (
          <Fragment key={key}>
            {value.slice(0, value.length - groups.snum.length)}
            <a className="xref" href={`#${target}`}>
              {groups.snum}
            </a>
          </Fragment>
        );
      }
    } else if ((groups.sci || groups.num) && mode === "prose") {
      node = (
        <span className="num" key={key}>
          {value}
        </span>
      );
    }

    if (node !== null) {
      if (start > last) out.push(text.slice(last, start));
      out.push(node);
      last = start + value.length;
    }
    match = re.exec(text);
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

export function InlineText({ parts, mode = "plain" }: { parts: Inline[]; mode?: RichMode }) {
  const map = useContext(XrefContext);
  return (
    <>
      {parts.map((part, index) =>
        part.type === "strong" ? (
          <strong key={index}>{renderRich(part.value, mode, map, `s${index}`)}</strong>
        ) : (
          <Fragment key={index}>{renderRich(part.value, mode, map, `t${index}`)}</Fragment>
        ),
      )}
    </>
  );
}
