import type { KeyboardEvent, MouseEvent, ReactNode } from "react";
import { createPortal } from "react-dom";
import { useEffect, useMemo, useRef, useState } from "react";
import type { SearchEntry, Section } from "../lib/parse";
import type { BodyFont, Leading, ThemeMode } from "../lib/ui";
import { FONT_LABELS, FONT_SCALES, LEADING_LABELS, nearestFontStep } from "../lib/ui";
import { jumpTo } from "../lib/clipboard";
import {
  IconArrowRight,
  IconArrowUp,
  IconClose,
  IconCopy,
  IconDownload,
  IconMenu,
  IconMoon,
  IconPrint,
  IconSearch,
  IconSource,
  IconSun,
  IconTextSize,
} from "./Icons";

export type SubNav = { id: string; num: string; title: string; level: 2 | 3 };

export function Monogram({ small = false }: { small?: boolean }) {
  return (
    <span className={`monogram${small ? " monogram--small" : ""}`} aria-hidden="true">
      <svg viewBox="0 0 48 48">
        <path d="M24 4 42 14v20L24 44 6 34V14L24 4Z" className="monogram-frame" />
        <path d="M24 12v24M14 24h20" className="monogram-axis" />
        <circle cx="24" cy="24" r="7.5" className="monogram-core" />
        <circle cx="24" cy="24" r="2.2" className="monogram-dot" />
      </svg>
    </span>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <a className="brand" href="#top" aria-label="衡天档案，回到顶部">
      <Monogram small={compact} />
      <span className="brand-copy">
        <strong>衡天档案</strong>
        {!compact ? <span>HENGTIAN · ARCHIVE</span> : null}
      </span>
    </a>
  );
}

function FontStepper({
  scale,
  onStep,
  className = "",
}: {
  scale: number;
  onStep: (delta: number) => void;
  className?: string;
}) {
  const step = nearestFontStep(scale);
  return (
    <div className={`font-stepper ${className}`.trim()} role="group" aria-label="正文字号">
      <button type="button" onClick={() => onStep(-1)} disabled={step === 0} aria-label="缩小字号" title="缩小字号">
        <span className="glyph-a glyph-a--small">A</span>
        <span className="glyph-sign">−</span>
      </button>
      <span className="font-stepper-value" aria-live="polite" title={FONT_LABELS[step]}>
        {Math.round(FONT_SCALES[step] * 100)}%
      </span>
      <button
        type="button"
        onClick={() => onStep(1)}
        disabled={step === FONT_SCALES.length - 1}
        aria-label="放大字号"
        title="放大字号"
      >
        <span className="glyph-a">A</span>
        <span className="glyph-sign">+</span>
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ rail */

type RailProps = {
  sections: Section[];
  subs: Record<string, SubNav[]>;
  activeId: string;
  activeSubId: string;
  progress: number;
  themeLabel: string;
  scale: number;
  onFontStep: (delta: number) => void;
  onToggleTheme: () => void;
  onOpenSearch: () => void;
  onOpenSettings: () => void;
  onOpenSource: () => void;
};

export function Rail({
  sections,
  subs,
  activeId,
  activeSubId,
  progress,
  themeLabel,
  scale,
  onFontStep,
  onToggleTheme,
  onOpenSearch,
  onOpenSettings,
  onOpenSource,
}: RailProps) {
  const railRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const rail = railRef.current;
    if (!rail) return;
    const item = rail.querySelector<HTMLElement>(".rail-nav > ol > li.is-active > a");
    if (!item) return;
    const railBox = rail.getBoundingClientRect();
    const box = item.getBoundingClientRect();
    if (box.top < railBox.top + 90 || box.bottom > railBox.bottom - 200) {
      rail.scrollTo({ top: rail.scrollTop + (box.top - railBox.top) - railBox.height * 0.28, behavior: "smooth" });
    }
  }, [activeId]);

  const activeLabel = sections.find((section) => section.id === activeId)?.label ?? "卷首";

  return (
    <aside className="rail" aria-label="档案目录" ref={railRef}>
      <div className="rail-head">
        <Wordmark />
        <span className="rail-edition">VOL.02 · 第二版</span>
      </div>

      <nav className="rail-nav" aria-label="章节导航">
        <div className="rail-nav-head">
          <span>INDEX</span>
          <span>{sections.length} CHAPTERS</span>
        </div>
        <ol>
          {sections.map((section) => {
            const active = activeId === section.id;
            const children = subs[section.id] ?? [];
            return (
              <li key={section.id} className={active ? "is-active" : ""}>
                <a href={`#${section.id}`} aria-current={active ? "location" : undefined}>
                  <span className="rail-nav-index">{section.kicker}</span>
                  <span className="rail-nav-label">{section.label}</span>
                  <span className="rail-nav-dot" aria-hidden="true" />
                </a>
                {children.length ? (
                  <div className="rail-sub-wrap">
                    <ol className="rail-sub" aria-label={`${section.label}的小节`}>
                      {children.map((item) => (
                        <li
                          key={item.id}
                          className={`rail-sub-item rail-sub-item--l${item.level}${activeSubId === item.id ? " is-current" : ""}`}
                        >
                          <a href={`#${item.id}`} tabIndex={active ? 0 : -1}>
                            {item.num ? <b>{item.num}</b> : <i aria-hidden="true" />}
                            <span>{item.title}</span>
                          </a>
                        </li>
                      ))}
                    </ol>
                  </div>
                ) : null}
              </li>
            );
          })}
        </ol>
      </nav>

      <div className="rail-progress">
        <div className="rail-progress-head">
          <span>READING</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="rail-progress-track" aria-hidden="true">
          <span style={{ width: `${Math.max(progress, 1)}%` }} />
        </div>
        <div className="rail-progress-caption">当前位于：{activeLabel}</div>
      </div>

      <div className="rail-font">
        <span className="rail-font-label">
          <IconTextSize size={15} />
          字号
        </span>
        <FontStepper scale={scale} onStep={onFontStep} />
      </div>

      <div className="rail-actions">
        <button type="button" className="rail-action" onClick={onOpenSearch}>
          <IconSearch size={16} />
          <span>检索</span>
          <kbd>⌘K</kbd>
        </button>
        <button type="button" className="rail-action" onClick={onToggleTheme}>
          {themeLabel === "深色" ? <IconSun size={16} /> : <IconMoon size={16} />}
          <span>{themeLabel === "深色" ? "日间" : "深色"}</span>
        </button>
        <button type="button" className="rail-action" onClick={onOpenSettings}>
          <IconTextSize size={16} />
          <span>显示设置</span>
        </button>
        <button type="button" className="rail-action" onClick={onOpenSource}>
          <IconSource size={16} />
          <span>原文</span>
        </button>
      </div>

      <div className="rail-seal">
        <span className="seal-mark">衡</span>
        <div>
          <span>FULL TEXT · UNEDITED</span>
          <p>原文完整收录，数值均可回查。</p>
        </div>
      </div>
    </aside>
  );
}

/* ------------------------------------------------------------------ topbar */

type TopbarProps = {
  active: { kicker: string; label: string };
  activeSub?: SubNav;
  themeLabel: string;
  scale: number;
  onFontStep: (delta: number) => void;
  onToggleTheme: () => void;
  onOpenMenu: () => void;
  onOpenSearch: () => void;
  onOpenSettings: () => void;
  progress: number;
};

export function Topbar({
  active,
  activeSub,
  themeLabel,
  scale,
  onFontStep,
  onToggleTheme,
  onOpenMenu,
  onOpenSearch,
  onOpenSettings,
  progress,
}: TopbarProps) {
  return (
    <header className="topbar">
      <div className="topbar-mobile-brand">
        <Wordmark compact />
      </div>
      <div className="topbar-context" aria-live="polite">
        <span className="topbar-context-kicker">{active.kicker}</span>
        <span className="topbar-context-sep" aria-hidden="true">
          /
        </span>
        <span className="topbar-context-label">{active.label}</span>
        {activeSub ? (
          <span className="topbar-context-sub">
            <i aria-hidden="true">›</i>
            {activeSub.num ? <b>{activeSub.num}</b> : null}
            {activeSub.title}
          </span>
        ) : null}
      </div>
      <span className="topbar-rule" aria-hidden="true" />
      <div className="topbar-progress" aria-hidden="true">
        <span style={{ width: `${progress}%` }} />
      </div>
      <div className="topbar-actions">
        <FontStepper scale={scale} onStep={onFontStep} className="topbar-font" />
        <button type="button" className="icon-button topbar-search" onClick={onOpenSearch} aria-label="检索档案">
          <IconSearch size={18} />
          <span className="topbar-search-label">检索</span>
          <kbd>⌘K</kbd>
        </button>
        <button
          type="button"
          className="icon-button topbar-theme"
          onClick={onToggleTheme}
          aria-label={`当前为${themeLabel}主题，切换主题`}
          title={`切换主题（当前${themeLabel}）`}
        >
          {themeLabel === "深色" ? <IconSun size={18} /> : <IconMoon size={18} />}
        </button>
        <button type="button" className="icon-button topbar-settings" onClick={onOpenSettings} aria-label="字号与显示设置">
          <IconTextSize size={18} />
        </button>
        <button type="button" className="icon-button topbar-menu" onClick={onOpenMenu} aria-label="打开章节目录">
          <IconMenu size={19} />
        </button>
      </div>
    </header>
  );
}

/* ------------------------------------------------------------------ overlay */

type OverlayProps = {
  open: boolean;
  onClose: () => void;
  label: string;
  className?: string;
  children: ReactNode;
  initialFocus?: string;
};

function Overlay({ open, onClose, label, className = "", children, initialFocus }: OverlayProps) {
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const root = document.documentElement;
    const prior = root.style.overflow;
    const previouslyFocused = document.activeElement as HTMLElement | null;
    root.style.overflow = "hidden";
    const timer = window.setTimeout(() => {
      const target = initialFocus
        ? panelRef.current?.querySelector<HTMLElement>(initialFocus)
        : panelRef.current?.querySelector<HTMLElement>("button, a[href], input, textarea, [tabindex]:not([tabindex='-1'])");
      target?.focus({ preventScroll: true });
    }, 40);

    const onKeyDown = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
      }
      if (event.key !== "Tab" || !panelRef.current) return;
      const focusable = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>(
          "a[href], button:not([disabled]), input:not([disabled]), textarea, select, [tabindex]:not([tabindex='-1'])",
        ),
      ).filter((element) => element.offsetParent !== null);
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener("keydown", onKeyDown);
    return () => {
      root.style.overflow = prior;
      window.clearTimeout(timer);
      document.removeEventListener("keydown", onKeyDown);
      previouslyFocused?.focus?.({ preventScroll: true });
    };
  }, [open, onClose, initialFocus]);

  if (!open) return null;
  return createPortal(
    <div
      className={`overlay ${className}`.trim()}
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="overlay-panel" role="dialog" aria-modal="true" aria-label={label} ref={panelRef}>
        {children}
      </div>
    </div>,
    document.body,
  );
}

/* ------------------------------------------------------------------ mobile menu */

export function MobileMenu({
  open,
  onClose,
  sections,
  subs,
  activeId,
  activeSubId,
  onOpenSettings,
  onOpenSource,
}: {
  open: boolean;
  onClose: () => void;
  sections: Section[];
  subs: Record<string, SubNav[]>;
  activeId: string;
  activeSubId: string;
  onOpenSettings: () => void;
  onOpenSource: () => void;
}) {
  const go = (event: MouseEvent<HTMLAnchorElement>, id: string) => {
    event.preventDefault();
    onClose();
    window.setTimeout(() => jumpTo(id), 60);
  };
  return (
    <Overlay open={open} onClose={onClose} label="章节目录" className="overlay--nav">
      <div className="sheet-grip" aria-hidden="true" />
      <div className="sheet-head">
        <div>
          <span className="sheet-kicker">ARCHIVE INDEX</span>
          <h2>章节目录</h2>
        </div>
        <button type="button" className="icon-button" onClick={onClose} aria-label="关闭目录">
          <IconClose size={20} />
        </button>
      </div>
      <nav className="mobile-nav" aria-label="章节目录">
        <ol>
          {sections.map((section) => {
            const active = activeId === section.id;
            const children = subs[section.id] ?? [];
            return (
              <li key={section.id} className={active ? "is-active" : ""}>
                <a href={`#${section.id}`} onClick={(event) => go(event, section.id)} aria-current={active ? "location" : undefined}>
                  <span className="mobile-nav-index">{section.kicker}</span>
                  <span className="mobile-nav-copy">
                    <strong>{section.label}</strong>
                    <small>{section.english}</small>
                  </span>
                  <IconArrowRight size={16} />
                </a>
                {children.length ? (
                  <ol className="mobile-sub">
                    {children.map((item) => (
                      <li key={item.id} className={activeSubId === item.id ? "is-current" : ""}>
                        <a href={`#${item.id}`} onClick={(event) => go(event, item.id)}>
                          <b>{item.num || "·"}</b>
                          <span>{item.title}</span>
                        </a>
                      </li>
                    ))}
                  </ol>
                ) : null}
              </li>
            );
          })}
        </ol>
      </nav>
      <div className="sheet-actions">
        <button
          type="button"
          className="button button--quiet"
          onClick={() => {
            onClose();
            onOpenSettings();
          }}
        >
          <IconTextSize size={16} />
          字号与主题
        </button>
        <button
          type="button"
          className="button button--quiet"
          onClick={() => {
            onClose();
            onOpenSource();
          }}
        >
          <IconSource size={16} />
          查看原文
        </button>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ search */

function highlightSnippet(text: string, query: string) {
  if (!query) return text;
  const lower = text.toLowerCase();
  const needle = query.toLowerCase();
  const out: ReactNode[] = [];
  let index = 0;
  let found = lower.indexOf(needle, index);
  let key = 0;
  while (found >= 0) {
    if (found > index) out.push(text.slice(index, found));
    out.push(<mark key={key++}>{text.slice(found, found + query.length)}</mark>);
    index = found + query.length;
    found = lower.indexOf(needle, index);
  }
  if (index < text.length) out.push(text.slice(index));
  return out;
}

export function SearchDialog({
  open,
  onClose,
  entries,
  onNavigate,
}: {
  open: boolean;
  onClose: () => void;
  entries: SearchEntry[];
  onNavigate: (id: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const results = useMemo(() => {
    const clean = query.trim().toLowerCase();
    if (!clean) return [];
    return entries.filter((entry) => entry.text.toLowerCase().includes(clean)).slice(0, 30);
  }, [entries, query]);

  useEffect(() => {
    if (!open) {
      setActive(0);
      return;
    }
    const timer = window.setTimeout(() => inputRef.current?.focus(), 60);
    return () => window.clearTimeout(timer);
  }, [open]);

  useEffect(() => {
    setActive(0);
  }, [query]);

  const go = (entry: SearchEntry) => {
    onNavigate(entry.id);
    onClose();
  };

  const onKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActive((value) => Math.min(value + 1, Math.max(results.length - 1, 0)));
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      setActive((value) => Math.max(value - 1, 0));
    }
    if (event.key === "Enter" && results[active]) {
      event.preventDefault();
      go(results[active]);
    }
  };

  const suggestions = ["束缚能", "汽化", "钢纤维", "云层", "白矮星", "强度", "GBU-57", "KI 极限"];
  const clean = query.trim();

  return (
    <Overlay open={open} onClose={onClose} label="检索档案" className="overlay--search" initialFocus="input">
      <div className="search-top">
        <IconSearch size={21} />
        <input
          ref={inputRef}
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          onKeyDown={onKeyDown}
          placeholder="输入材质、量纲、天体或公式…"
          aria-label="检索关键词"
          autoComplete="off"
          spellCheck={false}
          enterKeyHint="search"
        />
        <button type="button" className="icon-button" onClick={onClose} aria-label="关闭检索">
          <IconClose size={20} />
        </button>
      </div>
      <div className="search-body">
        {!clean ? (
          <div className="search-empty">
            <span className="sheet-kicker">SEARCH THE CODEX</span>
            <h3>在整份档案中定位一行数字</h3>
            <p>检索覆盖全部标题、正文、列表与数据图版，结果会直接跳到原文位置并短暂高亮。</p>
            <div className="search-suggestions">
              {suggestions.map((suggestion) => (
                <button type="button" key={suggestion} onClick={() => setQuery(suggestion)}>
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : results.length ? (
          <>
            <div className="search-summary">
              <span>找到 {results.length} 条结果</span>
              <span>↑↓ 选择 · Enter 跳转</span>
            </div>
            <ul className="search-results">
              {results.map((entry, index) => {
                const position = entry.text.toLowerCase().indexOf(clean.toLowerCase());
                const start = Math.max(0, position - 30);
                const end = Math.min(entry.text.length, position + clean.length + 64);
                const snippet = `${start > 0 ? "…" : ""}${entry.text.slice(start, end)}${end < entry.text.length ? "…" : ""}`;
                return (
                  <li key={entry.id + index} className={active === index ? "is-active" : ""}>
                    <button type="button" onMouseEnter={() => setActive(index)} onClick={() => go(entry)}>
                      <span className="search-result-main">
                        <span className="search-result-meta">
                          <span>{entry.sectionKicker}</span>
                          <span>{entry.sectionLabel}</span>
                          {entry.subLabel ? <span className="search-result-sub">› {entry.subLabel}</span> : null}
                        </span>
                        <span className="search-result-text">{highlightSnippet(snippet, clean)}</span>
                      </span>
                      <IconArrowRight size={15} />
                    </button>
                  </li>
                );
              })}
            </ul>
          </>
        ) : (
          <div className="search-no-results">
            <span className="sheet-kicker">NO MATCH</span>
            <h3>没有找到「{clean}」</h3>
            <p>试试更短的关键词，或在原文视图中使用浏览器查找。</p>
            <button type="button" className="button button--quiet" onClick={() => setQuery("")}>
              清空关键词
            </button>
          </div>
        )}
      </div>
      <div className="search-foot">
        <span>全文检索</span>
        <span>原文未删改</span>
        <span>Esc 关闭</span>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ display settings */

export function DisplayDialog({
  open,
  onClose,
  themeMode,
  onThemeChange,
  scale,
  onScaleSet,
  bodyFont,
  onBodyFont,
  leading,
  onLeading,
  onReset,
  onOpenSource,
  onPrint,
}: {
  open: boolean;
  onClose: () => void;
  themeMode: ThemeMode;
  onThemeChange: (mode: ThemeMode) => void;
  scale: number;
  onScaleSet: (scale: number) => void;
  bodyFont: BodyFont;
  onBodyFont: (font: BodyFont) => void;
  leading: Leading;
  onLeading: (leading: Leading) => void;
  onReset: () => void;
  onOpenSource: () => void;
  onPrint: () => void;
}) {
  const step = nearestFontStep(scale);
  const themes: { value: ThemeMode; label: string; note: string }[] = [
    { value: "light", label: "日间", note: "PAPER / INK" },
    { value: "dark", label: "深色", note: "OBSIDIAN / EMBER" },
    { value: "system", label: "跟随系统", note: "AUTO" },
  ];
  return (
    <Overlay open={open} onClose={onClose} label="显示设置" className="overlay--settings">
      <div className="sheet-grip" aria-hidden="true" />
      <div className="sheet-head">
        <div>
          <span className="sheet-kicker">DISPLAY / READING</span>
          <h2>显示设置</h2>
        </div>
        <button type="button" className="icon-button" onClick={onClose} aria-label="关闭设置">
          <IconClose size={20} />
        </button>
      </div>
      <div className="settings-scroll">
        <div className="settings-section">
          <div className="settings-label">
            <span>字号</span>
            <span>
              {FONT_LABELS[step]} · {Math.round(FONT_SCALES[step] * 100)}%
            </span>
          </div>
          <div className="scale-control">
            <button
              type="button"
              className="font-step"
              onClick={() => onScaleSet(FONT_SCALES[Math.max(0, step - 1)])}
              disabled={step === 0}
              aria-label="缩小字号"
            >
              <span className="glyph-a glyph-a--small">A</span>
            </button>
            <div className="scale-dots" role="radiogroup" aria-label="字号档位">
              <span className="scale-rail" aria-hidden="true">
                <span style={{ width: `${(step / (FONT_SCALES.length - 1)) * 100}%` }} />
              </span>
              {FONT_SCALES.map((value, index) => (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={index === step}
                  aria-label={`${FONT_LABELS[index]} ${Math.round(value * 100)}%`}
                  className={`scale-dot${index <= step ? " is-on" : ""}${index === step ? " is-current" : ""}`}
                  onClick={() => onScaleSet(value)}
                >
                  <i />
                </button>
              ))}
            </div>
            <button
              type="button"
              className="font-step"
              onClick={() => onScaleSet(FONT_SCALES[Math.min(FONT_SCALES.length - 1, step + 1)])}
              disabled={step === FONT_SCALES.length - 1}
              aria-label="放大字号"
            >
              <span className="glyph-a">A</span>
            </button>
          </div>
          <div className="scale-labels" aria-hidden="true">
            <span>小</span>
            <span>标准</span>
            <span>超大</span>
          </div>
        </div>

        <div className="settings-section settings-section--split">
          <div>
            <div className="settings-label">
              <span>正文字体</span>
            </div>
            <div className="seg" role="radiogroup" aria-label="正文字体">
              {(["sans", "serif"] as BodyFont[]).map((font) => (
                <button
                  key={font}
                  type="button"
                  role="radio"
                  aria-checked={bodyFont === font}
                  className={bodyFont === font ? "is-active" : ""}
                  onClick={() => onBodyFont(font)}
                >
                  <span className={`seg-glyph seg-glyph--${font}`}>永</span>
                  {font === "sans" ? "黑体" : "宋体"}
                </button>
              ))}
            </div>
          </div>
          <div>
            <div className="settings-label">
              <span>行距</span>
            </div>
            <div className="seg" role="radiogroup" aria-label="行距">
              {(["compact", "normal", "relaxed"] as Leading[]).map((value) => (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={leading === value}
                  className={leading === value ? "is-active" : ""}
                  onClick={() => onLeading(value)}
                >
                  <span className={`seg-lines seg-lines--${value}`} aria-hidden="true">
                    <i />
                    <i />
                    <i />
                  </span>
                  {LEADING_LABELS[value]}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="settings-section">
          <div className="font-preview">
            <span>预览</span>
            <p>
              实战判定最容易出错的地方，不是查错数字，而是<strong>用错量纲</strong>。
            </p>
          </div>
        </div>

        <div className="settings-section">
          <div className="settings-label">
            <span>主题</span>
            <span>日间与深色均为独立配色</span>
          </div>
          <div className="theme-options" role="radiogroup" aria-label="主题选择">
            {themes.map((theme) => (
              <button
                key={theme.value}
                type="button"
                role="radio"
                aria-checked={themeMode === theme.value}
                className={`theme-option theme-option--${theme.value === "system" ? "auto" : theme.value}${
                  themeMode === theme.value ? " is-active" : ""
                }`}
                onClick={() => onThemeChange(theme.value)}
              >
                <span className="theme-swatch">
                  <i />
                  <i />
                </span>
                <span>
                  {theme.label}
                  <small>{theme.note}</small>
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="settings-actions">
        <button type="button" className="settings-action" onClick={onOpenSource}>
          <IconSource size={18} />
          <span>
            原文视图
            <small>完整 Markdown</small>
          </span>
          <IconArrowRight size={15} />
        </button>
        <button type="button" className="settings-action" onClick={onPrint}>
          <IconPrint size={18} />
          <span>
            打印 / 导出 PDF
            <small>版式自动转为纸面</small>
          </span>
          <IconArrowRight size={15} />
        </button>
      </div>
      <p className="settings-foot">
        <span>设置会保存在本机浏览器中</span>
        <button type="button" className="link-button" onClick={onReset}>
          恢复默认
        </button>
      </p>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ source */

export function SourceDialog({
  open,
  onClose,
  raw,
  lineCount,
  onCopy,
  onDownload,
  onPrint,
  copied,
}: {
  open: boolean;
  onClose: () => void;
  raw: string;
  lineCount: number;
  onCopy: () => void;
  onDownload: () => void;
  onPrint: () => void;
  copied: boolean;
}) {
  return (
    <Overlay open={open} onClose={onClose} label="完整原文" className="overlay--source">
      <div className="source-head">
        <div>
          <span className="sheet-kicker">SOURCE · VERBATIM</span>
          <h2>完整原文</h2>
          <p>未删改 · {lineCount} 行 · Markdown 源文</p>
        </div>
        <div className="source-actions">
          <button type="button" className="source-action" onClick={onCopy}>
            <IconCopy size={17} />
            <span>{copied ? "已复制" : "复制原文"}</span>
          </button>
          <button type="button" className="source-action" onClick={onDownload}>
            <IconDownload size={17} />
            <span>下载 .md</span>
          </button>
          <button type="button" className="source-action source-action--icon" onClick={onPrint} aria-label="打印">
            <IconPrint size={17} />
          </button>
          <button type="button" className="source-action source-action--icon" onClick={onClose} aria-label="关闭原文">
            <IconClose size={19} />
          </button>
        </div>
      </div>
      <div className="source-body">
        <pre>{raw}</pre>
      </div>
      <div className="source-foot">
        <span>原文校验视图</span>
        <span>自动换行 · 无内容截断</span>
      </div>
    </Overlay>
  );
}

/* ------------------------------------------------------------------ mobile dock / fab / resume */

export function MobileDock({
  progress,
  hidden,
  onOpenMenu,
  onOpenSearch,
  onOpenSettings,
  onBackTop,
}: {
  progress: number;
  hidden: boolean;
  onOpenMenu: () => void;
  onOpenSearch: () => void;
  onOpenSettings: () => void;
  onBackTop: () => void;
}) {
  return (
    <nav className={`mobile-dock${hidden ? " is-hidden" : ""}`} aria-label="快捷导航">
      <span className="mobile-dock-progress" aria-hidden="true">
        <i style={{ width: `${progress}%` }} />
      </span>
      <button type="button" onClick={onOpenMenu} aria-label="打开章节目录">
        <IconMenu size={20} />
        <span>目录</span>
      </button>
      <button type="button" onClick={onOpenSearch} aria-label="检索档案">
        <IconSearch size={20} />
        <span>检索</span>
      </button>
      <button type="button" onClick={onOpenSettings} aria-label="字号与主题">
        <IconTextSize size={20} />
        <span>字号</span>
      </button>
      <button type="button" onClick={onBackTop} aria-label="回到顶部">
        <IconArrowUp size={20} />
        <span>顶部</span>
      </button>
    </nav>
  );
}

export function BackToTop({ visible, onBackTop }: { visible: boolean; onBackTop: () => void }) {
  return (
    <button
      type="button"
      className={`fab-top${visible ? " is-visible" : ""}`}
      onClick={onBackTop}
      aria-label="回到顶部"
      tabIndex={visible ? 0 : -1}
    >
      <IconArrowUp size={18} />
    </button>
  );
}

export function ContinueReading({
  label,
  onResume,
  onDismiss,
}: {
  label: string;
  onResume: () => void;
  onDismiss: () => void;
}) {
  return (
    <div className="resume-pill" role="status">
      <span className="resume-dot" aria-hidden="true" />
      <button type="button" className="resume-main" onClick={onResume}>
        <small>继续上次阅读</small>
        <strong>{label}</strong>
      </button>
      <button type="button" className="resume-close" onClick={onDismiss} aria-label="关闭继续阅读提示">
        <IconClose size={15} />
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ footer */

export function Footer({
  sections,
  onOpenSource,
  onDownload,
  onPrint,
  onBackTop,
}: {
  sections: Section[];
  onOpenSource: () => void;
  onDownload: () => void;
  onPrint: () => void;
  onBackTop: () => void;
}) {
  return (
    <footer className="site-footer">
      <div className="footer-top">
        <div className="footer-brand">
          <Monogram />
          <div>
            <strong>材质与破坏能量数据库</strong>
            <span>衡天⊙多维战力量级体系 · 配套数据参考</span>
          </div>
        </div>
        <div className="footer-stamp">
          <span>VOL. 02</span>
          <span>SECOND EDITION</span>
          <span>FULL TEXT</span>
        </div>
      </div>
      <nav className="footer-index" aria-label="全部章节">
        {sections.map((section) => (
          <a key={section.id} href={`#${section.id}`}>
            <b>{section.kicker}</b>
            <span>{section.label}</span>
          </a>
        ))}
      </nav>
      <div className="footer-body">
        <p className="footer-quote">“所有数值标注来源，可交叉核实。”</p>
        <div className="footer-actions">
          <button type="button" className="button button--quiet" onClick={onOpenSource}>
            <IconSource size={16} />
            完整原文
          </button>
          <button type="button" className="button button--quiet" onClick={onDownload}>
            <IconDownload size={16} />
            下载 .md
          </button>
          <button type="button" className="button button--quiet" onClick={onPrint}>
            <IconPrint size={16} />
            打印
          </button>
          <button type="button" className="button button--quiet" onClick={onBackTop}>
            <IconArrowUp size={16} />
            回到顶部
          </button>
        </div>
      </div>
      <div className="footer-bottom">
        <span>HENGTIAN ARCHIVE · DATA CODEX 02</span>
        <span>全文逐字收录 · 版式重排未改原文</span>
        <span>按需查表，不必通读</span>
      </div>
      <span className="footer-glyph" aria-hidden="true">
        衡
      </span>
    </footer>
  );
}
