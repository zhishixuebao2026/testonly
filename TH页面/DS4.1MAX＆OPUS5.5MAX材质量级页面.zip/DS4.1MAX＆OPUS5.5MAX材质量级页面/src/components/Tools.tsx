import { useId, useState, type ReactNode } from "react";
import * as P from "../lib/physics";
import { IconChevron } from "./Icons";

/* ------------------------------------------------------------------ primitives */

function Sci({ value, digits = 3 }: { value: number; digits?: number }) {
  const parts = P.sci(value, digits);
  if (parts.exponent === null) return <>{parts.mantissa}</>;
  return (
    <>
      {parts.mantissa}
      <span className="sci-x">×10</span>
      <sup>{parts.exponent}</sup>
    </>
  );
}

function Field({
  label,
  unit,
  value,
  onChange,
  hint,
}: {
  label: string;
  unit?: string;
  value: string;
  onChange: (value: string) => void;
  hint?: string;
}) {
  const id = useId();
  const parsed = P.parseNum(value);
  const invalid = value.trim() !== "" && !Number.isFinite(parsed);
  return (
    <div className={`tool-field${invalid ? " is-invalid" : ""}`}>
      <label htmlFor={id}>{label}</label>
      <div className="tool-input">
        <input
          id={id}
          inputMode="decimal"
          autoComplete="off"
          spellCheck={false}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          aria-invalid={invalid}
        />
        {unit ? <span className="tool-unit">{unit}</span> : null}
      </div>
      {hint ? <span className="tool-hint">{hint}</span> : null}
    </div>
  );
}

function Segmented<T extends string>({
  value,
  options,
  onChange,
  label,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
  label: string;
}) {
  return (
    <div className="tool-seg" role="radiogroup" aria-label={label}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          role="radio"
          aria-checked={value === option.value}
          className={value === option.value ? "is-active" : ""}
          onClick={() => onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

function Chips({
  label,
  items,
  onPick,
}: {
  label: string;
  items: { key: string; label: string }[];
  onPick: (key: string) => void;
}) {
  return (
    <div className="tool-chips" role="group" aria-label={label}>
      <span className="tool-chips-label">{label}</span>
      {items.map((item) => (
        <button key={item.key} type="button" onClick={() => onPick(item.key)}>
          {item.label}
        </button>
      ))}
    </div>
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (value: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      className={`tool-switch${checked ? " is-on" : ""}`}
      onClick={() => onChange(!checked)}
    >
      <span className="tool-switch-track" aria-hidden="true">
        <i />
      </span>
      {label}
    </button>
  );
}

function Result({
  label,
  value,
  unit,
  sub,
  tone = "default",
  digits,
}: {
  label: string;
  value: number;
  unit: string;
  sub?: ReactNode;
  tone?: "default" | "accent" | "muted";
  digits?: number;
}) {
  return (
    <div className={`tool-result tool-result--${tone}`}>
      <span className="tool-result-label">{label}</span>
      <span className="tool-result-value">
        <span className="tool-num">
          <Sci value={value} digits={digits} />
        </span>
        {unit ? <span className="tool-result-unit">{unit}</span> : null}
      </span>
      {sub ? <span className="tool-result-sub">{sub}</span> : null}
    </div>
  );
}

function ToolShell({
  code,
  title,
  formula,
  source,
  summary,
  children,
}: {
  code: string;
  title: string;
  formula: ReactNode;
  source: string;
  summary: ReactNode;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const bodyId = useId();
  return (
    <section className="tool reveal" data-open={open ? "true" : "false"} aria-label={`交互工具：${title}`}>
      <button
        type="button"
        className="tool-head"
        aria-expanded={open}
        aria-controls={bodyId}
        onClick={() => setOpen((value) => !value)}
      >
        <span className="tool-badge">
          <span className="tool-badge-dot" aria-hidden="true" />
          交互工具 · {code}
        </span>
        <span className="tool-title">{title}</span>
        <span className="tool-formula">{formula}</span>
        <span className="tool-summary">{summary}</span>
        <span className="tool-toggle">
          {open ? "收起" : "展开计算"}
          <IconChevron size={14} />
        </span>
      </button>
      <div className="tool-collapse" id={bodyId}>
        <div className="tool-collapse-inner" inert={!open}>
          {children}
          <p className="tool-note">
            依原文 {source} 所列公式实时计算 · 支持科学计数输入（如 5.972e24 或 5.972×10^24）· 结果仅作交叉校验，判定以原文为准
          </p>
        </div>
      </div>
    </section>
  );
}

const valid = (...values: number[]) => values.every((value) => Number.isFinite(value) && value > 0);

/* ------------------------------------------------------------------ 0.3 */

function DepthDiagram({ b, h, a }: { b: number; h: number; a: number }) {
  if (!valid(b, h, a) || a >= 90) {
    return <div className="depth-diagram depth-diagram--empty">输入有效的宽度、深度与高度角后显示示意</div>;
  }
  const tan = Math.tan((a * Math.PI) / 180);
  const limit = b * tan;
  const top = 40;
  const x0 = 104;
  const maxDepth = Math.max(h, Math.min(limit, h * 1.5));
  let s = 108 / maxDepth;
  if (b * s > 118) s = 118 / b;
  const w = Math.max(b * s, 3);
  const d = h * s;
  const hitsWall = limit <= h;
  const hitX = hitsWall ? x0 + w : x0 + (h / tan) * s;
  const hitY = hitsWall ? top + limit * s : top + d;
  const reach = Math.min(64, (top - 8) / tan);
  const sx = x0 - reach;
  const sy = top - reach * tan;
  const lit = hitsWall
    ? `${x0},${top} ${x0 + w},${top} ${x0 + w},${top + limit * s}`
    : `${x0},${top} ${x0 + w},${top} ${x0 + w},${top + d} ${hitX},${top + d}`;
  return (
    <svg className="depth-diagram" viewBox="0 0 280 168" role="img" aria-label="坑或裂缝的日照示意">
      <rect x="0" y={top} width="280" height={168 - top} className="dd-ground" />
      <rect x={x0} y={top} width={w} height={d} className="dd-pit" />
      <polygon points={lit} className="dd-lit" />
      <line x1={sx} y1={sy} x2={hitX} y2={hitY} className="dd-ray" />
      <circle cx={sx} cy={sy} r="6" className="dd-sun" />
      <line x1="0" y1={top} x2={x0} y2={top} className="dd-edge" />
      <line x1={x0 + w} y1={top} x2="280" y2={top} className="dd-edge" />
      <text x={x0 + w / 2} y={top - 7} className="dd-label" textAnchor="middle">
        b
      </text>
      <text x={x0 + w + 8} y={top + d / 2} className="dd-label">
        h
      </text>
      <text x={sx + 12} y={sy + 4} className="dd-label dd-label--muted">
        a
      </text>
      <line x1={x0 + w - 4} y1={hitY} x2={x0 + w + 4} y2={hitY} className="dd-tick" />
    </svg>
  );
}

export function SightTool() {
  const [tab, setTab] = useState<"depth" | "curve" | "ext">("depth");
  const [b, setB] = useState("50");
  const [h, setH] = useState("200");
  const [a, setA] = useState("60");
  const [radius, setRadius] = useState("6371");
  const [eye, setEye] = useState("1.7");
  const [target, setTarget] = useState("0");
  const [k, setK] = useState("0.075");
  const [x, setX] = useState("50");

  const bn = P.parseNum(b);
  const hn = P.parseNum(h);
  const an = P.parseNum(a);
  const angleOk = Number.isFinite(an) && an > 0 && an < 90;
  const limit = angleOk ? bn * Math.tan((an * Math.PI) / 180) : Number.NaN;
  const depthOk = Number.isFinite(limit) && Number.isFinite(hn) && hn > limit;

  const rKm = P.parseNum(radius);
  const eyeKm = P.parseNum(eye) / 1000;
  const targetKm = P.parseNum(target) / 1000;
  const s1 = P.horizon(rKm, eyeKm);
  const s2 = Number.isFinite(targetKm) && targetKm > 0 ? P.horizon(rKm, targetKm) : 0;
  const total = s1 + s2;

  const kn = P.parseNum(k);
  const xn = P.parseNum(x);
  const trans = P.transmittance(kn, xn);

  const summary =
    tab === "depth" ? (
      Number.isFinite(limit) ? (
        <>
          b·tan(a) ≈ <Sci value={limit} /> m · {depthOk ? "深不见底成立" : "日光可达底部"}
        </>
      ) : (
        "—"
      )
    ) : tab === "curve" ? (
      <>
        S ≈ <Sci value={total} /> km
      </>
    ) : (
      <>光强剩余 ≈ {P.percent(trans)}</>
    );

  const formula =
    tab === "depth" ? "h > b × tan(a)" : tab === "curve" ? "S = √(2Rh + h²) + √(2RH + H²)" : "I / I₀ = e^(−kx)";

  return (
    <ToolShell code="0.3" title="描写验证：深不见底 / 远处可见" formula={formula} source="0.3" summary={summary}>
      <div className="tool-tabs">
        <Segmented
          label="验证项目"
          value={tab}
          onChange={setTab}
          options={[
            { value: "depth", label: "深不见底" },
            { value: "curve", label: "曲率遮挡" },
            { value: "ext", label: "空气消光" },
          ]}
        />
      </div>
      {tab === "depth" ? (
        <div className="tool-grid">
          <div className="tool-inputs">
            <Field label="坑 / 裂缝宽度 b" unit="m" value={b} onChange={setB} />
            <Field label="深度 h" unit="m" value={h} onChange={setH} />
            <Field label="太阳高度角 a" unit="°" value={a} onChange={setA} hint="0° – 90° 之间" />
          </div>
          <div className="tool-outputs">
            <DepthDiagram b={bn} h={hn} a={an} />
            <Result label="日光可直射的最大深度 b·tan(a)" value={limit} unit="m" />
            <div className={`tool-verdict ${depthOk ? "is-yes" : "is-no"}`}>
              {Number.isFinite(limit) && Number.isFinite(hn)
                ? depthOk
                  ? "h > b·tan(a)：日光无法直射底部，「深不见底」在物理上成立"
                  : "h ≤ b·tan(a)：日光可以照到底部，「深不见底」更可能是观感"
                : "请输入有效数值"}
            </div>
          </div>
        </div>
      ) : null}
      {tab === "curve" ? (
        <div className="tool-grid">
          <div className="tool-inputs">
            <Chips
              label="星体"
              items={[
                { key: "earth", label: "地球 6371 km" },
                { key: "mars", label: "火星 3390 km" },
                { key: "moon", label: "月球 1737 km" },
              ]}
              onPick={(key) => setRadius(key === "earth" ? "6371" : key === "mars" ? "3390" : "1737")}
            />
            <Field label="星体半径 R" unit="km" value={radius} onChange={setRadius} />
            <Field label="观察点高度 h" unit="m" value={eye} onChange={setEye} />
            <Field label="远处目标高度 H（可选）" unit="m" value={target} onChange={setTarget} hint="0 表示目标位于地面" />
          </div>
          <div className="tool-outputs">
            <Result label="观察者地平线距离 √(2Rh + h²)" value={s1} unit="km" />
            <Result label="目标自身可见延伸 √(2RH + H²)" value={s2} unit="km" tone="muted" />
            <Result label="最远可见距离 S" value={total} unit="km" tone="accent" sub="忽略大气，理想球形星体" />
          </div>
        </div>
      ) : null}
      {tab === "ext" ? (
        <div className="tool-grid">
          <div className="tool-inputs">
            <Chips
              label="大气"
              items={[
                { key: "0.02", label: "极清澈 0.02" },
                { key: "0.075", label: "干净乡村 0.075" },
                { key: "0.35", label: "城市 / 轻霾 0.35" },
              ]}
              onPick={setK}
            />
            <Field label="消光系数 k" unit="/km" value={k} onChange={setK} hint="原文：0.01–0.03 / 0.05–0.1 / 0.2–0.5" />
            <Field label="距离 x" unit="km" value={x} onChange={setX} />
          </div>
          <div className="tool-outputs">
            <Result label="剩余光强 I / I₀" value={trans} unit="" sub={P.percent(trans)} tone="accent" digits={3} />
            <div className="tool-meter" aria-hidden="true">
              <span style={{ width: `${Number.isFinite(trans) ? Math.max(0.6, trans * 100) : 0}%` }} />
            </div>
            <p className="tool-caption">普通地表远眺取消光公式；星体表面观测取曲率公式。</p>
          </div>
        </div>
      ) : null}
    </ToolShell>
  );
}

/* ------------------------------------------------------------------ 4.2 – 4.4 */

const BODY_PRESETS: Record<string, { label: string; mass: string; radius: string; model: "uniform" | "poly" }> = {
  mars: { label: "火星", mass: "6.4169e23", radius: "3390", model: "uniform" },
  earth: { label: "地球", mass: "5.972e24", radius: "6371", model: "uniform" },
  jupiter: { label: "木星", mass: "1.898e27", radius: "69911", model: "uniform" },
  sun: { label: "太阳", mass: "1.989e30", radius: "695700", model: "uniform" },
  wd5: { label: "白矮星 0.5 M☉", mass: "9.945e29", radius: "9700", model: "poly" },
  wd6: { label: "白矮星 0.6 M☉", mass: "1.1934e30", radius: "8700", model: "poly" },
};

export function BindingTool() {
  const [mode, setMode] = useState<"mass" | "density">("mass");
  const [model, setModel] = useState<"uniform" | "poly">("uniform");
  const [mass, setMass] = useState("5.972e24");
  const [radius, setRadius] = useState("6371");
  const [density, setDensity] = useState("2");
  const [diameter, setDiameter] = useState("1000");

  const radiusM = mode === "mass" ? P.parseNum(radius) * 1000 : (P.parseNum(diameter) * 1000) / 2;
  const massKg = mode === "mass" ? P.parseNum(mass) : P.sphereMass(P.parseNum(density) * 1000, radiusM);
  const ok = valid(radiusM, massKg);
  const U = ok ? (model === "uniform" ? P.uniformSphereBinding(massKg, radiusM) : P.polytropeBinding(massKg, radiusM)) : Number.NaN;

  const pick = (key: string) => {
    const preset = BODY_PRESETS[key];
    if (!preset) return;
    setMode("mass");
    setMass(preset.mass);
    setRadius(preset.radius);
    setModel(preset.model);
  };

  return (
    <ToolShell
      code="4.2"
      title="天体引力束缚能"
      formula={model === "uniform" ? "U = 3GM² / (5R)" : "U = (6/7)GM² / R"}
      source="4.2 与 4.4"
      summary={
        <>
          U ≈ <Sci value={U} /> J
        </>
      }
    >
      <div className="tool-tabs">
        <Segmented
          label="输入方式"
          value={mode}
          onChange={setMode}
          options={[
            { value: "mass", label: "质量 + 半径" },
            { value: "density", label: "密度 + 直径" },
          ]}
        />
        <Segmented
          label="结构模型"
          value={model}
          onChange={setModel}
          options={[
            { value: "uniform", label: "均匀球 3/5" },
            { value: "poly", label: "多方球 n=1.5" },
          ]}
        />
      </div>
      <div className="tool-grid">
        <div className="tool-inputs">
          <Chips
            label="预设"
            items={Object.entries(BODY_PRESETS).map(([key, preset]) => ({ key, label: preset.label }))}
            onPick={pick}
          />
          {mode === "mass" ? (
            <>
              <Field label="质量 M" unit="kg" value={mass} onChange={setMass} />
              <Field label="半径 R" unit="km" value={radius} onChange={setRadius} />
            </>
          ) : (
            <>
              <Field label="平均密度 ρ" unit="t/m³" value={density} onChange={setDensity} />
              <Field label="直径 D" unit="km" value={diameter} onChange={setDiameter} />
            </>
          )}
        </div>
        <div className="tool-outputs">
          <Result label={model === "uniform" ? "引力束缚能（均匀球估计）" : "引力束缚能（n=1.5 多方球）"} value={U} unit="J" tone="accent" sub={P.tntLabel(U)} />
          {model === "poly" ? (
            <Result label="净束缚能（位力定理，约为一半）" value={U / 2} unit="J" />
          ) : (
            <Result label="相对太阳束缚能（2.277×10⁴¹ J）" value={U / P.SUN_BINDING_J} unit="倍" tone="muted" />
          )}
          {mode === "density" ? <Result label="推得质量 M" value={massKg} unit="kg" tone="muted" /> : null}
          <p className="tool-caption">
            {model === "uniform"
              ? "真实天体核心更致密，真实束缚能通常高于均匀球估计（地球约高 11%）。"
              : "白矮星由简并压支撑，不能直接用均匀球公式；钱德拉塞卡极限附近请直接查 4.4 的阶梯表。"}
          </p>
        </div>
      </div>
    </ToolShell>
  );
}

/* ------------------------------------------------------------------ 4.5 */

export function TearTool() {
  const [diameter, setDiameter] = useState("1000");
  const [density, setDensity] = useState("2");
  const [gap, setGap] = useState("1");
  const radiusM = (P.parseNum(diameter) * 1000) / 2;
  const massKg = P.sphereMass(P.parseNum(density) * 1000, radiusM);
  const ok = valid(radiusM, massKg);
  const force = ok ? P.hemisphereForce(massKg, radiusM) : Number.NaN;
  const distance = P.parseNum(gap);
  const energy = force * distance;
  return (
    <ToolShell
      code="4.5"
      title="撕星：沿截面拉开两个半球"
      formula="F = 3GM² / (16R²) · E ≈ F × d"
      source="4.5"
      summary={
        <>
          F ≈ <Sci value={force} /> N
        </>
      }
    >
      <div className="tool-grid">
        <div className="tool-inputs">
          <Chips
            label="预设"
            items={[{ key: "doc", label: "原文示例：直径 1000 km · 2 t/m³" }]}
            onPick={() => {
              setDiameter("1000");
              setDensity("2");
              setGap("1");
            }}
          />
          <Field label="星球直径 D" unit="km" value={diameter} onChange={setDiameter} />
          <Field label="平均密度 ρ" unit="t/m³" value={density} onChange={setDensity} />
          <Field label="拉开距离 d" unit="m" value={gap} onChange={setGap} />
        </div>
        <div className="tool-outputs">
          <Result label="两半球之间的引力 F" value={force} unit="N" />
          <Result label={`拉开 ${Number.isFinite(distance) ? distance : "—"} m 所需能量`} value={energy} unit="J" tone="accent" sub={P.tntLabel(energy)} />
          <p className="tool-caption">标度律：F ∝ ρ²R⁴ —— 半径扩大 n 倍，每米能耗扩大 n⁴ 倍；密度扩大 n 倍，扩大 n² 倍。</p>
        </div>
      </div>
    </ToolShell>
  );
}

/* ------------------------------------------------------------------ 5.2 */

export function FluxTool() {
  const [target, setTarget] = useState("280");
  const [base, setBase] = useState("240");
  const [days, setDays] = useState("365");
  const targetN = P.parseNum(target);
  const baseN = P.parseNum(base);
  const delta = targetN - baseN;
  const power = Number.isFinite(delta) ? P.extraPower(targetN, baseN) : Number.NaN;
  const share = power / P.totalInsolation();
  const seconds = P.parseNum(days) * 86400;
  const energy = power * seconds;
  return (
    <ToolShell
      code="5.2"
      title="全球持续热注入：所需额外功率"
      formula="ΔP = (F目标 − 240 W/m²) × 4πR²"
      source="5.1 与 5.2"
      summary={
        <>
          ΔP ≈ <Sci value={power} /> W
        </>
      }
    >
      <div className="tool-grid">
        <div className="tool-inputs">
          <Chips
            label="阈值"
            items={[
              { key: "280", label: "KI 280" },
              { key: "282", label: "SN 282（Goldblatt 2013）" },
              { key: "310", label: "早期 310" },
              { key: "385", label: "早期 385" },
            ]}
            onPick={setTarget}
          />
          <Field label="目标吸收通量" unit="W/m²" value={target} onChange={setTarget} />
          <Field label="当前吸收通量" unit="W/m²" value={base} onChange={setBase} hint="原文取约 240 W/m²" />
          <Field label="作用时长（换算焦耳用）" unit="天" value={days} onChange={setDays} />
        </div>
        <div className="tool-outputs">
          <Result label="需提升的平均吸收通量" value={delta} unit="W/m²" tone="muted" />
          <Result label="额外持续功率 ΔP" value={power} unit="W" tone="accent" sub={`约占地球总日照功率（1367 W/m² × πR²）的 ${P.percent(share)}`} />
          <Result label="按作用时长换算的总能量" value={energy} unit="J" sub={P.tntLabel(energy)} />
          <p className="tool-caption tool-caption--warn">功率（W）与一次性能量（J）维度不同；跨部分比较前须先从原文确认作用时长。</p>
        </div>
      </div>
    </ToolShell>
  );
}

/* ------------------------------------------------------------------ 8.1 */

export function BlastTool() {
  const [tab, setTab] = useState<"air" | "ground" | "recv">("air");
  const [airMode, setAirMode] = useState<"area" | "radius">("area");
  const [area, setArea] = useState("105");
  const [radiusKm, setRadiusKm] = useState("5.78");
  const [conventional, setConventional] = useState(true);
  const [groundR, setGroundR] = useState("1000");
  const [pressure, setPressure] = useState(String(P.DEFAULT_OVERPRESSURE_BAR));
  const [recvE, setRecvE] = useState("1.84e16");
  const [recvR, setRecvR] = useState("1000");
  const [groundBurst, setGroundBurst] = useState(false);

  const radius = airMode === "area" ? Math.sqrt(P.parseNum(area) / Math.PI) : P.parseNum(radiusKm);
  const yieldMt = valid(radius) ? P.airBurstMt(radius, conventional) : Number.NaN;
  const airJ = yieldMt * 1e6 * P.TNT_TON_J;
  const groundTons = valid(P.parseNum(groundR), P.parseNum(pressure))
    ? P.groundBurstTons(P.parseNum(groundR), P.parseNum(pressure))
    : Number.NaN;
  const groundJ = groundTons * P.TNT_TON_J;
  const received = valid(P.parseNum(recvE), P.parseNum(recvR))
    ? P.blastReceived(P.parseNum(recvE), P.parseNum(recvR), groundBurst)
    : Number.NaN;

  const summary =
    tab === "air" ? (
      <>
        Y ≈ <Sci value={yieldMt} /> Mt
      </>
    ) : tab === "ground" ? (
      <>
        W ≈ <Sci value={groundTons} /> 吨
      </>
    ) : (
      <>
        承受 ≈ <Sci value={received} /> J
      </>
    );
  const formula =
    tab === "air" ? "Y = (x ÷ 0.28)³ ÷ 1000" : tab === "ground" ? "W = R³(√(27136P+8649)/13568 − 93/13568)²" : "I = P ÷ 4πr² · E = I × 0.68 m²";

  return (
    <ToolShell code="8.1" title="爆炸半径与当量（交叉校验）" formula={formula} source="8.1" summary={summary}>
      <div className="tool-tabs">
        <Segmented
          label="计算项目"
          value={tab}
          onChange={setTab}
          options={[
            { value: "air", label: "空爆当量" },
            { value: "ground", label: "地爆当量" },
            { value: "recv", label: "承受份额" },
          ]}
        />
      </div>
      {tab === "air" ? (
        <div className="tool-grid">
          <div className="tool-inputs">
            <Segmented
              label="输入方式"
              value={airMode}
              onChange={setAirMode}
              options={[
                { value: "area", label: "按毁伤面积" },
                { value: "radius", label: "按半径" },
              ]}
            />
            <Chips
              label="预设"
              items={[{ key: "paris", label: "原文示例：巴黎 105 km²" }]}
              onPick={() => {
                setAirMode("area");
                setArea("105");
                setConventional(true);
              }}
            />
            {airMode === "area" ? (
              <Field label="近乎全部致死的面积" unit="km²" value={area} onChange={setArea} hint={`等效半径 ≈ ${P.sci(radius).plain} km`} />
            ) : (
              <Field label="近乎全部致死半径 x" unit="km" value={radiusKm} onChange={setRadiusKm} />
            )}
            <Toggle checked={conventional} onChange={setConventional} label="常规爆炸（结果 × 0.5，真核爆不减半）" />
          </div>
          <div className="tool-outputs">
            <Result label="当量 Y" value={yieldMt} unit="百万吨 TNT" />
            <Result label="能量" value={airJ} unit="J" tone="accent" sub={P.tntLabel(airJ)} />
            <Result label="相对衡天城▽（4.184×10¹⁵ J）" value={airJ / P.CITY_TIER_J} unit="倍" tone="muted" />
            <p className="tool-caption tool-caption--warn">经验式定义为「近乎全部致死」，与衡天继承区的「完全摧毁」不同，以衡天继承区为准，差异须在结论中注明。</p>
          </div>
        </div>
      ) : null}
      {tab === "ground" ? (
        <div className="tool-grid">
          <div className="tool-inputs">
            <Field label="半径 R" unit="m" value={groundR} onChange={setGroundR} />
            <Field label="冲击波超压 P" unit="巴" value={pressure} onChange={setPressure} hint="社区通常取 1.37895 巴（约 20 psi）" />
          </div>
          <div className="tool-outputs">
            <Result label="当量 W（地爆式不减半）" value={groundTons} unit="吨 TNT" />
            <Result label="能量" value={groundJ} unit="J" tone="accent" sub={P.tntLabel(groundJ)} />
          </div>
        </div>
      ) : null}
      {tab === "recv" ? (
        <div className="tool-grid">
          <div className="tool-inputs">
            <Field label="爆炸总能量 P" unit="J" value={recvE} onChange={setRecvE} />
            <Field label="角色与爆心距离 r" unit="m" value={recvR} onChange={setRecvR} />
            <Toggle checked={groundBurst} onChange={setGroundBurst} label="地爆（作用面积取一半 2πr²）" />
          </div>
          <div className="tool-outputs">
            <Result label="角色承受的能量（截面积 0.68 m²）" value={received} unit="J" tone="accent" sub={P.tntLabel(received)} />
            <p className="tool-caption">只有爆炸发生于体内、被其完全包覆、或紧贴爆心且爆炸比角色小时，才算承受全部当量。</p>
          </div>
        </div>
      ) : null}
    </ToolShell>
  );
}

/* ------------------------------------------------------------------ 8.2 */

export function CloudTool() {
  const [view, setView] = useState("20");
  const [thickness, setThickness] = useState("8000");
  const [water, setWater] = useState("1");
  const [time, setTime] = useState("60");
  const viewN = P.parseNum(view);
  const volume = valid(viewN, P.parseNum(thickness)) ? P.cloudVolume(viewN, P.parseNum(thickness)) : Number.NaN;
  const condensation = P.condensationEnergy(volume, P.parseNum(water));
  const speed = (2 * viewN * 1000) / P.parseNum(time);
  const kinetic = P.cloudKinetic(volume, speed);
  const lowest = Math.min(condensation, kinetic);
  return (
    <ToolShell
      code="8.2"
      title="云层能量：凝结 / 动能"
      formula="V = π × 视距² × 厚度"
      source="8.2"
      summary={
        <>
          凝结 ≈ <Sci value={condensation} /> J
        </>
      }
    >
      <div className="tool-grid">
        <div className="tool-inputs">
          <Chips
            label="预设"
            items={[
              { key: "doc", label: "原文常见结果：积雨云 8000 m · 1 g/m³" },
              { key: "max", label: "积雨云上限 11800 m · 3 g/m³" },
            ]}
            onPick={(key) => {
              setView("20");
              setTime("60");
              setThickness(key === "doc" ? "8000" : "11800");
              setWater(key === "doc" ? "1" : "3");
            }}
          />
          <Field label="视距（半径）" unit="km" value={view} onChange={setView} hint="标准视距取 20 公里" />
          <Field label="云层厚度" unit="m" value={thickness} onChange={setThickness} />
          <Field label="液态含水量" unit="g/m³" value={water} onChange={setWater} />
          <Field label="覆盖全部天空用时" unit="s" value={time} onChange={setTime} hint="速度按 2 × 视距 ÷ 用时估算" />
        </div>
        <div className="tool-outputs">
          <Result label="云体积" value={volume} unit="m³" tone="muted" />
          <Result label="凝结 / 汽化（水 × 2,264,705 J/kg）" value={condensation} unit="J" sub={P.tntLabel(condensation)} />
          <Result label="动能（1.003 kg/m³ × V × v² ÷ 2）" value={kinetic} unit="J" sub={`v ≈ ${P.sci(speed).plain} m/s`} />
          <Result label="两种算法中的较低值" value={lowest} unit="J" tone="accent" sub="不确定时三种都算取最低值（对流有效位能需另算）" />
        </div>
      </div>
    </ToolShell>
  );
}
