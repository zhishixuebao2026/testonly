import { useContext, useState, type ReactNode } from "react";
import type { TableBlock } from "../lib/parse";
import { parseInline } from "../lib/parse";
import { InlineText } from "./Inline";
import { firstNumber, numberRange, scientificLog } from "../lib/data";
import { ToastContext } from "../lib/context";
import { copyText } from "../lib/clipboard";
import { IconCheck, IconCopy } from "./Icons";

function Cell({ value }: { value: string }) {
  return <InlineText parts={parseInline(value)} mode="cell" />;
}

/** Rebuilds the table exactly as written in the source Markdown. */
function tableMarkdown(block: TableBlock) {
  return [
    `| ${block.header.join(" | ")} |`,
    `|${block.header.map(() => "---").join("|")}|`,
    ...block.rows.map((row) => `| ${row.join(" | ")} |`),
  ].join("\n");
}

function FigureFrame({
  block,
  caption,
  children,
  className = "",
}: {
  block: TableBlock;
  caption: string;
  children: ReactNode;
  className?: string;
}) {
  const toast = useContext(ToastContext);
  const [copied, setCopied] = useState(false);
  const onCopy = async () => {
    const ok = await copyText(tableMarkdown(block));
    toast(ok ? "原表已复制（Markdown，逐字未改）" : "复制失败，请在原文视图中手动复制");
    if (ok) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    }
  };
  return (
    <figure className={`data-figure reveal ${className}`.trim()} data-figure={block.figure} id={block.id}>
      <div className="figure-rail">
        <span className="figure-dot" aria-hidden="true" />
        <span className="figure-code">FIG. {block.figure.replace("T-", "")}</span>
        <span className="figure-rule" aria-hidden="true" />
        <span className="figure-kind" aria-hidden="true">
          {block.rows.length} 行 · {block.header.length} 列
        </span>
        <button type="button" className={`figure-copy${copied ? " is-done" : ""}`} onClick={onCopy}>
          {copied ? <IconCheck size={13} /> : <IconCopy size={13} />}
          <span>{copied ? "已复制" : "复制原表"}</span>
        </button>
      </div>
      <figcaption className="figure-caption">{caption}</figcaption>
      {children}
      <p className="figure-origin">数值以原文表格为准 · 图形仅为比例示意</p>
    </figure>
  );
}

const ROMAN = ["Ⅰ", "Ⅱ", "Ⅲ", "Ⅳ", "Ⅴ", "Ⅵ", "Ⅶ", "Ⅷ", "Ⅸ", "Ⅹ"];

function DimensionFigure({ block }: { block: TableBlock }) {
  return (
    <FigureFrame
      block={block}
      caption="五种量纲的光谱：彼此独立，不可互换"
      className="figure--dimensions"
    >
      <div className="dimension-list">
        {block.rows.map((row, index) => (
          <article className="dimension-card" key={index}>
            <div className="dimension-index">
              <span>{ROMAN[index]}</span>
              <i aria-hidden="true" />
            </div>
            <div className="dimension-main">
              <span className="metric-key">{block.header[0]}</span>
              <h4>
                <Cell value={row[0]} />
              </h4>
              <p className="dimension-question">
                <span className="metric-key">{block.header[2]}</span>
                <Cell value={row[2]} />
              </p>
            </div>
            <div className="dimension-side">
              <div className="unit-chip">
                <span className="metric-key">{block.header[1]}</span>
                <span className="unit-value">
                  <Cell value={row[1]} />
                </span>
              </div>
              <div className="chapter-chip">
                <span className="metric-key">{block.header[3]}</span>
                <span>
                  <Cell value={row[3]} />
                </span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </FigureFrame>
  );
}

function StageFigure({ block }: { block: TableBlock }) {
  return (
    <FigureFrame
      block={block}
      caption="两条轴：残骸是否飞散 × 颗粒细到什么程度"
      className="figure--stages"
    >
      <div className="destruction-spectrum" aria-hidden="true">
        <span className="spectrum-label spectrum-label--start">大块</span>
        {block.rows.map((_, index) => (
          <span className={`spectrum-stop spectrum-stop--${index + 1}`} key={index}>
            {String(index + 1).padStart(2, "0")}
          </span>
        ))}
        <span className="spectrum-label spectrum-label--end">汽化</span>
      </div>
      <div className="stage-grid">
        {block.rows.map((row, index) => (
          <article className={`stage-card stage-card--${index + 1}`} key={index}>
            <span className="stage-index">{String(index + 1).padStart(2, "0")}</span>
            <h4>
              <Cell value={row[0]} />
            </h4>
            <div className="stage-value">
              <span className="metric-key">{block.header[1]}</span>
              <p>
                <Cell value={row[1]} />
              </p>
            </div>
            <div className="stage-source">
              <span className="metric-key">{block.header[2]}</span>
              <p>
                <Cell value={row[2]} />
              </p>
            </div>
          </article>
        ))}
      </div>
    </FigureFrame>
  );
}

function CrushFigure({ block }: { block: TableBlock }) {
  const values = block.rows.map((row) => firstNumber(row[2]) ?? 0);
  const max = Math.max(...values, 1200);
  return (
    <FigureFrame
      block={block}
      caption="同一体积的粉碎代价，按能量密度线性排列"
      className="figure--crush"
    >
      <div className="axis-row" aria-hidden="true">
        <span>0</span>
        <span>{Math.round(max / 2).toLocaleString("en-US")}</span>
        <span>{max.toLocaleString("en-US")} J/cc</span>
      </div>
      <div className="crush-list">
        {block.rows.map((row, index) => {
          const value = values[index];
          const width = Math.max(1.4, (value / max) * 100);
          return (
            <article className="crush-row" key={index}>
              <div className="crush-head">
                <span className="material-index">M{String(index + 1).padStart(2, "0")}</span>
                <h4>
                  <Cell value={row[0]} />
                </h4>
                <div className="crush-value">
                  <span className="crush-energy">
                    <Cell value={row[2]} />
                  </span>
                  <span className="crush-tnt">
                    {block.header[1]} <Cell value={row[1]} />
                  </span>
                </div>
              </div>
              <div className="energy-track bar-track" aria-hidden="true">
                <span className="bar-fill" style={{ ["--w" as string]: `${width}%` }} />
                <i className="bar-tip" style={{ left: `calc(${width}% - 3px)` }} />
              </div>
            </article>
          );
        })}
      </div>
    </FigureFrame>
  );
}

function PenetrationFigure({ block }: { block: TableBlock }) {
  const max = 61;
  return (
    <FigureFrame
      block={block}
      caption="同一武器，多套互相矛盾的公开数字"
      className="figure--penetration"
    >
      <div className="penetration-scale" aria-hidden="true">
        {[0, 20, 40, 60].map((value) => (
          <span key={value} style={{ left: `${(value / 61) * 100}%` }}>
            {value} m
          </span>
        ))}
      </div>
      <div className="dossier-list">
        {block.rows.map((row, index) => {
          const numeric = firstNumber(row[1]) ?? 0;
          const width = Math.max(2, (numeric / max) * 100);
          const unverified = row[0].includes("未证实");
          return (
            <article
              className={`dossier-card${unverified ? " dossier-card--unverified" : ""}`}
              key={index}
            >
              <div className="dossier-top">
                <span className="dossier-source-label">{block.header[0]}</span>
                <span className="dossier-source">
                  <Cell value={row[0]} />
                </span>
                {unverified ? <span className="verdict-tag">未证实口径</span> : null}
              </div>
              <div className="dossier-body">
                <p className="dossier-depth">
                  <span className="metric-key">{block.header[1]}</span>
                  <strong>
                    <Cell value={row[1]} />
                  </strong>
                </p>
                <p className="dossier-material">
                  <span className="metric-key">{block.header[2]}</span>
                  <Cell value={row[2]} />
                </p>
              </div>
              <div className="depth-track bar-track" aria-hidden="true">
                <span className="bar-fill" style={{ ["--w" as string]: `${width}%` }} />
                <i style={{ left: `calc(${width}% - 2px)` }} />
              </div>
            </article>
          );
        })}
      </div>
    </FigureFrame>
  );
}

function StrengthFigure({ block }: { block: TableBlock }) {
  return (
    <FigureFrame
      block={block}
      caption="抗压、抗拉与断裂韧性：不能混用的三把尺"
      className="figure--strength"
    >
      <div className="strength-header" aria-hidden="true">
        <span>{block.header[1]}</span>
        <span>{block.header[2]}</span>
        <span>{block.header[3]}</span>
      </div>
      <div className="strength-grid">
        {block.rows.map((row, index) => (
          <article className="material-card" key={index}>
            <div className="material-top">
              <span className="material-index">M-{String(index + 1).padStart(2, "0")}</span>
              <h4>
                <Cell value={row[0]} />
              </h4>
            </div>
            <dl className="material-metrics">
              <div>
                <dt>{block.header[1]}</dt>
                <dd className={row[1] === "—" ? "is-empty" : ""}>
                  <Cell value={row[1]} />
                </dd>
              </div>
              <div>
                <dt>{block.header[2]}</dt>
                <dd className={row[2] === "—" ? "is-empty" : ""}>
                  <Cell value={row[2]} />
                </dd>
              </div>
              <div>
                <dt>{block.header[3]}</dt>
                <dd className={row[3] === "—" ? "is-empty" : ""}>
                  <Cell value={row[3]} />
                </dd>
              </div>
            </dl>
            {row[4] && row[4] !== "—" ? (
              <p className="material-note">
                <span className="metric-key">{block.header[4]}</span>
                <Cell value={row[4]} />
              </p>
            ) : (
              <p className="material-note material-note--empty">
                <span className="metric-key">{block.header[4]}</span>
                <span>—</span>
              </p>
            )}
          </article>
        ))}
      </div>
    </FigureFrame>
  );
}

function LatentFigure({ block }: { block: TableBlock }) {
  const max = Math.max(
    ...block.rows.map((row) => firstNumber(row[2]) ?? 0),
    47900,
  );
  return (
    <FigureFrame
      block={block}
      caption="相变的第一步与最后一步"
      className="figure--latent"
    >
      <div className="latent-legend" aria-hidden="true">
        <span>
          <i className="legend-swatch legend-swatch--melt" />
          {block.header[1]}
        </span>
        <span>
          <i className="legend-swatch legend-swatch--vapor" />
          {block.header[2]}
        </span>
      </div>
      <div className="latent-grid">
        {block.rows.map((row, index) => {
          const melt = firstNumber(row[1]) ?? 0;
          const vapor = firstNumber(row[2]) ?? 0;
          return (
            <article className="phase-card" key={index}>
              <div className="phase-card-top">
                <span className="material-index">P-{String(index + 1).padStart(2, "0")}</span>
                <h4>
                  <Cell value={row[0]} />
                </h4>
              </div>
              <div className="phase-metric">
                <div className="phase-metric-label">
                  <span>{block.header[1]}</span>
                  <strong>
                    <Cell value={row[1]} />
                  </strong>
                </div>
                <div className="phase-track bar-track" aria-hidden="true">
                  <span
                    className="phase-melt bar-fill"
                    style={{ ["--w" as string]: `${Math.max(2, (melt / max) * 100)}%` }}
                  />
                </div>
              </div>
              <div className="phase-metric">
                <div className="phase-metric-label">
                  <span>{block.header[2]}</span>
                  <strong>
                    <Cell value={row[2]} />
                  </strong>
                </div>
                <div className="phase-track bar-track" aria-hidden="true">
                  <span
                    className="phase-vapor bar-fill"
                    style={{ ["--w" as string]: `${Math.max(3, (vapor / max) * 100)}%` }}
                  />
                </div>
              </div>
              <div className="phase-basis">
                <span className="metric-key">{block.header[3]}</span>
                <p>
                  <Cell value={row[3]} />
                </p>
              </div>
            </article>
          );
        })}
      </div>
    </FigureFrame>
  );
}

function VaporTotalFigure({ block }: { block: TableBlock }) {
  const max = 109000;
  return (
    <FigureFrame
      block={block}
      caption="从室温到全部汽化：完整过程的总代价"
      className="figure--vapor-total"
    >
      <div className="axis-row" aria-hidden="true">
        <span>0</span>
        <span>50,000</span>
        <span>100,000 J/cc</span>
      </div>
      <div className="range-list">
        {block.rows.map((row, index) => {
          const [low, high] = numberRange(row[1]);
          const left = low ? (low / max) * 100 : 0;
          const right = high ? (high / max) * 100 : left;
          return (
            <article className="range-row" key={index}>
              <div className="range-head">
                <div>
                  <span className="metric-key">{block.header[0]}</span>
                  <h4>
                    <Cell value={row[0]} />
                  </h4>
                </div>
                <p>
                  <span className="metric-key">{block.header[1]}</span>
                  <strong>
                    <Cell value={row[1]} />
                  </strong>
                </p>
              </div>
              <div className="range-track bar-track" aria-hidden="true">
                <span className="bar-fill bar-fill--range" style={{ left: `${left}%`, ["--w" as string]: `${Math.max(2, right - left)}%` }} />
                <i style={{ left: `${left}%` }} />
                <i style={{ left: `${right}%` }} />
              </div>
              <p className="range-note">
                <span className="metric-key">{block.header[2]}</span>
                <Cell value={row[2]} />
              </p>
            </article>
          );
        })}
      </div>
    </FigureFrame>
  );
}

function RatioFigure({ block }: { block: TableBlock }) {
  return (
    <FigureFrame
      block={block}
      caption="汽化 ÷ 粉碎：两到三个数量级的鸿沟"
      className="figure--ratio"
    >
      <div className="ratio-scale" aria-hidden="true">
        <span className="ratio-zero">1× 粉碎基准</span>
        <span className="ratio-end">1,090×</span>
      </div>
      <div className="ratio-grid">
        {block.rows.map((row, index) => {
          const [low, high] = numberRange(row[1]);
          const start = low ? (low / 1090) * 100 : 0;
          const end = high ? (high / 1090) * 100 : start;
          return (
            <article className="ratio-card" key={index}>
              <span className="material-index">R-{String(index + 1).padStart(2, "0")}</span>
              <h4>
                <Cell value={row[0]} />
              </h4>
              <p className="ratio-number">
                <Cell value={row[1]} />
              </p>
              <div className="ratio-track bar-track" aria-hidden="true">
                <span className="bar-fill bar-fill--range" style={{ left: `${start}%`, ["--w" as string]: `${Math.max(2, end - start)}%` }} />
              </div>
              <span className="metric-key ratio-key">{block.header[1]}</span>
            </article>
          );
        })}
      </div>
    </FigureFrame>
  );
}

function LedgerFigure({ block }: { block: TableBlock }) {
  const logs = block.rows.map((row) => scientificLog(row[1]) ?? 43);
  const max = Math.max(...logs, 44.6);
  const min = Math.min(...logs, 43);
  return (
    <FigureFrame
      block={block}
      caption="Ia 型超新星的能量收支"
      className="figure--ledger"
    >
      <div className="ledger-list">
        {block.rows.map((row, index) => {
          const ratio = (logs[index] - min) / Math.max(max - min, 1);
          return (
            <article className="ledger-row" key={index}>
              <div className="ledger-label">
                <span className="metric-key">{block.header[0]}</span>
                <h4>
                  <Cell value={row[0]} />
                </h4>
              </div>
              <div className="ledger-value">
                <span className="metric-key">{block.header[1]}</span>
                <strong>
                  <Cell value={row[1]} />
                </strong>
              </div>
              <div className="ledger-track bar-track" aria-hidden="true">
                <span className="bar-fill" style={{ ["--w" as string]: `${14 + ratio * 86}%` }} />
              </div>
            </article>
          );
        })}
      </div>
      <p className="figure-footnote">
        <span aria-hidden="true">↳</span> 条形长度为对数比例示意；数值以原表为准。
      </p>
    </FigureFrame>
  );
}

function CelestialFigure({ block }: { block: TableBlock }) {
  const logs = block.rows.map((row) => scientificLog(row[1]) ?? 30);
  const min = 30;
  const max = 42;
  return (
    <FigureFrame
      block={block}
      caption="常规天体的引力束缚能（对数刻度）"
      className="figure--celestial"
    >
      <div className="axis-row" aria-hidden="true">
        <span>10³⁰ J</span>
        <span>10³⁶ J</span>
        <span>10⁴² J</span>
      </div>
      <div className="celestial-list">
        {block.rows.map((row, index) => {
          const position = Math.min(100, Math.max(0, ((logs[index] - min) / (max - min)) * 100));
          return (
            <article className="celestial-row" key={index}>
              <div className="celestial-id">
                <span className="celestial-index">C-{String(index + 1).padStart(2, "0")}</span>
                <h4>
                  <Cell value={row[0]} />
                </h4>
              </div>
              <p className="celestial-value">
                <span className="metric-key">{block.header[1]}</span>
                <strong>
                  <Cell value={row[1]} />
                </strong>
              </p>
              <div className="celestial-track" aria-hidden="true">
                <span className="celestial-axis" />
                <i style={{ left: `${position}%` }} />
              </div>
            </article>
          );
        })}
      </div>
    </FigureFrame>
  );
}

function LadderFigure({ block }: { block: TableBlock }) {
  const multipliers = block.rows.map((row) => firstNumber(row[2]) ?? 1);
  const max = 130000;
  return (
    <FigureFrame
      block={block}
      caption="从恒星到中子星：束缚能阶梯"
      className="figure--ladder"
    >
      <div className="ladder-grid">
        {block.rows.map((row, index) => {
          const position = Math.max(4, Math.log10(multipliers[index] + 1) / Math.log10(max) * 100);
          return (
            <article className="ladder-step" key={index}>
              <div className="ladder-index">
                <span>0{index + 1}</span>
                <i aria-hidden="true" />
              </div>
              <div className="ladder-body">
                <span className="metric-key">{block.header[0]}</span>
                <h4>
                  <Cell value={row[0]} />
                </h4>
                <p className="ladder-energy">
                  <span className="metric-key">{block.header[1]}</span>
                  <Cell value={row[1]} />
                </p>
              </div>
              <div className="ladder-multiplier">
                <span className="metric-key">{block.header[2]}</span>
                <strong>
                  <Cell value={row[2]} />
                </strong>
              </div>
              <div className="ladder-track bar-track" aria-hidden="true">
                <span className="bar-fill" style={{ ["--w" as string]: `${position}%` }} />
              </div>
            </article>
          );
        })}
      </div>
      <p className="figure-footnote">
        <span aria-hidden="true">↳</span> 条形按相对太阳倍数的对数关系排布；数值以原表为准。
      </p>
    </FigureFrame>
  );
}

function CloudShape({ index }: { index: number }) {
  return (
    <svg viewBox="0 0 120 54" className="cloud-glyph" aria-hidden="true">
      <path d="M18 42C9 42 4 36 6 29c2-7 10-8 15-5 1-9 10-14 20-12 6-9 22-8 26 3 11-2 20 4 20 13 4 6-1 14-11 14H18Z" />
      <path d="M30 46h43M50 51h64" className="cloud-rain" opacity={index > 1 ? 0.55 : 0.18} />
      <path d="M74 46h30" className="cloud-rain" opacity={index === 3 ? 0.55 : 0} />
    </svg>
  );
}

function CloudFigure({ block }: { block: TableBlock }) {
  return (
    <FigureFrame block={block} caption="不同云型的厚度与液态含水量" className="figure--clouds">
      <div className="cloud-grid">
        {block.rows.map((row, index) => (
          <article className="cloud-card" key={index}>
            <div className="cloud-card-art" aria-hidden="true">
              <CloudShape index={index} />
              <span>C-{String(index + 1).padStart(2, "0")}</span>
            </div>
            <h4>
              <Cell value={row[0]} />
            </h4>
            <dl className="cloud-metrics">
              <div>
                <dt>{block.header[1]}</dt>
                <dd className={row[1] === "—" ? "is-empty" : ""}>
                  <Cell value={row[1]} />
                </dd>
              </div>
              <div>
                <dt>{block.header[2]}</dt>
                <dd className={row[2] === "—" ? "is-empty" : ""}>
                  <Cell value={row[2]} />
                </dd>
              </div>
            </dl>
          </article>
        ))}
      </div>
    </FigureFrame>
  );
}

function GenericFigure({ block }: { block: TableBlock }) {
  return (
    <FigureFrame block={block} caption="数据表" className="figure--generic">
      <div className="generic-rows">
        {block.rows.map((row, index) => (
          <article className="generic-card" key={index}>
            {row.map((cell, cellIndex) => (
              <div className="generic-cell" key={cellIndex}>
                <span className="metric-key">{block.header[cellIndex]}</span>
                <span>
                  <Cell value={cell} />
                </span>
              </div>
            ))}
          </article>
        ))}
      </div>
    </FigureFrame>
  );
}

export function DataFigure({ block }: { block: TableBlock }) {
  const signature = block.header.join("|");
  if (signature === "量|单位|回答什么问题|本文件对应章节") return <DimensionFigure block={block} />;
  if (signature === "描写|取值|依据") return <StageFigure block={block} />;
  if (signature === "材质|TNT 当量|能量密度") return <CrushFigure block={block} />;
  if (signature === "来源类型|声称的穿透深度|材质") return <PenetrationFigure block={block} />;
  if (signature === "材质|抗压强度|抗拉强度|断裂韧性 K_IC|备注") return <StrengthFigure block={block} />;
  if (signature === "材质|熔化潜热|汽化潜热|推算依据") return <LatentFigure block={block} />;
  if (signature === "材质|汽化总能量|说明") return <VaporTotalFigure block={block} />;
  if (signature === "材质|汽化总能量 ÷ 粉碎能量") return <RatioFigure block={block} />;
  if (signature === "量|数值") return <LedgerFigure block={block} />;
  if (signature === "天体|束缚能") return <CelestialFigure block={block} />;
  if (signature === "天体|束缚能|相对太阳倍数") return <LadderFigure block={block} />;
  if (signature === "云型|典型厚度|液态含水量") return <CloudFigure block={block} />;
  return <GenericFigure block={block} />;
}
