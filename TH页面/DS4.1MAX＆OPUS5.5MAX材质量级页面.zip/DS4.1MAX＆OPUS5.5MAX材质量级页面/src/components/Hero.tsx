import type { Section } from "../lib/parse";
import { InlineText } from "./Inline";
import { OrbitPlate } from "./OrbitPlate";
import { HeroCanvas } from "./HeroCanvas";
import { IconArrowDown, IconArrowRight, IconSource } from "./Icons";

type HeroProps = {
  titleSection: Section;
  sections: Section[];
  rawLineCount: number;
  tableCount: number;
  onOpenSource: () => void;
  onStartReading: () => void;
};

export function Hero({
  titleSection,
  sections,
  rawLineCount,
  tableCount,
  onOpenSource,
  onStartReading,
}: HeroProps) {
  const title = titleSection.title;
  const editionIndex = title.indexOf("（");
  const baseTitle = editionIndex >= 0 ? title.slice(0, editionIndex) : title;
  const edition = editionIndex >= 0 ? title.slice(editionIndex) : "";
  const titleLines = ["材质与破坏", "能量数据库"];
  const titleExtra = baseTitle.replace(titleLines.join(""), "");
  const intro = titleSection.blocks.find((block) => block.type === "quote");
  const partCount = sections.filter(
    (section) => section.index > 0 && /^第.+部分/.test(section.title),
  ).length;
  const navSections = sections.filter((section) => section.index > 0);

  const partSection = (needle: string) =>
    sections.find((section) => section.title.startsWith(needle))?.id ?? "";
  const anchors = {
    strength: partSection("第二部分"),
    crush: partSection("第一部分"),
    phase: partSection("第三部分"),
    gravity: partSection("第四部分"),
    flux: partSection("第五部分"),
  };

  return (
    <section className="hero reveal is-visible" aria-labelledby="hero-title">
      <div className="hero-backdrop" aria-hidden="true">
        <div className="hero-gridlines" />
        <div className="hero-orbit hero-orbit--one" />
        <div className="hero-orbit hero-orbit--two" />
        <div className="hero-ember" />
        <HeroCanvas />
        <div className="hero-grain" />
      </div>

      <div className="hero-masthead">
        <span className="masthead-mark" aria-hidden="true">
          <span />
          <span />
        </span>
        <span>HENGTIAN ARCHIVE</span>
        <span className="masthead-slash">/</span>
        <span>DATA CODEX 02</span>
        <span className="masthead-rule" />
        <span className="masthead-edition">第二版 · V2.0</span>
      </div>

      <div className="hero-grid">
        <div className="hero-copy">
          <div className="hero-kicker">
            <span className="status-dot" aria-hidden="true" />
            材质研究档案
            <span className="hero-kicker-rule" aria-hidden="true" />
            完整收录
          </div>

          <h1 id="hero-title" className="hero-title" aria-label={`${baseTitle}${edition}`}>
            <span className="hero-title-line">
              <span className="hero-title-text">{titleLines[0]}</span>
            </span>
            <span className="hero-title-line">
              <span className="hero-title-text">{titleLines[1]}</span>
              {titleExtra ? <span className="hero-title-extra">{titleExtra}</span> : null}
              {edition ? <em>{edition}</em> : null}
            </span>
          </h1>

          <div className="hero-deck">
            {intro && intro.type === "quote" ? (
              intro.paragraphs.map((paragraph, index) => (
                <p key={index}>
                  <InlineText parts={paragraph} />
                </p>
              ))
            ) : (
              <p>{titleSection.title}</p>
            )}
          </div>

          <div className="hero-guide" aria-label="阅读指南">
            <span className="hero-guide-step">
              <i>1</i>先看第零部分定量纲
            </span>
            <span className="hero-guide-arrow" aria-hidden="true">
              →
            </span>
            <span className="hero-guide-step">
              <i>2</i>按需查表，不必通读
            </span>
            <span className="hero-guide-arrow" aria-hidden="true">
              →
            </span>
            <span className="hero-guide-step">
              <i>3</i>数值回查来源
            </span>
          </div>

          <div className="hero-actions">
            <button type="button" className="button button--primary" onClick={onStartReading}>
              进入档案
              <IconArrowDown size={16} />
            </button>
            <button type="button" className="button button--quiet" onClick={onOpenSource}>
              <IconSource size={16} />
              查看完整原文
            </button>
          </div>

          <div className="hero-facts" aria-label="档案数据">
            <div className="hero-fact">
              <span className="hero-fact-value">{partCount}</span>
              <span className="hero-fact-label">个部分</span>
            </div>
            <div className="hero-fact">
              <span className="hero-fact-value">{String(tableCount).padStart(2, "0")}</span>
              <span className="hero-fact-label">组数据表</span>
            </div>
            <div className="hero-fact">
              <span className="hero-fact-value">{rawLineCount}</span>
              <span className="hero-fact-label">行原文</span>
            </div>
            <div className="hero-fact hero-fact--wide">
              <span className="hero-fact-kicker">READING NOTE</span>
              <span className="hero-fact-label">按需查表，不必通读</span>
            </div>
          </div>

          <nav className="hero-pills" aria-label="章节速览">
            <span className="hero-pills-label">速览</span>
            <div className="hero-pills-row">
              {navSections.map((section) => (
                <a key={section.id} className="hero-pill" href={`#${section.id}`}>
                  <b>{section.kicker}</b>
                  <span>{section.label}</span>
                </a>
              ))}
            </div>
          </nav>
        </div>

        <div className="hero-art">
          <OrbitPlate anchors={anchors} />
          <a href={`#${sections[1]?.id ?? "sec-1"}`} className="hero-art-caption">
            <span className="hero-art-caption-index">00</span>
            <span>
              先确认量纲
              <small>METHOD BEFORE NUMBERS</small>
            </span>
            <IconArrowRight size={15} />
          </a>
        </div>
      </div>

      <div className="hero-footnote">
        <span className="hero-footnote-mark" aria-hidden="true">
          ◆
        </span>
        <span>数值均标注来源，可交叉核实</span>
        <span className="hero-footnote-rule" />
        <span>全文逐字收录 · 未删改原文</span>
      </div>
    </section>
  );
}
