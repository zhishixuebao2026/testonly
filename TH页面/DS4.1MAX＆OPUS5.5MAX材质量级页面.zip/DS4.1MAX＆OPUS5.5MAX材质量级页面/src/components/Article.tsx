import { useContext, type MouseEvent, type ReactNode } from "react";
import type { Block, HeadingBlock, ListBlock, ParagraphBlock, Section } from "../lib/parse";
import { InlineText } from "./Inline";
import { DataFigure } from "./Tables";
import { Emblem } from "./Emblems";
import { BindingTool, BlastTool, CloudTool, FluxTool, SightTool, TearTool } from "./Tools";
import { IconArrowRight, IconLink, IconSource } from "./Icons";
import { ToastContext } from "../lib/context";
import { copyText } from "../lib/clipboard";

/** Interactive tools are appended at the end of the listed subsections. */
const TOOLS: Record<string, () => ReactNode> = {
  "0.3": () => <SightTool />,
  "4.4": () => <BindingTool />,
  "4.5": () => <TearTool />,
  "5.2": () => <FluxTool />,
  "8.1": () => <BlastTool />,
  "8.2": () => <CloudTool />,
};

function isAllStrong(text: string) {
  return /^\*\*.+\*\*$/.test(text.trim());
}

type RuleTone = "warn" | "rule" | "tip" | "verdict" | null;

function detectRuleTone(text: string): RuleTone {
  const head = text.trim().slice(0, 24);
  if (/^\*\*(常见错误|边界|引用提醒)/.test(head)) return "warn";
  if (/^\*\*(判定规则|使用方法|适用边界|读法|建议|用法)/.test(head)) return "rule";
  if (/^\*\*(结论|校准案例|与衡天)/.test(head)) return "verdict";
  if (/^\*\*(来源与可靠性|数据来源说明|归属|关于金刚石|下界参考|升温部分)/.test(head)) return "tip";
  return null;
}

function ruleLabel(tone: NonNullable<RuleTone>): string {
  if (tone === "warn") return "注意";
  if (tone === "rule") return "判定";
  if (tone === "verdict") return "结论";
  return "说明";
}

function CraterDiagram() {
  return (
    <figure className="crater-diagram reveal" aria-label="撞击成坑过程示意">
      <div className="figure-rail">
        <span className="figure-dot" aria-hidden="true" />
        <span className="figure-code">FIG. 6.1</span>
        <span className="figure-rule" aria-hidden="true" />
        <span className="figure-kind">SCHEMATIC · 示意</span>
      </div>
      <figcaption className="figure-caption">撞击 → 耦合 → 成坑：能量并不是简单乘以体积</figcaption>
      <svg viewBox="0 0 560 190" role="img" aria-hidden="true" className="crater-svg">
        <defs>
          <linearGradient id="ground-g" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" className="crater-ground-top" />
            <stop offset="100%" className="crater-ground-bottom" />
          </linearGradient>
          <linearGradient id="shock-g" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" className="crater-shock-a" />
            <stop offset="100%" className="crater-shock-b" />
          </linearGradient>
        </defs>
        <rect x="0" y="96" width="560" height="94" fill="url(#ground-g)" rx="10" />
        <path d="M150 96 Q280 168 410 96 Q380 108 350 108 Q280 132 210 108 Q180 108 150 96Z" className="crater-bowl" />
        <path d="M150 96 Q130 88 118 78 M410 96 Q430 88 442 78" className="crater-rim" />
        <g className="crater-impactor">
          <circle cx="280" cy="38" r="13" />
          <path d="M280 12v-6M258 20l-5-5M302 20l5-5M252 38h-8M308 38h8" />
          <path d="M270 50 L262 92 M290 50 L298 92" className="crater-trail" />
        </g>
        <g className="crater-shock">
          <path d="M232 92 Q280 60 328 92" fill="none" />
          <path d="M214 92 Q280 44 346 92" fill="none" opacity="0.55" />
          <path d="M196 92 Q280 28 364 92" fill="none" opacity="0.3" />
        </g>
        <g className="crater-labels">
          <text x="280" y="176" textAnchor="middle">
            重力 / 强度控制机制转换 · π 标度体系
          </text>
        </g>
      </svg>
      <p className="figure-origin">示意图 · 精确判定须查行星科学撞击标度律原始文献</p>
    </figure>
  );
}

function ThresholdPlate() {
  const stops = [
    { value: 240, label: "当前吸收通量", tone: "earth" },
    { value: 280, label: "KI 极限", tone: "ki" },
    { value: 282, label: "SN 极限 · Goldblatt 等（2013）", tone: "sn" },
  ];
  const scaleMax = 400;
  return (
    <aside className="threshold-plate reveal" aria-label="持续热注入阈值示意">
      <div className="threshold-head">
        <div>
          <span className="figure-code">FIG. 5.1</span>
          <h3>吸收通量的临界带</h3>
        </div>
        <span className="metric-key">W/m² · 持续通量</span>
      </div>
      <div className="threshold-chart" aria-hidden="true">
        <div className="threshold-axis">
          {[0, 100, 200, 300, 400].map((tick) => (
            <span key={tick} style={{ left: `${(tick / scaleMax) * 100}%` }}>
              {tick}
            </span>
          ))}
        </div>
        <div className="threshold-zone" />
        <div
          className="threshold-band"
          style={{ left: `${(310 / scaleMax) * 100}%`, width: `${((385 - 310) / scaleMax) * 100}%` }}
        >
          <span>早期估计 310–385</span>
        </div>
        {stops.map((stop) => (
          <i
            key={stop.tone}
            className={`threshold-marker threshold-marker--${stop.tone}`}
            style={{ left: `${(stop.value / scaleMax) * 100}%` }}
          />
        ))}
        <span className="threshold-earth-glow" style={{ width: `${(240 / scaleMax) * 100}%` }} />
      </div>
      <div className="threshold-legend">
        {stops.map((stop) => (
          <div className={`threshold-legend-item threshold-legend-item--${stop.tone}`} key={stop.tone}>
            <span className="threshold-number">{stop.value}</span>
            <span>{stop.label}</span>
          </div>
        ))}
        <div className="threshold-legend-item threshold-legend-item--range">
          <span className="threshold-number">310–385</span>
          <span>文献间的早期估计区间</span>
        </div>
      </div>
      <p className="figure-footnote">
        <span aria-hidden="true">↳</span> 图示仅整理 5.1 所列数值；这里读到的是持续功率，不能与焦耳数值直接比较。
      </p>
    </aside>
  );
}

function ChapterHeading({ section, indexLabel }: { section: Section; indexLabel: string }) {
  const prefixMatch = section.title.match(/^(第.+?部分　)(.*)$/);
  const prefix = prefixMatch?.[1] ?? "";
  const rest = prefixMatch?.[2] ?? section.title;
  const figureCount = section.blocks.filter((block) => block.type === "table").length;
  const paragraphCount = section.blocks.filter(
    (block) => block.type === "p" || block.type === "ul" || block.type === "ol",
  ).length;
  const subCount = section.blocks.filter((block) => block.type === "h2").length;

  return (
    <header className="chapter-header reveal">
      <div className="chapter-glyph" aria-hidden="true">
        {section.glyph}
      </div>
      <Emblem kicker={section.kicker} />
      <div className="chapter-eyebrow">
        <span className="chapter-kicker">{section.kicker}</span>
        <span className="chapter-eyebrow-rule" aria-hidden="true" />
        <span>{section.english}</span>
        <span className="chapter-count" aria-hidden="true">
          {indexLabel}
        </span>
      </div>
      <h2 id={section.id} className="chapter-title">
        {prefix ? <span className="chapter-prefix">{prefix}</span> : null}
        <span>{rest}</span>
      </h2>
      <div className="chapter-footer">
        <span className="chapter-chip-mini">
          <i aria-hidden="true" />
          {section.label}
        </span>
        {subCount > 0 ? <span className="chapter-meta">{subCount} 个小节</span> : null}
        <span className="chapter-meta">{paragraphCount} 段正文</span>
        {figureCount > 0 ? (
          <span className="chapter-meta chapter-meta--accent">{String(figureCount).padStart(2, "0")} 组数据图版</span>
        ) : null}
        <span className="chapter-footer-line" aria-hidden="true" />
      </div>
    </header>
  );
}

function Subhead({ block }: { block: HeadingBlock }) {
  const toast = useContext(ToastContext);
  const match = block.text.match(/^((?:\d+\.\d+)|(?:束缚能阶梯))\s+(.*)$/);
  const label = match?.[1] ?? "";
  const title = match?.[2] ?? block.text;
  const Tag = (block.type === "h2" ? "h3" : "h4") as "h3" | "h4";

  const onCopy = async (event: MouseEvent<HTMLAnchorElement>) => {
    event.preventDefault();
    const url = `${window.location.href.split("#")[0]}#${block.id}`;
    try {
      window.history.replaceState(null, "", `#${block.id}`);
    } catch {
      // file:// contexts may refuse; the copy still works.
    }
    const ok = await copyText(url);
    toast(ok ? `已复制「${block.text}」的链接` : "复制失败，可直接复制地址栏");
  };

  return (
    <Tag id={block.id} className={`subhead subhead--${block.type} reveal`}>
      {label ? <span className="subhead-index">{label}</span> : <span className="subhead-mark" aria-hidden="true" />}
      <span className="subhead-text">{title}</span>
      <a
        className="subhead-anchor"
        href={`#${block.id}`}
        onClick={onCopy}
        aria-label={`复制「${block.text}」的链接`}
        title="复制本节链接"
      >
        <IconLink size={15} />
      </a>
    </Tag>
  );
}

function Paragraph({ block, lead }: { block: ParagraphBlock; lead: boolean }) {
  const statement = isAllStrong(block.text);
  const tone = detectRuleTone(block.text);
  if (tone) {
    return (
      <aside id={block.id} className={`rule-card rule-card--${tone} reveal`}>
        <span className="rule-card-tag" aria-hidden="true">
          {ruleLabel(tone)}
        </span>
        <p>
          <InlineText parts={block.inline} mode="prose" />
        </p>
      </aside>
    );
  }
  return (
    <p
      id={block.id}
      className={[
        "prose-paragraph reveal",
        lead ? "prose-paragraph--lead" : "",
        statement ? "prose-paragraph--statement" : "",
      ]
        .filter(Boolean)
        .join(" ")}
    >
      <InlineText parts={block.inline} mode="prose" />
    </p>
  );
}

function ListBlockView({ block, isSources }: { block: ListBlock; isSources: boolean }) {
  return (
    <ol
      id={block.id}
      className={`prose-list reveal ${block.type === "ol" ? "prose-list--ordered" : "prose-list--unordered"}${
        isSources ? " prose-list--sources" : ""
      }`}
    >
      {block.items.map((item, index) => (
        <li key={index}>
          {block.type === "ul" ? <span className="list-marker" aria-hidden="true" /> : null}
          <span className="list-content">
            <InlineText parts={item} mode={isSources ? "plain" : "prose"} />
          </span>
        </li>
      ))}
    </ol>
  );
}

function BlockView({ block, lead, section }: { block: Block; lead: boolean; section: Section }) {
  if (block.type === "h1" || block.type === "hr") return null;
  if (block.type === "h2" || block.type === "h3") return <Subhead block={block} />;
  if (block.type === "p") return <Paragraph block={block} lead={lead} />;
  if (block.type === "quote") {
    return (
      <blockquote id={block.id} className="prose-quote reveal">
        <span className="quote-mark" aria-hidden="true">
          ※
        </span>
        <div>
          {block.paragraphs.map((paragraph, index) => (
            <p key={index}>
              <InlineText parts={paragraph} mode="prose" />
            </p>
          ))}
        </div>
      </blockquote>
    );
  }
  if (block.type === "ul" || block.type === "ol") {
    return <ListBlockView block={block} isSources={section.english === "SOURCES"} />;
  }
  if (block.type === "table") return <DataFigure block={block} />;
  return null;
}

function ChapterPager({ prev, next }: { prev?: Section; next?: Section }) {
  return (
    <nav className="chapter-pager reveal" aria-label="章节翻页">
      {prev ? (
        <a className="pager-link pager-link--prev" href={`#${prev.id}`}>
          <small>上一章</small>
          <span>
            <b>{prev.kicker}</b>
            {prev.label}
          </span>
        </a>
      ) : (
        <span className="pager-spacer" aria-hidden="true" />
      )}
      {next ? (
        <a className="pager-link pager-link--next" href={`#${next.id}`}>
          <small>下一章</small>
          <span>
            <b>{next.kicker}</b>
            {next.label}
          </span>
          <IconArrowRight size={16} />
        </a>
      ) : (
        <a className="pager-link pager-link--next" href="#top">
          <small>已读完全文</small>
          <span>回到卷首</span>
          <IconArrowRight size={16} />
        </a>
      )}
    </nav>
  );
}

export function Article({ sections, onOpenSource }: { sections: Section[]; onOpenSource: () => void }) {
  const content = sections.filter((section) => section.index > 0);
  return (
    <article className="document" aria-label="材质与破坏能量数据库全文">
      {content.map((section, sectionIndex) => {
        const nodes: ReactNode[] = [];
        let currentSub = "";
        let firstParagraphSeen = false;
        const flushTool = () => {
          const tool = TOOLS[currentSub];
          if (tool) nodes.push(<div key={`tool-${currentSub}`}>{tool()}</div>);
        };
        for (const block of section.blocks) {
          if (block.type === "h2") {
            flushTool();
            const match = block.text.match(/^(\d+\.\d+)\s/);
            currentSub = match ? match[1] : "";
          }
          const lead = block.type === "p" && !firstParagraphSeen && !detectRuleTone(block.text);
          if (lead) firstParagraphSeen = true;
          nodes.push(<BlockView block={block} lead={lead} section={section} key={block.id} />);
        }
        flushTool();

        const indexLabel = `${String(sectionIndex + 1).padStart(2, "0")} / ${String(content.length).padStart(2, "0")}`;
        return (
          <section
            className={`chapter chapter--${section.accent} chapter--${section.kicker.toLowerCase()}`}
            key={section.id}
            id={`${section.id}-chapter`}
            data-section={section.kicker}
          >
            <ChapterHeading section={section} indexLabel={indexLabel} />
            <div className="chapter-body">
              {section.title.startsWith("第五部分") ? <ThresholdPlate /> : null}
              {section.kicker === "06" ? <CraterDiagram /> : null}
              {nodes}
              {section.kicker === "TODO" ? (
                <div className="pending-stamp reveal" aria-hidden="true">
                  <span>OPEN FILE</span>
                  <i />
                  <span>NEXT EDITION</span>
                </div>
              ) : null}
              {section.kicker === "SRC" ? (
                <button type="button" className="source-inline-cta reveal" onClick={onOpenSource}>
                  <IconSource size={17} />
                  <span>
                    对照完整原文
                    <small>逐字未改 · 可复制、可下载</small>
                  </span>
                  <IconArrowRight size={16} />
                </button>
              ) : null}
            </div>
            <ChapterPager prev={content[sectionIndex - 1]} next={content[sectionIndex + 1]} />
          </section>
        );
      })}
    </article>
  );
}
