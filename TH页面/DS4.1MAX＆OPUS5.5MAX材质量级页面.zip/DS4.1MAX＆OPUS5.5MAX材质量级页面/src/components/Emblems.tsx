/**
 * Line-drawn chapter emblems. Every stroke uses pathLength=1 so the CSS can draw it
 * in when the chapter header scrolls into view.
 */
type LineProps = { d: string; accent?: boolean; dash?: boolean; transform?: string };

function Line({ d, accent, dash, transform }: LineProps) {
  return (
    <path
      d={d}
      transform={transform}
      pathLength={1}
      className={`em-line${accent ? " em-line--accent" : ""}${dash ? " em-line--dash" : ""}`}
    />
  );
}

function Dot({ cx, cy, r = 3.6, muted }: { cx: number; cy: number; r?: number; muted?: boolean }) {
  return <circle cx={cx} cy={cy} r={r} className={`em-dot${muted ? " em-dot--muted" : ""}`} />;
}

const ring = (cx: number, cy: number, r: number) =>
  `M ${cx - r} ${cy} a ${r} ${r} 0 1 0 ${r * 2} 0 a ${r} ${r} 0 1 0 ${-r * 2} 0`;

const ellipse = (cx: number, cy: number, rx: number, ry: number) =>
  `M ${cx - rx} ${cy} a ${rx} ${ry} 0 1 0 ${rx * 2} 0 a ${rx} ${ry} 0 1 0 ${-rx * 2} 0`;

function Art({ kicker }: { kicker: string }) {
  switch (kicker) {
    case "REV":
      return (
        <>
          <Line d="M34 16 H76 L90 30 V104 H34 Z" />
          <Line d="M76 16 V30 H90" />
          <Line d="M44 46 H80 M44 58 H80 M44 70 H64" />
          <Line accent d="M60 86 L69 95 L88 74" />
          <Dot cx={98} cy={20} />
        </>
      );
    case "00":
      return (
        <>
          <Line d="M60 18 L100 47 L85 95 L35 95 L20 47 Z" />
          <Line dash d="M60 60 L60 18 M60 60 L100 47 M60 60 L85 95 M60 60 L35 95 M60 60 L20 47" />
          <Line accent d={ring(60, 60, 9)} />
          <Dot cx={60} cy={18} />
          <Dot cx={100} cy={47} muted />
          <Dot cx={85} cy={95} muted />
          <Dot cx={35} cy={95} muted />
          <Dot cx={20} cy={47} muted />
        </>
      );
    case "01":
      return (
        <>
          <Line d="M22 30 H86 V94 H22 Z" />
          <Line accent d="M54 30 L48 52 L60 64 L52 94" />
          <Line d="M22 58 L36 54 L48 52 M60 64 L86 72 M36 54 L40 76 L52 94" />
          <Line accent d="M95 21 L105 18 L107 27 L98 29 Z" />
          <Line d="M98 42 L106 41 L103 49 Z M90 61 L96 59 L97 65 Z" />
        </>
      );
    case "02":
      return (
        <>
          <Line d="M60 14 L94 26 V58 C94 80 79 95 60 104 C41 95 26 80 26 58 V26 Z" />
          <Line accent d="M60 43 L73 50.5 L73 65.5 L60 73 L47 65.5 L47 50.5 Z" />
          <Line dash d="M60 26 V43 M73 65.5 L86 73 M47 65.5 L34 73" />
          <Dot cx={60} cy={58} r={3} />
        </>
      );
    case "03":
      return (
        <>
          <Line d="M50 24 C50 24 28 52 28 69 A22 22 0 0 0 72 69 C72 52 50 24 50 24 Z" />
          <Line accent d="M40 71 A10 10 0 0 0 50 81" />
          <Line d="M86 60 C80 54 92 48 86 42 C80 36 92 30 86 24" />
          <Line dash d="M99 66 C93 60 105 54 99 48 C93 42 105 36 99 30" />
          <Line d="M22 104 H98" />
        </>
      );
    case "04":
      return (
        <>
          <Line d={ring(54, 62, 15)} />
          <Line d={ellipse(54, 62, 44, 15)} transform="rotate(-18 54 62)" />
          <Line dash d="M68 48 L96 22 M70 66 L108 70" />
          <Dot cx={98} cy={20} />
          <Dot cx={110} cy={70} muted />
          <Line accent d="M44 56 A12 12 0 0 1 58 50" />
        </>
      );
    case "05":
      return (
        <>
          <Line accent d={ring(60, 34, 12)} />
          <Line d="M60 12 V17 M39 21 L42 24 M81 21 L78 24" />
          <Line d="M47 54 L39 74 M60 52 V78 M73 54 L81 74" />
          <Line d="M12 92 C24 86 36 86 48 92 S72 98 84 92 S100 86 108 92" />
          <Line dash d="M20 104 H100" />
        </>
      );
    case "06":
      return (
        <>
          <Line d="M10 74 H34 C44 74 46 98 60 98 C74 98 76 74 86 74 H110" />
          <Line d="M34 74 C30 68 26 66 21 68 M86 74 C90 68 94 66 99 68" />
          <Line accent d={ring(82, 28, 7)} />
          <Line dash d="M76 35 L59 55 M44 70 L36 60 M76 70 L84 60" />
        </>
      );
    case "07":
      return (
        <>
          <Line d="M60 52 L60 22 M67 56 L93 41 M67 64 L93 79 M60 68 L60 98 M53 64 L27 79 M53 56 L27 41" />
          <Line dash d="M60 22 L93 41 L93 79 L60 98 L27 79 L27 41 Z" />
          <Line accent d={ring(60, 60, 8)} />
          <Dot cx={60} cy={22} />
          <Dot cx={93} cy={41} muted />
          <Dot cx={93} cy={79} muted />
          <Dot cx={60} cy={98} muted />
          <Dot cx={27} cy={79} muted />
          <Dot cx={27} cy={41} muted />
        </>
      );
    case "08":
      return (
        <>
          <Line accent d={ring(60, 60, 10)} />
          <Line d={ring(60, 60, 24)} />
          <Line dash d={ring(60, 60, 39)} />
          <Line d="M60 12 V22 M60 98 V108 M12 60 H22 M98 60 H108 M26 26 L33 33 M87 87 L94 94 M94 26 L87 33 M26 94 L33 87" />
        </>
      );
    case "SRC":
      return (
        <>
          <Line d="M24 84 H96 V98 H24 Z M28 68 H92 V82 H28 Z M32 52 H88 V66 H32 Z" />
          <Line accent d="M72 52 V32 L78 37 L84 32 V52" />
          <Line dash d="M34 91 H62 M38 75 H64 M42 59 H60" />
        </>
      );
    case "TODO":
      return (
        <>
          <Line d="M24 26 H38 V40 H24 Z M24 53 H38 V67 H24 Z M24 80 H38 V94 H24 Z" />
          <Line d="M48 33 H92 M48 60 H84 M48 87 H72" />
          <Line accent d="M84 100 L102 82 L109 89 L91 107 Z" />
          <Line dash d="M48 101 H74" />
        </>
      );
    default:
      return <Line d={ring(60, 60, 30)} />;
  }
}

export function Emblem({ kicker }: { kicker: string }) {
  return (
    <span className="chapter-emblem" aria-hidden="true">
      <svg viewBox="0 0 120 120" focusable="false">
        <Art kicker={kicker} />
      </svg>
    </span>
  );
}
