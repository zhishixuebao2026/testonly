const CENTER = { x: 260, y: 258 };

type OrbitNode = {
  key: string;
  index: string;
  label: string;
  unit: string;
  anchor: string;
  angle: number;
};

const nodes: Omit<OrbitNode, "anchor">[] = [
  { key: "strength", index: "01", label: "强度", unit: "MPa", angle: -90 },
  { key: "crush", index: "02", label: "破碎比能", unit: "J/cc", angle: -18 },
  { key: "phase", index: "03", label: "相变潜热", unit: "J/kg", angle: 54 },
  { key: "gravity", index: "04", label: "引力束缚能", unit: "J", angle: 126 },
  { key: "flux", index: "05", label: "持续通量", unit: "W/m²", angle: 198 },
];

function ticks(count: number, radius: number) {
  return Array.from({ length: count }, (_, i) => {
    const angle = (i / count) * Math.PI * 2;
    const inner = radius - (i % 5 === 0 ? 9 : 4);
    return {
      x1: CENTER.x + Math.cos(angle) * inner,
      y1: CENTER.y + Math.sin(angle) * inner,
      x2: CENTER.x + Math.cos(angle) * radius,
      y2: CENTER.y + Math.sin(angle) * radius,
      major: i % 5 === 0,
    };
  });
}

export function OrbitPlate({ anchors }: { anchors: Record<string, string> }) {
  const ringTicks = ticks(60, 202);
  return (
    <div className="orbit-plate" aria-label="五种独立物理量纲示意图">
      <div className="plate-corner plate-corner--tl" aria-hidden="true">
        FIG. 0.0
      </div>
      <div className="plate-corner plate-corner--tr" aria-hidden="true">
        五 / 量 / 纲
      </div>
      <svg
        viewBox="0 0 520 556"
        role="img"
        aria-labelledby="orbit-title orbit-desc"
        className="orbit-svg"
      >
        <title id="orbit-title">五种独立量纲</title>
        <desc id="orbit-desc">
          强度、破碎比能、相变潜热、引力束缚能与持续通量，是五个彼此独立的物理量，不可互相替代。
        </desc>
        <defs>
          <radialGradient id="core-glow" cx="50%" cy="46%" r="62%">
            <stop offset="0%" className="core-stop core-stop--bright" />
            <stop offset="58%" className="core-stop core-stop--mid" />
            <stop offset="100%" className="core-stop core-stop--fade" />
          </radialGradient>
          <linearGradient id="fracture-fill" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" className="fracture-stop fracture-stop--a" />
            <stop offset="100%" className="fracture-stop fracture-stop--b" />
          </linearGradient>
          <clipPath id="core-clip">
            <circle cx={CENTER.x} cy={CENTER.y} r="95" />
          </clipPath>
          <marker id="tiny-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto">
            <path d="M 0 0 L 10 5 L 0 10 z" className="svg-arrow" />
          </marker>
        </defs>

        <g className="orbit-aura">
          <circle cx={CENTER.x} cy={CENTER.y} r="205" className="orbit-halo" />
          <circle cx={CENTER.x} cy={CENTER.y} r="172" className="orbit-halo orbit-halo--soft" />
        </g>

        <g className="orbit-ticks" aria-hidden="true">
          {ringTicks.map((tick, index) => (
            <line
              key={index}
              x1={tick.x1}
              y1={tick.y1}
              x2={tick.x2}
              y2={tick.y2}
              className={tick.major ? "orbit-tick orbit-tick--major" : "orbit-tick"}
            />
          ))}
        </g>

        <g className="orbit-rotor" style={{ transformOrigin: `${CENTER.x}px ${CENTER.y}px` }}>
          <circle cx={CENTER.x} cy={CENTER.y} r="156" className="orbit-ring orbit-ring--dashed" />
          <circle cx={CENTER.x} cy={CENTER.y} r="114" className="orbit-ring" />
          <path
            d="M 76 258 A 184 184 0 0 1 442 258"
            className="orbit-ring orbit-ring--arc"
            markerEnd="url(#tiny-arrow)"
          />
          <circle cx={CENTER.x + 156} cy={CENTER.y} r="3.5" className="orbit-satellite" />
          <circle cx={CENTER.x} cy={CENTER.y - 114} r="2.5" className="orbit-satellite orbit-satellite--dim" />
        </g>

        <g className="fracture-fan" clipPath="url(#core-clip)" aria-hidden="true">
          <circle cx={CENTER.x} cy={CENTER.y} r="90" fill="url(#core-glow)" />
          <path
            d="M260 171 L281 216 L324 204 L303 247 L348 266 L302 281 L319 326 L271 303 L252 347 L232 303 L185 323 L207 279 L166 260 L210 244 L189 205 L231 218 Z"
            fill="url(#fracture-fill)"
            className="core-shard"
          />
          <path
            d="M260 178 L258 231 L291 243 L262 262 L277 307 L250 286 L227 326 L235 281 L202 260 L244 248 L224 214 L258 232"
            className="core-ridge"
          />
          <circle cx={CENTER.x} cy={CENTER.y} r="76" className="core-outline" />
        </g>

        <path d="M260 56v48M260 412v48M58 258h54M408 258h54" className="axis-line" />
        <circle cx="260" cy="258" r="4" className="axis-node" />
        <circle cx="260" cy="258" r="10" className="axis-node axis-node--soft" />

        <text x="260" y="92" className="plate-caption plate-caption--anchor">
          FIVE MEASURES · ONE ARCHIVE
        </text>
        <text x="260" y="450" className="plate-caption">
          五种量相互独立 · 不可替代
        </text>

        {nodes.map((node) => {
          const rad = (node.angle * Math.PI) / 180;
          const radius = 184;
          const x = CENTER.x + Math.cos(rad) * radius;
          const y = CENTER.y + Math.sin(rad) * radius;
          const anchor = anchors[node.key];
          const labelBelow = Math.sin(rad) > 0.3;
          return (
            <a
              href={anchor ? `#${anchor}` : undefined}
              key={node.key}
              className="orbit-node-link"
              aria-label={`${node.label}，查看对应章节`}
            >
              <g className="orbit-node">
                <circle cx={x} cy={y} r="38" className="orbit-node-disc" />
                <circle cx={x} cy={y} r="31" className="orbit-node-disc-inner" />
                <text x={x} y={y - 1} textAnchor="middle" className="node-label">
                  {node.label}
                </text>
                <text x={x} y={y + 15} textAnchor="middle" className="node-unit">
                  {node.index} / {node.unit}
                </text>
                <line
                  x1={CENTER.x + Math.cos(rad) * 96}
                  y1={CENTER.y + Math.sin(rad) * 96}
                  x2={x - Math.cos(rad) * 39}
                  y2={y - Math.sin(rad) * 39}
                  className="node-connector"
                />
                <circle cx={x} cy={labelBelow ? y + 29 : y - 29} r="1.8" className="node-pin" />
              </g>
            </a>
          );
        })}

        <g className="core-label">
          <text x="260" y="251" textAnchor="middle" className="core-number">
            五
          </text>
          <text x="260" y="278" textAnchor="middle" className="core-word">
            量纲 / DIMENSION
          </text>
        </g>
      </svg>
      <div className="plate-footer" aria-hidden="true">
        <span>HENGTIAN ARCHIVE</span>
        <span className="plate-footer-rule" />
        <span>UNIT DISCIPLINE</span>
      </div>
    </div>
  );
}
