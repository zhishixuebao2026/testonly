import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import rawSource from "./data/source.md?raw";
import { buildSearchIndex, parseDocument, type HeadingBlock } from "./lib/parse";
import {
  DEFAULT_SCALE,
  LEADING_VALUES,
  isValidScale,
  stepScale,
  type BodyFont,
  type Leading,
  type ThemeMode,
} from "./lib/ui";
import { useReveal } from "./lib/reveal";
import { copyText } from "./lib/clipboard";
import { ToastContext, XrefContext, type XrefMap } from "./lib/context";
import { Hero } from "./components/Hero";
import { Article } from "./components/Article";
import {
  BackToTop,
  ContinueReading,
  DisplayDialog,
  Footer,
  MobileDock,
  MobileMenu,
  Rail,
  SearchDialog,
  SourceDialog,
  Topbar,
  type SubNav,
} from "./components/Chrome";

const STORAGE = {
  theme: "heng-theme",
  scale: "heng-reader-scale",
  font: "heng-body-font",
  leading: "heng-leading",
  position: "heng-last-pos",
};

function safeRead(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function safeWrite(key: string, value: string) {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // Storage can be denied (private mode, file:// policies); the UI keeps working.
  }
}

function readTheme(): ThemeMode {
  const stored = safeRead(STORAGE.theme);
  return stored === "light" || stored === "dark" || stored === "system" ? stored : "system";
}

function resolveTheme(mode: ThemeMode): "light" | "dark" {
  if (mode === "system") {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  return mode;
}

function readScale(): number {
  const stored = Number(safeRead(STORAGE.scale));
  return safeRead(STORAGE.scale) !== null && isValidScale(stored) ? stored : DEFAULT_SCALE;
}

export default function App() {
  const documentModel = useMemo(() => parseDocument(rawSource), []);
  const contentSections = useMemo(() => documentModel.filter((section) => section.index > 0), [documentModel]);
  const searchEntries = useMemo(() => buildSearchIndex(documentModel), [documentModel]);
  const tableCount = useMemo(
    () => documentModel.reduce((total, section) => total + section.blocks.filter((block) => block.type === "table").length, 0),
    [documentModel],
  );
  const rawLineCount = useMemo(() => rawSource.replace(/\n$/, "").split("\n").length, []);

  const subsByChapter = useMemo(() => {
    const map: Record<string, SubNav[]> = {};
    for (const section of contentSections) {
      map[section.id] = section.blocks
        .filter((block): block is HeadingBlock => block.type === "h2" || block.type === "h3")
        .map((block) => {
          const match = block.text.match(/^(\d+\.\d+)\s+(.*)$/);
          return {
            id: block.id,
            num: match ? match[1] : "",
            title: match ? match[2] : block.text,
            level: block.type === "h3" ? 3 : 2,
          };
        });
    }
    return map;
  }, [contentSections]);

  const xrefMap = useMemo<XrefMap>(() => {
    const subs: Record<string, string> = {};
    const chapters: Record<string, string> = {};
    for (const section of contentSections) {
      const chapter = section.title.match(/^第([零一二三四五六七八])部分/);
      if (chapter) chapters[chapter[1]] = section.id;
      for (const block of section.blocks) {
        if (block.type !== "h2") continue;
        const match = block.text.match(/^(\d+\.\d+)\s/);
        if (match) subs[match[1]] = block.id;
      }
    }
    return { subs, chapters };
  }, [contentSections]);

  const [themeMode, setThemeMode] = useState<ThemeMode>(readTheme);
  const [resolvedTheme, setResolvedTheme] = useState<"light" | "dark">(() => resolveTheme(readTheme()));
  const [scale, setScale] = useState<number>(readScale);
  const [bodyFont, setBodyFont] = useState<BodyFont>(() => (safeRead(STORAGE.font) === "serif" ? "serif" : "sans"));
  const [leading, setLeading] = useState<Leading>(() => {
    const stored = safeRead(STORAGE.leading);
    return stored === "compact" || stored === "relaxed" ? stored : "normal";
  });
  const [progress, setProgress] = useState(0);
  const [activeId, setActiveId] = useState("intro");
  const [activeSubId, setActiveSubId] = useState("");
  const [dockHidden, setDockHidden] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [sourceOpen, setSourceOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState("");
  const [resume, setResume] = useState<{ y: number; label: string } | null>(() => {
    if (window.location.hash) return null;
    try {
      const raw = safeRead(STORAGE.position);
      if (!raw) return null;
      const data = JSON.parse(raw) as { y?: number; id?: string; ratio?: number };
      if (typeof data.y !== "number" || data.y < 700 || (data.ratio ?? 0) < 0.04) return null;
      const sections = parseDocument(rawSource).filter((section) => section.index > 0);
      const section = sections.find((item) => item.id === data.id);
      return {
        y: data.y,
        label: section ? `${section.kicker} · ${section.label}` : `已读 ${Math.round((data.ratio ?? 0) * 100)}%`,
      };
    } catch {
      return null;
    }
  });

  const frame = useRef<number | null>(null);
  const toastTimer = useRef<number | null>(null);
  const lastY = useRef(0);
  const lastSave = useRef(0);
  const holdDock = useRef(0);

  const showToast = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 2600);
  }, []);

  useEffect(() => {
    const next = resolveTheme(themeMode);
    setResolvedTheme(next);
    document.documentElement.dataset.theme = next;
    document.documentElement.style.colorScheme = next;
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", next === "dark" ? "#090c0d" : "#f3efe6");
    safeWrite(STORAGE.theme, themeMode);
  }, [themeMode]);

  useEffect(() => {
    if (themeMode !== "system") return;
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const handle = () => {
      const next = media.matches ? "dark" : "light";
      setResolvedTheme(next);
      document.documentElement.dataset.theme = next;
      document.documentElement.style.colorScheme = next;
    };
    media.addEventListener("change", handle);
    return () => media.removeEventListener("change", handle);
  }, [themeMode]);

  useEffect(() => {
    document.documentElement.style.setProperty("--reader-scale", String(scale));
    safeWrite(STORAGE.scale, String(scale));
  }, [scale]);

  useEffect(() => {
    document.documentElement.dataset.bodyFont = bodyFont;
    safeWrite(STORAGE.font, bodyFont);
  }, [bodyFont]);

  useEffect(() => {
    document.documentElement.style.setProperty("--leading", String(LEADING_VALUES[leading]));
    safeWrite(STORAGE.leading, leading);
  }, [leading]);

  useEffect(() => {
    const onScroll = () => {
      if (frame.current) return;
      frame.current = window.requestAnimationFrame(() => {
        frame.current = null;
        const y = window.scrollY;
        const max = document.documentElement.scrollHeight - window.innerHeight;
        setProgress(max > 0 ? Math.min(100, Math.max(0, (y / max) * 100)) : 0);

        let current = "intro";
        for (const section of contentSections) {
          const element = document.getElementById(section.id);
          if (!element) continue;
          if (element.getBoundingClientRect().top <= 150) current = section.id;
          else break;
        }
        setActiveId(current);

        let sub = "";
        for (const item of subsByChapter[current] ?? []) {
          const element = document.getElementById(item.id);
          if (!element) continue;
          if (element.getBoundingClientRect().top <= 170) sub = item.id;
          else break;
        }
        setActiveSubId(sub);

        const delta = y - lastY.current;
        if (y < 160 || max - y < 220) {
          setDockHidden(false);
          lastY.current = y;
        } else if (Math.abs(delta) > 10) {
          setDockHidden(delta > 0 && Date.now() > holdDock.current);
          lastY.current = y;
        }

        if (y > 420) setResume(null);
        const now = Date.now();
        if (y > 0 && now - lastSave.current > 900) {
          lastSave.current = now;
          safeWrite(STORAGE.position, JSON.stringify({ y: Math.round(y), id: current, ratio: max > 0 ? y / max : 0 }));
        }
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (frame.current) window.cancelAnimationFrame(frame.current);
      frame.current = null;
    };
  }, [contentSections, subsByChapter]);

  useEffect(() => {
    const hold = () => {
      holdDock.current = Date.now() + 1600;
      setDockHidden(false);
    };
    const onClick = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest?.('a[href^="#"]')) hold();
    };
    window.addEventListener("heng:navigate", hold);
    document.addEventListener("click", onClick, true);
    return () => {
      window.removeEventListener("heng:navigate", hold);
      document.removeEventListener("click", onClick, true);
    };
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target?.tagName === "INPUT" || target?.tagName === "TEXTAREA" || target?.isContentEditable;
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setSearchOpen(true);
        return;
      }
      if (event.key === "/" && !typing) {
        event.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  useEffect(() => {
    if (!window.location.hash) return;
    const timer = window.setTimeout(() => {
      const id = decodeURIComponent(window.location.hash.replace("#", ""));
      document.getElementById(id)?.scrollIntoView({ behavior: "auto", block: "start" });
    }, 350);
    return () => window.clearTimeout(timer);
  }, []);

  const themeLabel = resolvedTheme === "dark" ? "深色" : "日间";
  const activeSection = contentSections.find((section) => section.id === activeId);
  const topbarSection = activeSection ?? { kicker: "VOL", label: "卷首" };
  const activeSub = (subsByChapter[activeId] ?? []).find((item) => item.id === activeSubId);

  const toggleTheme = () => setThemeMode(resolvedTheme === "dark" ? "light" : "dark");
  const fontStep = (delta: number) => setScale((value) => stepScale(value, delta));

  const openSource = () => {
    setSettingsOpen(false);
    setMenuOpen(false);
    setCopied(false);
    setSourceOpen(true);
  };

  const goToFirstSection = () => {
    const first = contentSections[0];
    if (first) document.getElementById(first.id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const navigateToBlock = (id: string) => {
    window.dispatchEvent(new Event("heng:navigate"));
    window.setTimeout(() => {
      const element = document.getElementById(id);
      if (!element) return;
      element.scrollIntoView({ behavior: "smooth", block: "center" });
      element.classList.add("is-located");
      window.setTimeout(() => element.classList.remove("is-located"), 2200);
    }, 80);
  };

  const copySource = async () => {
    const ok = await copyText(rawSource);
    if (ok) {
      setCopied(true);
      showToast("原文已复制到剪贴板");
      window.setTimeout(() => setCopied(false), 2600);
    } else {
      showToast("复制失败，请在原文视图中手动选择");
    }
  };

  const downloadSource = () => {
    const blob = new Blob([rawSource], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "材质与破坏能量数据库（第二版）.md";
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
    showToast("正在下载 Markdown 原文");
  };

  const printDocument = () => {
    setSettingsOpen(false);
    setSourceOpen(false);
    document.querySelectorAll(".reveal").forEach((node) => node.classList.add("is-visible"));
    window.setTimeout(() => window.print(), 180);
  };

  const resetDisplay = () => {
    setScale(DEFAULT_SCALE);
    setBodyFont("sans");
    setLeading("normal");
    setThemeMode("system");
    showToast("已恢复默认显示设置");
  };

  const scrollTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  useReveal(`${documentModel.length}-${scale}-${resolvedTheme}-${bodyFont}-${leading}`);

  return (
    <ToastContext.Provider value={showToast}>
      <XrefContext.Provider value={xrefMap}>
        <div className="reading-progress" aria-hidden="true">
          <span style={{ width: `${progress}%` }} />
        </div>
        <div className="page-texture" aria-hidden="true" />
        <a className="skip-link" href="#main-content">
          跳到正文
        </a>

        <Rail
          sections={contentSections}
          subs={subsByChapter}
          activeId={activeId}
          activeSubId={activeSubId}
          progress={progress}
          themeLabel={themeLabel}
          scale={scale}
          onFontStep={fontStep}
          onToggleTheme={toggleTheme}
          onOpenSearch={() => setSearchOpen(true)}
          onOpenSettings={() => setSettingsOpen(true)}
          onOpenSource={openSource}
        />

        <div className="app-shell" id="top">
          <Topbar
            active={topbarSection}
            activeSub={activeSub}
            themeLabel={themeLabel}
            scale={scale}
            onFontStep={fontStep}
            onToggleTheme={toggleTheme}
            onOpenMenu={() => setMenuOpen(true)}
            onOpenSearch={() => setSearchOpen(true)}
            onOpenSettings={() => setSettingsOpen(true)}
            progress={progress}
          />
          <main id="main-content">
            <Hero
              titleSection={documentModel[0]}
              sections={documentModel}
              rawLineCount={rawLineCount}
              tableCount={tableCount}
              onOpenSource={openSource}
              onStartReading={goToFirstSection}
            />
            <div className="document-intro">
              <span className="document-intro-rule" aria-hidden="true" />
              <span>FULL DOCUMENT</span>
              <span className="document-intro-rule" aria-hidden="true" />
              <span>零 — 八部分 · 附录</span>
            </div>
            <Article sections={documentModel} onOpenSource={openSource} />
            <Footer
              sections={contentSections}
              onOpenSource={openSource}
              onDownload={downloadSource}
              onPrint={printDocument}
              onBackTop={scrollTop}
            />
          </main>
        </div>

        <MobileMenu
          open={menuOpen}
          onClose={() => setMenuOpen(false)}
          sections={contentSections}
          subs={subsByChapter}
          activeId={activeId}
          activeSubId={activeSubId}
          onOpenSettings={() => setSettingsOpen(true)}
          onOpenSource={openSource}
        />
        <SearchDialog
          open={searchOpen}
          onClose={() => setSearchOpen(false)}
          entries={searchEntries}
          onNavigate={navigateToBlock}
        />
        <DisplayDialog
          open={settingsOpen}
          onClose={() => setSettingsOpen(false)}
          themeMode={themeMode}
          onThemeChange={setThemeMode}
          scale={scale}
          onScaleSet={setScale}
          bodyFont={bodyFont}
          onBodyFont={setBodyFont}
          leading={leading}
          onLeading={setLeading}
          onReset={resetDisplay}
          onOpenSource={openSource}
          onPrint={printDocument}
        />
        <SourceDialog
          open={sourceOpen}
          onClose={() => setSourceOpen(false)}
          raw={rawSource}
          lineCount={rawLineCount}
          onCopy={copySource}
          onDownload={downloadSource}
          onPrint={printDocument}
          copied={copied}
        />

        {resume ? (
          <ContinueReading
            label={resume.label}
            onResume={() => {
              window.scrollTo({ top: resume.y, behavior: "smooth" });
              setResume(null);
            }}
            onDismiss={() => setResume(null)}
          />
        ) : null}
        <BackToTop visible={progress > 12} onBackTop={scrollTop} />
        <MobileDock
          progress={progress}
          hidden={dockHidden && !menuOpen && !searchOpen && !settingsOpen}
          onOpenMenu={() => setMenuOpen(true)}
          onOpenSearch={() => setSearchOpen(true)}
          onOpenSettings={() => setSettingsOpen(true)}
          onBackTop={scrollTop}
        />

        <div className={`toast${toast ? " is-visible" : ""}`} role="status" aria-live="polite">
          {toast}
        </div>
      </XrefContext.Provider>
    </ToastContext.Provider>
  );
}
