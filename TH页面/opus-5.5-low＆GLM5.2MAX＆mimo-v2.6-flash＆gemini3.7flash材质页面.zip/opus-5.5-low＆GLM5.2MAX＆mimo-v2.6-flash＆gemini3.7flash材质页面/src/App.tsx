import { Fragment, useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import raw from './content.md?raw';
import { parse, plain, type Block } from './md';
import { Inline } from './components/Inline';
import { Table } from './components/Table';
import { HeroCanvas, ScaleRuler, Locator } from './components/Hero';
import { AxisTool, BlastTool, CloudTool, PhaseEnthalpyChart, BindingEnergyExplorer, ThermalFluxCalculator, Search } from './components/Tools';
import { ArtBanner } from './components/ArtBanner';
import { PLATE, STRATA, MOLTEN, NEUTRON_STAR, WHITE_DWARF, VAPORIZATION, CLOUD_ANVIL, IMPACT_CRATER } from './art';
import { sound } from './utils/sound';

type H = Extract<Block, { t: 'h' }>;
type Sec = { head: H; blocks: Block[] };
const HUES: Record<string, number> = { 'Ⅱ': 32, '零': 266, '一': 22, '二': 184, '三': 348, '四': 225, '五': 152, '六': 195, '七': 45, '八': 205, '附': 32 };
const ICONS: Record<string, string> = { 'Ⅱ': '◈', '零': '◎', '一': '◆', '二': '▣', '三': '◍', '四': '◉', '五': '◐', '六': '◇', '七': '▦', '八': '◎', '附': '❖' };

function splitTitle(t: string) {
  const m = /^(第[零一二三四五六七八]部分)[　\s]+(.*)$/.exec(t);
  if (m) return { tag: m[1], title: m[2], num: m[1][1] };
  if (/^附：/.test(t)) return { tag: '附录', title: t, num: '附' };
  return { tag: '第二版', title: t, num: 'Ⅱ' };
}

const INSERTS: Record<string, () => ReactNode> = {
  '0.2': () => <AxisTool />,
  '2.2': () => (
    <ArtBanner
      src={NEUTRON_STAR}
      title="中子星外壳与库仑晶体"
      tag="防御高端锚点 · 依据 2.2"
      caption="Horowitz 与 Kadau（2009，PRL）分子动力学模拟：中子星外壳库仑晶体所能承受的剪切应力约为钢的一百亿倍，断裂应变约 0.1，为已知最坚固物质。"
      meta={[
        { label: '物质强度', value: '钢的 ~100 亿倍' },
        { label: '断裂应变', value: '~0.1' },
        { label: '战力归属', value: '衡天 9.2 “御”维度' },
      ]}
    />
  ),
  '3.1': () => (
    <ArtBanner
      src={VAPORIZATION}
      title="定向能岩石汽化与相变潜热"
      tag="相变物理机制 · 依据 3.1"
      caption="相变需要克服材料潜热与升温焓，完全独立于结构破碎。高能束打击玄武岩/花岗岩时，汽化总能量密度比单纯粉碎高出两到三个数量级。"
      meta={[
        { label: '玄武岩汽化', value: '22.4–29.1 kJ/cc' },
        { label: '花岗岩汽化', value: '48.2–109 kJ/cc' },
        { label: '机制差异', value: '潜热 ≫ 结合能' },
      ]}
    />
  ),
  '3.2': () => <PhaseEnthalpyChart />,
  '4.1': () => (
    <ArtBanner
      src={WHITE_DWARF}
      title="Ia 型超新星与钱德拉塞卡白矮星解体"
      tag="引力束缚能校准 · 依据 4.1"
      caption="Woosley 等人（2007）模型：白矮星净束缚能约 4.6×10⁴³ J，抛射物在无穷远处动能约 1.2×10⁴⁴ J（约为净束缚能的 2.6 倍，但低于总引力束缚能 3.35×10⁴⁴ J）。"
      meta={[
        { label: '引力束缚能', value: '3.35×10⁴⁴ J' },
        { label: '净束缚能', value: '4.6×10⁴³ J' },
        { label: '抛射物动能', value: '~1.2×10⁴⁴ J' },
      ]}
    />
  ),
  '4.4': () => <BindingEnergyExplorer />,
  '5.1': () => <ThermalFluxCalculator />,
  '第六部分': () => (
    <ArtBanner
      src={IMPACT_CRATER}
      title="超高速撞击成坑动力学（π 标度体系）"
      tag="行星科学框架 · 依据第六部分"
      caption="Housen 与 Holsapple 撞击标度律：通过撞击体质量、速度、密度反推坑径与深度，包含冲击波耦合、重力控制与强度控制域转换。"
      meta={[
        { label: '标度体系', value: 'Housen & Holsapple π' },
        { label: '适用场景', value: '撞击成坑精准反推' },
      ]}
    />
  ),
  '8.1': () => <BlastTool />,
  '8.2': () => (
    <>
      <ArtBanner
        src={CLOUD_ANVIL}
        title="行星级积雨云砧与对流有效位能"
        tag="气象图像判读 · 依据 8.2"
        caption="卫星视距 20 公里、积雨云厚 8000 米时，水汽凝结潜热约为 2.277×10¹⁶ J，一分钟全天空扩散动能约 2.241×10¹⁸ J。多属衡天“控”或“域”。"
        meta={[
          { label: '凝结潜热', value: '2.277×10¹⁶ J' },
          { label: '动能扩散', value: '2.241×10¹⁸ J' },
          { label: '判定归属', value: '衡天“控”/“域”' },
        ]}
      />
      <CloudTool />
    </>
  ),
};

const BANDS: Record<string, string> = { '二': '18%', '三': '52%', '四': '86%', '五': '34%', '六': '68%', '七': '10%', '八': '44%', '零': '60%', '一': '74%' };

function Blocks({ blocks }: { blocks: Block[] }) {
  return <>{blocks.map(b => {
    switch (b.t) {
      case 'h': {
        const Tag = (b.level === 2 ? 'h3' : 'h4') as 'h3';
        const key = Object.keys(INSERTS).find(k => plain(b.text).startsWith(k));
        return (
          <Fragment key={b.id}>
            {key && INSERTS[key]()}
            <Tag id={b.id} className={`sub sub-${b.level} reveal`}><span className="sub-mark" /><Inline text={b.text} /><AnchorBtn id={b.id} /></Tag>
          </Fragment>
        );
      }
      case 'p': return <p key={b.id} id={b.id} className="para reveal"><Inline text={b.text} /></p>;
      case 'quote': return <blockquote key={b.id} id={b.id} className="quote reveal"><span className="q-mark">编</span><div>{b.lines.map((l, j) => <p key={j}><Inline text={l} /></p>)}</div></blockquote>;
      case 'ul': return <ul key={b.id} id={b.id} className="list reveal">{b.items.map((it, j) => <li key={j}><Inline text={it} /></li>)}</ul>;
      case 'ol': return <ol key={b.id} id={b.id} className="olist reveal">{b.items.map((it, j) => <li key={j}><span className="on">{String(j + 1).padStart(2, '0')}</span><div><Inline text={it} /></div></li>)}</ol>;
      case 'table': return <Table key={b.id} id={b.id} head={b.head} rows={b.rows} />;
      default: return null;
    }
  })}</>;
}

function AnchorBtn({ id }: { id: string }) {
  return (
    <button className="anchor" aria-label="复制此节链接" title="复制链接"
      onClick={e => {
        e.stopPropagation();
        sound.click(750);
        const u = location.origin !== 'null' ? `${location.origin}${location.pathname}#${id}` : `#${id}`;
        navigator.clipboard?.writeText(u).catch(() => {});
      }}>
      <svg viewBox="0 0 16 16" aria-hidden><path d="M4 9.5 9.5 4a2.5 2.5 0 0 1 3.5 3.5L7.5 13 5 15 1 11l2-2Z" fill="none" stroke="currentColor" strokeWidth="1.3" /><path d="M6 7.5 3 10.5" stroke="currentColor" strokeWidth="1.3" /></svg>
    </button>
  );
}

export default function App() {
  const blocks = useMemo(() => parse(raw), []);
  const { title, intro, secs } = useMemo(() => {
    const first = blocks.findIndex(b => b.t === 'h' && b.level === 1);
    const title = blocks[first] as H;
    const secs: Sec[] = []; const intro: Block[] = [];
    for (let i = first + 1; i < blocks.length; i++) {
      const b = blocks[i];
      if (b.t === 'h' && b.level === 1) secs.push({ head: b, blocks: [] });
      else (secs.length ? secs[secs.length - 1].blocks : intro).push(b);
    }
    return { title, intro, secs };
  }, [blocks]);

  const stats = useMemo(() => ({
    parts: secs.length,
    tables: blocks.filter(b => b.t === 'table').length,
    rows: blocks.reduce((n, b) => n + (b.t === 'table' ? b.rows.length : 0), 0),
  }), [blocks, secs]);

  const [dark, setDark] = useState(() => { const s = localStorage.getItem('hm-theme'); return s ? s === 'dark' : !window.matchMedia('(prefers-color-scheme: light)').matches; });
  const [fs, setFs] = useState(() => Number(localStorage.getItem('hm-fs')) || 17);
  const [soundOn, setSoundOn] = useState(() => sound.enabled);
  const [active, setActive] = useState('');
  const [toc, setToc] = useState(false);
  const [prog, setProg] = useState(0);
  const [show, setShow] = useState(false);
  const [search, setSearch] = useState(false);
  const [narrow, setNarrow] = useState(() => window.matchMedia('(max-width: 1020px)').matches);

  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; localStorage.setItem('hm-theme', dark ? 'dark' : 'light'); }, [dark]);
  useEffect(() => { document.documentElement.style.fontSize = fs + 'px'; localStorage.setItem('hm-fs', String(fs)); }, [fs]);

  useEffect(() => {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -5% 0px' });
    const add = () => document.querySelectorAll('.reveal:not(.in)').forEach(el => io.observe(el));
    add();
    const spyEls = Array.from(document.querySelectorAll<HTMLElement>('[data-spy]'));
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const d = document.documentElement;
        setProg(d.scrollTop / Math.max(1, d.scrollHeight - d.clientHeight));
        setShow(d.scrollTop > 700);
        let cur = '';
        for (const el of spyEls) if (el.getBoundingClientRect().top < innerHeight * .3) cur = el.id; else break;
        setActive(cur);
        const hero = document.querySelector('.hero-inner') as HTMLElement | null;
        if (hero) { const y = Math.min(1, d.scrollTop / (innerHeight * .8)); hero.style.transform = `translateY(${y * -60}px)`; hero.style.opacity = `${1 - y * .85}`; }
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true }); window.addEventListener('resize', onScroll); onScroll();
    return () => { io.disconnect(); window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); if (raf) cancelAnimationFrame(raf); };
  }, []);

  useEffect(() => {
    const mq = window.matchMedia('(max-width: 1020px)');
    const f = () => setNarrow(mq.matches);
    mq.addEventListener('change', f);
    return () => mq.removeEventListener('change', f);
  }, []);

  useEffect(() => { document.documentElement.style.overflow = search || (toc && narrow) ? 'hidden' : ''; }, [search, toc, narrow]);

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setToc(false);
      if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) { e.preventDefault(); sound.sweep(true); setSearch(v => !v); }
      if (e.key === '/' && !/input|textarea/i.test((e.target as HTMLElement)?.tagName ?? '')) { e.preventDefault(); sound.sweep(true); setSearch(true); }
    };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, []);

  const jump = useCallback((id: string) => {
    setToc(false);
    const el = document.getElementById(id);
    if (!el) return;
    const prev = el.previousElementSibling;
    const land = el.classList.contains('part-head') && prev?.classList.contains('part-band') ? prev : el;
    land.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const card = el.closest('.card, .quote, .axistool, .tool, .locator, .ruler, .art-card');
    const t = card ?? el;
    t.classList.remove('flash'); void (t as HTMLElement).offsetWidth; t.classList.add('flash');
    setTimeout(() => t.classList.remove('flash'), 1900);
  }, []);

  const tocItems = useMemo(() => secs.map(s => {
    const st = splitTitle(s.head.text);
    return { ...st, id: s.head.id, subs: s.blocks.filter((b): b is H => b.t === 'h' && b.level === 2) };
  }), [secs]);
  const activeTop = secs.find(s => s.head.id === active || s.blocks.some(b => b.t === 'h' && b.id === active))?.head.id ?? '';
  const activeHue = HUES[tocItems.find(t => t.id === activeTop)?.num ?? '一'] ?? 22;
  useEffect(() => { document.documentElement.style.setProperty('--ah', String(activeHue)); }, [activeHue]);
  const [tTitle, tSub] = title.text.split(/（|）/);
  const nowTitle = tocItems.find(t => t.id === activeTop)?.title ?? '';

  return (
    <div className="app">
      <div className="aurora" aria-hidden /><div className="vignette" aria-hidden />
      <div className="progress" style={{ transform: `scaleX(${prog})` }} />
      <a className="skip" href="#content">跳到正文</a>

      <header className="topbar">
        <button className="brand" onClick={() => { sound.click(500); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>
          <span className="logo" aria-hidden><i /></span><span className="brand-t">材质与破坏能量数据库</span>
        </button>
        <span className={`now ${activeTop && prog > 0.02 ? 'on' : ''}`} aria-hidden>{nowTitle}</span>
        <div className="tools">
          <button className="searchbtn" onClick={() => { sound.sweep(true); setSearch(true); }}><span aria-hidden>⌕</span><em>检索全文</em><kbd>/</kbd></button>
          <div className="fsz" role="group" aria-label="字号调整">
            <button onClick={() => { sound.click(480); setFs(f => Math.max(13, f - 1)); }} aria-label="缩小字体" disabled={fs <= 13}>A<sup>−</sup></button>
            <span>{Math.round(fs / 17 * 100)}%</span>
            <button onClick={() => { sound.click(620); setFs(f => Math.min(24, f + 1)); }} aria-label="放大字体" disabled={fs >= 24}>A<sup>+</sup></button>
          </div>
          <button
            className={`audio-btn ${soundOn ? 'on' : ''}`}
            onClick={() => { const next = sound.toggle(); setSoundOn(next); }}
            aria-label={soundOn ? '关闭音效' : '开启音效'}
            title={soundOn ? '音效：已开启' : '音效：已静音'}>
            <span className="audio-icon" aria-hidden>{soundOn ? '🔊' : '🔇'}</span>
          </button>
          <button className="theme" onClick={() => { sound.sweep(!dark); setDark(d => !d); }} aria-label={dark ? '切换到亮色主题' : '切换到暗色主题'} title={dark ? '切换到亮色' : '切换到暗色'}>
            <span className={`th-icon ${dark ? 'moon' : 'sun'}`} />
          </button>
          <button className="menu-btn" onClick={() => { sound.click(520); setToc(v => !v); }} aria-label="打开目录" aria-expanded={toc}><span /><span /><span /></button>
        </div>
      </header>

      <section className="hero">
        <div className="hero-plate" aria-hidden style={{ backgroundImage: `url(${PLATE})` }} />
        <HeroCanvas dark={dark} />
        <div className="hero-inner">
          <div className="hero-kicker"><span>衡天 ⊙ 配套数据参考</span><span className="k2">{tSub}</span></div>
          <h1 className="hero-title">{tTitle.split('').map((c, i) => <span key={i} style={{ ['--i' as string]: i }}>{c}</span>)}</h1>
          <div className="hero-intro"><Blocks blocks={intro} /></div>
          <div className="hero-stats">
            {[['部分', stats.parts], ['数据表', stats.tables], ['数据行', stats.rows]].map(([k, v]) => (
              <div key={String(k)} className="stat"><b>{String(v)}</b><span>{String(k)}</span></div>
            ))}
            <div className="stat stat-w"><b>未删改</b><span>原文全量呈现</span></div>
          </div>
          <div className="hero-cta">
            <button onClick={() => { sound.sweep(true); jump(secs[1]?.head.id ?? ''); }}>从第零部分开始 →</button>
            <button className="ghost" onClick={() => { sound.click(520); narrow ? setToc(true) : jump(secs[0]?.head.id ?? ''); }}>查看目录</button>
            <button className="ghost" onClick={() => { sound.sweep(true); setSearch(true); }}>⌕ 检索</button>
          </div>
        </div>
        <div className="scroll-hint" aria-hidden><span /></div>
      </section>

      <div className="layout">
        <aside className={`toc ${toc ? 'open' : ''}`} aria-label="目录">
          <div className="toc-head"><span>目录</span><button onClick={() => setToc(false)} aria-label="关闭目录">✕</button></div>
          <nav>
            {tocItems.map(it => (
              <div key={it.id} className={`toc-g ${activeTop === it.id ? 'on' : ''}`} style={{ ['--ph' as string]: HUES[it.num] }}>
                <button className="toc-1" onClick={() => { sound.click(580); jump(it.id); }} aria-current={activeTop === it.id ? 'true' : undefined}>
                  <em>{ICONS[it.num] ?? '◆'}</em><span>{it.title}</span>
                </button>
                {it.subs.map(h => (
                  <button key={h.id} className={`toc-2 ${active === h.id ? 'on' : ''}`} onClick={() => { sound.click(640); jump(h.id); }}>
                    {plain(h.text)}
                  </button>
                ))}
              </div>
            ))}
          </nav>
        </aside>
        {toc && narrow && <div className="scrim" onClick={() => setToc(false)} />}

        <main className="content" id="content">
          <div className="quick">
            <ScaleRuler />
            <Locator />
          </div>
          {secs.map(s => {
            const st = splitTitle(s.head.text);
            return (
              <section key={s.head.id} className="part" style={{ ['--ph' as string]: HUES[st.num] ?? 22 }}>
                <div className="part-band" aria-hidden
                  style={{ backgroundImage: `url(${st.num === '三' ? MOLTEN : STRATA})`, backgroundPosition: `${BANDS[st.num] ?? '50%'} 50%` }} />
                <header id={s.head.id} data-spy className="part-head reveal">
                  <span className="part-num" aria-hidden>{st.num}</span>
                  <span className="part-tag"><i aria-hidden>{ICONS[st.num] ?? '◆'}</i>{st.tag}</span>
                  <h2><Inline text={st.title} /><AnchorBtn id={s.head.id} /></h2>
                  <span className="part-line" aria-hidden>
                    <svg viewBox="0 0 400 12" preserveAspectRatio="none"><path d="M0 6 L34 2.5 L62 9 L96 3.5 L134 10 L172 2 L206 8.5 L242 3 L278 9.5 L316 2.5 L352 8 L400 5" /></svg>
                  </span>
                </header>
                <Blocks blocks={s.blocks} />
              </section>
            );
          })}
          <footer className="foot">
            <div>
              <p>原文：《{title.text}》</p>
              <p>全文未作删改；表格重排为卡片与信息图，图表数值均取自原文。</p>
            </div>
            <button onClick={() => { sound.sweep(true); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>回到顶部 ↑</button>
          </footer>
        </main>
      </div>

      <button className={`fab ${show ? 'on' : ''}`} onClick={() => { sound.sweep(true); window.scrollTo({ top: 0, behavior: 'smooth' }); }} aria-label="回到顶部"><span aria-hidden>↑</span></button>
      <Search open={search} onClose={() => setSearch(false)} blocks={blocks} jump={jump} />
    </div>
  );
}
