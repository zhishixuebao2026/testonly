import { useState } from 'react';
import { sound } from '../utils/sound';

interface ArtBannerProps {
  src: string;
  title: string;
  caption: string;
  tag: string;
  meta?: { label: string; value: string }[];
}

export function ArtBanner({ src, title, caption, tag, meta }: ArtBannerProps) {
  const [zoomed, setZoomed] = useState(false);

  return (
    <>
      <figure className="art-card reveal">
        <div className="art-media" onClick={() => { sound.click(720); setZoomed(true); }} role="button" tabIndex={0} aria-label={`查看大图：${title}`}>
          <img src={src} alt={title} loading="lazy" />
          <div className="art-overlay">
            <span className="art-tag">{tag}</span>
            <span className="art-hint"><i aria-hidden>⌕</i> 点击放大</span>
          </div>
        </div>
        <figcaption className="art-caption">
          <div className="art-info">
            <h4>{title}</h4>
            <p>{caption}</p>
          </div>
          {meta && meta.length > 0 && (
            <div className="art-meta">
              {meta.map((m, i) => (
                <div key={i} className="meta-chip">
                  <dt>{m.label}</dt>
                  <dd>{m.value}</dd>
                </div>
              ))}
            </div>
          )}
        </figcaption>
      </figure>

      {zoomed && (
        <div className="art-modal" onClick={() => setZoomed(false)} role="dialog" aria-modal="true" aria-label={title}>
          <div className="art-modal-scrim" />
          <div className="art-modal-body" onClick={e => e.stopPropagation()}>
            <img src={src} alt={title} />
            <div className="art-modal-bar">
              <div className="modal-title">
                <span className="art-tag">{tag}</span>
                <b>{title}</b>
              </div>
              <p>{caption}</p>
              <button className="modal-close" onClick={() => { sound.click(500); setZoomed(false); }} aria-label="关闭">✕</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
