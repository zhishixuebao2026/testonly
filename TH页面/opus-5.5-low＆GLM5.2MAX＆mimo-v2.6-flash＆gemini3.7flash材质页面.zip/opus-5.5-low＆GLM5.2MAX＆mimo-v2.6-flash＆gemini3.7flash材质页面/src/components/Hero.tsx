import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { sci } from '../md';
import { sound } from '../utils/sound';

export const ANCHORS: { v: number; label: string; s: string }[] = [
  { v: 1.2e9, label: 'GBU-57 动能', s: '约 12 亿焦耳' },
  { v: 4.184e15, label: '衡天 城▽', s: '4.184×10¹⁵ J' },
  { v: 2.277e16, label: '积雨云凝结', s: '约 2.277×10¹⁶ J' },
  { v: 4.6e19, label: '撕星（1000 km 级，每拉开 1 米）', s: '约 5.5×10¹⁹ J' },
  { v: 4.864e30, label: '火星', s: '4.864×10³⁰ J' },
  { v: 2.49e32, label: '地球（PREM 真实值）', s: '2.49×10³² J' },
  { v: 2.063e36, label: '木星', s: '2.063×10³⁶ J' },
  { v: 2.277e41, label: '太阳', s: '2.277×10⁴¹ J' },
  { v: 3.35e44, label: '白矮星（钱德拉塞卡极限附近）', s: '约 3.35×10⁴⁴ J' },
  { v: 3e46, label: '中子星（1.4 M☉）', s: '3×10⁴⁶ J' },
];
const LO = 8, HI = 48;

export function HeroCanvas({ dark }: { dark: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current!; const ctx = cv.getContext('2d', { alpha: true })!;
    let w = 0, h = 0, raf = 0, t = 0, live = true;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const mouse = { x: -9e9, y: -9e9 };
    type S = { x: number; y: number; vx: number; vy: number; r: number; a: number; va: number; pts: number[]; hue: number };
    let shards: S[] = [];
    let stars: { x: number; y: number; r: number; p: number }[] = [];
    const make = (): S => {
      const n = 3 + Math.floor(Math.random() * 3), pts: number[] = [];
      for (let k = 0; k < n; k++) { const ang = (k / n) * Math.PI * 2 + Math.random() * .6, rr = .5 + Math.random() * .5; pts.push(Math.cos(ang) * rr, Math.sin(ang) * rr); }
      return { x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5) * .25, vy: (Math.random() - .5) * .25, r: 2 + Math.random() ** 3 * 22, a: Math.random() * 6, va: (Math.random() - .5) * .006, pts, hue: Math.random() };
    };
    const resize = () => {
      w = cv.clientWidth; h = cv.clientHeight;
      cv.width = Math.max(1, Math.round(w * dpr)); cv.height = Math.max(1, Math.round(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      shards = Array.from({ length: Math.round(Math.min(112, w * h / 9800)) }, make);
      stars = Array.from({ length: Math.round(w < 520 ? 0 : Math.min(80, w * h / 16000)) }, () => ({
        x: Math.random() * w, y: Math.random() * h, r: Math.random() * 1.1 + .25, p: Math.random() * 6.28,
      }));
    };
    const frame = () => {
      if (!live) { raf = requestAnimationFrame(frame); return; }
      t += 1; ctx.clearRect(0, 0, w, h);
      const narrow = w < 700;
      const cx = w * .74, cy = narrow ? h * .16 : h * .44, R = Math.min(w, h) * (narrow ? .3 : .27);

      // starfield
      for (const s of stars) {
        const tw = reduce ? .5 : .35 + .65 * Math.abs(Math.sin(t * .012 + s.p));
        ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = dark ? `rgba(226,232,255,${.22 * tw})` : `rgba(60,40,25,${.16 * tw})`; ctx.fill();
      }

      // ambient nebula
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 2.6);
      if (dark) { g.addColorStop(0, 'rgba(255,168,96,.26)'); g.addColorStop(.28, 'rgba(255,96,60,.09)'); g.addColorStop(.62, 'rgba(96,120,255,.05)'); g.addColorStop(1, 'rgba(0,0,0,0)'); }
      else { g.addColorStop(0, 'rgba(214,88,44,.15)'); g.addColorStop(.3, 'rgba(214,120,60,.06)'); g.addColorStop(1, 'rgba(0,0,0,0)'); }
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

      // orbit rings
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(-.32);
      for (let k = 0; k < 6; k++) {
        const rr = R * (.9 + k * .3);
        ctx.beginPath(); ctx.ellipse(0, 0, rr, rr * .3, 0, 0, Math.PI * 2);
        ctx.strokeStyle = dark ? `rgba(255,206,164,${.15 - k * .02})` : `rgba(120,44,20,${.16 - k * .022})`;
        ctx.lineWidth = 1; ctx.setLineDash(k % 2 ? [2, 7] : []);
        ctx.lineDashOffset = reduce ? 0 : -t * .25 * (k + 1); ctx.stroke();
      }
      ctx.setLineDash([]); ctx.restore();

      // cracked sphere
      const pulse = 1 + (reduce ? 0 : Math.sin(t * .02) * .014);
      const SR = R * .4 * pulse;
      ctx.save(); ctx.translate(cx, cy);
      ctx.beginPath(); ctx.arc(0, 0, SR, 0, Math.PI * 2);
      const sg = ctx.createRadialGradient(-SR * .3, -SR * .32, 0, 0, 0, SR * 1.05);
      if (dark) { sg.addColorStop(0, '#fff0d6'); sg.addColorStop(.42, '#ffab5e'); sg.addColorStop(.78, '#e0501f'); sg.addColorStop(1, '#4d1106'); }
      else { sg.addColorStop(0, '#fff6ec'); sg.addColorStop(.45, '#ef8b52'); sg.addColorStop(.82, '#b93d18'); sg.addColorStop(1, '#5e1608'); }
      ctx.fillStyle = sg; ctx.fill();
      ctx.shadowColor = dark ? 'rgba(255,140,60,.7)' : 'rgba(180,60,20,.45)'; ctx.shadowBlur = R * .5; ctx.fill(); ctx.shadowBlur = 0;

      // fracture network
      ctx.lineCap = 'round';
      for (let k = 0; k < 9; k++) {
        const a0 = k * .7 + (reduce ? 0 : t * .0012);
        ctx.beginPath(); ctx.moveTo(0, 0);
        for (let s = 1; s <= 6; s++) { const rr = SR * s / 6, aa = a0 + Math.sin(k * 2.7 + s * 1.3) * .42; ctx.lineTo(Math.cos(aa) * rr, Math.sin(aa) * rr); }
        ctx.strokeStyle = dark ? 'rgba(255,246,226,.9)' : 'rgba(255,250,240,.95)';
        ctx.globalAlpha = .3 + .35 * Math.abs(Math.sin(t * .026 + k)); ctx.lineWidth = 1.1; ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // shockwave
      if (!reduce) {
        const ph = (t % 300) / 300;
        const rr = SR * (.55 + ph * 3.4);
        ctx.beginPath(); ctx.arc(0, 0, rr, 0, Math.PI * 2);
        ctx.strokeStyle = dark ? `rgba(255,196,148,${(1 - ph) * .3})` : `rgba(150,50,20,${(1 - ph) * .22})`;
        ctx.lineWidth = 2.4 * (1 - ph) + .3; ctx.stroke();
      }
      ctx.restore();

      // shards
      for (const s of shards) {
        if (!reduce) { s.x += s.vx; s.y += s.vy; s.a += s.va; }
        const dx = s.x - mouse.x, dy = s.y - mouse.y, d2 = dx * dx + dy * dy;
        if (d2 < 20000) { const f = (1 - d2 / 20000) * .55, d = Math.sqrt(d2) + 1; s.vx += dx / d * f; s.vy += dy / d * f; }
        s.vx = s.vx * .986 + (Math.random() - .5) * .012; s.vy = s.vy * .986 + (Math.random() - .5) * .012;
        if (s.x < -40) s.x = w + 40; if (s.x > w + 40) s.x = -40; if (s.y < -40) s.y = h + 40; if (s.y > h + 40) s.y = -40;
        ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.a); ctx.beginPath();
        for (let k = 0; k < s.pts.length; k += 2) { const X = s.pts[k] * s.r, Y = s.pts[k + 1] * s.r; k ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); }
        ctx.closePath();
        const al = .16 + (1 - s.r / 24) * .42;
        if (dark) { ctx.fillStyle = s.hue > .72 ? `rgba(255,154,86,${al})` : `rgba(178,198,255,${al * .45})`; ctx.strokeStyle = `rgba(255,224,186,${al})`; }
        else { ctx.fillStyle = s.hue > .72 ? `rgba(196,72,40,${al * .55})` : `rgba(48,44,58,${al * .2})`; ctx.strokeStyle = `rgba(64,30,18,${al * .55})`; }
        ctx.fill(); ctx.lineWidth = .7; ctx.stroke(); ctx.restore();
      }
      raf = requestAnimationFrame(frame);
    };
    resize(); frame();
    const onResize = () => resize();
    const mv = (e: PointerEvent) => { const b = cv.getBoundingClientRect(); mouse.x = e.clientX - b.left; mouse.y = e.clientY - b.top; };
    const lv = () => { mouse.x = mouse.y = -9e9; };
    const io = new IntersectionObserver(es => es.forEach(e => { live = e.isIntersecting; }), { threshold: 0 });
    io.observe(cv);
    window.addEventListener('resize', onResize); cv.addEventListener('pointermove', mv); cv.addEventListener('pointerleave', lv);
    return () => { cancelAnimationFrame(raf); io.disconnect(); window.removeEventListener('resize', onResize); cv.removeEventListener('pointermove', mv); cv.removeEventListener('pointerleave', lv); };
  }, [dark]);
  return <canvas ref={ref} className="hero-canvas" aria-hidden />;
}

export function ScaleRuler() {
  const [on, setOn] = useState(false);
  const [rows, setRows] = useState<number[]>(() => ANCHORS.map((_, i) => i % 2));
  const [height, setHeight] = useState(10.6);
  const boxRef = useRef<HTMLDivElement>(null);
  useEffect(() => { const id = setTimeout(() => setOn(true), 400); return () => clearTimeout(id); }, []);

  // Pack labels into rows using their real measured widths so nothing collides.
  useLayoutEffect(() => {
    const box = boxRef.current;
    if (!box) return;
    const W = box.clientWidth;
    if (!W) return;
    const els = Array.from(box.querySelectorAll<HTMLElement>('.ruler-mark'));
    if (els.length !== ANCHORS.length) return;
    const spans = els.map((e, i) => {
      const pos = (Math.log10(ANCHORS[i].v) - LO) / (HI - LO) * 100;
      const tx = pos < 10 ? 0 : pos > 88 ? -100 : -50;
      let w = 0;
      e.querySelectorAll('b, small').forEach(c => { w = Math.max(w, c.getBoundingClientRect().width / W * 100); });
      const left = pos + (w * tx) / 100;
      return { left, right: left + w };
    });
    const right: number[] = []; const out: number[] = [];
    spans.forEach(s2 => {
      let r = right.findIndex(rt => s2.left >= rt + 2);
      if (r < 0) { r = right.length; right.push(-999); }
      right[r] = s2.right; out.push(r);
    });
    const half = (n: number) => 3.62 + Math.max(0, n - 1) * 2.1;
    const above = Math.ceil(out.length / 2), below = Math.floor(out.length / 2);
    setRows(out);
    setHeight(Math.max(10.6, 2 * Math.max(half(above), half(below)) + 1.4));
  }, []);

  const pos = (e: number) => `${Math.max(0, Math.min(100, (e - LO) / (HI - LO) * 100))}%`;
  return (
    <div className="ruler reveal">
      <div className="ruler-title"><span>能量量级尺</span><em>10⁸ → 10⁴⁸ J · 对数轴 · 数值取自下文各表</em></div>
      <div className="ruler-track" ref={boxRef} role="img" aria-label="能量量级尺，从 GBU-57 到中子星" style={{ height: `${height}rem` }}>
        <div className="ruler-beam" />
        {Array.from({ length: (HI - LO) / 4 + 1 }, (_, k) => LO + k * 4).map(e => (
          <span key={e} className="ruler-grid" style={{ left: pos(e) }}><i>10<sup>{e}</sup></i></span>
        ))}
        {ANCHORS.map((m, k) => {
          const e = Math.log10(m.v);
          const p = (e - LO) / (HI - LO) * 100;
          const row = rows[k] ?? 0;
          const up = row % 2 === 0;
          const lvl = Math.floor(row / 2);
          const tx = p < 10 ? '-10%' : p > 88 ? '-90%' : '-50%';
          return (
            <span key={k}
              className={`ruler-mark ${up ? 'up' : 'dn'} ${p < 10 ? 'edge-l' : p > 88 ? 'edge-r' : ''}`}
              style={{ left: `${p}%`, ['--tx' as string]: tx, ['--b' as string]: `${1.5 + lvl * 2.1}rem`, transitionDelay: `${k * 70}ms` }}>
              <b>{m.label}</b><small>{m.s}</small>
            </span>
          );
        })}
      </div>
      <ol className={`ruler-list ${on ? 'on' : ''}`}>
        {ANCHORS.map((m, k) => (
          <li key={k} style={{ transitionDelay: `${k * 55}ms` }}>
            <span className="rl-bar" style={{ ['--w' as string]: pos(Math.log10(m.v)) }} />
            <b>{m.label}</b><small>{m.s}</small>
          </li>
        ))}
      </ol>
    </div>
  );
}

/** 量级定位器：输入焦耳数，输出 TNT 当量与在阶梯上的位置 */
export function Locator() {
  const [raw, setRaw] = useState('2.49e32');
  const [v, setV] = useState<number | null>(2.49e32);
  useEffect(() => { import('../md').then(({ parseJ }) => setV(parseJ(raw))); }, [raw]);
  const e = v ? Math.log10(v) : 0;
  const below = [...ANCHORS].reverse().find(a => Math.log10(a.v) <= e);
  const above = ANCHORS.find(a => Math.log10(a.v) >= e);
  const tons = v ? v / 4.184e9 : 0;
  const T = (n: number, u: string) => sci(n) + ' ' + u;
  const tnt = tons >= 1e8 ? T(tons / 1e8, '亿吨 TNT') : tons >= 1e4 ? T(tons / 1e4, '万吨 TNT') : tons >= 1 ? T(tons, '吨 TNT') : T(tons * 1000, '千克 TNT');
  return (
    <div className="locator reveal">
      <div className="loc-head">
        <h3>量级定位器</h3>
        <p>输入一个焦耳数，看它落在哪个区间。换算用 1 吨 TNT = 4.184×10⁹ J。</p>
      </div>
      <label className="loc-input">
        <span>能量 / J</span>
        <input value={raw} onChange={e => { sound.tick(); setRaw(e.target.value); }} inputMode="text" spellCheck={false}
          placeholder="例如 3e46 或 2.49×10^32" aria-label="输入能量，单位焦耳" />
        <output>{v ? sci(v) + ' J' : '无法解析'}</output>
      </label>
      {v && (
        <>
          <div className="loc-out">
            <div className="loc-chip"><dt>TNT 当量</dt><dd>{tnt}</dd></div>
            <div className="loc-chip"><dt>量级</dt><dd>10<sup>{Math.floor(e)}</sup> J</dd></div>
          </div>
          <div className="loc-bar" role="img" aria-label="在能量量级尺上的位置">
            <div className="loc-track">
              {ANCHORS.map((a, k) => <span key={k} className="loc-dot" style={{ left: pos2(Math.log10(a.v)) }} title={a.label} />)}
              <span className="loc-cursor" style={{ left: pos2(e) }} />
            </div>
            <p className="loc-note">
              {below && <>介于 <b>{below.label}</b>（{below.s}）</>}
              {below && above && <> 与 <b>{above.label}</b>（{above.s}）之间。</>}
              {!below && <>低于尺上最小的锚点 <b>{ANCHORS[0].label}</b>。</>}
              {below && !above && <>已超过尺上最大的锚点 <b>{ANCHORS[ANCHORS.length - 1].label}</b>。</>}
            </p>
          </div>
        </>
      )}
      <p className="loc-warn">注意：本页第五部分的持续通量单位是 W（功率），须先明确作用时长才能换算成焦耳。</p>
    </div>
  );
}
const pos2 = (e: number) => `${Math.max(0, Math.min(100, (e - LO) / (HI - LO) * 100))}%`;
