import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { plain, sci, type Block } from '../md';
import { sound } from '../utils/sound';

/* ============ 0.1 破坏动词判定器 ============ */
const AXIS1 = [
  { k: 'split', d: '碎、裂', n: '残骸可能仍彼此吸引、原地或松散堆积', out: '只需克服材质强度（第二部分），不套引力束缚能' },
  { k: 'blast', d: '爆、毁、灭', n: '残骸被抛散到彼此再也无法靠引力重新聚合', out: '需要克服引力束缚能（第四部分）' },
] as const;
const AXIS2 = [
  { k: 'chunk', d: '破、裂成大块或小碎块', v: '约 0.4–5.2 J/cc', ref: '衡天 2.2 的碎块刻度' },
  { k: 'powder', d: '粉碎、化为齑粉、打成灰尘', v: '约 40–1200 J/cc', ref: '本文件第一部分；比碎块高约 40–90 倍' },
  { k: 'melt', d: '熔、熔毁', v: '破碎能量之上另加熔化潜热与升温', ref: '第三部分' },
  { k: 'vapor', d: '汽化、湮灭', v: '另加汽化潜热与升温，比粉碎再高两到三个数量级', ref: '第三部分 3.2' },
] as const;

export function AxisTool() {
  const [scale, setScale] = useState<'ground' | 'body'>('body');
  const [a1, setA1] = useState<(typeof AXIS1)[number]['k']>('blast');
  const [a2, setA2] = useState<(typeof AXIS2)[number]['k']>('powder');
  const A1 = AXIS1.find(x => x.k === a1)!, A2 = AXIS2.find(x => x.k === a2)!;
  const useA1 = scale === 'body';

  return (
    <div className="axistool reveal">
      <div className="ax-head">
        <span className="ax-kicker">速查工具 · 依据 0.1</span>
        <h3>破坏动词判定器</h3>
        <p>两条轴分别判断、按需叠加，不是二选一。先问残骸有没有飞散（轴一），再问残骸细到什么程度、有没有相变（轴二）。</p>
      </div>

      <div className="ax-scale" role="radiogroup" aria-label="目标尺度">
        {([['ground', '地面尺度（建筑、山体）'], ['body', '行星、恒星级天体']] as const).map(([k, d]) => (
          <button key={k} className={scale === k ? 'on' : ''} onClick={() => { sound.click(500); setScale(k); }} role="radio" aria-checked={scale === k}>{d}</button>
        ))}
      </div>

      <div className="ax-body">
        <section className={`ax-col ${useA1 ? '' : 'dim'}`}>
          <h4><i>轴一</i>残骸是否克服了引力束缚{!useA1 && <em>地面尺度不适用</em>}</h4>
          {AXIS1.map(o => (
            <button key={o.k} disabled={!useA1} className={`ax-opt ${useA1 && a1 === o.k ? 'on' : ''}`} onClick={() => { sound.click(620); setA1(o.k); }}>
              <b>{o.d}</b><small>{o.n}</small>
            </button>
          ))}
        </section>
        <section className="ax-col">
          <h4><i>轴二</i>残骸颗粒大小与物质形态</h4>
          {AXIS2.map(o => (
            <button key={o.k} className={`ax-opt ${a2 === o.k ? 'on' : ''}`} onClick={() => { sound.click(720); setA2(o.k); }}>
              <b>{o.d}</b><small>{o.v}</small>
            </button>
          ))}
        </section>
      </div>

      <div className="ax-result" key={`${scale}-${a1}-${a2}`}>
        <span className="ax-tag">判定</span>
        <div className="ax-text">
          {useA1 ? (
            a1 === 'blast'
              ? <p><b>轴一 + 轴二，两项相加。</b>引力束缚能（第四部分）＋ 轴二对应的能量密度。{a2 === 'vapor' && <>「湮灭」通常默认两轴一起算，因为汽化的物质必然离开原位，除非原文明确写了「原地湮灭、残骸未曾飞散」。</>}</p>
              : <p><b>只按轴二取值。</b>残骸未被拆散，不套引力束缚能；结构断裂参考第二部分的材质强度。{a2 === 'powder' && <>「原地碎成粉末，没有飞散」＝ 只套轴二，残骸仍在原处。</>}</p>
          ) : (
            <p><b>地面尺度目标不涉及轴一，只按轴二取值。</b>{a2 === 'chunk' ? '碎块刻度见衡天 2.2。' : a2 === 'powder' ? '粉碎取值见第一部分。' : '相变能量见第三部分。'}</p>
          )}
          <ul>
            <li><span>轴二</span>{A2.d} → {A2.ref}</li>
            {useA1 && <li><span>轴一</span>{A1.d} → {A1.out}</li>}
          </ul>
        </div>
      </div>
      <p className="ax-note">同一个天体，「碎」和「爆」可以相差好几个完整分级（如六千公里直径的星球，「爆它」是星▽，「碎它」只到表☆）。</p>
    </div>
  );
}

/* ============ 3.2 相变能量阶梯柱状图 ============ */
interface RockSpecimen {
  name: string;
  chunk: number;       // J/cc
  powder: number;      // J/cc
  melt?: number;       // J/cc
  vaporMin: number;    // J/cc
  vaporMax: number;    // J/cc
  note: string;
}

const SPECIMENS: RockSpecimen[] = [
  { name: '玄武岩', chunk: 3, powder: 100, melt: 1200, vaporMin: 22400, vaporMax: 29100, note: '汽化总能量约为坚硬岩石粉碎的 224–291 倍（arXiv 暗物质撞击论文与量热实验交叉验证）。' },
  { name: '花岗岩', chunk: 4, powder: 100, melt: 1500, vaporMin: 48200, vaporMax: 109000, note: '汽化总能量约为粉碎的 482–1090 倍，不同产地（Barre, Westerly, St. Cloud）浮动达 2.3 倍。' },
  { name: '铁（标准对照）', chunk: 12, powder: 300, melt: 1947, vaporMin: 47900, vaporMax: 47900, note: '熔化潜热 1,947 J/cc、汽化潜热 47,900 J/cc，标准物性常数。' },
];

export function PhaseEnthalpyChart() {
  const [idx, setIdx] = useState(0);
  const cur = SPECIMENS[idx];
  const maxV = 110000;
  const logMax = Math.log10(maxV);
  const logMin = 0;

  const getPct = (v: number) => {
    const l = Math.log10(Math.max(1, v));
    return ((l - logMin) / (logMax - logMin)) * 100;
  };

  return (
    <div className="tool phase-chart reveal">
      <div className="ax-head">
        <span className="ax-kicker">对比图谱 · 依据 3.2</span>
        <h3>破坏状态与相变能量阶梯（对数刻度）</h3>
        <p>破碎与相变是完全不同的物理机制：破碎仅克服结合强度，汽化需额外提供巨大潜热，两者相差 2 到 3 个数量级。</p>
      </div>
      <div className="tool-in">
        <div className="seg" role="radiogroup" aria-label="材质切换">
          {SPECIMENS.map((s, i) => (
            <button key={s.name} role="radio" aria-checked={idx === i} className={idx === i ? 'on' : ''} onClick={() => { sound.click(580); setIdx(i); }}>
              {s.name}
            </button>
          ))}
        </div>
        <div className="phase-bars">
          <div className="phase-row">
            <div className="phase-meta"><b>碎块（大/小碎块）</b><span>约 {cur.chunk} J/cc</span></div>
            <div className="phase-track">
              <div className="phase-fill chunk" style={{ width: `${getPct(cur.chunk)}%` }} />
              <span className="phase-tick">10^{Math.log10(cur.chunk).toFixed(1)}</span>
            </div>
          </div>
          <div className="phase-row">
            <div className="phase-meta"><b>粉碎（打成齑粉）</b><span>基准 100 J/cc</span></div>
            <div className="phase-track">
              <div className="phase-fill powder" style={{ width: `${getPct(cur.powder)}%` }} />
              <span className="phase-tick">10^{Math.log10(cur.powder).toFixed(1)}</span>
            </div>
          </div>
          {cur.melt && (
            <div className="phase-row">
              <div className="phase-meta"><b>熔化潜热</b><span>约 {cur.melt.toLocaleString()} J/cc</span></div>
              <div className="phase-track">
                <div className="phase-fill melt" style={{ width: `${getPct(cur.melt)}%` }} />
                <span className="phase-tick">10^{Math.log10(cur.melt).toFixed(1)}</span>
              </div>
            </div>
          )}
          <div className="phase-row highlight">
            <div className="phase-meta">
              <b>完全汽化（含升温）</b>
              <strong>{cur.vaporMin === cur.vaporMax ? `${cur.vaporMin.toLocaleString()} J/cc` : `${cur.vaporMin.toLocaleString()}–${cur.vaporMax.toLocaleString()} J/cc`}</strong>
            </div>
            <div className="phase-track">
              <div className="phase-fill vapor" style={{ width: `${getPct(cur.vaporMax)}%` }} />
              <span className="phase-tick">10^{Math.log10(cur.vaporMax).toFixed(1)}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="tool-out">
        <div className="phase-multiplier">
          <span>汽化 ÷ 粉碎倍率</span>
          <strong>{cur.vaporMin === cur.vaporMax ? `${Math.round(cur.vaporMin / cur.powder)} 倍` : `${Math.round(cur.vaporMin / cur.powder)}–${Math.round(cur.vaporMax / cur.powder)} 倍`}</strong>
        </div>
        <p className="tool-note">{cur.note}</p>
      </div>
    </div>
  );
}

/* ============ 4.4 天体引力束缚能与致密星模拟器 ============ */
interface BodyItem {
  id: string;
  name: string;
  mass: string;
  radius: string;
  u: number;            // Joules
  uStr: string;
  formula: string;
  desc: string;
  note: string;
  multSun: string;
}

const BODIES: BodyItem[] = [
  { id: 'mars', name: '火星', mass: '0.107 M⊕', radius: '3,390 km', u: 4.864e30, uStr: '4.864×10³⁰ J', formula: 'U = 3GM²/(5R)', desc: '均匀球模型复算', note: '普通岩石行星，内能可忽略。', multSun: '0.000021' },
  { id: 'earth', name: '地球', mass: '1.0 M⊕', radius: '6,371 km', u: 2.49e32, uStr: '2.49×10³² J', formula: 'PREM 真实密度模型', desc: '均匀球估计为 2.241×10³² J，真实剖面高出约 11%', note: '战力体系行星级标准基准。', multSun: '0.00109' },
  { id: 'jupiter', name: '木星', mass: '317.8 M⊕', radius: '69,911 km', u: 2.063e36, uStr: '2.063×10³⁶ J', formula: 'U = 3GM²/(5R)', desc: '气体巨行星', note: '引力结合远超岩石行星。', multSun: '0.00906' },
  { id: 'sun', name: '太阳', mass: '1.0 M☉', radius: '696,340 km', u: 2.277e41, uStr: '2.277×10⁴¹ J', formula: 'U = 3GM²/(5R)', desc: '恒星级基准（×1）', note: '覆盖模型中 0.8 M☉ 平均场星为 1.7×10⁴¹ J。', multSun: '×1.0' },
  { id: 'wd05', name: '白矮星 (0.5 M☉)', mass: '0.5 M☉', radius: '约 9,700 km', u: 5.8e42, uStr: '约 5.8×10⁴² J', formula: 'n=1.5 多方球 (6/7)GM²/R', desc: '引力束缚能 5.8×10⁴² J / 净束缚能 2.9×10⁴² J', note: '简并压支撑；真实半径与地球相当。旧版误取 696 km 偏高 10 倍已废弃。', multSun: '约 ×25' },
  { id: 'wd_chandra', name: '白矮星 (钱氏极限附近)', mass: '约 1.4 M☉', radius: '更小（质量越大越小）', u: 3.35e44, uStr: '约 3.35×10⁴⁴ J', formula: 'Woosley 2007 模型', desc: '引力束缚能 3.35×10⁴⁴ J / 净束缚能 4.6×10⁴³ J', note: 'Ia 型超新星抛射物无穷远动能约 1.2×10⁴⁴ J（为净束缚能的 2.6 倍，但低于总引力束缚能）。', multSun: '约 ×1,500' },
  { id: 'ns', name: '中子星 (1.4 M☉)', mass: '1.4 M☉', radius: '约 10–12 km', u: 3e46, uStr: '3×10⁴⁶ J (3×10⁵³ erg)', formula: 'Fukugita & Peebles 宇宙能量收支标准值', desc: '超新星理论塌缩释放引力结合能', note: '已知引力束缚能最高的常规天体，为太阳的 13 万倍。', multSun: '约 ×130,000' },
];

export function BindingEnergyExplorer() {
  const [curId, setCurId] = useState('earth');
  const b = BODIES.find(x => x.id === curId) || BODIES[1];

  return (
    <div className="tool binding-explorer reveal">
      <div className="ax-head">
        <span className="ax-kicker">天体物理探针 · 依据 4.1–4.4</span>
        <h3>天体引力束缚能阶梯与公式透镜</h3>
        <p>引力束缚能严格对应「把天体拆散到无穷远所需的理论能量下限」，不等于碎裂或汽化。致密天体不能套均匀球公式。</p>
      </div>
      <div className="tool-in">
        <div className="body-tabs" role="tablist">
          {BODIES.map(item => (
            <button
              key={item.id}
              role="tab"
              aria-selected={item.id === curId}
              className={`body-tab ${item.id === curId ? 'on' : ''}`}
              onClick={() => { sound.click(640); setCurId(item.id); }}>
              <b>{item.name}</b>
              <small>{item.multSun}</small>
            </button>
          ))}
        </div>
      </div>
      <div className="tool-out">
        <div className="body-spotlight">
          <div className="spot-header">
            <div>
              <span className="spot-tag">天体档案</span>
              <h4>{b.name}</h4>
            </div>
            <div className="spot-energy">
              <em>束缚能下限</em>
              <strong>{b.uStr}</strong>
            </div>
          </div>
          <div className="spot-grid">
            <div><dt>质量</dt><dd>{b.mass}</dd></div>
            <div><dt>半径</dt><dd>{b.radius}</dd></div>
            <div><dt>计算模型</dt><dd><code className="fx">{b.formula}</code></dd></div>
            <div><dt>相对太阳倍率</dt><dd className="hl-val">{b.multSun}</dd></div>
          </div>
          <div className="spot-desc">
            <p><b>模型解析：</b>{b.desc}</p>
            <p><b>实战判定注意：</b>{b.note}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============ 5.1 全球热注入通量模拟器 ============ */
const EARTH_RADIUS = 6371000; // m
const EARTH_AREA_CROSS = Math.PI * EARTH_RADIUS * EARTH_RADIUS; // ~1.275e14 m²

export function ThermalFluxCalculator() {
  const [flux, setFlux] = useState(282); // W/m²
  const delta = Math.max(0, flux - 240);
  const totalPowerW = delta * EARTH_AREA_CROSS * 4; // over 4π sphere equivalent or cross-section
  const petawatts = totalPowerW / 1e15;

  const isKI = Math.abs(flux - 280) < 0.5;
  const isSN = Math.abs(flux - 282) < 0.5;

  return (
    <div className="tool thermal-tool reveal">
      <div className="ax-head">
        <span className="ax-kicker">持续通量模拟 · 依据 5.1</span>
        <h3>全球持续热注入与气候失控阈值（KI / SN 极限）</h3>
        <p>回答长期持续散发热量的功率阈值（单位是 W/m² 与 W，非单次 J）。地球基准吸收通量为 240 W/m²。</p>
      </div>
      <div className="tool-in">
        <div className="range">
          <span>吸收通量设定 <b>{flux.toFixed(1)}</b> W/m²（当前地球约 240 W/m²）</span>
          <input
            type="range"
            min={240}
            max={340}
            step={0.5}
            value={flux}
            onChange={e => { sound.tick((+e.target.value - 240) / 100); setFlux(+e.target.value); }}
            aria-label="全球平均吸收通量"
          />
        </div>
        <div className="presets">
          <button className={isKI ? 'on' : ''} onClick={() => { sound.click(600); setFlux(280); }}>KI 极限（280 W/m² · 海洋蒸发）</button>
          <button className={isSN ? 'on' : ''} onClick={() => { sound.click(720); setFlux(282); }}>SN 极限（282 W/m² · 全球岩浆洋）</button>
          <button className={flux === 240 ? 'on' : ''} onClick={() => { sound.click(480); setFlux(240); }}>重置为地球现状（240 W/m²）</button>
        </div>
      </div>
      <div className="tool-out">
        <div className="chips">
          <div><dt>需额外注入通量 ΔΦ</dt><dd>+{delta.toFixed(1)} W/m² ({((delta / 240) * 100).toFixed(1)}%)</dd></div>
          <div><dt>全球等效持续注入总功率</dt><dd>{petawatts >= 1000 ? `${(petawatts / 1000).toFixed(2)} 艾瓦 (EW)` : `${petawatts.toFixed(1)} 拍瓦 (PW)`}</dd></div>
        </div>
        <div className="flux-status">
          {flux < 280 ? (
            <p className="status-safe"><b>温室稳定带：</b>通量低于 KI 极限，海洋尚未失控蒸发，地球尚能通过红外辐射向外散热维持稳态。</p>
          ) : flux < 282 ? (
            <p className="status-warn"><b>触及 KI 极限（Komabayashi–Ingersoll）：</b>海洋开始不可逆完全蒸发进入大气，地表水圈瓦解。</p>
          ) : (
            <p className="status-danger"><b>突破 SN 极限（Simpson–Nakajima）：</b>失控温室效应彻底爆发，地表温度飙升至岩石熔点，形成全球岩浆洋。</p>
          )}
        </div>
        <p className="tool-note">注：太阳常数 1367 W/m²。输出单位是持续功率（W），必须乘以实际作用时长才能换算为焦耳。</p>
      </div>
    </div>
  );
}

/* ============ 8.1 爆炸当量速算 ============ */
const TONS_J = 4.184e9;      // 1 吨 TNT
const CITY = 4.184e15;       // 衡天 城▽
const airYieldMt = (km: number) => Math.pow(km / 0.28, 3) / 1000;
const groundYieldT = (m: number, p: number) => Math.pow(m, 3) * Math.pow((Math.sqrt(27136 * p + 8649) - 93) / 13568, 2);

export function BlastTool() {
  const [r, setR] = useState(5.78);
  const [kind, setKind] = useState<'air-conv' | 'air-nuke' | 'ground'>('air-conv');
  const [p, setP] = useState(1.37895);
  const [open, setOpen] = useState(false);
  const isGround = kind === 'ground';
  const tons = isGround ? groundYieldT(r * 1000, p) : airYieldMt(r) * 1e6 * (kind === 'air-conv' ? .5 : 1);
  const joule = tons * TONS_J;
  const rel = joule / CITY;
  const tonsTxt = tons >= 1e8 ? `${sci(tons / 1e8)} 亿吨` : tons >= 1e4 ? `${sci(tons / 1e4)} 万吨` : `${sci(tons)} 吨`;
  const isParis = Math.abs(r - 5.78) < 0.06;

  return (
    <div className="tool blast reveal">
      <div className="ax-head">
        <span className="ax-kicker">速查工具 · 依据 8.1</span>
        <h3>爆炸当量速算</h3>
        <p>由「近乎全部致死」的半径反推当量。空爆常规爆炸取能量的一半，核爆不减半；地爆式不减半，超压 P 默认 1.37895 巴（约 20 psi）。</p>
      </div>
      <div className="tool-in">
        <div className="seg" role="radiogroup" aria-label="爆炸类型">
          {([['air-conv', '空爆 · 常规'], ['air-nuke', '空爆 · 核'], ['ground', '地爆']] as const).map(([k, d]) => (
            <button key={k} role="radio" aria-checked={kind === k} className={kind === k ? 'on' : ''} onClick={() => { sound.click(520); setKind(k); }}>{d}</button>
          ))}
        </div>
        <label className="range">
          <span>半径 <b>{r.toFixed(2)}</b> km</span>
          <input type="range" min={0.2} max={20} step={0.01} value={r} onChange={e => { sound.tick(+e.target.value / 20); setR(+e.target.value); }} aria-label="半径，公里" />
        </label>
        <div className="presets">
          {([[5.78, '巴黎 105 km²'], [1, '1 km'], [10, '10 km'], [0.5, '0.5 km']] as const).map(([v, d]) => (
            <button key={d} onClick={() => { sound.click(620); setR(v); }} className={Math.abs(r - v) < 1e-9 ? 'on' : ''}>{d}</button>
          ))}
          <button className="adv" onClick={() => { sound.click(420); setOpen(o => !o); }}>{open ? '收起超压 ▴' : '超压 P ▾'}</button>
        </div>
        {open && (
          <label className="range small">
            <span>冲击波超压 P = <b>{p.toFixed(4)}</b> 巴</span>
            <input type="range" min={0.1} max={6} step={0.0001} value={p} onChange={e => setP(+e.target.value)} aria-label="冲击波超压，巴" />
          </label>
        )}
      </div>
      <div className="tool-out" key={`${kind}-${isGround}`}>
        <div className="big">
          <em>{isGround ? '地爆当量' : kind === 'air-nuke' ? '空爆当量（核，不减半）' : '空爆当量（常规，已减半）'}</em>
          <strong>{tonsTxt}</strong>
          <code>≈ {sci(joule)} J</code>
        </div>
        <div className="chips">
          <div><dt>对衡天城▽</dt><dd>× {sci(rel)}</dd></div>
          <div><dt>换算</dt><dd>1 吨 = 4.184×10⁹ J</dd></div>
        </div>
        <p className="tool-note">
          {isParis
            ? <>与原文交叉校验一致：巴黎 105 km² 反算等效半径 5.78 km，空爆减半后约 <b>1.84×10¹⁶ J</b>，比衡天城▽（4.184×10¹⁵ J）高约 <b>4 倍</b>。两者定义不同，以衡天继承区为准。</>
            : <>经验式只作交叉校验：其口径是「近乎全部致死」，与「完全摧毁」不同，结论中须注明差异。</>}
        </p>
      </div>
    </div>
  );
}

/* ============ 8.2 云层速算 ============ */
const LATENT = 2264705; // J/kg
export function CloudTool() {
  const [d, setD] = useState(20);       // 视距 km
  const [th, setTh] = useState(8000);   // 厚度 m
  const [cw, setCw] = useState(1);      // g/m³
  const [t, setT] = useState(60);       // s
  const D = d * 1000;
  const Vdisc = Math.PI * D * D * th;            // 凝结口径
  const Vsph = 4 * Math.PI * D * D * th;         // 动能口径（覆盖全部天空）
  const mw = Vdisc * cw / 1000;                  // kg 水
  const cond = mw * LATENT;
  const mt = Vsph * 1.003;                       // kg 水 + 空气
  const v = D / t;
  const ke = 0.5 * mt * v * v;
  const low = Math.min(cond, ke);
  const nearMatch = (a: number, b: number) => Math.abs(Math.log10(a) - Math.log10(b)) < 0.02;

  return (
    <div className="tool cloud reveal">
      <div className="ax-head">
        <span className="ax-kicker">速查工具 · 依据 8.2</span>
        <h3>云层速算</h3>
        <p>体积口径 π ×（视距）² × 厚度用于凝结/汽化；动能口径按覆盖全部天空（4π 视距² × 厚度，速度 = 视距 ÷ 时间）。不确定用哪种时，三种都算，取最低值。</p>
      </div>
      <div className="tool-in">
        <div className="grid4">
          <label><span>视距 <b>{d}</b> km</span><input type="range" min={2} max={60} step={1} value={d} onChange={e => { sound.tick(d / 60); setD(+e.target.value); }} /></label>
          <label><span>云层厚度 <b>{th.toLocaleString('zh-CN')}</b> m</span><input type="range" min={200} max={12000} step={100} value={th} onChange={e => { sound.tick(th / 12000); setTh(+e.target.value); }} /></label>
          <label><span>液态含水量 <b>{cw}</b> g/m³</span><input type="range" min={0.05} max={3} step={0.05} value={cw} onChange={e => { sound.tick(cw / 3); setCw(+e.target.value); }} /></label>
          <label><span>时间 <b>{t}</b> s</span><input type="range" min={10} max={600} step={10} value={t} onChange={e => { sound.tick(t / 600); setT(+e.target.value); }} /></label>
        </div>
        <div className="presets">
          {([[8000, 1, '积雨云 8000 m · 1 g/m³'], [3000, 0.45, '雨层云 3000 m'], [600, 0.25, '积云 600 m']] as const).map(([a, b, d2]) => (
            <button key={d2} onClick={() => { sound.click(680); setTh(a); setCw(b); }} className={th === a && cw === b ? 'on' : ''}>{d2}</button>
          ))}
        </div>
      </div>
      <div className="tool-out">
        <div className="grid3">
          <div className="cell"><em>云体积（π 口径）</em><strong>{sci(Vdisc)} m³</strong><span>水质量 {sci(mw)} kg</span></div>
          <div className="cell"><em>凝结或汽化</em><strong>{sci(cond)} J</strong><span>m × 2,264,705 J/kg</span></div>
          <div className="cell"><em>动能</em><strong>{sci(ke)} J</strong><span>0.5 × {sci(mt)} kg × ({sci(v)} m/s)²</span></div>
        </div>
        <div className="verify">
          <span className={nearMatch(cond, 2.277e16) ? 'ok' : ''}>原文示例：凝结 ≈ 2.277×10¹⁶ J {nearMatch(cond, 2.277e16) && '✓'}</span>
          <span className={nearMatch(ke, 2.241e18) ? 'ok' : ''}>原文示例：动能 ≈ 2.241×10¹⁸ J {nearMatch(ke, 2.241e18) && '✓'}</span>
          <span className="low">取最低值 {sci(low)} J</span>
        </div>
        <p className="tool-note">原文的两个常见结果都可在默认参数下复算：凝结 <b>2.277×10¹⁶ J</b>、动能 <b>2.241×10¹⁸ J</b>（假设一分钟内覆盖全部天空）。时间更长、视距不足 20 公里或不是积雨云时，不能直接套用；云层表现多属「控」或「域」，只有确实摧毁了物体才进「破」。</p>
      </div>
    </div>
  );
}

/* ============ 全文检索 ============ */
type Hit = { id: string; title: string; where: string; snip: ReactNode };

export function Search({ open, onClose, blocks, jump }: { open: boolean; onClose: () => void; blocks: Block[]; jump: (id: string) => void }) {
  const [q, setQ] = useState('');
  const [i, setI] = useState(0);
  const input = useRef<HTMLInputElement>(null);

  const index = useMemo(() => {
    const out: { id: string; title: string; where: string; text: string }[] = [];
    let where = '';
    for (const b of blocks) {
      if (b.t === 'h') { where = plain(b.text); continue; }
      const texts: string[] = b.t === 'table' ? [b.head.map(plain).join(' / '), ...b.rows.map(r => r.map(plain).join(' / '))]
        : b.t === 'quote' ? b.lines.map(plain) : b.t === 'p' ? [plain(b.text)]
          : b.t === 'hr' ? [] : (b as { items: string[] }).items.map(plain);
      const text = texts.join('　');
      if (text) out.push({ id: b.id, title: where, where: b.t === 'table' ? '表格' : b.t === 'quote' ? '引文' : '正文', text });
    }
    return out;
  }, [blocks]);

  const hits = useMemo<Hit[]>(() => {
    const s = q.trim().toLowerCase();
    if (s.length < 1) return [];
    const res: Hit[] = [];
    for (const it of index) {
      const p = it.text.toLowerCase().indexOf(s);
      if (p < 0) continue;
      const st = Math.max(0, p - 26), cut = it.text.slice(st, st + 110);
      const at = cut.toLowerCase().indexOf(s);
      res.push({
        id: it.id, title: it.title || '开头', where: it.where,
        snip: <>{cut.slice(0, at)}<mark>{cut.slice(at, at + s.length)}</mark>{cut.slice(at + s.length)}{st + 110 < it.text.length ? '…' : ''}</>,
      });
      if (res.length >= 14) break;
    }
    return res;
  }, [q, index]);

  useEffect(() => { if (open) { setQ(''); setI(0); setTimeout(() => input.current?.focus(), 60); } }, [open]);
  useEffect(() => { setI(0); }, [q]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (!open) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowDown') { e.preventDefault(); sound.click(450); setI(v => Math.min(hits.length - 1, v + 1)); }
      if (e.key === 'ArrowUp') { e.preventDefault(); sound.click(550); setI(v => Math.max(0, v - 1)); }
      if (e.key === 'Enter' && hits[i]) { sound.sweep(true); jump(hits[i].id); onClose(); }
    };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [open, hits, i, onClose, jump]);

  return (
    <div className={`search ${open ? 'open' : ''}`} role="dialog" aria-modal="true" aria-label="全文检索" hidden={!open}>
      <div className="scrim" onClick={onClose} />
      <div className="search-box">
        <div className="search-bar">
          <span className="s-ico" aria-hidden>⌕</span>
          <input ref={input} value={q} onChange={e => setQ(e.target.value)} placeholder="检索全文：材质、天体、数值、章节…" aria-label="检索关键词" />
          <button onClick={onClose} aria-label="关闭检索">ESC</button>
        </div>
        <div className="search-res">
          {!q.trim() && <p className="s-hint">支持中文与数字，例如「花岗岩」「束缚能」「中子星」「白矮星」「40 J/cc」。</p>}
          {q.trim() && !hits.length && <p className="s-hint">没有匹配的内容。</p>}
          {hits.map((h, k) => (
            <button key={h.id} className={`s-row ${k === i ? 'on' : ''} ${k < i ? 'up' : ''} ${k > i ? 'dn' : ''}`}
              onMouseEnter={() => setI(k)} onClick={() => { sound.sweep(true); jump(h.id); onClose(); }}>
              <span className="s-where">{h.where}</span>
              <span className="s-body"><em>{h.title}</em>{h.snip}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
