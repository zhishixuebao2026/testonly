import { Fragment, type ReactNode } from 'react';
import { plain } from '../md';

const FX = [
  'U = 3GM²/(5R)', 'F = 3GM²/(16R²)', 'F × d', 'S = √(2Rh + h²)',
  'S最大 = √(2Rh + h²) + √(2RH + H²)', 'h > b × tan(a)', 'Y（百万吨 TNT）=（x ÷ 0.28）³ ÷ 1000',
  'W（吨 TNT）= R³ ×（√(27136P + 8649) ÷ 13568 − 93 ÷ 13568）²', 'I = P ÷ A', 'A = 4πr²',
  '0.5 × 云的总质量 × 移动速度²', 'π ×（视距）² × 云层厚度', '3×10⁵³ erg = 3×10⁴⁶ J', 'ρ²R⁴',
];
const FX_RE = new RegExp('(' + FX.map(f => f.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'g');

function seg(s: string): ReactNode[] {
  return s.split(FX_RE).filter(Boolean).map((p, i) =>
    FX.includes(p) ? <code key={i} className="fx" dir="ltr">{p}</code> : <Fragment key={i}>{p}</Fragment>);
}
function lines(s: string, k: number): ReactNode {
  return <Fragment key={k}>{s.split('\n').map((x, j) => <Fragment key={j}>{j > 0 && <br />}{seg(x)}</Fragment>)}</Fragment>;
}
export function Inline({ text }: { text: string }) {
  return <>{text.split(/(\*\*[^*]+\*\*)/g).filter(Boolean).map((p, i) =>
    p.startsWith('**') && p.endsWith('**') && p.length > 4
      ? <strong key={i} className="hl">{plain(p).split('\n').map((x, j) => <Fragment key={j}>{j > 0 && <br />}{seg(x)}</Fragment>)}</strong>
      : lines(p, i))}</>;
}
