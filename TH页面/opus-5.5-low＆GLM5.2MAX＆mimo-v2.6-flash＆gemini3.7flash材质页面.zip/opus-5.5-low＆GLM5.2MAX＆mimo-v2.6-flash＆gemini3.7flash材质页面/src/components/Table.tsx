import { useEffect, useRef } from 'react';
import { Inline } from './Inline';
import { magnitude, stress, plain } from '../md';

type Col = { i: number; mode: 'mag' | 'stress' };
function pickCol(head: string[], rows: string[][]): Col | null {
  for (let c = 1; c < head.length; c++) {
    const h = plain(head[c]);
    if (!/束缚能|能量|动能|当量|强度/.test(h) || /备注|依据|说明|材质/.test(h)) continue;
    const f = /强度/.test(h) ? stress : magnitude;
    if (rows.some(r => r[c] && f(r[c]) !== null)) return { i: c, mode: /强度/.test(h) ? 'stress' : 'mag' };
  }
  return null;
}

function useSpot<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const mv = (e: PointerEvent) => {
      const card = (e.target as HTMLElement).closest('.card') as HTMLElement | null;
      if (!card || !el.contains(card)) return;
      const b = card.getBoundingClientRect();
      card.style.setProperty('--mx', `${((e.clientX - b.left) / b.width) * 100}%`);
      card.style.setProperty('--my', `${((e.clientY - b.top) / b.height) * 100}%`);
    };
    el.addEventListener('pointermove', mv);
    return () => el.removeEventListener('pointermove', mv);
  }, []);
  return ref;
}

/* ---------- 4.4 束缚能阶梯：对数阶梯图 ---------- */
function Ladder({ head, rows, id }: { head: string[]; rows: string[][]; id?: string }) {
  const data = rows.map(r => ({ name: plain(r[0] ?? ''), e: magnitude(r[1] ?? '') ?? 0, be: plain(r[1] ?? ''), mult: plain(r[2] ?? '') }));
  const lo = Math.min(...data.map(d => d.e)) - 1, hi = Math.max(...data.map(d => d.e)) + 1;
  return (
    <div className="tbl ladder reveal" id={id}>
      <div className="tbl-legend"><span className="dot" />束缚能阶梯 · 对数轴 · 太阳为 ×1 基准</div>
      <div className="ladder-wrap">
        {data.map((d, i) => (
          <div key={i} className="ladder-row" style={{ ['--i' as string]: i }}>
            <div className="ladder-name"><b><Inline text={rows[i][0]} /></b><small>{d.be}</small></div>
            <div className="ladder-track">
              <div className="ladder-bar" style={{ ['--w' as string]: `${((d.e - lo) / (hi - lo)) * 100}%` }}>
              </div>
              <span className="ladder-mult">{d.mult}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="tbl-cap">原表列：{head.map((h, i) => <span key={i}><Inline text={h} /></span>)}</div>
    </div>
  );
}

/* ---------- 3.2 汽化 ÷ 粉碎：倍率大字卡 ---------- */
function Ratios({ head, rows, id }: { head: string[]; rows: string[][]; id?: string }) {
  return (
    <div className="tbl ratios reveal" id={id}>
      <div className="tbl-legend"><span className="dot" />{plain(head[1])} · 以坚硬岩石粉碎值 100 J/cc 为基准</div>
      <div className="ratio-grid">
        {rows.map((r, i) => (
          <div key={i} className="ratio-card" style={{ ['--i' as string]: i }}>
            <span className="ratio-v">{plain(r[1] ?? '').replace(/\s*倍$/, '')}<em> 倍</em></span>
            <h4><Inline text={r[0]} /></h4>
            <p>汽化总能量 ÷ 粉碎能量</p>
          </div>
        ))}
      </div>
      <div className="tbl-cap">原表列：{head.map((h, i) => <span key={i}><Inline text={h} /></span>)}</div>
    </div>
  );
}

export function Table({ head, rows, id }: { head: string[]; rows: string[][]; id?: string }) {
  if (head.some(h => plain(h).includes('相对太阳倍数'))) return <Ladder head={head} rows={rows} id={id} />;
  if (head.length === 2 && /÷/.test(plain(head[1] ?? ''))) return <Ratios head={head} rows={rows} id={id} />;

  const col = pickCol(head, rows);
  const val = (c: number, r: string[]) => (col && c === col.i ? (col.mode === 'stress' ? stress(r[c]) : magnitude(r[c])) : null);
  const mags = col ? rows.map(r => val(col.i, r)).filter((v): v is number => v !== null) : [];
  const mn = mags.length ? Math.min(...mags) : 0, mx = mags.length ? Math.max(...mags) : 1;
  const span = mx - mn || 1;
  const two = head.length === 2;
  const grid = useSpot<HTMLDivElement>();

  return (
    <div className={`tbl ${two ? 'tbl-two' : ''} reveal`} ref={grid} id={id}>
      {col && (
        <div className="tbl-legend">
          <span className="dot" />{col.mode === 'stress' ? '抗压 / 抗拉强度对比' : '数值对比'} · {plain(head[col.i])} · 对数刻度 · 跨度约 {span < 1 ? span.toFixed(2) : Math.round(span)} 个数量级
        </div>
      )}
      <div className="tbl-grid">
        {rows.map((r, i) => {
          const m = col ? val(col.i, r) : null;
          return (
            <article key={i} className="card" style={{ ['--i' as string]: i }}>
              <div className="card-head">
                <span className="idx">{String(i + 1).padStart(2, '0')}</span>
                <h4><Inline text={r[0] ?? ''} /></h4>
              </div>
              <dl>
                {Array.from({ length: Math.max(head.length - 1, r.length - 1) }, (_, c) => {
                  const h = head[c + 1] ?? '—';
                  const v = r[c + 1] ?? '';
                  const empty = v === '—' || v === '';
                  return (
                    <div key={c} className={`kv ${col && c + 1 === col.i ? 'kv-num' : ''} ${empty ? 'kv-empty' : ''}`}>
                      <dt><Inline text={h} /></dt>
                      <dd><Inline text={v || '—'} /></dd>
                    </div>
                  );
                })}
              </dl>
              {m !== null && (
                <div className="bar" aria-hidden>
                  <div className="bar-fill" style={{ ['--w' as string]: `${10 + 90 * (m - mn) / span}%` }} />
                  <span className="bar-tick">10^{m.toFixed(1)}</span>
                </div>
              )}
            </article>
          );
        })}
      </div>
      <div className="tbl-cap">原表列：{head.map((h, i) => <span key={i}><Inline text={h} /></span>)}</div>
    </div>
  );
}
