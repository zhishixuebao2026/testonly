export type Block =
  | { t: 'h'; level: number; text: string; id: string }
  | { t: 'p'; text: string; id: string }
  | { t: 'quote'; lines: string[]; id: string }
  | { t: 'ul'; items: string[]; id: string }
  | { t: 'ol'; items: string[]; id: string }
  | { t: 'table'; head: string[]; rows: string[][]; id: string }
  | { t: 'hr'; id: string };

export const plain = (s: string) => s.replace(/\*\*/g, '').trim();

export function parse(md: string): Block[] {
  const lines = md.replace(/\r/g, '').split('\n');
  const out: Block[] = [];
  let i = 0, hc = 0, bc = 0;
  const id = () => 'b' + (bc++);
  const row = (l: string) => l.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(s => s.trim());
  while (i < lines.length) {
    const l = lines[i];
    if (!l.trim()) { i++; continue; }
    const h = /^(#{1,6})\s+(.*)$/.exec(l);
    if (h) { out.push({ t: 'h', level: h[1].length, text: h[2].trim(), id: 's' + (hc++) }); i++; continue; }
    if (/^---+\s*$/.test(l)) { out.push({ t: 'hr', id: id() }); i++; continue; }
    if (l.startsWith('>')) {
      const q: string[] = [];
      while (i < lines.length && lines[i].startsWith('>')) { q.push(lines[i].replace(/^>\s?/, '')); i++; }
      out.push({ t: 'quote', lines: q, id: id() }); continue;
    }
    if (l.trim().startsWith('|') && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}/.test(lines[i + 1])) {
      const head = row(l); i += 2; const rows: string[][] = [];
      while (i < lines.length && lines[i].trim().startsWith('|')) { rows.push(row(lines[i])); i++; }
      out.push({ t: 'table', head, rows, id: id() }); continue;
    }
    if (/^\s*[-*]\s+/.test(l)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) { items.push(lines[i].replace(/^\s*[-*]\s+/, '')); i++; }
      out.push({ t: 'ul', items, id: id() }); continue;
    }
    if (/^\s*\d+\.\s+/.test(l)) {
      const items: string[] = [];
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) { items.push(lines[i].replace(/^\s*\d+\.\s+/, '')); i++; }
      out.push({ t: 'ol', items, id: id() }); continue;
    }
    const p: string[] = [];
    while (i < lines.length && lines[i].trim() && !/^(#|>|\||---|\s*[-*]\s|\s*\d+\.\s)/.test(lines[i])) { p.push(lines[i]); i++; }
    if (!p.length) { p.push(lines[i]); i++; }
    out.push({ t: 'p', text: p.join('\n'), id: id() });
  }
  return out;
}

const SUP: Record<string, string> = { '⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4', '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9', '⁻': '-' };
/** log10 of a value written as "3.35×10⁴⁴ J" or "40 J/cc" */
export function magnitude(s: string): number | null {
  const t = plain(s).replace(/,/g, '');
  const sci = /([\d.]+)\s*[×x]\s*10([⁰¹²³⁴⁵⁶⁷⁸⁹⁻]+)/.exec(t);
  if (sci) { const e = parseInt(sci[2].split('').map(c => SUP[c]).join('')); const m = parseFloat(sci[1]); return m > 0 ? Math.log10(m) + e : null; }
  const m2 = /([\d.]+)\s*[eE]\s*([+-]?\d+)/.exec(t);
  if (m2) { const v = parseFloat(m2[1]) * Math.pow(10, parseInt(m2[2])); return v > 0 ? Math.log10(v) : null; }
  const n = /([\d.]+)/.exec(t);
  if (n) { const v = parseFloat(n[1]); return v > 0 ? Math.log10(v) : null; }
  return null;
}
/** parse a leading physical value, normalising GPa→MPa so bars stay comparable */
export function stress(s: string): number | null {
  const t = plain(s);
  if (!/MPa|GPa|Pa/.test(t)) return null;
  const n = /([\d.]+)/.exec(t); if (!n) return null;
  let v = parseFloat(n[1]);
  if (/GPa/.test(t)) v *= 1000; else if (/kPa/.test(t)) v /= 1000;
  return v > 0 ? Math.log10(v) : null;
}

export const sup = (e: number) => {
  const M = '-0123456789', S = '-⁰¹²³⁴⁵⁶⁷⁸⁹';
  const r = Math.round(e).toString();
  return r.split('').map(c => S[M.indexOf(c)] ?? c).join('');
};
export const sci = (v: number, d = 2) => {
  if (!isFinite(v) || v <= 0) return '—';
  const e = Math.floor(Math.log10(v));
  const m = v / Math.pow(10, e);
  if (e >= -1 && e <= 4) return v.toLocaleString('zh-CN', { maximumFractionDigits: 2 });
  return `${m.toFixed(d)}×10${sup(e)}`;
};
export function parseJ(input: string): number | null {
  let t = input.trim().replace(/[Jj焦耳\s,，]/g, '');
  t = t.replace(/×\s*10\s*\^?/g, 'e').replace(/10\s*\^/g, 'e').replace(/[Ee]\+/g, 'e');
  t = t.replace(/(\d)([Ee])(\d)/g, '$1e$3');
  const m = /^(-?[\d.]+(?:e-?\d+)?)$/i.exec(t);
  if (!m) return null;
  const v = Number(m[1]);
  return isFinite(v) && v > 0 ? v : null;
}
