@echo off
chcp 65001 >nul
setlocal EnableExtensions

title DSH + QQ 机器人 一键启动

REM ============================================================
REM  开机后双击这个文件：自动用管理员权限启动 NapCat(QQ) 和 DSH
REM  放在 C:\Users\X7\.dsh\启动QQ机器人.bat
REM ============================================================

set "NAPCAT_DIR=C:\Users\X7\.dsh\napcat"
set "DSH_HOME=C:\Users\X7\.dsh"
set "OB_PORT=3001"
set "WEB_PORT=3080"
REM 快速登录：用本地登录缓存直接登小号，不用每次扫码。
REM 想临时改用别的号，把这个改成对应 QQ 号即可（0 = 关闭快速登录）。
set "BOT_QQ=3227****06"

REM ---------- 0. 自我提权 ----------
net session >nul 2>&1
if errorlevel 1 (
    echo 正在请求管理员权限...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b 0
)

cls
echo ============================================
echo    DSH + QQ 机器人 启动中
echo ============================================
echo.

REM ---------- 1. NapCat / QQ ----------
tasklist /FI "IMAGENAME eq QQ.exe" 2>nul | find /I "QQ.exe" >nul
if not errorlevel 1 (
    echo [1/3] QQ 已在运行，检查登录状态 ...
    REM QQ 进程在，但可能已经掉线（被踢/登录失效）。掉线就杀掉重开，让它走快速登录。
    powershell -NoProfile -Command "try{$r=Invoke-RestMethod 'http://127.0.0.1:3000/get_status' -TimeoutSec 5;if($r.data.online -eq $true){exit 0}else{exit 1}}catch{exit 1}" >nul 2>&1
    if not errorlevel 1 (
        echo      已在线，跳过
    ) else (
        echo      QQ 掉线了，重启 NapCat ...
        taskkill /IM QQ.exe /F >nul 2>&1
        timeout /t 3 >nul
        if exist "%NAPCAT_DIR%\launcher.bat" (
            start "" /D "%NAPCAT_DIR%" "%NAPCAT_DIR%\launcher.bat" -q %BOT_QQ%
        )
    )
) else (
    echo [1/3] 启动 NapCat ...
    if not exist "%NAPCAT_DIR%\launcher.bat" (
        echo      找不到 launcher.bat，跳过
    ) else (
        start "" /D "%NAPCAT_DIR%" "%NAPCAT_DIR%\launcher.bat" -q %BOT_QQ%
    )
)

REM ---------- 2. 等 OneBot 端口 ----------
echo [2/3] 等待 OneBot 端口 %OB_PORT% ...
set /a WAIT_N=0

:WAIT_PORT
set /a WAIT_N+=1
powershell -NoProfile -Command "try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',%OB_PORT%);$c.Close();exit 0}catch{exit 1}" >nul 2>&1
if not errorlevel 1 goto PORT_OK
if %WAIT_N% GEQ 60 goto PORT_TIMEOUT
timeout /t 2 >nul
goto WAIT_PORT

:PORT_TIMEOUT
echo      超时（可能还在扫码登录），先继续启动 DSH
goto START_DSH

:PORT_OK
echo      端口已就绪

:START_DSH
REM ---------- 3. DSH ----------
echo [3/3] 启动 DSH Web ...
powershell -NoProfile -Command "try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',%WEB_PORT%);$c.Close();exit 0}catch{exit 1}" >nul 2>&1
if not errorlevel 1 (
    echo      DSH 已在运行，跳过
) else (
    start "DSH Web" cmd /k "cd /d %DSH_HOME% && dsh web"
)

echo.
echo ============================================
echo  完成
echo    Web UI : http://127.0.0.1:%WEB_PORT%
echo    机器人 : 小号 3227****06
echo.
echo  注意：NapCat 那个黑窗口不要关，
echo        关掉机器人就下线。
echo ============================================
timeout /t 6 >nul
