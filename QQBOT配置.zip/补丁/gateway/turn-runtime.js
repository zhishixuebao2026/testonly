// 回合运行时：入站消息的主流程（限流、鉴权、识图、模型回合、回复）与图片缓存清扫。
// 从 gateway/plugin.js 搬出（P3 2.4 第三阶段，只搬不改）：状态仍在插件 state，
// 其余依赖（会话/工具/权限/flowGate/适配器写帧）全部注入。
import { promises as fsPromises } from 'node:fs';
import { join } from 'node:path';
import { chunkMarkdown } from '../message/chunk.js';
import { imageCacheDir, isInside } from '../session/workspace.js';
import { shouldStream } from '../message/stream.js';
import { pickInterim } from '../message/interim.js';

export function createTurnRuntime(deps) {
  const {
    TAG, getConfig, getState, ctx, describeError, sendReply, writeToAdapter, callAdapterAction,
    adminApi, sessionApi, toolsApi, flowGate, valves, acquireOrder, takeTurnSlot, notifyThrottled,
    inboundMaxChars, inboundQueueMax, handleAuthMessage, handleFlowCommand, requestFlowAuth, ownerQq,
    describeImages, deliverFlowArtifacts, handleModelCommand, parseModelCommand, flowInterceptKind,
    stripInvisible, buildPersonaHint, sanitizeDisplayName, summarizeTurnReason, idValue, streamBridge, allowlistOk, qqMsgRootSync, uid, warnOwnerMissingOnce, isReplyToSelf,
    noteAssistantSend,
  } = deps;

  /** 内部错误只记日志，绝不发到聊天里（用户要求：报错不要发出去）。 */
  function sendError(frame, text) {
    const where = frame && frame.message_type === 'group' ? '群聊 ' + String(frame.group_id) : '私聊 ' + String(frame.user_id);
    console.error(TAG + ' [已静默] ' + where + ' ' + text);
  }

  /** 「只 @ 没正文」的等待表：会话键 → { cancel }。 */
  const bareAtPending = new Map();
  /** 已经挂起等过一次的消息 id：延时到了重入时不再挂起。 */
  const bareAtWaited = new Set();
  /** 已注入过的人格指纹：会话 id → 指纹。放在插件作用域，entry 被重建也不会丢。 */
  const personaVersions = new Map();

  /**
   * 把一条回复拆成 1-3 段，像真人分几条发。
   * 规则：
   *  - 有换行就按换行拆（QQ 里消息内部的 \n 会显示成一段空白，很难看）；
   *  - 没换行但句子多且够长，按句末标点拆；
   *  - 每段内部不再保留换行（换成空格），避免出现空白行。
   * 第一段带引用，后面几段不带（引用只挂一次）。
   */
  /**
   * 「我不想说」的占位符。主动发言的提示词里写了「不想说就什么内容都不要输出」，
   * 但模型经常不是真的留空，而是写一句「（无输出）」「（不说了）」「[沉默]」——
   * 这些不该当成发言发到群里（真出过：群里收到一条「（无输出）」）。
   */
  function isSilencePlaceholder(text) {
    const raw = String(text).trim();
    if (raw === '') return true;
    // 去掉各种括号、引号、空白、标点，只留内容
    const core = raw
      .replace(/[（(【\[「『《<]/g, '')
      .replace(/[）)】\]」』》>]/g, '')
      .replace(/[\s"'`。，、,,.。!！?？~～…—-]/g, '');
    if (core === '') return true;
    return /^(无输出|不输出|没有输出|不发言|不说话|不出声|沉默|略|空|无|省略|跳过|省略号|什么都不说|不说了|空着|pass|skip|none|null|empty|nooutput|silent)$/i.test(core);
  }

  /**
   * 「括号里的自言自语」——模型把内心旁白当成正文输出了。
   *
   * 典型：（KK柠在问抹茶，不是我，不插嘴）。
   * 注意**不能见括号就杀**：网上聊天本来就常用括号补语气（笑）（小声）（跑），
   * 那是正常正文。所以只认旁白词，不认括号本身。
   */
  function isMetaAside(text) {
    const raw = String(text).trim();
    if (raw === '') return true;
    // 旁白词：都是「我在决定要不要说」的语言，正常聊天不会这么讲。
    const asideWords = /(不插嘴|不说话|没说话|没话接|没开口|不出声|不评论|不回应|不接了|跳过|略过|置身事外|与我无关|不关我事|不是问我|没叫我|没提我|没点名|回的是|是在回|这不该我|我不该|我应该|让我查查|我先看看|只是发图|只发图)/;
    if (asideWords.test(raw) !== true) return false;
    // 旁白通常很短；长句里出现这些词多半是在正常接话，不拦。
    if (raw.length > 60) return false;
    // 整条被括号包住 = 明确是在「旁白」，直接拦。
    if (/^[（(【\[][\s\S]*[）)】\]]$/.test(raw) === true) return true;
    // 没括号但很短又全是旁白词，也拦（例：没话接，跳过）。
    return raw.length <= 40;
  }

  function splitReply(text) {
    const raw = String(text).trim();
    if (raw === '') return [];
    if (isSilencePlaceholder(raw) === true) return [];
    if (isMetaAside(raw) === true) return [];
    const flat = (s) => s.replace(/\s*\n+\s*/g, ' ').replace(/\s{2,}/g, ' ').trim();

    // 先按换行切；有 2 段以上就直接用
    let parts = raw.split(/\n+/).map(flat).filter((s) => s !== '');
    if (parts.length >= 2) {
      if (parts.length <= 3) return parts;
      return [...parts.slice(0, 2), parts.slice(2).join(' ')];
    }

    // 单段：特别短的（一句「好」「行吧」）不拆，其余按句子拆
    if (raw.length <= 24) return [flat(raw)];

    parts = raw
      .split(/(?<=[。！？!?…~])\s*/)
      .map(flat)
      .filter((s) => s !== '');
    if (parts.length <= 1) return [flat(raw)];
    if (parts.length === 2) return parts;
    return [...parts.slice(0, 2), parts.slice(2).join('')];
  }

  /** 分条发送：段间留一点间隔，像人在打字。 */
  async function sendSplit(frame, text, withQuote) {
    const parts = splitReply(text);
    if (parts.length === 0) return;
    for (let i = 0; i < parts.length; i += 1) {
      sendReply(frame, parts[i], i === 0 && withQuote === true);
      if (i < parts.length - 1) {
        await new Promise((resolve) => {
          try { ctx.timeout(() => resolve(), 700); } catch { resolve(); }
        });
      }
    }
    // 正常回复也要记一笔：否则定时扫描以为这个群没人跟它说话，过几分钟又插一句。
    try {
      if (frame.message_type === 'group' && typeof noteAssistantSend === 'function') {
        noteAssistantSend(frame.group_id, Array.isArray(parts) ? parts.join(' ') : text);
      }
    } catch { /* 记账失败不影响回复 */ }
  }

  async function acceptMessage(frame) {
    // 去重放在最前面：走完准入再判重，重投消息会先被计入 skipped 并可能触发回复提示。
    // 例外：空 @ 等满 10 秒后的「重入」不是重投，是同一个 frame 的第二次进入。
    // msgIds.hit() 第一次调用就会把它标记为已见，所以这里必须放行，否则重入会被当成重复丢掉
    // （2026-11-07 的 bug：日志说「等满了」，但群里什么都没发出来）。
    const frameId = (frame.message_id === undefined || frame.message_id === null) ? '' : String(frame.message_id).trim();
    if (frame.__bareAtResume !== true && frameId !== '' && getState().msgIds.hit(frameId) === true) {
      getState().stats.skipped += 1;
      getState().stats.duplicates += 1;
      return;
    }
    const isGroup = frame.message_type === 'group';
    const policy = isGroup ? getConfig().group : getConfig().private;
    const chatId = isGroup ? frame.group_id : frame.user_id;

    // 空 @ 等待合并：有人先 @ 一下、正文在下一句时，把这两条接起来当一条处理。
    // 若这个会话正挂着一个「刚被 @、还没正文」的等待，就取消它，把当前这条当作正文。
    const pendKey = (isGroup ? 'g' : 'p') + String(chatId);
    let adoptedBareAt = false;
    if (bareAtPending.has(pendKey)) {
      const pend = bareAtPending.get(pendKey);
      bareAtPending.delete(pendKey);
      try { pend.cancel(); } catch { /* 已经触发 */ }
      adoptedBareAt = true;
      console.log(TAG + ' 空 @ 合并：接上了下一条消息');
    }

    if (policy.enabled !== true) { getState().stats.skipped += 1; return; }
    const selfId = frame.self_id === null || frame.self_id === undefined ? null : String(frame.self_id);
    if (selfId !== null && String(frame.user_id) === selfId) { getState().stats.skipped += 1; return; }

    // 默认准入是 fail-closed（#27）：没有拥有者就**不驱动任何会话**。
    // 以前 owners 为空只是「没人有额外权限」，而白名单为空又表示「不限」，于是装好即对外开放——
    // 任何人私聊或在群里 @ 一下就能消耗拥有者的额度，并把插件当成打内网/搜网页的跳板。
    if (ownerQq() === '') {
      getState().stats.skipped += 1;
      warnOwnerMissingOnce();
      // 只在私聊里回配置指引：群里回一句就等于把配置口暴露给所有人看，还容易被当成噪声。
      if (isGroup !== true) {
        sendReply(frame, '还没配置拥有者，我不会驱动会话。请到「插件 → 已安装 → @sputnikzaychik/dsh-qq-bot → 基本 → 拥有者 QQ 号」填上你自己的 QQ 号后重试。');
      }
      return;
    }

    // 白名单必须排在**所有**处理之前（2026-10-28 审计 A2）。
    // 以前它排在群管理指令和 /model 之后，于是 group.allow 收紧到单群之后，
    // 其它群里的 /help、/whoami 仍然会拿到回复——白名单实际只挡住了「进 Agent 回合」，
    // 没挡住「在群里说话」。默认准入是 fail-closed，这里也照同一个口径。
    if (!allowlistOk(policy.allow, chatId)) { getState().stats.skipped += 1; return; }

    // 等满 10 秒重入的那次：当作已挂起过，不再挂起一次，直接按空 @ 正常处理。
    const resumedFromBareAt = frameId !== '' && bareAtWaited.has(frameId);

    // 群管理指令优先：不要求 @ 机器人，也不会送给模型。
    if (isGroup) {
      const handled = await adminApi.handleAdminCommand(frame, typeof frame.text === 'string' ? frame.text : '');
      if (handled === true) return;
    }
    // /model：模型查看与切换（拥有者专用）。
    // 群里被 @ 时文本前面会带 "@qq "，指令前也可能有空格——统一交给 parseModelCommand 剥。
    if (adminApi.isOwner(frame.user_id) === true) {
      const parsedModel = parseModelCommand(stripInvisible(frame.text), String(getConfig().admin.prefix || '/'));
      if (parsedModel !== null) {
        const chatKey = isGroup === true ? 'g' + String(frame.group_id) : 'p' + String(frame.user_id);
        sendReply(frame, await handleModelCommand(parsedModel.rest, chatKey), true);
        return;
      }
    }
    // 私聊二次授权：/auth 动态码 + /flow 流程脚本管理。只认「拥有者 + 私聊 + 消息首位」，
    // 命中即在此结束：不进 Agent 回合，动态码不落会话（不会被历史或日志带出去）。
    const flowInterceptOn = getConfig().flowAuth !== undefined && getConfig().flowAuth !== null && getConfig().flowAuth.enabled === true;
    // 判定与解析必须用同一份文本：只剥一次，否则零宽串会被「拦下来但解析失败」，消息人间蒸发。
    const flowText = stripInvisible(frame.text);
    const flowKind = flowInterceptOn === true
      ? flowInterceptKind({ isGroup, isOwner: adminApi.isOwner(frame.user_id), text: flowText })
      : null;
    if (flowKind === 'auth') { await handleAuthMessage(frame, flowText); return; }
    if (flowKind === 'flow') { await handleFlowCommand(frame, flowText); return; }


    let text = typeof frame.text === 'string' ? frame.text : '';
    const frameHasImage = (Array.isArray(frame.image_urls) && frame.image_urls.length > 0)
      || (Array.isArray(frame.replyImageUrls) && frame.replyImageUrls.length > 0);

    // 命令前缀（如 /ai）：命中视同点名（bot 被调用），豁免 requireAt；
    // 与群管理指令同理，也走「QQ 回复消息流程」引用回复。
    let prefixHit = false;
    if (getConfig().commandPrefix !== '') {
      if (!text.startsWith(getConfig().commandPrefix)) { getState().stats.skipped += 1; return; }
      text = text.slice(getConfig().commandPrefix.length).trim();
      prefixHit = true;
    }

    // 被回复（引用）了 bot 消息：视同 @ 处理（群聊 + 开关开启时）。
    // 查询被引用消息的发送者是否 bot 自己；查不到按非 bot 处理。
    // 前缀指令已豁免 @，无需再查。
    let repliedToBot = false;
    // 只要开关开启且消息带了被引用消息，就查发送者是否 bot 自己；
    // 不依赖 requireAt——requireAt 关闭（群=全部）时回复了 bot 同样要识别并引用回复。
    if (!prefixHit && isGroup && getConfig().reply.botReply === true
      && frame.reply_to !== null && frame.reply_to !== undefined) {
      repliedToBot = await isReplyToSelf(frame);
    }

    // bot 是否被点名（@ 了 bot / 回复了 bot / 前缀指令）：被点名才用「QQ 回复消息流程」引用回复。
    let botMentioned = repliedToBot || prefixHit;
    let mentionHit = false;
    if (isGroup && policy.requireAt === true && !prefixHit) {
      // 判定只认「at 段」，不认正文（2026-10-28 审计 A1）：
      //   1) 用户在正文里手打 '@机器人QQ' 会命中旧的 includes 判定，requireAt 形同虚设；
      //   2) '@10001' 是 '@100012' 的前缀，正常 @ 别人会被误判成 @ 了我，
      //      而旧代码 split('@10001').join(' ') 剥前缀时还会把对方 QQ 号咬掉一位。
      // 适配器都带 frame.mentions；自定义适配器没给时退化成「@数字 + 数字边界」的保守匹配，
      // 宁可漏判（要求 @）也不误判（把别人的 @ 算成我的）。
      const mentions = Array.isArray(frame.mentions) ? frame.mentions.map((qq) => String(qq)) : null;
      const mention = selfId === null ? null : '@' + selfId;
      const mentionPattern = mention === null ? null : mention.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?!\\d)';
      const atMe = (mentions !== null && selfId !== null)
        ? mentions.includes(selfId)
        : (mentionPattern === null ? text.includes('@') : new RegExp(mentionPattern).test(text));
      if (atMe === true) {
        if (mentionPattern !== null) text = text.replace(new RegExp(mentionPattern, 'g'), ' ').trim();
        botMentioned = true;
        mentionHit = true;
      } else if (!repliedToBot && adoptedBareAt !== true) { getState().stats.skipped += 1; return; }
    }

    // 例外：回复了 bot 但正文 @ 的是别人（剥离 @bot 后仍有 @）——
    // 这条可能不是对 bot 说的，不强制引用回复，交给 bot 自行判断是否继续回复。
    if (repliedToBot && !mentionHit && /@/.test(text)) botMentioned = false;

    // 只 @ 一下、没有正文也没有图：先挂起，等 bareAtWaitSeconds 秒看有没有下一句。
    // 期间来消息的话，开头那段的合并逻辑会取消这个定时器并把新消息当正文。
    const bareAtWait = Math.max(0, Math.floor(Number(getConfig().reply.bareAtWaitSeconds ?? 10) || 0));
    if (adoptedBareAt !== true && resumedFromBareAt !== true
      && mentionHit === true && text === '' && frameHasImage === false && bareAtWait > 0) {
      if (frameId !== '') bareAtWaited.add(frameId);
      console.log(TAG + ' 只 @ 没正文：等 ' + bareAtWait + ' 秒看有没有下一句');
      const placeholder = { cancel: () => { /* 占位，真正的 cancel 下面补 */ } };
      bareAtPending.set(pendKey, placeholder);
      const fire = () => {
        if (!bareAtPending.has(pendKey)) return;
        bareAtPending.delete(pendKey);
        console.log(TAG + ' 等满了：把这条空 @ 当正式消息回');
        // 标记为重入：绕过入口的重复消息判重（那条消息 id 已经在挂起时被记为见过了）。
        frame.__bareAtResume = true;
        acceptMessage(frame).catch((error) => {
          console.error(TAG + ' 空 @ 延时回合失败：' + describeError(error));
        });
      };
      try {
        const timer = ctx.timeout(fire, bareAtWait * 1000);
        bareAtPending.set(pendKey, { cancel: () => { if (typeof timer === 'function') timer(); } });
      } catch {
        bareAtPending.delete(pendKey);
        fire();
      }
      return;
    }

    // 不再主动拉取聊天上下文塞进会话（fetchReplyContext/replyTargetQQs 已移除）：
    // 需要群内近期消息/图片时，由 AI 主动调 qq_history 工具自取。
    // 只保留「被回复消息的图片」收集，供 describeImages 一并识别（回复引用流程不受影响）。
    if (frame.reply_to !== null && frame.reply_to !== undefined
      && (repliedToBot || mentionHit)) {
      try { await sessionApi.collectReplyImageUrls(frame); }
      catch (error) { console.log(TAG + ' 收集被回复图片失败（忽略）：' + describeError(error)); }
    }

    // 无正文：bot 被点名（@ / 回复 bot / 命令前缀）时也给一个占位正文让它回应（如纯回复/纯 @）；
    // 否则（普通空消息）照旧跳过。
    if (text === '' && !(typeof frame.images === 'number' && frame.images > 0)) {
      if (!botMentioned) { getState().stats.skipped += 1; return; }
      text = '（本条消息无正文，仅点名了 bot）';
    }
    // 单条长度上限（#22）：超长正文不进提示词，否则一条几百 KB 的消息就能顶掉整轮上下文。
    const inboundCap = inboundMaxChars();
    if (text.length > inboundCap) {
      text = text.slice(0, inboundCap) + '\n…（消息过长，已截断：原文 ' + text.length + ' 字，只处理前 ' + inboundCap + ' 字）';
    }
    getState().stats.accepted += 1;

    // 入口路由：按「拥有者 / 非拥有者」决定走哪条会话与 preset；
    // 两个 preset 都不配就共用一条会话（行为与以前一致）。
    const route = sessionApi.sessionRoute(frame);
    const entryKey = getConfig().perChatSession ? route.entryKey : 'shared';
    const sessionId = getConfig().perChatSession ? route.sessionId : 'qqbot-shared';
    const preset = getConfig().perChatSession ? route.preset : getConfig().agentPreset;

    const fixedTitle = (getConfig().session !== null && getConfig().session !== undefined && getConfig().session.fixedName === true)
      ? await buildFixedTitle(frame.message_type === 'group' ? 'group' : 'private',
        frame.message_type === 'group' ? frame.group_id : frame.user_id,
        frame.message_type === 'group' ? '' : sanitizeDisplayName(frame.sender === null || frame.sender === undefined ? '' : (frame.sender.card || frame.sender.nickname)))
      : null;
    // 从这里开始的处理必须按到达顺序进行（建会话、查群成员鉴权都是 await）。
    const releaseOrder = acquireOrder(entryKey);
    let entry;
    try { entry = await sessionApi.getEntry(entryKey, sessionId, preset, fixedTitle); }
    catch (error) {
      getState().stats.errors += 1;
      console.error(TAG + ' 为 ' + entryKey + ' 建会话失败：' + describeError(error));
      sendError(frame, '内部错误：无法创建对话会话');
      releaseOrder();
      return;
    }

    // 记录本条消息的说话人与身份：qqgroup 工具的鉴权依据（三路并行）。
    const speakerAuthority = await adminApi.resolveAuthority(frame.user_id, isGroup ? chatId : null);
    entry.groupId = isGroup ? String(chatId) : null;
    // 记录本条触发消息，qq_history 工具以此锚定图片识别窗口（最新提及）。
    entry.currentFrame = frame;
    entry.speaker = {
      userId: String(frame.user_id),
      groupId: entry.groupId,
      tier: speakerAuthority.tier,
      owner: speakerAuthority.owner === true,
      sources: speakerAuthority.sources,
    };

    // 本回合是否允许使用 DSH 内部工具：只有拥有者（或显式放开 guestDshTools）才行。
    const allowDsh = speakerAuthority.owner === true || getConfig().auth.guestDshTools === true;

    // 入站限流（#22）：同一个人在同一会话里每分钟最多驱动 N 个回合。
    // 必须等「这条消息确定会驱动回合」之后再计费：放在入口处会把群里的闲聊、
    // 图片消息和没点名的消息全算进去，活跃群里几十条闲聊就能把额度刷光，
    // 之后真正的 @ 反而被静默丢掉（群里不回复，只加 skipped 计数）。
    if (takeTurnSlot((isGroup === true ? 'g' : 'p') + String(chatId) + ':' + String(frame.user_id)) !== true) {
      getState().stats.skipped += 1;
      notifyThrottled(frame, isGroup);
      releaseOrder();
      return;
    }

    const generation = entry.generation;
    // 入队时就把发言人钉住：排队期间新消息不会改动这一回合的身份判定。
    const turnSpeaker = { userId: String(frame.user_id), groupId: entry.groupId, tier: speakerAuthority.tier, owner: speakerAuthority.owner === true, sources: speakerAuthority.sources };
    // 队列深度上限（#22）：排太多就直接拒收，不让消息无限堆在内存里（每条都要跑一个完整回合）。
    const queueMax = inboundQueueMax();
    const pendingTurns = Number(entry.pendingTurns === undefined ? 0 : entry.pendingTurns) + 1;
    if (pendingTurns > queueMax) {
      getState().stats.skipped += 1;
      sendError(frame, '这条先不处理：同一会话排队的回合太多了');
      releaseOrder();
      return;
    }
    entry.pendingTurns = pendingTurns;
    entry.queue = entry.queue
      .then(() => runTurn(entry, frame, text, generation, allowDsh, botMentioned, turnSpeaker))
      .then(() => deliverFlowArtifacts(entry, frame))
      .catch((error) => {
        getState().stats.errors += 1;
        console.error(TAG + ' ' + entryKey + ' 回合失败：' + describeError(error));
      })
      .then(() => { entry.pendingTurns = Math.max(0, Number(entry.pendingTurns || 1) - 1); });
    // 已挂上会话队列：顺序由 entry.queue 保证，这里释放顺序锁。
    releaseOrder();
  }

  /**
   * 识别 QQ 消息里的图片：下载图片，用 DSH 已配置的视觉模型（从自定义 providers
   * 里选，协议/baseURL/apiKey 全部沿用 DSH 原本填写的）做图片理解，返回识别文本。
   * 返回 { error, text }：error 非空 = 不应继续（可读报错提示）；text 非空 = 识别结果。
   */


  /** 昵称/群名片 → 一行安全文本（去 \r\n 与方括号、压空白、限长）。 */
  /**
   * 被 @ 时自动带上「群聊最近几条」。
   * 会话里只有「@ 过它的消息 + 它自己的回复」，群里没人 @ 它的闲话它根本看不到，
   * 于是经常答非所问（「这个怎么样」——哪个？）。
   * 这里在回合开始前拉一次历史，只取当前这条之前的 N 条，尽量避开会话里已有的内容。
   */
  async function buildRecentContext(frame) {
    try {
      // 每群可单独设条数：perGroupContext 里写了的群优先，没写的用全局 recentContextCount。
      const replyCfg = getConfig().reply !== null && getConfig().reply !== undefined ? getConfig().reply : {};
      const chatKey = String(frame.message_type === 'group' ? frame.group_id : frame.user_id);
      let want = Math.max(0, Math.floor(Number(replyCfg.recentContextCount) || 0));
      const perGroup = replyCfg.perGroupContext;
      if (perGroup !== null && perGroup !== undefined && typeof perGroup === 'object') {
        const hit = perGroup[chatKey] !== undefined
          ? perGroup[chatKey]
          : perGroup[String(frame.message_type) + '-' + chatKey];
        if (hit !== undefined && hit !== null && String(hit) !== '') want = Math.max(0, Math.floor(Number(hit) || 0));
      }
      if (want === 0) return '';
      const isGroup = frame.message_type === 'group';
      const res = isGroup
        ? await callAdapterAction('get_group_msg_history', { group_id: frame.group_id, count: want + 3 }, 8000)
        // 私聊也照样拉：之前这里直接 return，于是私聊只看得到当前一条，
        // 上下文全靠 DSH 会话本身——会话被压缩/重建时就断片了。
        : await callAdapterAction('get_friend_msg_history', { user_id: frame.user_id, count: want + 3 }, 8000);
      if (res === null || res === undefined || res.ok !== true) return '';
      const list = res.data !== null && res.data !== undefined && Array.isArray(res.data.messages) ? res.data.messages : [];
      if (list.length === 0) return '';
      const selfId = String(getState().proactive !== null && getState().proactive !== undefined && getState().proactive.selfId !== null
        ? getState().proactive.selfId : '');
      const curId = frame.message_id === undefined || frame.message_id === null ? '' : String(frame.message_id);
      const lines = [];
      // 从旧到新，跳过当前这条，取最后 want 条
      for (const m of list) {
        if (m === null || typeof m !== 'object') continue;
        if (curId !== '' && String(m.message_id) === curId) continue;
        const uid = String(m.user_id !== undefined ? m.user_id : (m.sender && m.sender.user_id));
        const sender = m.sender !== null && m.sender !== undefined ? (m.sender.card || m.sender.nickname || '') : '';
        const who = uid !== '' && uid === selfId ? '你自己' : sanitizeDisplayName(sender) || '某人';
        let body = '';
        if (Array.isArray(m.message)) {
          for (const seg of m.message) {
            if (seg === null || typeof seg !== 'object') continue;
            const type = String(seg.type ?? '').toLowerCase();
            if (type === 'text') body += String(seg.data && seg.data.text !== undefined ? seg.data.text : '');
            else if (type === 'image') body += '[图片]';
            else if (type === 'face') body += '[表情]';
            // 视频/文件/语音这些以前直接漏掉，上下文里就只剩「谁：」什么都没有。
            else if (type === 'video') body += '[视频]';
            else if (type === 'record') body += '[语音]';
            else if (type === 'file') body += '[文件]';
            else if (type === 'markdown') {
              const c = String(seg.data && seg.data.content !== undefined ? seg.data.content : '');
              body += (/!\[[^\]]*\]\([^)]+\)/.test(c) === true || /<img/i.test(c) === true) ? '[图片]' : '';
            }
          }
        } else if (typeof m.raw_message === 'string') {
          body = m.raw_message;
        }
        body = body.replace(/\s+/g, ' ').trim().slice(0, 120);
        if (body === '') continue;
        // 带时间：不然「最后一条图」和「这条问题」谁先谁后它只能靠猜，容易指错图。
        let hhmm = '';
        const rawTime = m.time !== undefined ? Number(m.time) : (m.timestamp !== undefined ? Number(m.timestamp) : 0);
        if (Number.isFinite(rawTime) && rawTime > 0) {
          const d2 = new Date(rawTime * 1000);
          hhmm = String(d2.getHours()).padStart(2, '0') + ':' + String(d2.getMinutes()).padStart(2, '0') + ' ';
        }
        lines.push(hhmm + who + '：' + body);
      }
      const tail = lines.slice(-want);
      if (tail.length === 0) return '';
      const where = isGroup ? '这个群' : '这个私聊';
      return '（以下是' + where + '在你收到这条消息之前的最近 ' + tail.length + ' 条，供理解上下文，不是要你逐条回复）\n'
        + tail.join('\n');
    } catch (error) {
      if (getConfig().proactive !== undefined && getConfig().proactive.verbose === true) {
        console.log(TAG + ' 拉群历史失败（忽略）：' + describeError(error));
      }
      return '';
    }
  }

  /**
   * 「这条消息在回复谁、回了什么」。
   *
   * 和群历史分开：私聊、recentContextCount=0、拉历史失败这些情况下，
   * 引用关系照样要拿到——之前它埋在 buildRecentContext 里，一 return 就全丢了，
   * 于是模型只看到一个 [回复]，不知道回的是哪句。
   */
  async function buildReplyAttr(frame) {
    try {
      const replyTo = frame.reply_to;
      if (replyTo === null || replyTo === undefined || String(replyTo) === '') return '';
      const idText = String(replyTo).replace(/[^0-9]/g, '');
      if (idText === '') return '';
      const got = await callAdapterAction('get_msg', { message_id: Number(idText) }, 6000);
      const d = got !== null && got !== undefined && got.ok === true ? got.data : null;
      if (d === null || d === undefined) return '';
      const selfId = String(getState().proactive !== null && getState().proactive !== undefined && getState().proactive.selfId !== null
        ? getState().proactive.selfId : '');
      const ruid = String(d.user_id !== undefined ? d.user_id : (d.sender && d.sender.user_id));
      const rsender = d.sender !== null && d.sender !== undefined ? (d.sender.card || d.sender.nickname || '') : '';
      const rwho = ruid !== '' && ruid === selfId ? '你自己' : sanitizeDisplayName(rsender) || '某人';
      let rbody = '';
      let sawCard = false;
      if (Array.isArray(d.message)) {
        for (const seg of d.message) {
          if (seg === null || typeof seg !== 'object') continue;
          const type = String(seg.type ?? '').toLowerCase();
          if (type === 'text') rbody += String(seg.data && seg.data.text !== undefined ? seg.data.text : '');
          else if (type === 'image') rbody += '[图片]';
          else if (type === 'face') rbody += '[表情]';
          // 推送机器人用 markdown 段发图（![#824px #1225px](url)），别把它当成纯文字。
          else if (type === 'markdown') {
            const c = String(seg.data && seg.data.content !== undefined ? seg.data.content : '');
            if (/!\[[^\]]*\]\([^)]+\)/.test(c) === true || /<img/i.test(c) === true) { rbody += '[图片]'; sawCard = true; }
            else rbody += c.replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\[\]\([^)]*\)/g, '');
          }
          else if (type === 'json' || type === 'xml' || type === 'forward') { rbody += '[卡片消息]'; sawCard = true; }
        }
      }
      rbody = rbody.replace(/\s+/g, ' ').trim().slice(0, 120);
      const fallback = sawCard === true ? '[卡片，看不到文字]' : '[无法读取文字，可能是图片或语音]';
      return '（这条消息是在回复 ' + rwho + ' 的内容：' + (rbody === '' ? fallback : rbody) + '）';
    } catch (error) {
      return '';
    }
  }

  /**
   * 会话标题：优先用群名/昵称，拿不到再退回群号。
   * 名字缓存在模块级 Map 里，群名改了也不会频繁去问协议端。
   */
  const titleNameCache = new Map();
  async function buildFixedTitle(kind, id, hintName) {
    const rawId = String(id);
    if (kind !== 'group') {
      const nick = String(hintName || '').trim();
      return '私聊_' + (nick === '' ? rawId : nick + '(' + rawId + ')');
    }
    if (titleNameCache.has(rawId)) return '群聊_' + titleNameCache.get(rawId);
    let name = '';
    try {
      const got = await callAdapterAction('get_group_info', { group_id: Number(rawId) }, 6000);
      if (got !== null && got !== undefined && got.ok === true && got.data !== null && got.data !== undefined) {
        name = String(got.data.group_name || got.data.groupName || '').trim();
      }
    } catch (error) {
      name = '';
    }
    const finalName = name === '' ? rawId : name;
    titleNameCache.set(rawId, finalName);
    return '群聊_' + finalName;
  }

  function buildPrompt(frame, text, entry, recentContext, replyAttr) {
    const sender = frame.sender;
    // 昵称/群名片是外部输入，进提示词前必须清洗：换行与方括号能让访客伪造出第二行身份头。
    const who = sanitizeDisplayName(sender === null || sender === undefined ? '' : (sender.card || sender.nickname));
    // 空正文有两种情况，必须分开：
    //  ① 真发了图（image_urls / replyImageUrls 非空）→ 说「发来了一张图片」；
    //  ② 只 @ 了一下、下面那句还在路上 → 说「只喊了你一声」，别让它以为自己没收到东西。
    const hasImage = (Array.isArray(frame.image_urls) && frame.image_urls.length > 0)
      || (Array.isArray(frame.replyImageUrls) && frame.replyImageUrls.length > 0);
    let body = text !== ''
      ? text
      : (hasImage
        ? '（发来了一张图片）'
        : '（只 @ 了你一声，没带正文。多半是下一句马上就到——你可以先应一句「咋了」，或者等他把话说完整。）');
    // 本条没附图时先说清楚：上下文里的 [图片] 是过去别人发的，不是现在这张。
    if (hasImage !== true) {
      body += '\n（这条消息本身没有附图。下面上下文里出现的 [图片] 都是别人以前发的，不是这次要你看的图，别拿它们当本条的内容来说。'
        + '如果你在回复某条消息，那条里的图会单独识别并给出描述——那是可以看、可以聊的。'
        + '但要是有人明确让你看群里最近的图（「看看新图」「上面那几张怎么样」），这是正当请求：调 qq_history 拉近期消息，它带图片识别，直接看，别说「没图」。）';
    }
    if (getConfig().reply.contextHeader !== true) return body;
    const where = frame.message_type === 'group' ? 'QQ群 ' + String(frame.group_id) : 'QQ私聊';
    // 把说话人身份带给 Agent：非拥有者的请求是否该执行，由 Agent 结合权限判断。
    let tag = '';
    // 身份标签同样读本回合的快照：排队串台时 entry.speaker 可能已经是别人的了。
    const speakerSnap = (entry !== null && entry !== undefined)
      ? ((entry.turnSpeaker !== undefined && entry.turnSpeaker !== null) ? entry.turnSpeaker : entry.speaker)
      : null;
    if (speakerSnap !== null && speakerSnap !== undefined) {
      const tier = adminApi.TIER_LABEL[speakerSnap.tier] === undefined ? speakerSnap.tier : adminApi.TIER_LABEL[speakerSnap.tier];
      const src = Array.isArray(speakerSnap.sources) && speakerSnap.sources.length > 0 ? '｜' + speakerSnap.sources.join('+') : '';
      tag = ' · 身份:' + tier + src;
    }
    let head = '[' + where + ' · ' + who + '(' + String(frame.user_id) + ')' + tag + ']';
    // 当前时间：群里连着发几张图时，靠它分辨「最后那条」是哪条。
    const nowDate = new Date();
    const nowLabel = String(nowDate.getHours()).padStart(2, '0') + ':' + String(nowDate.getMinutes()).padStart(2, '0');
    head = '（现在 ' + nowLabel + '）\n' + head;
    // 群聊上下文（可选）：拼在正文前面，让它知道「这句话接的是什么」。
    const context = recentContext === undefined || recentContext === null ? '' : String(recentContext).trim();
    // 引用关系紧贴正文：不管有没有群历史、是不是私聊，都要让它知道在回哪一句。
    const quoted = replyAttr === undefined || replyAttr === null ? '' : String(replyAttr).trim();
    let out = head + (quoted === '' ? '' : '\n' + quoted) + ' ' + body;
    if (context !== '') out = context + '\n\n' + out;
    return out;
  }

  /**
   * 中间发言循环：每过一会儿看一眼会话日志，把「说完但后面还有内容」的 assistant 段落发一条。
   * 最后一条 assistant 消息不在这里发（那是最终结算的正文），所以不会出现「先说一遍再正式回一遍」。
   * 返回停止函数；回合结束（whenIdle）时务必调用，否则会继续说下去。
   */
  function startInterimLoop(entry, frame, afterId, onInterim) {
    const conf = getConfig().reply || {};
    const maxPerTurn = Math.max(0, Math.floor(Number(conf.interimMaxPerTurn) || 0));
    if (conf.interim !== true || maxPerTurn === 0) return () => {};
    const gapMs = Math.max(500, Math.floor(Number(conf.interimMinGapMs) || 2500));
    const spoken = new Set();
    let sent = 0;
    let stopped = false;
    let cancel = null;
    const schedule = () => {
      if (stopped === true || sent >= maxPerTurn) return;
      try { cancel = ctx.timeout(tick, gapMs); } catch (error) { cancel = null; }
    };
    const tick = () => {
      cancel = null;
      if (stopped === true) return;
      const agent = entry.agent;
      const session = (agent === null || agent === undefined) ? null : agent.session;
      if (session === null || session === undefined || typeof session.deriveMessages !== 'function') { schedule(); return; }
      let messages = [];
      try { messages = session.deriveMessages(); } catch (error) { messages = []; }
      const picks = pickInterim(messages, afterId);
      for (const item of picks) {
        // 这里的 sent < maxPerTurn 由 schedule() 保证，不需要再判一次。
        if (spoken.has(item.id)) continue;
        spoken.add(item.id);
        sent += 1;
        // 不传 withQuote：中间发言不引用、也不 @ 任何人。
        // 流式模式下（官方 v2 私聊）交给桥累积，不单独再发一条。
        if (typeof onInterim === 'function') onInterim(item.text);
        else sendReply(frame, item.text);
        console.log(TAG + ' 中间发言（' + String(item.text.length) + ' 字）：' + item.text.slice(0, 40).replace(/\s+/g, ' '));
        break;      // 一次最多发一条，间隔交给下一轮定时器
      }
      schedule();
    };
    schedule();
    return () => {
      stopped = true;
      if (typeof cancel === 'function') { try { cancel(); } catch (error) { /* 已经触发过了 */ } }
    };
  }

  async function runTurn(entry, frame, text, generation, allowDsh, quoteReply, turnSpeaker) {
    // 发言人快照：排队期间的其它消息会覆盖 entry.speaker，闸门必须看本回合的。
    if (turnSpeaker !== undefined && turnSpeaker !== null) entry.turnSpeaker = turnSpeaker;
    // 上一轮可能留下没被消费的「已付码」记账（例如守卫放行后工具自己没跑成），新回合一律清空。
    entry.flowAllow = undefined;
    if (entry.generation !== generation) return;   // 已被 interrupt 作废

    // 必须在串行回合内部设置：如果在接收入口设，排队的两条消息（先拥有者后访客）
    // 会互相覆盖，导致后一个回合用错权限。
    entry.dshAllowed = allowDsh === true;
    if (entry.guardUnavailable === true && allowDsh !== true) {
      sendError(frame, '本会话无法安装工具隔离，已拒绝这次驱动');
      return;
    }

    entry.turns += 1;

    // 群上下文先取出来存变量：下面拼提示词要用，图片提醒也要看它有没有 [图片]。
    const recentContext = frame.__rawText === true ? '' : await buildRecentContext(frame);
    const body = frame.__rawText === true
      ? text
      : buildPrompt(frame, text, entry, recentContext, await buildReplyAttr(frame));
    // 人格（persona）与首轮提示：会话第一轮追加一次；另外人格文本变了也补注入一次
    // （改了人格之后，老会话不该一直用旧版本——以前它要等会话被删掉才会更新）。
    const firstHints = [];
    const personaHint = buildPersonaHint(getConfig().persona);
    if (personaHint !== '') firstHints.push(personaHint);
    if (getConfig().reply.firstTurnHint !== '') firstHints.push(getConfig().reply.firstTurnHint);
    const personaVersion = personaHint === '' ? '' : String(personaHint.length) + ':' + personaHint.slice(0, 40) + ':' + personaHint.slice(-40);
    const versionKey = String(entry.sessionId);
    const lastVersion = personaVersions.get(versionKey);
    // 没有版本号也当「变了」：进程重启后这张表是空的，于是每个老会话补注入一次。
    const personaChanged = personaVersion !== '' && lastVersion !== personaVersion;
    if (personaChanged === true) console.log(TAG + ' 人格已更新，给会话 ' + versionKey + ' 补注入一次');
    const injectHints = entry.turns === 1 || personaChanged === true;
    if (personaVersion !== '') personaVersions.set(versionKey, personaVersion);
    const userText = injectHints === true && firstHints.length > 0
      ? body + '\n\n' + firstHints.join('\n\n')
      : body;

    const content = [{ type: 'text', text: userText }];
    const vision = await describeImages(frame, entry);
    if (vision.error !== '') {
      // 识图失败：只写控制台，绝不把技术报错发到聊天里；也不中断回合——
      // 让模型知道「有张图没看清」，用正常口吻自己圆过去。
      console.error(TAG + ' 识图失败（已静默，继续走模型）：' + vision.error);
      content[0] = { type: 'text', text: userText + '\n\n（对方发了一张图，但没能加载出来，你看不到。别编内容，自然地让他重发或者说说别的。）' };
    }
    if (vision.text !== '') {
      // 把视觉识别结果并入用户消息，让 Agent 依据图片内容作答
      // 本条消息带图片：随附导出的原图路径（留档），并提示 Agent 结合用户发言作答、
      // 需确认身份时联网查证。图片仅用于本次会话，结算后自动删除。
      const imgPaths = Array.isArray(vision.paths) && vision.paths.length > 0
        ? '\n\n[图片文件] ' + vision.paths.join('\n')
        : '';
      // 上下文里最近还有别的 [图片] 时点名提醒：只识本张往往不够
      // （群友连发一串图、再 @ 你说「这怎么样」，看的就是整串）。
      const contextHasImages = String(recentContext || '').includes('[图片]');
      const moreHint = contextHasImages === true
        ? '\n（注意：上面上下文里还有最近的图片没识别过。要是大家刷屏发了一串图、或你判断问的不只是这一张，就调 qq_history 把近几条连图一起拉来看，别只看这一张就下结论。）'
        : '';
      content[0] = { type: 'text', text: userText + '\n\n[图片识别] ' + vision.text + imgPaths
        + '\n\n（本条消息含图片。请结合用户发言作答；自行提炼关键词调用qq_websearch qq_imgsearch进行查找（漫画用 kind=comic），尽量勿凭空猜测。）' + moreHint };
    }
    const message = {
      id: uid('qqmsg'),
      role: 'user',
      content,
      source: { kind: 'user' },
    };

    let acked = false;
    let cancelAck = null;
    if (getConfig().reply.ackAfterMs > 0 && getConfig().reply.ackText !== '') {
      try {
        cancelAck = ctx.timeout(() => { acked = true; sendReply(frame, getConfig().reply.ackText); }, getConfig().reply.ackAfterMs);
      } catch { /* 定时器不可用就跳过 */ }
    }

    // 流式：只有「官方 v2 + 私聊 + 有被动回复 msg_id + 开关打开」才走；其它协议保持原来的分段回复。
    const streamOn = shouldStream({
      protocol: getConfig().protocol,
      streaming: getConfig().protocols.qqOfficial !== undefined && getConfig().protocols.qqOfficial !== null && getConfig().protocols.qqOfficial.streaming === true,
      isGroup: frame.message_type === 'group',
      messageId: frame.message_id,
    });
    const streamKey = streamOn === true ? ('o:' + String(frame.user_id) + ':' + String(frame.message_id)) : null;
    let streamedText = '';
    const onInterim = streamKey === null ? null : (fragment) => {
      streamedText += String(fragment);
      streamBridge.push(streamKey, null, String(fragment));
    };
    if (streamKey !== null) {
      streamBridge.push(streamKey, { messageType: 'private', targetId: String(frame.user_id), msgId: String(frame.message_id) }, '');
    }
    // 中间发言：回合没跑完时，模型先说的那几句单独发出去（不引用、不 @）。
    const stopInterim = startInterimLoop(entry, frame, message.id, onInterim);
    try {
      entry.agent.followup(message);
      await entry.agent.whenIdle();
    } finally {
      stopInterim();
      if (typeof cancelAck === 'function') cancelAck();
    }

    const reply = extractReply(entry.agent, message.id);
    if (reply === '') {
      // 失败提示总是作为正式回复发出（即使 ack 已发过「正在处理」也不吞掉结论）
      sendError(frame, '本轮没有产生文字回复：' + lastTurnReason(entry.agent));
      // 这一支以前直接 return，跳过了下面的缓存清理：失败的回合一定留图。
      await cleanupImageCache(entry);
      return;
    }
    if (streamKey !== null) {
      // 最后一帧用 done 收尾：把中间没发到的剩余文本补进去（官方流式是全量替换）。
      const rest = streamedText !== '' && reply.startsWith(streamedText) ? reply.slice(streamedText.length) : (streamedText === '' ? reply : reply);
      if (rest !== '') streamBridge.push(streamKey, null, rest);
      const ended = await streamBridge.end(streamKey);
      if (ended === null || ended.ok !== true) {
        // 桥没发出任何帧（例如官方接口拒绝）：退化为普通发送，保证用户至少拿到一条。
        await sendSplit(frame, reply, quoteReply === true);
      }
    } else {
      await sendSplit(frame, reply, quoteReply === true);
    }
    getState().stats.replies += 1;

    // 会话结算：删除本会话缓存的图片目录（<QQ_msg>/qq-images/<会话id>/），
    // 图片仅用于本轮识图与联网查证，结算后不留残留；会话与工作区保留。
    await cleanupImageCache(entry);
  }

  /**
   * 删掉本会话的图片缓存目录。异常/中断的回合走不到这里，靠启动后的定期 sweep 兜底
   * （见 sweepStaleImages），这里只负责「正常收尾时立刻清掉」。
   */
  async function cleanupImageCache(entry) {
    const imgRoot = imageCacheDir(entry !== null && entry !== undefined && entry.sessionId ? entry.sessionId : 'default');
    try {
      // 路径已由 safeSessionId 净化；删除前再复核一次归属，绝不递归删 QQ_msg 之外的东西。
      if (isInside(join(qqMsgRootSync(), 'qq-images'), imgRoot) !== true) {
        console.log(TAG + ' 图片缓存目录越界，拒绝删除：' + imgRoot);
        return;
      }
      await fsPromises.rm(imgRoot, { recursive: true, force: true });
    } catch (cleanErr) {
      console.log(TAG + ' 图片缓存清理失败：' + describeError(cleanErr));
    }
  }

  const IMAGE_SWEEP_INTERVAL_MS = 6 * 60 * 60 * 1000;
  const IMAGE_SWEEP_MAX_AGE_MS = 24 * 60 * 60 * 1000;

  /**
   * 图片缓存的兜底收尸：回合抛异常、被取消、或者 qq_draw 的 gen 目录，都不会走
   * cleanupImageCache。这里按 mtime 清掉 24 小时以上的东西——正常回合结束就删了，
   * 剩下的按定义都是漏网的。只动 <QQ_msg>/qq-images 之下，不做递归越界。
   */
  async function sweepStaleImages() {
    const root = join(qqMsgRootSync(), 'qq-images');
    const now = Date.now();
    let entries;
    try { entries = await fsPromises.readdir(root, { withFileTypes: true }); } catch { return; }
    let removed = 0;
    for (const ent of entries) {
      const abs = join(root, ent.name);
      try {
        const st = await fsPromises.stat(abs);
        if (now - st.mtimeMs <= IMAGE_SWEEP_MAX_AGE_MS) continue;
        if (ent.isDirectory()) await fsPromises.rm(abs, { recursive: true, force: true });
        else await fsPromises.rm(abs, { force: true });
        removed += 1;
      } catch { /* 正在被写真删不掉，下一轮再说 */ }
    }
    if (removed > 0) console.log(TAG + ' 清理过期图片缓存 ' + removed + ' 项');
  }

  function scheduleImageSweep() {
    const tick = () => {
      void sweepStaleImages().catch((error) => {
        console.log(TAG + ' 图片缓存清理失败：' + describeError(error));
      });
      try { ctx.timeout(tick, IMAGE_SWEEP_INTERVAL_MS); } catch { /* 插件已卸载 */ }
    };
    try { ctx.timeout(tick, 8000); } catch { /* 定时器不可用就跳过 */ }
  }

  /** 只取 afterId（本条用户消息 id）之后新增的 assistant 文本；本轮无回复返回 ''，绝不回退重发上一轮内容 */
  function extractReply(agent, afterId) {
    const session = (agent === null || agent === undefined) ? null : agent.session;
    if (session === null || session === undefined || typeof session.deriveMessages !== 'function') return '';
    const messages = session.deriveMessages();
    if (!Array.isArray(messages)) return '';
    let start = 0;
    if (afterId !== undefined && afterId !== null) {
      const at = messages.findIndex((m) => m !== null && typeof m === 'object' && m.id === afterId);
      if (at < 0) return '';      // 锚点不在日志里：宁可不回，也不回退到上一轮内容
      start = at + 1;
    }
    for (let index = messages.length - 1; index >= start; index -= 1) {
      const message = messages[index];
      if (message === null || typeof message !== 'object' || message.role !== 'assistant') continue;
      if (!Array.isArray(message.content)) continue;
      let text = '';
      for (const block of message.content) {
        if (block !== null && typeof block === 'object' && block.type === 'text' && typeof block.text === 'string') text += block.text;
      }
      if (text.trim() !== '') return text.trim();
    }
    return '';
  }

  /** 把 turn/end reason 清洗成一句话：只保留失败号（400/503/429…），隐藏 request id 等敏感内容 */
  function lastTurnReason(agent) {
    try {
      const session = agent.session;
      const events = session.snapshotEvents(0, session.seq);
      for (let index = events.length - 1; index >= 0; index -= 1) {
        if (events[index].type === 'turn/end') return summarizeTurnReason(events[index].data.reason);
      }
      return '本回合未结束（' + String(events.length) + ' 个事件）';
    } catch (error) {
      return '读取日志失败：' + describeError(error);
    }
  }

  /** 协议 id 归一：纯数字转 number，其余（qq-official 的 ROBOT1.0_… 之类）原样保留字符串。 */


  // runTurn 必须导出：auth-flow 的「授权后续跑」经 getRunTurn() 调它（接在 plugin.js 的
  // `getRunTurn: () => turnRuntime.runTurn`）。漏掉这一个键不会报错，只会被那边的 .catch
  // 吞成一行「授权后续跑失败」——用户侧表现为动态码用掉了、被拦下的任务再也没继续。
  /**
   * 定时主动发言的「会话版」：走真实会话回合，于是有工具、有记忆、DSH 里也看得见。
   * 和 acceptMessage 的区别：不检查 @、不限流、不排队（定时器自己已经限过频），
   * 正文由 instruction 直接给，不加「某人：」的来源前缀。
   */
  async function runProactiveTurn(groupId, instruction) {
    const gid = String(groupId);
    const owner = String(ownerQq() || '');
    const frame = {
      message_type: 'group',
      group_id: gid,
      user_id: owner,
      message_id: '',
      text: '',
      sender: { card: '群友', nickname: '群友' },
      mentions: [],
      image_urls: [],
      replyImageUrls: [],
      reply_to: null,
      raw_message: '',
      __rawText: true,
    };
    const route = sessionApi.sessionRoute(frame);
    const entryKey = getConfig().perChatSession ? route.entryKey : 'shared';
    const sessionId = getConfig().perChatSession ? route.sessionId : 'qqbot-shared';
    const preset = getConfig().perChatSession ? route.preset : getConfig().agentPreset;
    // 标题规则和正常回合保持一致，否则第一次由定时发言建出来的会话会叫另一套名字。
    const fixedTitle = (getConfig().session !== null && getConfig().session !== undefined && getConfig().session.fixedName === true)
      ? await buildFixedTitle('group', gid, '')
      : null;
    const releaseOrder = acquireOrder(entryKey);
    let entry;
    try {
      entry = await sessionApi.getEntry(entryKey, sessionId, preset, fixedTitle);
    } catch (error) {
      releaseOrder();
      console.error(TAG + ' 定时发言建会话失败：' + describeError(error));
      return false;
    }
    try {
      entry.groupId = gid;
      entry.currentFrame = frame;
      entry.speaker = { userId: owner, groupId: gid, tier: 'owner', owner: true, sources: ['proactive'] };
      // allowDsh = true：这是它自己的主动行为，拥有者和它自己一样有工具权限。
      entry.queue = entry.queue.then(() => runTurn(entry, frame, instruction, entry.generation, true, false, entry.speaker));
      await entry.queue;
      return true;
    } catch (error) {
      getState().stats.errors += 1;
      console.error(TAG + ' 定时发言回合失败：' + describeError(error));
      return false;
    } finally {
      releaseOrder();
    }
  }

  return { acceptMessage, scheduleImageSweep, runTurn, runProactiveTurn };
}
