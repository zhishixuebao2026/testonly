// 识图：下载消息里的图片、调视觉模型描述、拼进上下文。
// 从 gateway/plugin.js 搬出（P3 2.4 第三阶段，只搬不改）。
import { promises as fsPromises } from 'node:fs';
import { join } from 'node:path';
import { publicFetch } from '../shared/http.js';
import { imageCacheDir } from '../session/workspace.js';

export function createVision(deps) {
  const { TAG, getConfig, ctx, describeError, fetchImageUrls, groupNameOf } = deps;
  async function describeImages(frame, entry) {
    const vision = getConfig().vision || {};
    if (vision.enabled !== true) return { error: '', text: '' };
    let urls = [
      ...(Array.isArray(frame.image_urls) ? frame.image_urls : []),
      ...(Array.isArray(frame.replyImageUrls) ? frame.replyImageUrls : []),
    ];
    // 注意：这里不再给每条消息打诊断日志（之前刷屏太厉害），只在真失败时打。
    // 帧里没有图片地址时，先问协议端要一次；还是没有就说明这条消息**本来就没图**，
    // 必须安静返回 —— 否则每条纯文字都会被塞一句「图没刷出来」，非常离谱。
    if (urls.length === 0 && typeof fetchImageUrls === 'function') {
      try {
        const extra = await fetchImageUrls(frame);
        if (Array.isArray(extra) && extra.length > 0) urls = extra;
      } catch (error) {
        console.log(TAG + ' 识图取地址失败：' + describeError(error));
      }
    }
    if (urls.length === 0) return { error: '', text: '', paths: [] };
    const attachments = ctx.attachments;
    if (attachments === undefined || attachments === null || typeof attachments.saveImage !== 'function') {
      return { error: '（图片视觉已开启，但附件服务不可用，请检查 DSH 的 attachments 插件是否启用）', text: '' };
    }
    // 解析视觉模型：显式配置优先（用户从 DSH 自定义 providers 里选），否则用会话当前模型
    const provider = (typeof vision.provider === 'string' && vision.provider !== '') ? vision.provider
      : (entry && entry.agent && entry.agent.options && typeof entry.agent.options.provider === 'string'
        ? entry.agent.options.provider : '');
    const model = (typeof vision.model === 'string' && vision.model !== '') ? vision.model
      : (entry && entry.agent && entry.agent.options && typeof entry.agent.options.model === 'string'
        ? entry.agent.options.model : '');
    if (provider === '' || model === '') {
      return { error: '（图片视觉：未能确定视觉模型。请到「插件 → 已安装 → @sputnikzaychik/dsh-qq-bot → 能力 → 识图与绘图」里填写 provider 与 model，例如你的自定义 provider / deepseek-v4-flash-vision-exp）', text: '' };
    }
    // 识图模型链：主模型 → fallbackModels 里按顺序排的备选 → 官方 base64 直连。
    // 顺序试、谁先给出文字算谁，中间失败不声张，全部失败才让模型知道「图没看出来」。
    const chainSeen = new Set();
    const visionChain = [];
    const pushChain = (p, m) => {
      const pp = String(p || '').trim();
      const mm = String(m || '').trim();
      if (pp === '' || mm === '') return;
      const key = pp + '/' + mm;
      if (chainSeen.has(key)) return;
      chainSeen.add(key);
      visionChain.push({ provider: pp, model: mm });
    };
    pushChain(provider, model);
    // 新版：数组，可写多个备选
    if (Array.isArray(vision.fallbackModels)) {
      for (const item of vision.fallbackModels) {
        if (item === null || typeof item !== 'object') continue;
        pushChain(item.provider, item.model);
      }
    }
    // 旧版：单个 fallback*
    pushChain(
      typeof vision.fallbackProvider === 'string' ? vision.fallbackProvider : '',
      typeof vision.fallbackModel === 'string' ? vision.fallbackModel : '',
    );
    // 模型不支持图片时给可读报错（仅当能力明确可知；未知则放行交给请求本身判断）
    if (typeof ctx.llm === 'object' && ctx.llm !== null && typeof ctx.llm.resolveModelInfo === 'function') {
      try {
        const info = await ctx.llm.resolveModelInfo(provider, model);
        const modalities = (info && Array.isArray(info.inputModalities)) ? info.inputModalities : null;
        if (modalities !== null && !modalities.includes('image')) {
          return { error: '（当前视觉模型 ' + provider + '/' + model + ' 不支持图片识别。'
            + '请到「插件 → 已安装 → @sputnikzaychik/dsh-qq-bot → 能力 → 识图与绘图」切换支持图片的模型，例如 deepseek-v4-flash-vision-exp 或 deepseek-v4.1-flash-request）', text: '' };
        }
      } catch (error) {
        console.log(TAG + ' 视觉能力探测失败（放行，交给请求本身）：' + describeError(error));
      }
    }
    const max = Math.max(1, Math.min(vision.maxImages ?? 3, urls.length));
    const timeoutMs = vision.downloadTimeoutMs ?? 10000;
    const descriptions = [];
    const savedPaths = [];
    // 图片来源：哪来的群/私聊、谁发的。日志里缺这个时，多群同时刷图根本对不上号。
    const sourceOf = async (f) => {
      if (f === null || f === undefined) return '';
      const isGroup = String(f.message_type) === 'group' || String(f.message_type) === 'guild';
      // 群号字段在不同协议/帧里叫法不一，挨个取，取不到就别硬写 undefined。
      const rawId = isGroup
        ? (f.group_id ?? f.groupId ?? f.chat_id ?? f.target_id ?? '')
        : (f.user_id ?? f.userId ?? f.sender_id ?? '');
      // 拿不到 id 就不显示来源（表情包打标这类合成帧本来就没群号），
      // 别再打一个「群?」占地方。
      if (rawId === '' || rawId === null || rawId === undefined) return '';
      const id = String(rawId);
      // 群名：能拿到就写成「群名(群号)」，一眼看得出是哪个群；拿不到就只写号。
      let name = '';
      if (isGroup === true && typeof groupNameOf === 'function') {
        try {
          name = String(await groupNameOf(id) || '').replace(/\s+/g, ' ').trim();
        } catch (error) {
          name = '';
        }
      }
      const label = name === '' ? id : name + '(' + id + ')';
      const nick = f.sender !== null && f.sender !== undefined ? (f.sender.card || f.sender.nickname || '') : '';
      const who = nick === '' ? '' : '(' + String(nick).replace(/\s+/g, ' ').slice(0, 20) + ')';
      // 消息 id + 正文片段：把「识图结果」和「哪条聊天消息」钉在一起，
      // 同一群连发几张表情包时日志才不会各自飘着对不上号。
      const mid = f.message_id === undefined || f.message_id === null || String(f.message_id) === ''
        ? '' : ' #' + String(f.message_id);
      // 正文片段用来认消息，CQ 码（[CQ:reply,id=...][CQ:at,...]）全是噪音，先剥掉。
      const rawText = typeof f.raw_message === 'string' ? f.raw_message : '';
      const txt = rawText
        .replace(/\[CQ:[^\]]*\]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 30);
      const hint = txt === '' ? '' : ' 「' + txt + '」';
      return (isGroup ? '群' : '私聊') + label + mid + who + hint;
    };
    const source = await sourceOf(frame);
    // 只有真的有图才打一行，避免纯文字消息刷屏。
    console.log(TAG + ' 识图开始：' + urls.length + ' 张（本次至多识别 ' + Math.min(max, urls.length) + ' 张），'
      + String(frame.message_type) + (source === '' ? '' : ' [' + source + ']'));
    // 缓存图片导出：把原图写入 <QQ_msg>/qq-images/<会话id>/（留档用，识图由视觉模型完成）；
    // 会话结算（本轮回复完成后）会整体删除该缓存目录，见 runTurn 收尾。
    const imgRoot = imageCacheDir(entry ? entry.sessionId : 'default');
    /** 依次下载并识别一批 url；返回实际成功的张数。 */
    async function tryUrls(list) {
      let ok = 0;
      for (let i = 0; i < list.length; i += 1) {
        const url = list[i];
        if (typeof url !== 'string' || !/^https?:\/\//.test(url)) continue;
        try {
          const downloaded = await downloadImage(url, timeoutMs);
          if (downloaded === null) {
            console.log(TAG + ' 图片下载失败：' + url.slice(0, 80));
            continue;
          }
          // 识图按「模型链」依次试：主模型（vision.provider/model）→ 备模型（vision.fallback*）
          // → 官方 base64 直连。任何一环拿到文字就收工，**中间失败不往外抛**，
          // 这样不会出现「先回一句看不了、随后又答上」的割裂。
          const realType = sniffImageType(downloaded.data) || downloaded.mediaType || 'image/jpeg';
          let ref = null;
          try {
            ref = await attachments.saveImage({ data: downloaded.data, mediaType: realType });
          } catch (saveError) {
            console.log(TAG + ' 附件服务不收这张图（' + realType + '）：' + describeError(saveError) + ' → 改用直连');
            ref = null;
          }
          let text = '';
          for (const attempt of visionChain) {
            if (text !== '') break;
            try {
              // 每次尝试限时 5 分钟：maxTokens 拉到 131072 后，爱思考的模型
              // 能连着流好几分钟（实测猫窝一张图卡住整轮没回复）。
              // 超时就当这级失败，立刻换下一个模型，别让一张图拖死一条消息。
              text = await Promise.race([
                askVision(attempt.provider, attempt.model, ref, i + 1, source),
                new Promise((resolve) => {
                  const timer = setTimeout(() => resolve('__timeout__'), 300000);
                  if (typeof timer.unref === 'function') timer.unref();
                }),
              ]);
              if (text === '__timeout__') {
                text = '';
                console.log(TAG + ' 识图超时（' + attempt.provider + '/' + attempt.model + ' 第' + (i + 1)
                  + '张，5 分钟没出结果）→ 换下一个模型');
              }
            } catch (chainError) {
              console.log(TAG + ' 识图链 ' + attempt.provider + '/' + attempt.model + ' 抛错：' + describeError(chainError));
              text = '';
            }
            if (text !== '' && attempt.provider !== provider) {
              console.log(TAG + ' 识图由备选模型接手：' + attempt.provider + '/' + attempt.model);
            }
          }
          // 全链都空：最后一搏，官方 base64 直连（不看 mediaType，也不依赖附件引用）。
          if (text === '') {
            text = await askVisionDirect(Object.assign({}, downloaded, { mediaType: realType }), i + 1);
          }
          if (text !== '') { descriptions.push(text); ok += 1; }
          // 导出原图到工作目录（会话 id 区分），随消息附上路径
          try {
            const ext = downloaded.mediaType === 'image/png' ? 'png'
              : downloaded.mediaType === 'image/webp' ? 'webp'
                : downloaded.mediaType === 'image/gif' ? 'gif' : 'jpg';
            const abs = join(imgRoot, 'qq-' + Date.now() + '-' + i + '.' + ext);
            await fsPromises.mkdir(imgRoot, { recursive: true });
            await fsPromises.writeFile(abs, downloaded.data);
            savedPaths.push(abs);
          } catch (saveErr) {
            console.log(TAG + ' 图片导出失败（不影响识别）：' + describeError(saveErr));
          }
        } catch (error) {
          console.log(TAG + ' 图片识别失败（跳过）：' + describeError(error));
        }
      }
      return ok;
    }

    const tried = new Set();
    const first = urls.slice(0, max);
    for (const u of first) tried.add(u);
    let got = await tryUrls(first);

    // 兜底：帧里没 url 或全失败时，回头问协议端要这条消息的图片地址再试一次。
    // 群聊的实时帧有时只给 file、不给可下载的 url，只有拉历史才拿得到。
    if (got === 0 && typeof fetchImageUrls === 'function') {
      try {
        const extra = await fetchImageUrls(frame);
        const fresh = (Array.isArray(extra) ? extra : []).filter((u) => typeof u === 'string' && /^https?:\/\//.test(u) && !tried.has(u));
        if (fresh.length > 0) {
          console.log(TAG + ' 识图兜底：从协议端补到 ' + fresh.length + ' 个图片地址，重试');
          for (const u of fresh) tried.add(u);
          got = await tryUrls(fresh.slice(0, max));
        }
      } catch (error) {
        console.log(TAG + ' 识图兜底取地址失败：' + describeError(error));
      }
    }
    if (descriptions.length === 0) {
      // paths 必须一起返回：调用方据此清理已落盘的原图。以前这里丢掉 savedPaths，
      // 于是「识别全失败」这一支写进用户文档目录的图再没人知道，永远删不掉。
      console.log(TAG + ' 识图全失败：' + urls.length + ' 个地址，成功 0 张（首地址 ' + String(urls[0] || '').slice(0, 70) + '）');
      return { error: '（图片视觉：图片下载或识别失败，请稍后重试）', text: '', paths: savedPaths };
    }
    const joined = descriptions.join('\n');
    console.log(TAG + ' 识图完成：成功 ' + got + '/' + urls.length + ' 张，共 ' + joined.length + ' 字'
      + (source === '' ? '' : ' [' + source + ']'));
    return { error: '', text: joined, paths: savedPaths };
  }

  /** 下载一张 http(s) 图片，返回 { data: Uint8Array, mediaType } 或 null。 */
  async function downloadImage(url, timeoutMs) {
    // 走 publicFetch：公网校验 + 地址钉死 + 逐跳校验 + 8MB 上限。
    // 图片 URL 来自消息里的 CQ 码（[CQ:image,url=...]）或协议端帧，属外部输入，
    // 以前这里直接 fetch 且 arrayBuffer 整包读入——一条消息就能打内网或撑爆内存。
    try {
      const res = await publicFetch(url, { binary: true, timeoutMs, maxBytes: 8 * 1024 * 1024 });
      if (res.status < 200 || res.status >= 300) return null;
      const ct = String(res.contentType === undefined || res.contentType === null ? '' : res.contentType).split(';')[0].trim().toLowerCase();
      let mediaType = null;
      if (['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(ct)) mediaType = ct;
      else if (ct === '') {
        mediaType = /\.png$/i.test(url) ? 'image/png'
          : /\.webp$/i.test(url) ? 'image/webp'
            : /\.gif$/i.test(url) ? 'image/gif' : 'image/jpeg';
      } else {
        return null;
      }
      const bytes = new Uint8Array(/** @type {any} */ (res.body));
      if (bytes.length === 0) return null;
      return { data: bytes, mediaType };
    } catch {
      return null;
    }
  }

  /**
   * 这段文字是不是「拒答」而不是图片描述。
   *
   * 日日新 flash 遇到它觉得敏感的图会返回一段客气话（「这张图片的内容不适合详细讨论…」），
   * 既不是空串也不报错，于是被当成成功、后续备选模型根本没机会上场。
   * 判据：短（<200 字）且命中拒绝口径，不可能是正经的图片描述。
   */
  function looksLikeRefusal(text) {
    const t = String(text || '').trim();
    if (t === '') return false;
    if (t.length > 200) return false;
    const low = t.toLowerCase();
    // ① 中文固定说法：不靠枚举整句，用「拒绝动词 + 动作对象」的组合匹配。
    //    实测踩过两种：「我无法确认或提供该特定图像的相关分析信息」，
    //    以及图没加载成功时它复读「① 无法查看图片内容 ② 无法查看图片内容…」。
    if (/(无法|不能|不便|没办法|不提供|不予)[^。！？\n]{0,12}(确认|提供|查看|看到|识别|读取|分析|讨论|描述|评价|回答|协助|处理|判断|解读)/.test(t) === true) return true;
    if (/(抱歉|很抱歉|不好意思)[^。！？\n]{0,20}(无法|不能|不便)/.test(t) === true) return true;
    // ② 英文说法
    if (/\b(i can't|i cannot|i'm unable|unable to|cannot (help|analyze|discuss|assist))\b/.test(low) === true) return true;
    // ③ 兜底关键词（保持原有覆盖面）
    const patterns = [
      '不适合讨论', '不适合详细讨论', '违反规定', 'inappropriate', 'not appropriate',
    ];
    return patterns.some((p) => low.includes(p.toLowerCase()));
  }

  /**
   * 通用识图提示词（两条链路共用：DSH llm 与官方 base64 直连）。
   * 不预设图里有人；先判类型再说要点；颜色等细节只写看得清的。
   */
  function VISION_PROMPT(index) {
    return '这是用户发来的第 ' + index + ' 张图片。用简体中文说明，不要写分析过程：\n'
      + '① 这是什么类型的图：人像/二次元插画/聊天或网页截图/文档表格/商品食物/风景/表情包/合成梗图/其他；\n'
      + '② 主体是什么（人或物、在做什么、想表达什么）；\n'
      + '③ 明显的可见细节：配色、构图、显著物件或文字位置；\n'
      + '④ 把图里看得见的文字原样抄下来（中/日/英，含界面文字、水印、签名）；\n'
      + '⑤ 颜色、发色、服装、眼睛颜色这类细节，只写确定看得清的，看不清就写「看不清/不确定」，不要凭印象补；\n'
      + '⑥ 不要猜测图里没有的信息，不要给人物安身份；文字像歌名/标题就注明「这看起来是标题」。';
  }

  /** 用 DSH 的 llm 服务（走已注册的 provider 适配器）对一张图片做识别，返回识别文本。 */
  async function askVision(provider, model, ref, index, where) {
    const source = typeof where === 'string' ? where : '';
    const llm = ctx.llm;
    if (llm === undefined || llm === null || typeof llm.stream !== 'function') return '';
    const messages = [{
      role: 'user',
      content: [
        // 通用提示词：不预设图里有「人」。先判类型，再按类型说要点，
        // 颜色/外形这类细节明确要求「看不清就说不确定」，避免它按印象补配色。
        { type: 'text', text: VISION_PROMPT(index) },
        { type: 'image', attachment: ref },
      ],
    }];
    let out = '';
    try {
      // maxTokens 因模型而异，填错就是 400（实测）：
      //   sensenova-6.8-flash       允许 [1, 131072]
      //   sensenova-6.8-flash-lite  只允许 [1, 65536]  ← 填 131072 直接拒
      // 之前统一填 131072，导致 lite 每次必 400、识图一路掉到官方兜底（花钱）。
      // 这里按模型名给上限：lite 用 65536，其余 131072。
      const modelName = String(model || '').toLowerCase();
      const maxTokensForModel = modelName.includes('lite') ? 65536 : 131072;
      let reasoning = 0;
      let finish = '';
      let finishDetail = '';
      for await (const chunk of llm.stream({
        provider,
        model,
        messages,
        maxTokens: maxTokensForModel,
      })) {
        if (chunk === null || chunk === undefined) continue;
        if (chunk.type === 'text-delta' && typeof chunk.text === 'string') out += chunk.text;
        else if (chunk.type === 'reasoning-delta' && typeof chunk.text === 'string') reasoning += chunk.text.length;
        else if (chunk.type === 'finish') {
          finish = String(chunk.reason?.kind ?? chunk.reason ?? '');
          const errMsg = chunk.reason?.error?.message ?? chunk.reason?.message ?? '';
          if (typeof errMsg === 'string' && errMsg !== '') finishDetail = errMsg.slice(0, 120);
        }
      }
      // 把「思考了多少、为什么结束」留下来：空返回到底是审核拒、超预算还是断流，靠这个区分。
      globalThis.__dshQqBotLastVision = { reasoning, finish, finishDetail };
      if (out.trim() === '') {
        console.log(TAG + ' 视觉请求空返回（' + provider + '/' + model + ' 第' + index + '张图'
          + (source === '' ? '' : ' [' + source + ']') + '，思考 '
          + reasoning + ' 字，结束=' + (finish === '' ? '未知' : finish)
          + (finishDetail === '' ? '' : '：' + finishDetail.replace(/\s+/g, ' ')) + '）');
      } else if (finish === 'max-tokens') {
        console.log(TAG + ' 视觉请求被预算截断（' + provider + '/' + model + (source === '' ? '' : ' [' + source + ']')
          + '，思考 ' + reasoning + ' 字，正文 ' + out.trim().length + ' 字）');
      } else if (out.trim() !== '') {
        // 成功也报一声：只打前 60 个字，够看出它认成了什么，又不刷屏。
        console.log(TAG + ' 识图成功（' + provider + '/' + model + ' 第' + index + '张'
          + (source === '' ? '' : ' [' + source + ']') + '，'
          + out.trim().length + ' 字）：' + out.trim().replace(/\s+/g, ' ').slice(0, 60));
      }
    } catch (error) {
      console.log(TAG + ' 视觉请求失败（' + provider + '/' + model + ' 第' + index + '张）：' + describeError(error));
      return '';
    }
    // 拒答（格式上「成功」但内容不是描述）当成失败处理：让备选模型接着试。
    if (looksLikeRefusal(out) === true) {
      console.log(TAG + ' 视觉模型拒答（' + provider + '/' + model + ' 第' + index + '张，'
        + out.trim().length + ' 字）：' + out.trim().replace(/\s+/g, ' ').slice(0, 40) + ' → 交给下一个模型');
      return '';
    }
    return out.trim();
  }

  /**
   * 按文件头判断图片真实类型。QQ 的图经常把 webp/gif 报成 jpeg，
   * 附件服务会因此拒收（Unsupported or malformed image data）。
   */
  function sniffImageType(buf) {
    if (!Buffer.isBuffer(buf) || buf.length < 12) return '';
    if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
    if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
    if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) return 'image/gif';
    if (buf.slice(0, 4).toString('ascii') === 'RIFF' && buf.slice(8, 12).toString('ascii') === 'WEBP') return 'image/webp';
    if (buf.slice(4, 8).toString('ascii') === 'ftyp') return 'image/avif';
    return '';
  }

  /**
   * 直连官方 API 的兜底识图：不走 DSH 的附件通道，直接把 base64 塞进 image_url。
   * 实测「附件引用」这条路在官方 DS 上会返回空文本，而 base64 直连正常。
   * 密钥从 ~/.dsh/.credentials.yaml 的 DEEPSEEK_API_KEY 读；读不到就直接放弃。
   */
  async function askVisionDirect(downloaded, index) {
    try {
      const credPath = 'C:\\Users\\X7\\.dsh\\.credentials.yaml';
      const raw = await fsPromises.readFile(credPath, 'utf8');
      const m = /^\s*DEEPSEEK_API_KEY:\s*(\S+)\s*$/m.exec(raw);
      if (m === null) return '';
      const key = m[1];
      const b64 = Buffer.from(downloaded.data).toString('base64');
      const mediaType = downloaded.mediaType || 'image/jpeg';
      const resp = await publicFetch('https://api.deepseek.com/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'deepseek-flash',
          max_tokens: 1024,
          reasoning_effort: 'low',
          messages: [{
            role: 'user',
            content: [
              { type: 'text', text: VISION_PROMPT(index) },
              { type: 'image_url', image_url: { url: 'data:' + mediaType + ';base64,' + b64 } },
            ],
          }],
        }),
        timeoutMs: 60000,
      });
      // publicFetch 返回的是 { status, body, ... } 这种普通对象，不是标准 Response，
      // 所以不能 await resp.text()（之前就是这么崩的：resp.text is not a function）。
      const text = typeof resp.body === 'string' ? resp.body : String(resp.body === undefined ? '' : resp.body);
      if (resp.status !== undefined && Number(resp.status) !== 200) {
        console.log(TAG + ' 直连识图 HTTP ' + String(resp.status) + '：' + text.replace(/\s+/g, ' ').slice(0, 120));
        return '';
      }
      let json;
      try { json = JSON.parse(text); } catch { return ''; }
      if (json.error) {
        console.log(TAG + ' 直连识图报错：' + JSON.stringify(json.error).slice(0, 140));
        return '';
      }
      const content = json.choices && json.choices[0] && json.choices[0].message
        ? json.choices[0].message.content : '';
      const out = typeof content === 'string' ? content.trim() : '';
      if (out !== '') console.log(TAG + ' 直连识图成功（' + out.length + ' 字）');
      return out;
    } catch (error) {
      console.log(TAG + ' 直连识图失败：' + describeError(error));
      return '';
    }
  }


  return { describeImages, downloadImage, askVision, askVisionDirect };
}
