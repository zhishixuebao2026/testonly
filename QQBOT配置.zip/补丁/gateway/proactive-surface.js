// 主动发言的表面层：配置读取、排程、群级状态与一次 tick 的编排。
// 从 gateway/plugin.js 搬出（P3 2.4 第二阶段，只搬不改）：判定与提示词构建仍在
// session/proactive.js；这里只负责「什么时候看、看哪个群、看完怎么发」。
import {
  nowMinutes as proactiveNowMinutes, isQuiet as proactiveIsQuiet, normalizeMessages as proactiveNormalizeMessages,
  newerThan as proactiveNewerThan, buildDigest as proactiveBuildDigest, buildPrompt as proactiveBuildPrompt,
  parseDecision as proactiveParseDecision, validateMessage as proactiveValidateMessage, allowSend as proactiveAllowSend,
  analyzeEvent as proactiveAnalyzeEvent, topicKey as proactiveTopicKey, topicRepeated as proactiveTopicRepeated,
  resolveStageModels as proactiveResolveStageModels, buildSpeakPrompt as proactiveBuildSpeakPrompt,
  runSpeakStage as proactiveRunSpeakStage, resolvePersonaText as proactiveResolvePersonaText,
} from '../session/proactive.js';

export function createProactiveSurface(deps) {
  // 已识别过的图片：消息 id → 描述。定时发言每轮都会重看窗口里的消息，
  // 不缓存就会把同一张图反复送去识别（浪费额度，摘要里也重复）。
  const imageDescCache = new Map();
  const { TAG, getConfig, getState, ctx, describeError, callAdapterAction, getSessionApi, writeToAdapter, getHostPersona, sendStickerWithText, stickerAvailable, describeImageUrls, runSessionTurn } = deps;
  // 依赖名对不上时（历史上就写错过一次：调用方传了 sessionApi），别等到 15 分钟后第一次主动发言
  // 才在日志里冒一句「is not a function」——启动时就说清楚，功能会降级但不影响收发消息。
  if (typeof getSessionApi !== 'function') {
    console.error(TAG + ' 主动发言缺 getSessionApi 依赖：取不到会话模型，会退回用判断模型的正文发言');
  }
  // 只在「开关打开 + 显式列群 + 不在免打扰 + 新消息够多 + 频率没超」时才让模型看一次；
  // 要不要接、接什么话题全由模型判断，插话内容再过一遍长度/链接/@/重复校验。
  function proactiveConfig() {
    const p = getConfig().proactive;
    return (p === null || p === undefined) ? {} : p;
  }

  function proactiveGroupList() {
    const p = proactiveConfig();
    const list = Array.isArray(p.groups) ? p.groups : [];
    const out = [];
    for (const item of list) {
      const id = String(item === undefined || item === null ? '' : item).trim();
      if (id !== '' && out.indexOf(id) < 0) out.push(id);
    }
    return out;
  }

  function stopProactive() {
    if (getState().proactive.timer !== null) {
      try { getState().proactive.timer(); } catch (error) { /* 已经触发过 */ }
      getState().proactive.timer = null;
    }
  }

  function scheduleProactive() {
    stopProactive();
    // 配置可能刚被改过（热更新会重跑这里），缺项告警重新判断，不要因为旧的 warned 而哑掉。
    getState().proactive.warned = '';
    const p = proactiveConfig();
    if (p.enabled !== true) { getState().proactive.banner = ''; return; }
    const groups = proactiveGroupList();
    if (groups.length === 0) {
      console.log(TAG + ' 主动发言已开启但没配置群号（proactive.groups），跳过');
      return;
    }
    const minutes = Math.max(5, Number(p.intervalMinutes) > 0 ? Number(p.intervalMinutes) : 60);
    const base = minutes * 60000;
    const loop = async () => {
      try { await runProactiveTick(); }
      catch (error) { console.log(TAG + ' 主动发言检查失败（忽略）：' + describeError(error)); }
      // 这一轮 tick 可能在 await 期间跨过了插件卸载/重挂：那时 ctx.timeout 会抛
      // "cannot get required service in inactive context"，而 timer 回调丢弃返回值，
      // 抛出来就是 unhandled rejection —— Node 24 默认直接 exit 1，整个宿主陪葬。
      if (getState().stopping === true) return;
      const jitter = Math.floor(base * 0.2 * Math.random());
      try { getState().proactive.timer = ctx.timeout(loop, base + jitter); }
      catch (error) { console.log(TAG + ' 主动发言不再排下一轮（插件已卸载）：' + describeError(error)); }
    };
    getState().proactive.timer = ctx.timeout(loop, Math.floor(base * 0.5));
    const stage = proactiveResolveStageModels(p, null);
    const label = (s) => (s.provider !== '' && s.model !== '') ? (s.provider + '/' + s.model) : '群会话模型';
    const source = stage.judge;
    const sourceLabel = (source.provider !== '' && source.model !== '')
      ? ('指定模型 ' + source.provider + '/' + source.model)
      : '跟随群会话模型';
    const stageLabel = stage.twoStage === true
      ? ('，两段式（判断 ' + label(stage.judge) + ' / 发言 ' + label(stage.speak) + '）')
      : '';
    // 任何 volatile 字段改动都会重跑这里，横幅只在内容真的变了时才打，避免刷屏。
    const banner = '每 ' + minutes + ' 分钟看一次，群=' + groups.join(',')
      + '，首次检查约 ' + Math.round(minutes / 2) + ' 分钟后，模型来源=' + sourceLabel + stageLabel;
    if (banner !== getState().proactive.banner) {
      getState().proactive.banner = banner;
      console.log(TAG + ' 主动发言已开启：' + banner);
    }
  }

  function proactiveGroupState(groupId) {
    let s = getState().proactive.groups.get(groupId);
    if (s === undefined) {
      s = { lastSeenTime: 0, lastSentAt: 0, lastSentText: '', sentTimes: [], lastDecision: '', topics: [], sentTexts: [] };
      getState().proactive.groups.set(groupId, s);
    }
    return s;
  }

  async function runProactiveTick() {
    const p = proactiveConfig();
    if (p.enabled !== true) return;
    if (getState().connected !== true) return;
    if (proactiveIsQuiet(proactiveNowMinutes(new Date()), p.quietHours)) return;
    // 群与群之间错开几秒：魔塔免费档有每分钟的频率上限，
    // 一轮里连着打 6 个群很容易触发 429（实测：单发探测 200，扎堆就 429）。
    const staggerMs = Math.max(0, Math.floor(Number(p.groupStaggerMs) || 4000));
    let first = true;
    for (const groupId of proactiveGroupList()) {
      if (!first && staggerMs > 0) {
        await new Promise((resolve) => {
          try { ctx.timeout(() => resolve(), staggerMs); } catch { resolve(); }
        });
      }
      first = false;
      try { await proactiveConsiderGroup(groupId, p); }
      catch (error) { console.log(TAG + ' 主动发言（群 ' + groupId + '）失败（忽略）：' + describeError(error)); }
    }
  }

  async function proactiveSelfId() {
    if (getState().proactive.selfId !== null) return getState().proactive.selfId;
    try {
      const info = await callAdapterAction('get_login_info', {}, 8000);
      if (info.ok === true && info.data !== null && info.data !== undefined && info.data.user_id !== undefined) {
        getState().proactive.selfId = String(info.data.user_id);
      }
    } catch (error) { /* 取不到就按未知处理 */ }
    return getState().proactive.selfId;
  }

  // 配置不全时只告警一次，避免每轮刷屏；改完配置重启会重新判断。
  function warnProactiveIncomplete(missing) {
    const signature = missing.join('|');
    if (getState().proactive.warned === signature) return;
    getState().proactive.warned = signature;
    console.log(TAG + ' 主动发言不会真的发言：缺少 ' + missing.join('、')
      + '。可在插件设置「能力 → 对话与人格 → 主动发言」里用下拉选一个 provider/模型，留空则跟随群会话模型。');
  }

  /**
   * 取「这个群当前用的模型」：已有会话直接用；还没有会话就按全局 preset 建同一条会话
   * （主动发言要发话时本来也会用到它，所以不算额外开销）。
   * 这样即使刚重启、群里还没人说话，也能跟随会话模型而不是直接失败。
   */
  /** 一个会话条目对应的模型选项（没装模型路由时返回 null）。 */
  const optionsOfEntry = (entry) => (entry !== null && entry !== undefined && entry.agent !== null && entry.agent !== undefined
    && entry.agent.options !== null && entry.agent.options !== undefined) ? entry.agent.options : null;

  /**
   * 该群在 groupModels 里钉死的模型。
   *
   * 为什么不能只靠 optionsOfEntry：会话钉模型走的是 `selectForNextRequest`
   * （只管下一次请求），`agent.options` 里仍然是**全局默认**。于是主动发言的
   * 判断请求会跑到全局默认模型上（曾经因此跑到 Ling-2.6-1T 上连着空返回）。
   * 这里直接把配置里的钉死值拿出来用，优先于会话选项。
   */
  const pinnedModelFor = (groupId) => {
    const per = getConfig().groupModels;
    if (per === null || per === undefined || typeof per !== 'object') return null;
    const bare = String(groupId);
    const hit = per['group-' + bare] !== undefined ? per['group-' + bare]
      : (per[bare] !== undefined ? per[bare] : null);
    if (hit === null || hit === undefined || typeof hit !== 'object') return null;
    const provider = String(hit.provider || '').trim();
    const model = String(hit.model || '').trim();
    if (provider === '' || model === '') return null;
    return { provider, model };
  };

  /**
   * 取该群对应的**会话条目**（不只是模型选项）：人格求值也要用它里面的 agent，
   * 这样 soul-md 才能按「会话指定 → 工作区 → 默认卡」挑对人设。
   */
  async function proactiveEntry(groupId) {
    const scopeKey = 'group-' + String(groupId);
    // 1) 非分流配置下的主会话；2) 分流配置下 owner / guest 两条
    const candidates = [getState().convos.get(scopeKey), getState().convos.get(scopeKey + '@owner'), getState().convos.get(scopeKey + '@guest')];
    for (const entry of candidates) {
      if (optionsOfEntry(entry) !== null) return entry;
    }
    // 3) 冷启动：按和收消息时一样的入口建（不分流时就是这样）
    // 分流模式下会话键是 group-x@owner / group-x@guest，这里判断不了该算哪一档，
    // 硬建只会留下一条收消息时永远用不到的孤儿会话——直接放弃，交给告警提示去指定模型。
    const split = String(getConfig().auth.ownerPreset || '').trim() !== '' || String(getConfig().auth.guestPreset || '').trim() !== '';
    if (split) return null;
    try {
      const entryKey = getConfig().perChatSession ? scopeKey : 'shared';
      const sessionId = getConfig().perChatSession ? 'qqbot-' + scopeKey : 'qqbot-shared';
      const fixedTitle = (getConfig().session !== null && getConfig().session !== undefined && getConfig().session.fixedName === true)
        ? '群聊_' + String(groupId) : null;
      return await getSessionApi().getEntry(entryKey, sessionId, getConfig().agentPreset, fixedTitle);
    } catch (error) {
      console.log(TAG + ' 主动发言：取会话模型失败（' + describeError(error) + '）');
      return null;
    }
  }


  async function proactiveCallModel(source, prompt, p, temperature) {
    if (source.missing.length > 0) { warnProactiveIncomplete(source.missing); return ''; }
    if (p.verbose === true) {
      console.log(TAG + ' 主动发言请求：' + source.provider + '/' + source.model
        + ' prompt=' + prompt.length + ' 字 head=' + JSON.stringify(String(prompt).slice(0, 80)));
    }
    return proactiveLlmModel(source, prompt, p, temperature);
  }

  /** DSH 内置 llm 服务（走已注册 provider，认证由 DSH 负责，不需要 key）。 */
  async function proactiveLlmModel(source, prompt, p, temperature) {
    const llm = ctx.llm;
    if (llm === undefined || llm === null || typeof llm.stream !== 'function') {
      console.log(TAG + ' 主动发言：DSH llm 服务不可用（ctx.llm.stream 缺失），请确认 DSH 的 llm 插件已启用');
      return '';
    }
    const timeout = Math.max(5000, Math.floor(Number(p.timeoutMs) || 60000));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    const messages = [{ role: 'user', content: [{ type: 'text', text: prompt }] }];
    let out = '';
    try {
      const temp = Number.isFinite(temperature) ? temperature : 0.8;
      for await (const chunk of llm.stream({ provider: source.provider, model: source.model, messages, maxTokens: 2048, reasoningEffort: 'low', temperature: temp, signal: controller.signal })) {
        if (chunk && chunk.type === 'text-delta' && typeof chunk.text === 'string') out += chunk.text;
      }
    } catch (error) {
      console.log(TAG + ' 主动发言模型调用失败（' + source.provider + '/' + source.model + '）：' + describeError(error));
      return '';
    } finally {
      clearTimeout(timer);
    }
    if (out.trim() === '') console.log(TAG + ' 主动发言模型空返回（' + source.provider + '/' + source.model + '）');
    return out.trim();
  }

  async function proactiveConsiderGroup(groupId, p) {
    const st = proactiveGroupState(groupId);
    const verbose = p.verbose === true;
    const now = Date.now();
    // 发言额度不再提前挡：以前这里一挡就连历史都不拉、图都不识，
    // 结果「额度用完的群里发了图，它一眼没看」。额度只该决定「发不发」，
    // 不该决定「看不看」。改到真正要发之前再查（见下面 speak 分支）。
    const windowSize = Math.max(5, Math.min(100, Math.floor(Number(p.windowMessages) || 30)));
    const result = await callAdapterAction('get_group_msg_history', { group_id: Number(groupId), count: windowSize }, 8000);
    if (result.ok !== true) { if (verbose) console.log(TAG + ' 主动发言取历史失败（' + groupId + '）'); return; }
    const raw = result.data !== null && result.data !== undefined && Array.isArray(result.data.messages) ? result.data.messages : [];
    const selfId = await proactiveSelfId();
    const messages = proactiveNormalizeMessages(raw, selfId === null ? '' : selfId);
    const fresh = proactiveNewerThan(messages, st.lastSeenTime).filter((m) => m.isSelf !== true);
    for (const m of messages) { if (m.time > st.lastSeenTime) st.lastSeenTime = m.time; }
    const minNew = Math.max(1, Math.floor(Number(p.minNewMessages) || 6));
    // 冷群搭话：群里久没人说话时，允许它自己抛个话头。
    // 规则：新消息不到门槛，但「距最后一条消息」和「距自己上次发言」都超过 coldAfterMinutes。
    // coldAfterMinutes 默认 0 = 关闭；coldGroups 留空 = 所有群都能冷场开口，非空 = 只在这几个群。
    const coldAfterMinutes = Math.max(0, Math.floor(Number(p.coldAfterMinutes) || 0));
    const coldGroups = Array.isArray(p.coldGroups) ? p.coldGroups.map((g) => String(g)) : [];
    const coldAllowed = coldAfterMinutes > 0 && (coldGroups.length === 0 || coldGroups.includes(String(groupId)));
    let coldTalk = false;
    if (fresh.length < minNew) {
      // 冷场只看「别人」说了多久没说话：自己发过的不算群活跃度，
      // 否则它自己往死群里丢一句，就把安静计时清零了。
      const lastHumanTime = messages.reduce((acc, m) => {
        if (m.isSelf === true) return acc;
        return Math.max(acc, Number(m.time) || 0);
      }, 0);
      const silenceMs = lastHumanTime > 0 ? (now - lastHumanTime) : Number.POSITIVE_INFINITY;
      const sinceSentMs = now - (Number(st.lastSentAt) || 0);
      const needMs = coldAfterMinutes * 60000;
      if (coldAllowed && silenceMs >= needMs && sinceSentMs >= needMs) {
        coldTalk = true;
        const silenceText = Number.isFinite(silenceMs)
          ? Math.floor(silenceMs / 60000) + ' 分钟'
          : '一条历史消息都没有';
        console.log(TAG + ' 冷群搭话（' + groupId + '）：群友已安静 ' + silenceText + '，新消息 ' + fresh.length);
      } else {
        if (verbose) console.log(TAG + ' 主动发言跳过（' + groupId + '）：新消息 ' + fresh.length + ' < ' + minNew);
        return;
      }
    }

    // 图片群（推特推送之类）整屏都是图，纯文本摘要只剩「[图片]」，模型等于瞎看。
    // 这里给最新的一两条消息补识图描述（每次最多 2 张，控成本）。
    if (typeof describeImageUrls === 'function') {
      const byId = new Map();
      let rawImageSegs = 0;
      let resolvedImageSegs = 0;
      // 不做时间过滤：窗口里的图就该识。
      // （曾加过「只认 15 分钟内的」，结果冷群和隔一会儿的图全被静默跳过，
      //  定时发言就再也看不到图了。防重复靠下面的 imageDescCache，不需要时间窗。）
      for (const m of raw) {
        if (m === null || typeof m !== 'object' || !Array.isArray(m.message)) continue;
        const urls = [];
        for (const seg of m.message) {
          if (seg === null || typeof seg !== 'object') continue;
          const segType = String(seg.type ?? '').toLowerCase();
          // ① 推送机器人（reX_bot 之类）的图在 markdown 段里
          if (segType === 'markdown') {
            const c = String(seg.data && seg.data.content !== undefined ? seg.data.content : '');
            for (const mm of c.matchAll(/!\[[^\]]*\]\(([^)\s]+)\)/g)) {
              if (/^https?:\/\//.test(mm[1])) urls.push(mm[1]);
            }
            continue;
          }
          if (segType !== 'image') continue;
          rawImageSegs += 1;
          let u = seg.data && typeof seg.data.url === 'string' ? seg.data.url : '';
          // ② 历史里的图片段常常只有 file 没有 url，要问协议端换回来，
          //    否则这里永远是空数组——定时发言就「看图」这一路彻底失效。
          if ((u === '' || !/^https?:\/\//.test(u)) && seg.data && typeof seg.data.file === 'string' && seg.data.file !== '') {
            try {
              const got = await callAdapterAction('get_image', { file: seg.data.file }, 6000);
              const d = (got !== null && got !== undefined && got.ok === true) ? got.data : null;
              if (d !== null && d !== undefined && typeof d.url === 'string' && /^https?:\/\//.test(d.url)) u = d.url;
              else console.log(TAG + ' 定时识图：get_image 没换到 url（file=' + String(seg.data.file).slice(0, 24) + '）');
            } catch (error) {
              u = '';
              console.log(TAG + ' 定时识图：get_image 失败 ' + describeError(error));
            }
          }
          if (/^https?:\/\//.test(u)) { urls.push(u); resolvedImageSegs += 1; }
        }
        if (urls.length > 0) byId.set(Number(m.message_id), urls);
      }
      // 一眼看出到底有没有图、图有没有解析出地址：以前这些全是静默的，
      // 出问题时只知道「没看图」，不知道卡在哪一步。
      console.log(TAG + ' 定时识图检查（群' + groupId + '）：窗口 ' + raw.length + ' 条、新消息 ' + fresh.length
        + ' 条、图片段 ' + rawImageSegs + ' 个、解析出地址 ' + resolvedImageSegs + ' 个');
      let budget = 2;
      for (let i = fresh.length - 1; i >= 0 && budget > 0; i -= 1) {
        const m = fresh[i];
        const urls = byId.get(m.id);
        if (urls === undefined || urls.length === 0) continue;
        // 认过的就别再认：每次 tick 都会重新走一遍窗口里的消息，
        // 不缓存的话同一张图会被反复识别、反复写进摘要（也白花钱）。
        const cached = imageDescCache.get(m.id);
        if (cached !== undefined) {
          m.text = m.text + '（图片内容：' + cached + '）';
          budget -= Math.min(budget, urls.length);
          continue;
        }
        try {
          // 定时扫描必须短超时：9 个群是串行扫的，一个群卡 5 分钟会把后面所有群
          // 拖到下一轮去（实测：群群G_2843***58 一张图卡到 04:03，月之森的图整轮没轮到）。
          // 60 秒没结果就跳过这张，宁可这次不看，也不能堵住整条扫描链。
          const desc = await Promise.race([
            describeImageUrls(urls.slice(0, budget), groupId),
            new Promise((resolve) => {
              const timer = setTimeout(() => resolve(null), 60000);
              if (typeof timer.unref === 'function') timer.unref();
            }),
          ]);
          if (desc === null) {
            console.log(TAG + ' 定时识图超时（群' + groupId + '，60 秒）→ 跳过这张，继续下一个群');
            continue;
          }
          if (typeof desc === 'string' && desc.trim() !== '') {
            const short = desc.trim().replace(/\s+/g, ' ').slice(0, 300);
            m.text = m.text + '（图片内容：' + short + '）';
            imageDescCache.set(m.id, short);
            budget -= Math.min(budget, urls.length);
          }
        } catch (error) {
          console.log(TAG + ' 主动发言识图失败（跳过这张）：' + describeError(error));
        }
      }
      // 缓存只留最近 300 条，别无限长。
      if (imageDescCache.size > 300) {
        const keys = [...imageDescCache.keys()].slice(0, imageDescCache.size - 300);
        for (const k of keys) imageDescCache.delete(k);
      }
    }
    // 事件闸（可关）：过气的、只是应答一句的、自己刚说过的，都不接——避免对同一件事重复回复。
    // 冷群搭话时跳过这道闸：那本来就是「没在聊具体事」，闸一定判过气。
    const eventGuard = p.eventGuard !== false;
    let event = { ok: true, reason: '', ageMinutes: 0, eventTime: 0 };
    if (eventGuard === true && coldTalk !== true) {
      event = proactiveAnalyzeEvent(messages, { nowSec: Math.floor(Date.now() / 1000), staleMinutes: p.staleMinutes });
      if (event.ok !== true) { if (verbose) console.log(TAG + ' 主动发言跳过（' + groupId + '）：' + event.reason); return; }
    }
    // 模型来源由 proactiveCallModel 内部统一判断（留空就跟随群会话模型，不需要 key）。
    const personaText = String(p.persona === undefined || p.persona === null ? '' : p.persona).trim();
    const basePersona = getConfig().persona !== null && getConfig().persona !== undefined && String(getConfig().persona.text || '').trim() !== ''
      ? (String(getConfig().persona.name || '').trim() !== '' ? String(getConfig().persona.name).trim() + '：' : '') + String(getConfig().persona.text).trim()
      : '';
    // 人格优先级：手填的主动发言人设 → 宿主求值的 soul 人格段（dsh-soul-md）→ 插件自己的 persona（原有回退）。
    // 会话条目只取一次：既用来算模型选项，也把 agent 交给宿主做人格求值。
    const entry = await proactiveEntry(groupId);
    let hostPersona = '';
    if (personaText === '' && typeof getHostPersona === 'function') {
      try {
        hostPersona = String(await getHostPersona(entry === null || entry === undefined ? null : entry.agent)).trim();
      } catch (error) {
        hostPersona = '';
      }
    }
    const persona = proactiveResolvePersonaText({ explicit: personaText, host: hostPersona, fallback: basePersona });
    // 图库可用时才让模型给表情包关键词（否则纯文本路径不浪费 token）
    const wantsSticker = typeof stickerAvailable === 'function' && stickerAvailable() === true && typeof sendStickerWithText === 'function';
    // 冷群搭话：在摘要前加一句说明，让模型知道「不是有人说话，是群里冷着」。
    const digestText = proactiveBuildDigest(fresh, Math.min(40, windowSize));
    const coldDigest = coldTalk === true
      ? '（这个群已经很久没人说话了，下面是很久以前的消息。你可以随手抛一句轻松的话把场子热起来，也可以什么都不说。不要总结上面的内容。'
        + '特别注意：不要拿「邦邦/MyGO/说唱/战力定级」这类你自己的兴趣当话头——这个群本来就没在聊这些，硬抛会显得莫名其妙。'
        + '要开口就说跟这个群本身有关、或者谁都能接的闲话。）\n\n' + digestText
      : digestText;
    const prompt = proactiveBuildPrompt({
      persona,
      sticker: wantsSticker,
      // 冷场时不给兴趣清单：否则模型会从兴趣里硬挑一个话题（真出过：在无关的群里突然聊喵睦）。
      interests: coldTalk === true ? [] : p.interests,
      digest: coldDigest,
      maxChars: p.maxChars,
      // 把事件年龄与「别重复」的要求交给模型，配合上面的确定性事件闸一起用。
      eventAgeMinutes: event.ageMinutes,
      recentTopics: st.topics.map((item) => item.key).filter((key) => String(key).length > 0).slice(-3),
    });
    // 判断/发言可以各用各的模型；speakModel 没配时就是单段模式，行为与之前完全一致。
    // 群在 groupModels 里钉死的模型优先于会话选项（会话选项可能是全局默认）。
    const stageModels = proactiveResolveStageModels(p, pinnedModelFor(groupId) || optionsOfEntry(entry));
    // 两段式缺项在这里就拦住：等判断那次调用花完钱才发现配置填错没有意义。
    if (stageModels.twoStage === true && stageModels.speak.missing.length > 0) { warnProactiveIncomplete(stageModels.speak.missing); return; }
    let answer = '';
    let decision = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      answer = await proactiveCallModel(stageModels.judge, prompt, p, 0.8);
      decision = answer === '' ? null : proactiveParseDecision(answer);
      if (decision !== null) break;
      if (verbose) console.log(TAG + ' 主动发言：第 ' + String(attempt + 1) + ' 次无有效决策' + (answer === '' ? '' : '（原文：' + answer.slice(0, 120) + '）'));
      await new Promise((resolve) => setTimeout(resolve, 800));
    }
    if (decision === null) { if (verbose) console.log(TAG + ' 主动发言：放弃本轮'); return; }
    st.lastDecision = decision.topic + (decision.why === '' ? '' : '｜' + decision.why);
    if (decision.speak !== true) { if (verbose) console.log(TAG + ' 主动发言（' + groupId + '）：决定不接话｜' + st.lastDecision); return; }
    // 决定要说话了，这时才查额度：额度只限制「发多少」，不限制「看不看图」。
    const gate = proactiveAllowSend({ now, sentTimes: st.sentTimes, lastSentAt: st.lastSentAt, maxPerHour: p.maxPerHour, maxPerDay: p.maxPerDay, minGapMinutes: p.minGapMinutes });
    if (gate.ok !== true) {
      console.log(TAG + ' 主动发言跳过（' + groupId + '）：' + gate.reason + '（图已看过，只是没发）');
      return;
    }
    const maxChars = Math.max(20, Math.floor(Number(p.maxChars) || 120));
    const recentTexts = (Array.isArray(st.sentTexts) && st.sentTexts.length > 0 ? st.sentTexts : [st.lastSentText]);
    // 单段模式也过同一道兜底：开关默认关，透传不改变任何现有部署的行为。
    let verdict = proactiveValidateMessage(decision.message, { maxChars, recentTexts, requireCjk: p.requireCjk === true });
    // 两段式（可选）：判断只出 JSON，正文交给发言模型写；写不出来时才回退到判断模型给的那句。
    if (stageModels.twoStage === true) {
      const speakPrompt = proactiveBuildSpeakPrompt({
        persona,
        digest: coldDigest,
        topic: decision.topic,
        maxChars,
      });
      const stage = await proactiveRunSpeakStage({
        call: () => proactiveCallModel(stageModels.speak, speakPrompt, p, 0.9),
        // requireCjk 是发送前兜底（默认关）：无 CJK 且长度 > 12 判不可用，专治模型掉回英文拒答模板。
        validate: (raw) => proactiveValidateMessage(raw, { maxChars, recentTexts, requireCjk: p.requireCjk === true }),
        attempts: 2,
        // 判断阶段的 message 在这里只为回退保留：精简 judge 提示词时不能把它删掉，否则回退会静默失效。
        fallback: { enabled: p.speakFallback !== false, ok: verdict.ok === true, text: verdict.text },
        onBlocked: (index, checked) => { if (verbose) console.log(TAG + ' 主动发言：发言阶段第 ' + String(index + 1) + ' 次被拦（' + checked.reason + '）'); },
        onFallback: () => { if (verbose) console.log(TAG + ' 主动发言：发言阶段没有产出，回退用判断模型给的正文'); },
      });
      if (stage.text === '') {
        if (verbose) {
          const why = (p.speakFallback !== false && verdict.ok !== true) ? '（判断正文本身不可用：' + verdict.reason + '，无处可退）' : '';
          console.log(TAG + ' 主动发言（' + groupId + '）：两段式没有可发的正文' + why);
        }
        return;
      }
      verdict = { ok: true, reason: '', text: stage.text };
    }
    if (verdict.ok !== true) { if (verbose) console.log(TAG + ' 主动发言（' + groupId + '）：内容被拦（' + verdict.reason + '）'); return; }
    // 话题闸：冷却时间内说过同一件事（哪怕换了说法）就不再重复。
    const topicKey = proactiveTopicKey(decision.topic !== '' ? decision.topic : verdict.text);
    if (eventGuard === true && proactiveTopicRepeated(topicKey, st.topics, { now: Date.now(), cooldownMinutes: p.topicCooldownMinutes }) === true) {
      console.log(TAG + ' 主动发言跳过（' + groupId + '）：话题「' + topicKey + '」在冷却时间内已经说过');
      return;
    }
    if (p.dryRun === true) {
      const stickerNote = wantsSticker === true && decision.sticker !== '' ? '（本想配表情包关键词「' + decision.sticker + '」）' : '';
      console.log(TAG + ' 主动发言（演练，不发送）→ 群 ' + groupId + '：' + verdict.text + stickerNote);
      return;
    }
    // 会话模式：走真实回合，于是有工具（资料库/搜索）、有记忆、DSH 里也看得到。
    // 正文由模型自己在会话里写并发出去；它不想说就什么都不输出（空回复不会发）。
    if (p.useSession === true && typeof runSessionTurn === 'function') {
      const instruction = [
        '（这不是群友说的话，是定时提醒：这个群安静了一阵，或者刚聊到了你感兴趣的东西。你可以主动开口，也可以不说。）',
        decision.topic !== '' ? '引发这个念头的话题：' + decision.topic : '',
        verdict.ok === true && verdict.text !== '' ? '你原本想到的一句大概是：' + verdict.text : '',
        '要说话就直接用你自己的口吻说一到两句，' + maxChars + ' 字以内；不要解释、不要加引号、不要提"定时""提醒""我来活跃一下"这类字眼。',
        '需要查资料（BanG Dream 设定、说唱资料、战力体系等）就先用工具查，别凭印象编。',
        '不想说就什么内容都不要输出——空着不算失礼。',
      ].filter((line) => line !== '').join('\n');
      console.log(TAG + ' 主动发言（会话模式）→ 群 ' + groupId + '：' + verdict.text);
      const ok = await runSessionTurn(groupId, instruction);
      if (ok !== true) console.log(TAG + ' 主动发言（' + groupId + '）：会话回合没跑成');
      return;
    }
    // 文字 + 表情包：挑了图就让插件侧决定「合并一条」还是「先图后字」；挑不到图就只发文字。
    let sent = null;
    const stickerQuery = wantsSticker === true && typeof decision.sticker === 'string' ? decision.sticker : '';
    if (stickerQuery !== '') {
      let withSticker = false;
      try {
        withSticker = (await sendStickerWithText({ groupId, query: stickerQuery, text: verdict.text })) === true;
      } catch (error) {
        withSticker = false;
        if (verbose) console.log(TAG + ' 主动发言（' + groupId + '）：发表情包失败，退回纯文字（' + describeError(error) + '）');
      }
      if (withSticker === true) sent = true;
      else if (verbose) console.log(TAG + ' 主动发言（' + groupId + '）：没挑到合适表情包，只发文字');
    }
    if (sent !== true) sent = writeToAdapter({ type: 'send', message_type: 'group', target_id: groupId, text: verdict.text });
    if (sent !== true) { if (verbose) console.log(TAG + ' 主动发言（' + groupId + '）：适配器不可用'); return; }
    const sentAt = Date.now();
    st.lastSentAt = sentAt;
    st.lastSentText = verdict.text;
    st.sentTexts = (Array.isArray(st.sentTexts) ? st.sentTexts : []).concat([verdict.text]).slice(-5);
    st.topics = (Array.isArray(st.topics) ? st.topics : []).concat([{ at: sentAt, key: topicKey }]).slice(-20);
    st.sentTimes.push(sentAt);
    st.sentTimes = st.sentTimes.filter((t) => sentAt - t < 86400000);
    console.log(TAG + ' 主动发言 → 群 ' + groupId + (decision.topic === '' ? '' : '（' + decision.topic + '）') + '：' + verdict.text);
  }

  /**
   * 记录「刚在某个群说过话」——不管是定时发言还是被 @ 后的正常回复。
   * 不记的话，定时扫描不知道你刚聊过，几分钟后又会自己插一句。
   */
  function noteAssistantSend(groupId, text) {
    if (groupId === undefined || groupId === null || String(groupId) === '') return;
    const st = proactiveGroupState(String(groupId));
    st.lastSentAt = Date.now();
    if (typeof text === 'string' && text.trim() !== '') {
      st.lastSentText = text.trim().slice(0, 200);
      if (Array.isArray(st.sentTexts)) {
        st.sentTexts.push(text.trim().slice(0, 200));
        if (st.sentTexts.length > 20) st.sentTexts.shift();
      }
    }
  }

  return { scheduleProactive, stopProactive, noteAssistantSend };
}
